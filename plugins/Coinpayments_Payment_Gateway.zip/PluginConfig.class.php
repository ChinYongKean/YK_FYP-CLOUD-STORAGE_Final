<?php

namespace Plugins\Coinpayments;

use App\Services\PluginConfig AS CorePluginConfig;

class PluginConfig extends CorePluginConfig
{
    /**
     * Setup the plugin config.
     *
     * @var array
     */
    public $config = array(
        'plugin_name' => 'Coinpayments Payment Integration',
        'folder_name' => 'coinpayments',
        'plugin_description' => 'Accept payments using Coinpayments.',
        'plugin_version' => '8.0',
        'required_script_version' => '5.0',
    );

}
