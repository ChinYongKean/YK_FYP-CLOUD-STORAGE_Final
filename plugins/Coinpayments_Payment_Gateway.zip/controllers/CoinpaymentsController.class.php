<?php

namespace Plugins\Coinpayments\Controllers;

use App\Core\BaseController;
use App\Models\File;
use App\Models\Order;
use App\Models\PaymentLog;
use App\Models\User;
use App\Helpers\CoreHelper;
use App\Helpers\LogHelper;
use App\Helpers\OrderHelper;
use App\Helpers\PluginHelper;
use App\Helpers\UserHelper;

class CoinpaymentsController extends BaseController
{

    public function upgradeBox($params = array()) {
        // pickup request for later
        $request = $this->getRequest();

        // load template
        return $this->render('upgrade_box.html', array_merge($params, array(
                    'folder_name' => 'coinpayments',
                    'gateway_label' => 'Coinpayments',
                    'i' => $request->query->has('i') ? $request->query->get('i') : '',
                    'f' => $request->query->has('f') ? $request->query->get('f') : '',
                        )), PLUGIN_DIRECTORY_ROOT . 'coinpayments/views');
    }

    public function pay($params = array()) {
        // pickup request for later
        $request = $this->getRequest();

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('coinpayments');
        $pluginSettings = $pluginConfig['data']['plugin_settings'];
        $merchant_id = '';
        if (strlen($pluginSettings)) {
            $pluginSettingsArr = json_decode($pluginSettings, true);
            $merchant_id = $pluginSettingsArr['merchant_id'];
        }

        if (!$request->request->has('user_level_pricing_id')) {
            return $this->redirect(WEB_ROOT);
        }

        // require login
        if ($request->request->has('i') && strlen($request->request->get('i'))) {
            $user = User::loadOneByClause('identifier = :identifier', array(
                        'identifier' => $request->request->get('i')
            ));
            if (!$user) {
                return $this->redirect(CoreHelper::getCoreSitePath() . "/error?e=" . urlencode('Could not load user based on identifier, please contact support.'));
            }

            // setup variables for later
            $userId = $user->id;
            $username = $user->username;
            $userEmail = $user->email;
        }
        else {
            if (($response = $this->requireLogin('/register', 1)) !== false) {
                return $response;
            }

            // setup variables for later
            $Auth = $this->getAuth();
            $userId = $Auth->id;
            $username = $Auth->username;
            $userEmail = $Auth->email;
        }

        $userLevelPricingId = (int) $request->request->get('user_level_pricing_id');

        // check if we have a referring file
        $fileId = null;
        if ($request->request->has('f') && strlen($request->request->get('f'))) {
            $file = File::loadOneByShortUrl($request->request->get('f'));
            if ($file) {
                $fileId = $file->id;
            }
        }

        // create order entry
        $order = OrderHelper::createByPackageId($userId, $userLevelPricingId, $fileId);
        if ($order) {
            // redirect to the payment gateway
            $coinpaymentsUrl = 'https://www.coinpayments.net/index.php?cmd=_pay&reset=1&want_shipping=0&merchant=' . urlencode($merchant_id) . '&currency=' . SITE_CONFIG_COST_CURRENCY_CODE . '&amountf=' . urlencode($order->amount) . '&item_name=' . urlencode($order->description) . '&ipn_url=' . urlencode(WEB_ROOT . '/' . $pluginConfig['data']['folder_name'] . '/payment_ipn') . '&success_url=' . urlencode(WEB_ROOT . '/payment_complete') . '&cancel_url=' . urlencode(WEB_ROOT . '/upgrade') . '&custom=' . $order->payment_hash;

            return $this->redirect($coinpaymentsUrl);
        }

        // fallback
        return $this->redirect(CoreHelper::getCoreSitePath() . "/error?e=" . urlencode('Failed creating order, please try again later.'));
    }

    public function paymentIpn($params = array()) {
        // pickup request for later
        $request = $this->getRequest();

        // log response
        LogHelper::setContext('coinpayments');
        LogHelper::info('Received called back on IPN: ' . print_r($_REQUEST, true));

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('coinpayments');
        $pluginSettings = $pluginConfig['data']['plugin_settings'];
        $merchant_id = '';
        if (strlen($pluginSettings)) {
            $pluginSettingsArr = json_decode($pluginSettings, true);
            $merchant_id = trim($pluginSettingsArr['merchant_id']);
            $ipn_key = trim($pluginSettingsArr['ipn_key']);
        }

        // check for some required variables in the request
        if (!$request->request->has('status') || !$request->request->has('merchant')) {
            LogHelper::error('Failed to find merchant or status.');
            LogHelper::breakInLogFile();

            return $this->renderEmpty200Response();
        }

        // pickup variables
        $status = intval($request->request->get('status'));

        // validate using ipn secret key
        if (strlen($ipn_key)) {
            // logs
            LogHelper::info('Validating HMAC using IPN Key...');
            
            if (!isset($_SERVER['HTTP_HMAC']) || empty($_SERVER['HTTP_HMAC'])) {
                LogHelper::error('No HMAC signature sent.');
                LogHelper::breakInLogFile();
                
                return $this->renderEmpty200Response();
            }

            // check for hash_hmac function
            if (!function_exists('hash_hmac')) {
                LogHelper::error('hash_hmac() function not available in PHP. Needed for validating ipn secret key.');
                LogHelper::breakInLogFile();
                
                return $this->renderEmpty200Response();
            }

            // get request
            $requestAlt = file_get_contents('php://input');
            if ($requestAlt === FALSE || empty($requestAlt)) {
                LogHelper::error('Error reading POST data.');
                LogHelper::breakInLogFile();
                
                return $this->renderEmpty200Response();
            }

            // validate against secret key
            $hmac = hash_hmac("sha512", $requestAlt, $ipn_key);
            if ($hmac != $_SERVER['HTTP_HMAC']) {
                LogHelper::error('HMAC signature does not match.');
                LogHelper::breakInLogFile();
                
                return $this->renderEmpty200Response();
            }
            
            // logs
            LogHelper::info('Passed HMAC Validation.');
        }
        
        // logs
        LogHelper::info('Checking payment status and merchant details...');

        // make sure payment has completed and it's for the correct Coinpayments account
        if (($status >= 100 || $status == 2) && ($request->request->get('merchant') == $merchant_id)) {
            // load order using custom payment tracker hash
            $paymentTracker = $request->request->get('custom');

            // log
            LogHelper::info('Payment is complete, loading based on order tracker "' . $paymentTracker . '"');

            // load order
            $order = OrderHelper::loadByPaymentTracker($paymentTracker);
            if ($order) {
                // log
                LogHelper::info('Loaded order id "' . $order->id . '"');

                // retain all posted gateway parameters
                $gatewayVars = "";
                foreach ($_REQUEST AS $k => $v) {
                    $gatewayVars .= $k . " => " . $v . "\n";
                }

                // insert payment log
                $paymentLog = PaymentLog::create();
                $paymentLog->user_id = $order->user_id;
                $paymentLog->date_created = date("Y-m-d H:i:s", time());
                $paymentLog->amount = $request->request->get('amount1');
                $paymentLog->currency_code = $request->request->get('currency1');
                $paymentLog->from_email = 'CoinPayments';
                $paymentLog->to_email = $_REQUEST['merchant'];
                $paymentLog->description = $order->description;
                $paymentLog->request_log = $gatewayVars;
                $paymentLog->payment_method = 'Coinpayments';
                $paymentLog->save();

                // make sure the amount paid matched what we expect
                if ($request->request->get('amount1') != $order->amount) {
                    // order amounts did not match
                    LogHelper::info('Failed - order amounts did not match');

                    return $this->renderEmpty200Response();
                }

                // make sure the order is pending
                if ($order->order_status == 'completed') {
                    // order has already been completed
                    LogHelper::info('Failed - order has already been completed');

                    return $this->renderEmpty200Response();
                }

                // update order status to paid
                $order->order_status = 'completed';
                if ($order->save() === false) {
                    // failed to update order
                    LogHelper::info('Failed - failed to update order');

                    return $this->renderEmpty200Response();
                }

                // log
                LogHelper::info('Updated order, extending account.');

                // extend/upgrade user
                $rs = UserHelper::upgradeUserByPackageId($order->user_id, $order);
                if ($rs === false) {
                    // failed to update user
                    LogHelper::info('Failed - failed to update user');

                    return $this->renderEmpty200Response();
                }

                // log
                LogHelper::info('Account upgrade process complete.');

                // append any plugin includes
                PluginHelper::callHook('postUpgradePaymentIpn', array(
                    'order' => $order,
                ));
            }
        }
        else {
            // log
            LogHelper::warning('Invalid merchant ID or status does not equal 2 or greater than 100.');
        }

        return $this->renderEmpty200Response();
    }

}
