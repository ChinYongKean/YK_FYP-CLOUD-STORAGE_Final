CREATE TABLE IF NOT EXISTS `plugin_vouchers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher` varchar(100) COLLATE utf8_bin NOT NULL,
  `user_level_pricing_id` int(11) NOT NULL,
  `purchase_date` datetime NOT NULL,
  `purchase_price` decimal(10,2) NOT NULL,
  `purchase_user_id` int(11) NOT NULL,
  `purchase_source` enum('user','admin','api') COLLATE utf8_bin NOT NULL DEFAULT 'user',
  `status` enum('available','used','cancelled','expired') COLLATE utf8_bin NOT NULL DEFAULT 'available',
  `used_date` datetime DEFAULT NULL,
  `used_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `voucher` (`voucher`),
  KEY `user_level_pricing_id` (`user_level_pricing_id`),
  KEY `purchase_user_id` (`purchase_user_id`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE IF NOT EXISTS `plugin_vouchers_discount_range` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_amount` int(11) NOT NULL DEFAULT '0',
  `to_amount` int(11) NOT NULL DEFAULT '0',
  `discount_percentage` decimal(4,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=6 ;

TRUNCATE `plugin_vouchers_discount_range`;
INSERT INTO `plugin_vouchers_discount_range` (`id`, `from_amount`, `to_amount`, `discount_percentage`) VALUES
(4, 100, 299, 30.00),
(5, 300, 1000, 50.00),
(3, 1, 99, 10.00);

CREATE TABLE IF NOT EXISTS `plugin_vouchers_reseller` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `is_reseller` int(11) NOT NULL DEFAULT '0',
  `balance_available` decimal(10,2) DEFAULT NULL,
  `last_payment` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE IF NOT EXISTS `plugin_vouchers_reseller_transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reseller_user_id` int(11) NOT NULL,
  `transaction_type` enum('voucher_purchase','voucher_refund','deposit','admin_balance_amendment') COLLATE utf8_bin NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `description` varchar(100) COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE IF NOT EXISTS `plugin_vouchers_topup_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `payment_hash` varchar(32) COLLATE utf8_bin NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `description` varchar(100) COLLATE utf8_bin NOT NULL,
  `order_status` enum('pending','paid','cancelled') COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_hash` (`payment_hash`),
  KEY `user_id` (`user_id`),
  KEY `order_status` (`order_status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin;