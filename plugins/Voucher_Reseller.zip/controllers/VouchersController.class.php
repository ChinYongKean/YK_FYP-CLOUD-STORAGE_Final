<?php

namespace Plugins\Vouchers\Controllers;

use App\Core\BaseController;
use App\Core\Database;
use App\Helpers\CoreHelper;
use App\Helpers\LogHelper;
use App\Helpers\NotificationHelper;
use App\Helpers\PluginHelper;
use App\Helpers\TranslateHelper;
use App\Models\PaymentLog;
use Plugins\Vouchers\Models\PluginVouchersTopupOrder;

class VouchersController extends BaseController
{

    public function resellers() {
        // pickup request
        $folderName = 'vouchers';
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $Auth = $this->getAuth();

        // check if user is already part of the reseller program
        if ($Auth->loggedIn()) {
            $isReseller = (int) $db->getValue('SELECT is_reseller '
                            . 'FROM plugin_vouchers_reseller '
                            . 'WHERE user_id = :user_id '
                            . 'LIMIT 1', array(
                        'user_id' => $Auth->id,
            ));
            if ($isReseller == 1) {
                return $this->redirect(WEB_ROOT . '/reseller_home');
            }
        }

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration($folderName);
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);

        // get discount ranges
        $discountRanges = $db->getRows('SELECT id, from_amount, to_amount, discount_percentage '
                . 'FROM plugin_vouchers_discount_range '
                . 'ORDER BY from_amount ASC');
        $maxDiscount = 0;
        foreach ($discountRanges AS $discountRange) {
            if ($discountRange['discount_percentage'] > $maxDiscount) {
                $maxDiscount = $discountRange['discount_percentage'];
            }
        }

        // load template
        return $this->render('resellers.html', array(
                    'discountRanges' => $discountRanges,
                    'maxDiscount' => $maxDiscount,
                    'minDeposit' => SITE_CONFIG_COST_CURRENCY_SYMBOL . number_format($pluginSettings['reseller_balance_topup_minimum'], 2),
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function resellerHome() {
        // pickup request
        $folderName = 'vouchers';
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $Auth = $this->getAuth();

        // check if user is already part of the reseller program
        if ($Auth->loggedIn()) {
            $resellerData = $db->getRow('SELECT is_reseller, balance_available '
                    . 'FROM plugin_vouchers_reseller '
                    . 'WHERE user_id = :user_id '
                    . 'LIMIT 1', array(
                'user_id' => (int) $Auth->id,
            ));
            if (!$resellerData) {
                return $this->redirect(WEB_ROOT . '/resellers');
            }

            $is_reseller = (int) $resellerData['is_reseller'];
            $balance_available = (float) $resellerData['balance_available'];
            if ($is_reseller == 0) {
                return $this->redirect(WEB_ROOT . '/resellers');
            }
        }
        else {
            return $this->redirect(WEB_ROOT . '/resellers');
        }

        // api key
        $apiKey = $db->getValue('SELECT apikey '
                . 'FROM users '
                . 'WHERE id = :id '
                . 'LIMIT 1', array(
            'id' => $Auth->id,
        ));
        if (empty($apiKey)) {
            // create apikey
            $apiKey = md5(microtime() . (int) $Auth->id . microtime());

            // update in the database
            $db->query('UPDATE users '
                    . 'SET apikey = :apikey '
                    . 'WHERE id = :id '
                    . 'LIMIT 1', array(
                'apikey' => $apiKey,
                'id' => (int) $Auth->id,
            ));
        }

        // load vouchers details
        $pluginObj = PluginHelper::getInstance($folderName);
        $pluginConfig = PluginHelper::pluginSpecificConfiguration($folderName);
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);

        // get discount ranges
        $discountRanges = $db->getRows('SELECT id, from_amount, to_amount, '
                . 'discount_percentage '
                . 'FROM plugin_vouchers_discount_range '
                . 'ORDER BY from_amount ASC');
        $maxDiscount = 0;
        foreach ($discountRanges AS $discountRange) {
            if ($discountRange['discount_percentage'] > $maxDiscount) {
                $maxDiscount = $discountRange['discount_percentage'];
            }
        }

        // pre-load user types
        $availablePackagePricing = $pluginObj->getAccountPackages();

        // load status list
        $statuses = $pluginObj->getStatusList();

        // process actions - delete
        if ((isset($_REQUEST['d'])) && ($pluginSettings['reseller_allow_cancel'] == 1)) {
            if (_CONFIG_DEMO_MODE == true) {
                NotificationHelper::setError(TranslateHelper::t("no_changes_in_demo_mode"));
            }
            else {
                $voucherDetails = $db->getRow('SELECT * '
                        . 'FROM plugin_vouchers '
                        . 'WHERE id = :id '
                        . 'AND status=\'available\' '
                        . 'AND purchase_user_id = :purchase_user_id '
                        . 'LIMIT 1', array(
                    'id' => (int) $_REQUEST['d'],
                    'purchase_user_id' => (int) $Auth->id,
                ));
                if ($voucherDetails) {
                    // cost
                    $purchase_price = $voucherDetails['purchase_price'];

                    // log
                    LogHelper::setContext('plugin_vouchers');
                    LogHelper::info('Deleted voucher after user delete request. ' . print_r($voucherDetails, true));

                    // delete voucher
                    $db->query('DELETE '
                            . 'FROM plugin_vouchers '
                            . 'WHERE id = :id '
                            . 'AND status=\'available\' '
                            . 'AND purchase_user_id = :purchase_user_id '
                            . 'LIMIT 1', array(
                        'id' => (int) $_REQUEST['d'],
                        'purchase_user_id' => (int) $Auth->id,
                    ));

                    // add balance
                    if ($purchase_price > 0) {
                        $userBalance = $db->getValue('SELECT balance_available '
                                . 'FROM plugin_vouchers_reseller '
                                . 'WHERE user_id = :user_id '
                                . 'LIMIT 1', array(
                            'user_id' => (int) $Auth->id,
                        ));
                        $balance_available = (float) $userBalance + (float) $purchase_price;

                        // log
                        LogHelper::info('Updated reseller user id #' . $Auth->id . ' balance from ' . SITE_CONFIG_COST_CURRENCY_SYMBOL . $userBalance . ' to ' . SITE_CONFIG_COST_CURRENCY_SYMBOL . $balance_available . ' after delete of voucher worth ' . SITE_CONFIG_COST_CURRENCY_SYMBOL . $purchase_price);

                        // update
                        $db->query('UPDATE plugin_vouchers_reseller '
                                . 'SET balance_available = :balance_available '
                                . 'WHERE user_id = :user_id '
                                . 'LIMIT 1', array(
                            'balance_available' => $balance_available,
                            'user_id' => (int) $Auth->id,
                        ));

                        // log transaction
                        $pluginObj->createResellerTransactionEntry($Auth->id, 'voucher_refund', $purchase_price, "Refund of " . SITE_CONFIG_COST_CURRENCY_SYMBOL . $purchase_price . " voucher cost after 1 voucher cancellation by user.");

                        // onscreen confirmation
                        NotificationHelper::setSuccess('Voucher successfully removed and the cost refunded to your reseller balance.');
                    }
                    else {
                        NotificationHelper::setSuccess('Voucher successfully removed.');
                    }
                }
            }
        }
        // add vouchers
        elseif (isset($_REQUEST['generate_vouchers_form'])) {
            // get params
            $package_pricing_id = (int) $_REQUEST['package_pricing_id'];
            $voucher_quantity = (int) $_REQUEST['voucher_quantity'];

            // validation
            // check the package exists
            if (!isset($availablePackagePricing[$package_pricing_id])) {
                NotificationHelper::setError("Package id is invalid.");
            }

            // check the quantity is valid
            if (($voucher_quantity < 1) || ($voucher_quantity > $pluginSettings['reseller_generate_maximum'])) {
                NotificationHelper::setError("Quantity is invalid or exceeds the permitted limits.");
            }

            if (_CONFIG_DEMO_MODE == true) {
                NotificationHelper::setError(TranslateHelper::t("no_changes_in_demo_mode"));
            }

            if (!NotificationHelper::isErrors()) {
                // calculate discount
                $discountPercent = 0;
                foreach ($discountRanges AS $discountRange) {
                    if (($voucher_quantity >= $discountRange['from_amount']) && ($voucher_quantity <= $discountRange['to_amount'])) {
                        $discountPercent = $discountRange['discount_percentage'];
                    }
                }

                // calculate total cost
                $itemPrice = $availablePackagePricing[$package_pricing_id]['price'];
                $totalPriceBeforeDiscount = $itemPrice * $voucher_quantity;
                $totalPriceAfterDiscount = number_format(($totalPriceBeforeDiscount / 100) * (100 - $discountPercent), 2, '.', '');
                $itemPriceDiscounted = number_format($totalPriceAfterDiscount / $voucher_quantity, 2, '.', '');

                // check the user has enough balance in their account
                $userBalanceBefore = $balance_available;
                if (($userBalanceBefore - $totalPriceAfterDiscount) < 0) {
                    NotificationHelper::setError("Balance too low, please add some funds. Current balance: " . SITE_CONFIG_COST_CURRENCY_SYMBOL . number_format($userBalanceBefore, 2) . ". Cost of order: " . SITE_CONFIG_COST_CURRENCY_SYMBOL . number_format($totalPriceAfterDiscount, 2));
                }

                if (!NotificationHelper::isErrors()) {
                    // create the vouchers
                    $vouchers = $pluginObj->generateVouchers((int) $Auth->id, $package_pricing_id, $voucher_quantity, 'user', $itemPriceDiscounted);

                    // make sure we created some
                    if (!COUNT($vouchers)) {
                        NotificationHelper::setError("There was an issue adding the voucher(s), please try again later.");
                    }

                    if (!NotificationHelper::isErrors()) {
                        // only charge for the ones we created, just encase some failed
                        $totalCreated = count($vouchers);
                        $totalCreatedPrice = $totalCreated * $itemPriceDiscounted;
                        $newBalance = $userBalanceBefore - $totalCreatedPrice;

                        // update user balance
                        $db->query('UPDATE plugin_vouchers_reseller '
                                . 'SET balance_available = :balance_available '
                                . 'WHERE user_id = :user_id '
                                . 'LIMIT 1', array(
                            'balance_available' => $newBalance,
                            'user_id' => (int) $Auth->id,
                        ));

                        // set transaction log
                        $pluginObj->createResellerTransactionEntry($Auth->id, 'voucher_purchase', (0 - $totalCreatedPrice), "Purchase of " . $voucher_quantity . " voucher(s) via reseller account.");

                        // redirect
                        return $this->redirect('reseller_home?sc=1');
                    }
                }
            }
        }
        // success messages
        elseif (isset($_REQUEST['sc'])) {
            NotificationHelper::setSuccess("Vouchers succesfully created and listed below.");
        }

        // load template
        return $this->render('reseller_home.html', array(
                    'pluginSettings' => $pluginSettings,
                    'availablePackagePricing' => $availablePackagePricing,
                    'statuses' => $statuses,
                    'Auth' => $Auth,
                    'apiKey' => $apiKey,
                    'discountRanges' => $discountRanges,
                    'balance_available' => $balance_available,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function ajaxResellerHomeVouchers() {
        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $Auth = $this->getAuth();

        // check if user is already part of the reseller program
        if ($Auth->loggedIn()) {
            $resellerData = $db->getRow('SELECT is_reseller, balance_available '
                    . 'FROM plugin_vouchers_reseller '
                    . 'WHERE user_id = :user_id '
                    . 'LIMIT 1', array(
                'user_id' => (int) $Auth->id,
            ));
            if (!$resellerData) {
                return $this->redirect(WEB_ROOT . '/reseller');
            }

            $is_reseller = (int) $resellerData['is_reseller'];
            $balance_available = (float) $resellerData['balance_available'];
            if ($is_reseller == 0) {
                return $this->redirect(WEB_ROOT . '/reseller');
            }
        }
        else {
            return $this->redirect(WEB_ROOT . '/reseller');
        }

        $iDisplayLength = (int) $request->query->get('iDisplayLength');
        $iDisplayStart = (int) $request->query->get('iDisplayStart');
        $sSortDir_0 = ($request->query->has('sSortDir_0') && $request->query->get('sSortDir_0') === 'asc') ? 'asc' : 'desc';
        $filterText = strlen($_REQUEST['filterText']) ? $_REQUEST['filterText'] : null;
        $filterByPackage = strlen($_REQUEST['filterByPackage']) ? (int) $_REQUEST['filterByPackage'] : null;
        $filterByStatus = strlen($_REQUEST['filterByStatus']) ? $_REQUEST['filterByStatus'] : null;

        // get sorting columns
        $iSortCol_0 = (int) $request->query->get('iSortCol_0');
        $sColumns = trim($request->query->get('sColumns'));
        $arrCols = explode(",", $sColumns);
        $sortColumnName = $arrCols[$iSortCol_0];
        $sort = 'purchase_date';

        // setup plugin
        $pluginObj = PluginHelper::getInstance('vouchers');
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('vouchers');
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);

        // pre-load user types
        $availablePackagePricing = $pluginObj->getAccountPackages();

        $sqlClause = "WHERE plugin_vouchers.purchase_user_id = " . (int) $Auth->id . " ";
        if ($filterText) {
            $filterText = strtolower($db->escape($filterText));
            $sqlClause .= "AND (LOWER(plugin_vouchers.voucher) LIKE '%" . $filterText . "%')";
        }

        if ($filterByPackage) {
            $sqlClause .= "AND user_level_pricing.id = " . (int) $filterByPackage . " ";
        }

        if ($filterByStatus) {
            $sqlClause .= "AND plugin_vouchers.status = " . $db->quote($filterByStatus) . " ";
        }

        // load all rewards for this account
        $sQL = 'SELECT COUNT(plugin_vouchers.id) AS total '
                . 'FROM plugin_vouchers '
                . 'LEFT JOIN user_level_pricing ON plugin_vouchers.user_level_pricing_id = user_level_pricing.id ';
        $sQL .= $sqlClause . " ";
        $totalVouchers = $db->getValue($sQL);

        // load filtered
        $vouchers = $db->getRows('SELECT plugin_vouchers.* '
                . 'FROM plugin_vouchers '
                . 'LEFT JOIN user_level_pricing ON plugin_vouchers.user_level_pricing_id = user_level_pricing.id '
                . $sqlClause . ' '
                . 'ORDER BY ' . $sort . ' DESC '
                . 'LIMIT ' . $iDisplayStart . ',' . $iDisplayLength);


        $data = array();
        if ($vouchers) {
            foreach ($vouchers AS $voucher) {
                $lrs = array();

                $icon = 'available';
                $statusTitleText = '';
                if ($voucher['status'] == 'used') {
                    $icon = 'used';
                    $statusTitleText = CoreHelper::formatDate($voucher['used_date']);
                }

                $lrs[] = '<!--' . $icon . '--><img src="' . PLUGIN_WEB_ROOT . '/vouchers/assets/img/voucher_' . $icon . '_24.png" width="24" height="24" title="' . UCWords($voucher['status']) . ' ' . $statusTitleText . '" alt="' . UCWords($voucher['status']) . ' ' . $statusTitleText . '"/>';
                $lrs[] = $voucher['voucher'];
                $lrs[] = ucwords($availablePackagePricing[$voucher['user_level_pricing_id']]['label']) . ' (' . $availablePackagePricing[$voucher['user_level_pricing_id']]['pricing_label'] . ') / ' . ($availablePackagePricing[$voucher['user_level_pricing_id']]['period'] != 'null' ? $availablePackagePricing[$voucher['user_level_pricing_id']]['period'] : '-');
                $lrs[] = CoreHelper::formatDate($voucher['purchase_date']);
                $lrs[] = SITE_CONFIG_COST_CURRENCY_SYMBOL . $voucher['purchase_price'];
                $lrs[] = '<span title="' . $statusTitleText . '">' . UCWords(str_replace("_", " ", $voucher['status'])) . '</span>';

                // create links
                $links = array();
                if (($voucher['status'] == 'available') && ($pluginSettings['reseller_allow_cancel'] == 1)) {
                    $links[] = '<a href="reseller_home?d=' . (int) $voucher['id'] . '" onClick="return confirm(\'' . str_replace('\'', '', TranslateHelper::t('plugin_vouchers_reseller_home_landing_page_are_your_sure_delete', 'Are you sure you want to delete this voucher? If you purchased the voucher, the amount will be credited to your reseller balance.')) . '\');"><img src="' . PLUGIN_WEB_ROOT . '/vouchers/assets/img/delete.png" width="16" height="16" title="' . TranslateHelper::t('delete', 'delete') . '" alt="' . TranslateHelper::t('delete', 'delete') . '"/></a>';
                }
                $lrs[] = implode(" | ", $links);

                $data[] = $lrs;
            }
        }

        $resultArr = array();
        $resultArr["sEcho"] = intval($request->query->get('sEcho'));
        $resultArr["iTotalRecords"] = (int) $totalVouchers;
        $resultArr["iTotalDisplayRecords"] = $resultArr["iTotalRecords"];
        $resultArr["aaData"] = $data;

        // output response
        return $this->renderJson($resultArr);
    }

    public function ajaxResellerHomeTransactions() {
        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $Auth = $this->getAuth();

        // check if user is already part of the reseller program
        if ($Auth->loggedIn()) {
            $resellerData = $db->getRow('SELECT is_reseller, balance_available '
                    . 'FROM plugin_vouchers_reseller '
                    . 'WHERE user_id = :user_id '
                    . 'LIMIT 1', array(
                'user_id' => (int) $Auth->id,
            ));
            if (!$resellerData) {
                return $this->redirect(WEB_ROOT . '/reseller');
            }

            $is_reseller = (int) $resellerData['is_reseller'];
            $balance_available = (float) $resellerData['balance_available'];
            if ($is_reseller == 0) {
                return $this->redirect(WEB_ROOT . '/reseller');
            }
        }
        else {
            return $this->redirect(WEB_ROOT . '/reseller');
        }

        $iDisplayLength = (int) $request->query->get('iDisplayLength');
        $iDisplayStart = (int) $request->query->get('iDisplayStart');
        $sSortDir_0 = ($request->query->has('sSortDir_0') && $request->query->get('sSortDir_0') === 'asc') ? 'asc' : 'desc';

        // get sorting columns
        $iSortCol_0 = (int) $request->query->get('iSortCol_0');
        $sColumns = trim($request->query->get('sColumns'));
        $arrCols = explode(",", $sColumns);
        $sortColumnName = $arrCols[$iSortCol_0];

        // load all for this account
        $sQL = 'SELECT COUNT(id) '
                . 'FROM plugin_vouchers_reseller_transaction '
                . 'WHERE reseller_user_id = :reseller_user_id';
        $totalTransactions = $db->getValue($sQL, array(
            'reseller_user_id' => (int) $Auth->id,
        ));

        // load filtered
        $transactions = $db->getRows('SELECT transaction_type, amount, description, '
                . 'date_created '
                . 'FROM plugin_vouchers_reseller_transaction '
                . 'WHERE reseller_user_id = :reseller_user_id '
                . 'ORDER BY date_created DESC '
                . 'LIMIT ' . $iDisplayStart . ',' . $iDisplayLength, array(
            'reseller_user_id' => (int) $Auth->id,
        ));

        $data = array();
        if ($transactions) {
            foreach ($transactions AS $transaction) {
                $lrs = array();
                $lrs[] = '<img src="' . PLUGIN_WEB_ROOT . '/vouchers/assets/img/' . $transaction['transaction_type'] . '.png" width="24" height="24" title="' . UCWords(str_replace('_', ' ', $transaction['transaction_type'])) . '" alt="' . UCWords(str_replace('_', ' ', $transaction['transaction_type'])) . '"/>';
                $lrs[] = CoreHelper::formatDate($transaction['date_created'], SITE_CONFIG_DATE_TIME_FORMAT);
                $lrs[] = UCWords(str_replace('_', ' ', $transaction['transaction_type']));
                $lrs[] = $transaction['description'];
                $lrs[] = SITE_CONFIG_COST_CURRENCY_SYMBOL . $transaction['amount'];

                $data[] = $lrs;
            }
        }

        $resultArr = array();
        $resultArr["sEcho"] = intval($request->query->get('sEcho'));
        $resultArr["iTotalRecords"] = (int) $totalTransactions;
        $resultArr["iTotalDisplayRecords"] = $resultArr["iTotalRecords"];
        $resultArr["aaData"] = $data;

        // output response
        return $this->renderJson($resultArr);
    }

    public function api() {
        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $Auth = $this->getAuth();

        // pickup variables
        $username = trim($_REQUEST['username']);
        $api_key = trim($_REQUEST['api_key']);
        $package_id = (int) $_REQUEST['package_id'];
        $quantity = (int) $_REQUEST['quantity'];

        // load vouchers details
        $pluginObj = PluginHelper::getInstance('vouchers');
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('vouchers');
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);

        // validate user
        if ((empty($api_key)) || (empty($username))) {
            return $this->renderJson($pluginObj->apiErrorExit("1000", "Invalid username and api_key combination."));
        }

        if (_CONFIG_DEMO_MODE == true) {
            return $this->renderJson($pluginObj->apiErrorExit("999", TranslateHelper::t("no_changes_in_demo_mode")));
        }

        // try to load user
        $userId = (int) $db->getValue('SELECT id '
                        . 'FROM users '
                        . 'WHERE username = :username '
                        . 'AND apikey = :apikey '
                        . 'AND status =\'active\' '
                        . 'LIMIT 1', array(
                    'username' => $username,
                    'apikey' => $api_key,
        ));
        if (!$userId) {
            return $this->renderJson($pluginObj->apiErrorExit("1000", "Invalid username and api_key combination."));
        }

        // get discount ranges
        $discountRanges = $db->getRows('SELECT id, from_amount, to_amount, '
                . 'discount_percentage '
                . 'FROM plugin_vouchers_discount_range '
                . 'ORDER BY from_amount ASC');

        // pre-load user types
        $availablePackagePricing = $pluginObj->getAccountPackages();

        // load reseller data
        $resellerData = $db->getRow('SELECT is_reseller, balance_available '
                . 'FROM plugin_vouchers_reseller '
                . 'WHERE user_id = :user_id '
                . 'LIMIT 1', array(
            'user_id' => $userId,
        ));
        if (!$resellerData) {
            return $this->renderJson($pluginObj->apiErrorExit("1003", "User is not set as a reseller."));
        }
        $balance_available = (float) $resellerData['balance_available'];

        // setup response
        $rs = array();
        $rs['error'] = false;

        // check the package exists
        if (!isset($availablePackagePricing[$package_id])) {
            return $this->renderJson($pluginObj->apiErrorExit("1001", "Package id is invalid."));
        }

        // check the quantity is valid
        if (($quantity < 1) || ($quantity > $pluginSettings['reseller_generate_maximum'])) {
            return $this->renderJson($pluginObj->apiErrorExit("1002", "Quantity is invalid or exceeds the permitted limits."));
        }

        // calculate discount
        $discountPercent = 0;
        foreach ($discountRanges AS $discountRange) {
            if (($quantity >= $discountRange['from_amount']) && ($quantity <= $discountRange['to_amount'])) {
                $discountPercent = $discountRange['discount_percentage'];
            }
        }

        // calculate total cost
        $itemPrice = $availablePackagePricing[$package_id]['price'];
        $totalPriceBeforeDiscount = $itemPrice * $quantity;
        $totalPriceAfterDiscount = number_format(($totalPriceBeforeDiscount / 100) * (100 - $discountPercent), 2, '.', '');
        $itemPriceDiscounted = number_format($totalPriceAfterDiscount / $quantity, 2, '.', '');

        // check the user has enough balance in their account
        $userBalanceBefore = $balance_available;
        if (($userBalanceBefore - $totalPriceAfterDiscount) < 0) {
            return $this->renderJson($pluginObj->apiErrorExit("1004", "Balance too low. Current balance: " . $userBalanceBefore . ". Cost of order: " . $totalPriceAfterDiscount));
        }

        // create the vouchers
        $vouchers = $pluginObj->generateVouchers((int) $userId, $package_id, $quantity, 'api', $itemPriceDiscounted);

        // make sure we created some
        if (!COUNT($vouchers)) {
            $pluginObj->apiErrorExit("1005", "There was an issue adding the voucher, please try again later.");
        }

        // only charge for the ones we created, just encase some failed
        $totalCreated = COUNT($vouchers);
        $totalCreatedPrice = $totalCreated * $itemPriceDiscounted;
        $newBalance = $userBalanceBefore - $totalCreatedPrice;

        // update user balance
        $db->query('UPDATE plugin_vouchers_reseller '
                . 'SET balance_available = :balance_available '
                . 'WHERE user_id = :user_id '
                . 'LIMIT 1', array(
            'balance_available' => $newBalance,
            'user_id' => $userId,
        ));

        // set transaction log
        $pluginObj->createResellerTransactionEntry($userId, 'voucher_purchase', (0 - $totalCreatedPrice), "Purchase of " . $quantity . " voucher(s) via API.");

        // output result
        $rs['data'] = array();
        $rs['data']['voucher_codes'] = $vouchers;
        $rs['data']['voucher_quantity'] = $totalCreated;
        $rs['data']['total_cost'] = number_format($totalCreatedPrice, 2, '.', '');
        $rs['data']['account_balance_before'] = number_format($userBalanceBefore, 2, '.', '');
        $rs['data']['account_balance_after'] = number_format($newBalance, 2, '.', '');
        $rs['data']['total_discount'] = $discountPercent . '%';
        $rs['data']['date_time'] = CoreHelper::sqlDateTime();

        // output response
        return $this->renderJson($rs);
    }

    public function export() {
        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $Auth = $this->getAuth();

        // check if user is already part of the reseller program
        if ($Auth->loggedIn()) {
            $resellerData = $db->getRow('SELECT is_reseller, balance_available '
                    . 'FROM plugin_vouchers_reseller '
                    . 'WHERE user_id = :user_id '
                    . 'LIMIT 1', array(
                'user_id' => (int) $Auth->id,
            ));
            if (!$resellerData) {
                return $this->redirect(WEB_ROOT . '/reseller');
            }

            $is_reseller = (int) $resellerData['is_reseller'];
            $balance_available = (float) $resellerData['balance_available'];
            if ($is_reseller == 0) {
                return $this->redirect(WEB_ROOT . '/reseller');
            }
        }
        else {
            return $this->redirect(WEB_ROOT . '/reseller');
        }

        // get params
        $filterStatus = array();
        $filename = "all_voucher_codes.csv";
        if (isset($_REQUEST['unused'])) {
            $filterStatus[] = 'available';
            $filename = "available_voucher_codes.csv";
        }

        // setup plugin
        $pluginObj = PluginHelper::getInstance('vouchers');
        $packages = $pluginObj->getAccountPackages();

        /* resulting csv data */
        $formattedCSVData = array();

        /* header */
        $lArr = array();
        $lArr[] = "VoucherCode";
        $lArr[] = "PackageId";
        $lArr[] = "PackageName";
        $lArr[] = "Period";
        $lArr[] = "PurchaseDate";
        $lArr[] = "PurchaseValue";
        $lArr[] = "Status";
        $lArr[] = "UsedDate";
        $formattedCSVData[] = "\"" . implode("\",\"", $lArr) . "\"";

        /* get all url data */
        $voucherData = $db->getRows("SELECT * "
                . "FROM plugin_vouchers "
                . "WHERE purchase_user_id = :purchase_user_id "
                . (count($filterStatus) > 0 ? ('AND status IN ("' . implode('","', $filterStatus) . '")') : '') . " "
                . "ORDER BY purchase_date desc", array(
            'purchase_user_id' => (int) $Auth->id,
        ));
        foreach ($voucherData AS $row) {
            $lArr = array();
            $lArr[] = $row['voucher'];
            $lArr[] = $row['user_level_pricing_id'];
            $lArr[] = $packages[$row['user_level_pricing_id']]['label'] . ' ' . $packages[$row['user_level_pricing_id']]['pricing_label'];
            $lArr[] = $packages[$row['user_level_pricing_id']]['period'];
            $lArr[] = ($row['purchase_date'] != "0000-00-00 00:00:00") ? CoreHelper::formatDate($row['purchase_date']) : "";
            $lArr[] = $row['purchase_price'];
            $lArr[] = $row['status'];
            $lArr[] = ($row['used_date'] != "0000-00-00 00:00:00") ? CoreHelper::formatDate($row['used_date']) : "";

            $formattedCSVData[] = "\"" . implode("\",\"", $lArr) . "\"";
        }

        // output response
        return $this->renderDownloadFile(implode("\n", $formattedCSVData), $filename);
    }

    public function paymentComplete() {
        // load template
        $folderName = 'vouchers';

        return $this->render('payment_complete.html', array(), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function pay() {
        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $Auth = $this->getAuth();

        // check if user is already part of the reseller program
        if ($Auth->loggedIn()) {
            $resellerData = $db->getRow('SELECT is_reseller, balance_available '
                    . 'FROM plugin_vouchers_reseller '
                    . 'WHERE user_id = :user_id '
                    . 'LIMIT 1', array(
                'user_id' => (int) $Auth->id,
            ));
            if (!$resellerData) {
                return $this->redirect(WEB_ROOT . '/reseller');
            }

            $is_reseller = (int) $resellerData['is_reseller'];
            $balance_available = (float) $resellerData['balance_available'];
            if ($is_reseller == 0) {
                return $this->redirect(WEB_ROOT . '/reseller');
            }
        }
        else {
            return $this->redirect(WEB_ROOT . '/reseller');
        }

        // load plugin details
        $pluginObj = PluginHelper::getInstance('vouchers');
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('vouchers');
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);
        $paypalEmail = '';
        $enable_sandbox_mode = 0;
        if ($pluginSettings) {
            $paypalEmail = $pluginSettings['paypal_email'];
        }

        // pickup variables
        $amount = (float) $_REQUEST['topup_amount'];
        if ($amount == 0) {
            return $this->redirect(CoreHelper::getCoreSitePath() . "/error?e=" . urlencode('Invalid amount.'));
        }

        // validation
        if ($amount < $pluginSettings['reseller_balance_topup_minimum']) {
            return $this->redirect(CoreHelper::getCoreSitePath() . "/error?e=" . urlencode("Please enter a minimum of " . SITE_CONFIG_COST_CURRENCY_SYMBOL . $pluginSettings['reseller_balance_topup_minimum'] . " to topup by."));
        }

        if ($amount > $pluginSettings['reseller_balance_topup_maximum']) {
            return $this->redirect(CoreHelper::getCoreSitePath() . "/error?e=" . urlencode("Please enter a maximum of " . SITE_CONFIG_COST_CURRENCY_SYMBOL . $pluginSettings['reseller_balance_topup_maximum'] . " to topup by."));
        }

        // create order entry
        $order = $pluginObj->createTopupOrder($Auth->id, $amount);
        if ($order) {
            // redirect to the payment gateway
            $baseUrl = "https://www.paypal.com/cgi-bin/webscr";
            if ($enable_sandbox_mode == 1) {
                $baseUrl = "https://www.sandbox.paypal.com/cgi-bin/webscr";
            }
            $paypalUrl = $baseUrl . '?cmd=_xclick&notify_url=' . urlencode(PLUGIN_WEB_ROOT . '/' . $pluginConfig['data']['folder_name'] . '/vouchers/payment_ipn') . '&email=' . urlencode($Auth->user->email) . '&return=' . urlencode(PLUGIN_WEB_ROOT . '/' . $pluginConfig['data']['folder_name'] . '/vouchers/payment_complete') . '&business=' . urlencode($paypalEmail) . '&item_name=' . urlencode($order->description) . '&item_number=1&amount=' . urlencode($order->amount) . '&no_shipping=2&no_note=1&currency_code=' . SITE_CONFIG_COST_CURRENCY_CODE . '&lc=' . substr(SITE_CONFIG_COST_CURRENCY_CODE, 0, 2) . '&bn=PP%2dBuyNowBF&charset=UTF%2d8&custom=' . $order->payment_hash;

            return $this->redirect($paypalUrl);
        }

        return $this->redirect(CoreHelper::getCoreSitePath() . "/error?e=" . urlencode('Failed creating order, please contact support.'));
    }

    public function paymentIpn() {
        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $Auth = $this->getAuth();

        // load plugin details
        $pluginObj = PluginHelper::getInstance('vouchers');
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('vouchers');
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);
        $paypalEmail = '';
        $enable_sandbox_mode = 0;
        if ($pluginSettings) {
            $paypalEmail = $pluginSettings['paypal_email'];
        }

        // check for some required variables in the request
        if ((!isset($_REQUEST['payment_status'])) || (!isset($_REQUEST['business']))) {
            return $this->render404();
        }

        // make sure payment has completed and it's for the correct PayPal account
        if (($_REQUEST['payment_status'] == "Completed") && (strtolower($_REQUEST['business']) == $paypalEmail)) {
            // load order using custom payment tracker hash
            $paymentTracker = $_REQUEST['custom'];
            $order = $db->getRow("SELECT * "
                    . "FROM plugin_vouchers_topup_order "
                    . "WHERE payment_hash = :payment_hash "
                    . "AND order_status = 'pending' "
                    . "LIMIT 1", array(
                'payment_hash' => $paymentTracker,
            ));
            if ($order) {
                $userId = $order['user_id'];

                // log in payment_log
                $paypal_vars = "";
                foreach ($_REQUEST AS $k => $v) {
                    $paypal_vars .= $k . " => " . $v . "\n";
                }

                // insert payment log
                $paymentLog = PaymentLog::create();
                $paymentLog->user_id = $userId;
                $paymentLog->date_created = date("Y-m-d H:i:s", time());
                $paymentLog->amount = $request->request->get('mc_gross');
                $paymentLog->currency_code = $request->request->get('mc_currency');
                $paymentLog->from_email = $request->request->get('payer_email');
                $paymentLog->to_email = $request->request->get('business');
                $paymentLog->description = $order->description;
                $paymentLog->request_log = $gatewayVars;
                $paymentLog->payment_method = 'PayPal';
                $paymentLog->save();

                // make sure the amount paid matched what we expect
                if ($_REQUEST['mc_gross'] != $order['amount']) {
                    // order amounts did not match
                    LogHelper::info('Failed - order amounts did not match');
                    return $this->render404();
                }

                // make sure the order is pending
                if ($order['order_status'] == 'completed') {
                    // order has already been completed
                    LogHelper::info('Failed - order has already been completed');
                    return $this->render404();
                }

                // update order status to paid
                $pluginVouchersTopupOrder = PluginVouchersTopupOrder::loadOneById($order['id']);
                $pluginVouchersTopupOrder->order_status = 'completed';
                $effectedRows = $pluginVouchersTopupOrder->save();
                if ($effectedRows === false) {
                    // failed to update order
                    LogHelper::info('Failed - failed to update order');
                    return $this->render404();
                }

                // add the balance
                $userBalance = $db->getValue('SELECT balance_available '
                        . 'FROM plugin_vouchers_reseller '
                        . 'WHERE user_id = :user_id '
                        . 'LIMIT 1', array(
                    'user_id' => (int) $userId,
                ));
                $newBalance = (float) $userBalance + (float) $_REQUEST['mc_gross'];
                LogHelper::info('Updated balance on user id #' . $userId . ' from ' . $userBalance . ' to ' . $_REQUEST['mc_gross']);
                $db->query('UPDATE plugin_vouchers_reseller '
                        . 'SET balance_available = :balance_available '
                        . 'WHERE user_id = :user_id '
                        . 'LIMIT 1', array(
                    'balance_available' => $newBalance,
                    'user_id' => (int) $userId,
                ));

                return $this->renderEmpty200Response();
            }
        }
    }

}
