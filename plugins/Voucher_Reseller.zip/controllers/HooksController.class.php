<?php

namespace Plugins\Vouchers\Controllers;

use App\Core\BaseController;
use App\Core\Database;
use App\Helpers\CoreHelper;
use App\Helpers\LogHelper;
use App\Helpers\NotificationHelper;
use App\Helpers\TranslateHelper;
use App\Helpers\UserHelper;
use App\Models\User;

class HooksController extends BaseController
{

    public function adminPluginNav($params = null) {
        // output within the admin left-hand navigation
        $navigation = array(
            array('link_url' => '#', 'link_text' => 'Vouchers', 'link_key' => 'vouchers', 'icon_class' => 'fa fa-tags', 'children' => array(
                    array('link_url' => 'admin/voucher_manage', 'link_text' => 'Manage Vouchers', 'link_key' => 'vouchers_manage_vouchers'),
                    array('link_url' => 'admin/manage_account_balance', 'link_text' => 'Account Balances', 'link_key' => 'vouchers_manage_account_balances'),
                    array('link_url' => 'admin/voucher_manage?add=1', 'link_text' => 'Generate Vouchers', 'link_key' => 'vouchers_manage_vouchers_generate'),
                    array('link_url' => 'admin/plugin/vouchers/settings', 'link_text' => 'Plugin Settings', 'link_key' => 'vouchers_plugin_settings'),
                )),
        );

        // return array
        return $navigation;
    }

    /**
     * Shown on both the front-end and file manager.
     * 
     * @param type $params
     * @return type
     */
    public function siteHeaderNav($params = array()) {
        return array(
            '_found_hook' => true,
            array(
                'link_url' => WEB_ROOT . '/resellers',
                'link_text' => TranslateHelper::t("plugin_resellers", "Resellers"),
            ),
        );
    }

    public function upgradePageMiddle($params = null) {
        // load template
        return array(
            '_found_hook' => true,
            'response_html' => $this->getRenderedTemplate('partial/upgrade_page_middle.html', array(
                'formUrl' => (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'],
            ), PLUGIN_DIRECTORY_ROOT . 'vouchers/views')
        );
    }

    public function upgradePageProcess($params = null) {
        // do we have a voucher code
        if (isset($_REQUEST['plugin_vouchers_apply_voucher_code'])) {
            // block demo mode
            if (_CONFIG_DEMO_MODE == true) {
                NotificationHelper::setError(TranslateHelper::t("no_changes_in_demo_mode"));
                
                return $this->renderEmpty200Response();
            }
            else {
                // only logged in users
                $Auth = $this->getAuth();
                $db = Database::getDatabase();
                if ($Auth->loggedIn() == true) {
                    // logging
                    LogHelper::setContext("plugin_vouchers");

                    // check code
                    $plugin_vouchers_apply_voucher_code = trim($_REQUEST['plugin_vouchers_apply_voucher_code']);
                    if ($plugin_vouchers_apply_voucher_code) {
                        // track attempts
                        if (!isset($_SESSION['plugin_vouchers_voucher_tries'])) {
                            $_SESSION['plugin_vouchers_voucher_tries'] = 0;
                        }

                        // check they haven't hit the voucher limit
                        if ($_SESSION['plugin_vouchers_voucher_tries'] >= 20) {
                            // too many tries
                            NotificationHelper::setError(TranslateHelper::t("plugin_vouchers_voucher_error_too_many_attempts", "You have too many recent attempts at applying a voucher, please try again later."));
                            
                            return $this->renderEmpty200Response();
                        }
                        else {
                            // check code
                            $voucher = $db->getRow('SELECT * '
                                    . 'FROM plugin_vouchers '
                                    . 'WHERE voucher = ' . $db->quote($plugin_vouchers_apply_voucher_code) . ' '
                                    . 'AND status = \'available\' '
                                    . 'LIMIT 1');
                            if ($voucher) {
                                // valid voucher
                                $_SESSION['plugin_vouchers_voucher_tries'] = 0;

                                // set voucher as complete
                                $rs = $db->query('UPDATE plugin_vouchers '
                                        . 'SET status=\'used\', '
                                        . 'used_date=NOW(), '
                                        . 'used_user_id=' . (int) $Auth->id . ' '
                                        . 'WHERE id=' . (int) $voucher['id'] . ' '
                                        . 'LIMIT 1');
                                LogHelper::info("Voucher code '" . $plugin_vouchers_apply_voucher_code . "' set as used for account #" . (int) $Auth->id . ". " . print_r($voucher, true));

                                // upgrade user
                                if ($rs) {
                                    // load pricing info
                                    $price = $db->getRow('SELECT id, pricing_label, '
                                            . 'period, price, user_level_id '
                                            . 'FROM user_level_pricing '
                                            . 'WHERE id = ' . (int) $voucher['user_level_pricing_id'] . ' '
                                            . 'LIMIT 1');
                                    if ($price) {
                                        $priceStr = $price['price'];
                                        $days = (int) CoreHelper::convertStringDatePeriodToDays($price['period']);
                                        $newUserPackageId = $price['user_level_id'];

                                        // upgrade user
                                        $newExpiryDate = strtotime('+' . $days . ' days');

                                        // get level type id
                                        $userLevelId = UserHelper::getLevelIdFromPackageId($Auth->package_id);

                                        // load user
                                        $user = User::loadOneById($Auth->id);

                                        // extend user
                                        if ($userLevelId >= 2) {
                                            // add onto existing period
                                            $existingExpiryDate = strtotime($user->paidExpiryDate);

                                            // if less than today just revert to now
                                            if ($existingExpiryDate < time()) {
                                                $existingExpiryDate = time();
                                            }

                                            $newExpiryDate = (int) $existingExpiryDate + (int) ($days * (60 * 60 * 24));
                                        }

                                        // update user account to premium
                                        $user->level_id = $newUserPackageId;
                                        $user->lastPayment = CoreHelper::sqlDateTime();
                                        $user->paidExpiryDate = date("Y-m-d H:i:s", $newExpiryDate);
                                        $effectedRows = $user->save();
                                        if ($effectedRows === false) {
                                            // failed updating
                                            NotificationHelper::setError(TranslateHelper::t("plugin_vouchers_voucher_error_failed_database", "Failed updating the user account, please try again later."));
                                            
                                            return $this->renderEmpty200Response();
                                        }
                                        else {
                                            // log
                                            LogHelper::info("Account sucessfully upgraded to package pricing #" . $newUserPackageId . " after using voucher code." . print_r($dbUpdate, true));

                                            // account updated
                                            NotificationHelper::setSuccess(TranslateHelper::t("plugin_vouchers_voucher_upgraded", "Voucher succesfully applied. Please logout and back in to fully apply the upgrade."));
                                            
                                            return $this->renderEmpty200Response();
                                        }
                                    }
                                }
                            }
                            else {
                                // invalid voucher
                                $_SESSION['plugin_vouchers_voucher_tries'] ++;
                                NotificationHelper::setError(TranslateHelper::t("plugin_vouchers_voucher_error_invalid_code", "Invalid voucher code, please try again."));
                                
                                return $this->renderEmpty200Response();
                            }
                        }
                    }
                }
                else {
                    // too many tries
                    NotificationHelper::setError(TranslateHelper::t("plugin_vouchers_voucher_error_please_login", "Please register for an account and login above to apply a voucher."));
                    
                    return $this->renderEmpty200Response();
                }
            }
        }
        
        return false;
    }

}
