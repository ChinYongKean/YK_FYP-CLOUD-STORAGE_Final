<?php

namespace Plugins\vouchers\Controllers\Admin;

use App\Core\Database;
use App\Controllers\Admin\PluginController AS CorePluginController;
use App\Helpers\AdminHelper;
use App\Helpers\CoreHelper;
use App\Helpers\PluginHelper;
use App\Helpers\LogHelper;
use App\Models\Plugin;
use Plugins\Vouchers\Models\PluginVouchersReseller;

class PluginController extends CorePluginController
{

    public function pluginSettings() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // load plugin details
        $folderName = 'vouchers';
        $plugin = Plugin::loadOneByClause('folder_name = :folder_name', array(
                    'folder_name' => $folderName,
        ));

        if (!$plugin) {
            return $this->redirect(ADMIN_WEB_ROOT . '/plugin_manage?error=' . urlencode('There was a problem loading the plugin details.'));
        }

        // pre-load user types
        $userTypes = $db->getRows('SELECT id, level_id, label, level_type '
                . 'FROM user_level '
                . 'ORDER BY label');

        // get discount ranges
        $discountRanges = $db->getRows('SELECT id, from_amount, to_amount, discount_percentage '
                . 'FROM plugin_vouchers_discount_range '
                . 'ORDER BY from_amount ASC');

        // default params
        $plugin_enabled = (int) $plugin->plugin_enabled;
        $voucher_length = 20;
        $voucher_prepend = '';
        $reseller_generate_maximum = 1000;
        $reseller_user_groups = array();
        foreach ($userTypes AS $userType) {
            $reseller_user_groups[] = $userType['id'];
        }
        $reseller_allow_cancel = 1;
        $reseller_balance_topup_minimum = 100;
        $reseller_balance_topup_maximum = 2000;
        $available_package_pricing_id = array();
        $paypal_email = '';
        foreach ($userTypes AS $k => $userType) {
            // only show 'paid' user packages
            if ($userType['level_type'] != 'paid') {
                continue;
            }

            // get pricing
            $userTypes[$k]['_pricing'] = $db->getRows('SELECT id, pricing_label, period, price '
                    . 'FROM user_level_pricing '
                    . 'WHERE user_level_id = :user_level_id '
                    . 'ORDER BY price', array(
                'user_level_id' => (int) $userType['id'],
            ));
            if (!$userTypes[$k]['_pricing']) {
                continue;
            }

            foreach ($userTypes[$k]['_pricing'] AS $pricingItem) {
                $available_package_pricing_id[] = $pricingItem['id'];
            }
        }
        $reseller_pricing_discount = array();

        // load existing settings
        if (strlen($plugin->plugin_settings)) {
            $plugin_settings = json_decode($plugin->plugin_settings, true);
            if ($plugin_settings) {
                // load settings locally
                $voucher_length = (int) $plugin_settings['voucher_length'];
                $voucher_prepend = trim($plugin_settings['voucher_prepend']);
                $reseller_generate_maximum = (int) $plugin_settings['reseller_generate_maximum'];
                $reseller_user_groups = $plugin_settings['reseller_user_groups'];
                $reseller_allow_cancel = (int) $plugin_settings['reseller_allow_cancel'];
                $reseller_balance_topup_minimum = (float) $plugin_settings['reseller_balance_topup_minimum'];
                $reseller_balance_topup_maximum = (float) $plugin_settings['reseller_balance_topup_maximum'];
                $available_package_pricing_id = $plugin_settings['available_package_pricing_id'];
                $reseller_pricing_discount = $plugin_settings['reseller_pricing_discount'];
                $paypal_email = trim($plugin_settings['paypal_email']);
            }
        }

        // handle page submissions
        if ($request->request->has('submitted')) {
            // get variables
            $plugin_enabled = (int) $request->request->get('plugin_enabled');
            $plugin_enabled = $plugin_enabled != 1 ? 0 : 1;
            $voucher_length = (int) $_REQUEST['voucher_length'];
            $voucher_prepend = trim($_REQUEST['voucher_prepend']);
            $reseller_generate_maximum = (int) $_REQUEST['reseller_generate_maximum'];
            $reseller_user_groups = $_REQUEST['reseller_user_groups'];
            $reseller_allow_cancel = (int) $_REQUEST['reseller_allow_cancel'];
            $reseller_balance_topup_minimum = (float) $_REQUEST['reseller_balance_topup_minimum'];
            $reseller_balance_topup_maximum = (float) $_REQUEST['reseller_balance_topup_maximum'];
            $available_package_pricing_id = $_REQUEST['available_package_pricing_id'];
            $reseller_pricing_discount = $_REQUEST['reseller_pricing_discount'];
            $paypal_email = trim($_REQUEST['paypal_email']);

            // validate submission
            if (_CONFIG_DEMO_MODE == true) {
                AdminHelper::setError(AdminHelper::t('no_changes_in_demo_mode', 'No change permitted in demo mode.'));
            }
            elseif ($plugin_enabled === 1) {
                if ($voucher_length === 0) {
                    AdminHelper::setError(AdminHelper::t("plugin_vouchers_please_set_the_length_of_vouchers", "Please set the length of vouchers to create."));
                }
            }

            // update the settings
            if (AdminHelper::isErrors() == false) {
                // compile new settings
                $settingsArr = array();
                $settingsArr['voucher_length'] = $voucher_length;
                $settingsArr['voucher_prepend'] = $voucher_prepend;
                $settingsArr['reseller_generate_maximum'] = $reseller_generate_maximum;
                $settingsArr['reseller_user_groups'] = $reseller_user_groups;
                $settingsArr['reseller_allow_cancel'] = $reseller_allow_cancel;
                $settingsArr['reseller_balance_topup_minimum'] = $reseller_balance_topup_minimum;
                $settingsArr['reseller_balance_topup_maximum'] = $reseller_balance_topup_maximum;
                $settingsArr['available_package_pricing_id'] = $available_package_pricing_id;
                $settingsArr['paypal_email'] = $paypal_email;

                // update the plugin settings
                $plugin->plugin_enabled = $plugin_enabled;
                $plugin->plugin_settings = json_encode($settingsArr);
                $plugin->save();

                // update discounts
                foreach ($discountRanges AS $discountRange) {
                    $discount = isset($reseller_pricing_discount[$discountRange['id']]) ? (int) $reseller_pricing_discount[$discountRange['id']] : 0;
                    if (($discount > 99) || ($discount < 0)) {
                        $discount = 0;
                    }
                    $db->query('UPDATE plugin_vouchers_discount_range '
                            . 'SET discount_percentage = :discount_percentage '
                            . 'WHERE id = :id '
                            . 'LIMIT 1', array(
                        'discount_percentage' => $discount,
                        'id' => (int) $discountRange['id'],
                    ));
                }

                // reload plugin cache
                PluginHelper::loadPluginConfigurationFiles(true);
                AdminHelper::setSuccess('Plugin settings updated.');
            }
        }

        // load template
        return $this->render('admin/plugin_settings.html', array(
                    'pluginName' => $plugin->plugin_name,
                    'yesNoOptions' => array(
                        0 => 'No',
                        1 => 'Yes'),
                    'voucherLengthOptions' => range(8, 50),
                    'userTypes' => $userTypes,
                    'discountRanges' => $discountRanges,
                    'plugin_enabled' => $plugin_enabled,
                    'voucher_length' => (int) $voucher_length,
                    'voucher_prepend' => $voucher_prepend,
                    'reseller_generate_maximum' => (int) $reseller_generate_maximum,
                    'reseller_user_groups' => $reseller_user_groups,
                    'reseller_allow_cancel' => (int) $reseller_allow_cancel,
                    'reseller_balance_topup_minimum' => (float) $reseller_balance_topup_minimum,
                    'reseller_balance_topup_maximum' => (float) $reseller_balance_topup_maximum,
                    'available_package_pricing_id' => $available_package_pricing_id,
                    'reseller_pricing_discount' => $reseller_pricing_discount,
                    'paypal_email' => $paypal_email,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function voucherManage() {
        // admin restrictions
        $this->restrictAdminAccess();

        // for later
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $Auth = $this->getAuth();
        $vouchersObj = PluginHelper::getInstance('vouchers');
        $vouchersSettings = $vouchersObj->settings;

        // load user list
        $users = $db->getRows('SELECT id, username '
                . 'FROM users '
                . 'WHERE status = \'active\' '
                . 'ORDER BY username');

        // load packages
        $packages = $db->getRows('SELECT user_level_pricing.id, user_level_pricing.pricing_label, '
                . 'user_level_pricing.price, user_level.label '
                . 'FROM user_level_pricing '
                . 'LEFT JOIN user_level ON user_level_pricing.user_level_id = user_level.id '
                . 'WHERE user_level.level_type = \'paid\' '
                . 'ORDER BY user_level.label, user_level_pricing.price');

        // generate vouchers
        $account_username = $Auth->id;
        $voucher_package = '';
        $voucher_quantity = 100;
        if ($request->request->has('new_voucher_form_submitted')) {
            $account_username = (int) $_REQUEST['account_username'];
            $voucher_package = (int) $_REQUEST['voucher_package'];
            $voucher_quantity = (int) $_REQUEST['voucher_quantity'];
            if (_CONFIG_DEMO_MODE == true) {
                AdminHelper::setError(AdminHelper::t("no_changes_in_demo_mode"));
            }
            elseif ($voucher_quantity == 0) {
                AdminHelper::setError(AdminHelper::t("plugin_vouchers_please_enter_the_quantity_to_generate", "Please enter the voucher quantity to generate."));
            }
            elseif ($voucher_quantity > 1000) {
                AdminHelper::setError(AdminHelper::t("plugin_vouchers_maximum_you_can_generate_is_1000", "The maximum vouchers you can generate at once is 1000."));
            }

            // if no errors
            if (AdminHelper::isErrors() == false) {
                // create the vouchers
                $vouchersArr = $vouchersObj->generateVouchers($account_username, $voucher_package, $voucher_quantity, 'admin');

                // output onto screen
                AdminHelper::setSuccess(AdminHelper::t("plugin_vouchers_total_vouchers_generated", "[[[TOTAL_VOUCHERS]]] voucher(s) generated: [[[VOUCHER_CODES]]]", array('TOTAL_VOUCHERS' => COUNT($vouchersArr), 'VOUCHER_CODES' => implode(', ', $vouchersArr))));
            }
        }

        // pickup filters
        $filterByUser = null;
        if (isset($_REQUEST['filterByUser'])) {
            $filterByUser = (int) $_REQUEST['filterByUser'];
            $account_username = (int) $_REQUEST['filterByUser'];
        }
        $filterByPurchasedOnly = null;
        if (isset($_REQUEST['filterByPurchasedOnly'])) {
            $filterByPurchasedOnly = (int) $_REQUEST['filterByPurchasedOnly'];
        }
        $filterByStatus = null;
        if (isset($_REQUEST['filterByStatus'])) {
            $filterByStatus = trim($_REQUEST['filterByStatus']);
        }

        // overview stats
        $totalIssued = (int) $db->getValue("SELECT COUNT(id) AS total FROM plugin_vouchers");
        $totalAvailable = (int) $db->getValue("SELECT COUNT(id) AS total FROM plugin_vouchers WHERE status='available'");
        $totalUsed = (int) $db->getValue("SELECT COUNT(id) AS total FROM plugin_vouchers WHERE status='used'");
        $totalPurchaseValue = (float) $db->getValue("SELECT SUM(purchase_price) AS total FROM plugin_vouchers");
        $totalResellers = (float) $db->getValue("SELECT COUNT(id) AS total FROM plugin_vouchers_reseller WHERE is_reseller = 1");

        // load template
        return $this->render('admin/voucher_manage.html', array(
                    'vouchersObj' => $vouchersObj,
                    'vouchersSettings' => $vouchersSettings,
                    'statusDetails' => $vouchersObj->getStatusList(),
                    'filterByUser' => $filterByUser,
                    'filterByPurchasedOnly' => $filterByPurchasedOnly,
                    'filterByStatus' => $filterByStatus,
                    'account_username' => $account_username,
                    'voucher_package' => $voucher_package,
                    'voucher_quantity' => $voucher_quantity,
                    'users' => $users,
                    'packages' => $packages,
                    'totalIssued' => $totalIssued,
                    'totalAvailable' => $totalAvailable,
                    'totalUsed' => $totalUsed,
                    'totalPurchaseValue' => $totalPurchaseValue,
                    'totalResellers' => $totalResellers,
                    'triggerAdd' => isset($_REQUEST['add']),
                        ), PLUGIN_DIRECTORY_ROOT . 'vouchers/views');
    }

    public function ajaxVoucherManage() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        $iDisplayLength = (int) $request->query->get('iDisplayLength');
        $iDisplayStart = (int) $request->query->get('iDisplayStart');
        $sSortDir_0 = ($request->query->has('sSortDir_0') && $request->query->get('sSortDir_0') === 'asc') ? 'asc' : 'desc';
        $filterText = strlen($_REQUEST['filterText']) ? $_REQUEST['filterText'] : null;
        $filterByUser = strlen($_REQUEST['filterByUser']) ? (int) $_REQUEST['filterByUser'] : null;
        $filterByPackage = strlen($_REQUEST['filterByPackage']) ? (int) $_REQUEST['filterByPackage'] : null;
        $filterByStatus = strlen($_REQUEST['filterByStatus']) ? $_REQUEST['filterByStatus'] : null;
        $filterByPurchasedOnly = $_REQUEST['filterByPurchasedOnly'] == 'true' ? true : null;

        // setup joins
        $joins = array();

        // get sorting columns
        $iSortCol_0 = (int) $request->query->get('iSortCol_0');
        $sColumns = trim($request->query->get('sColumns'));
        $arrCols = explode(",", $sColumns);
        $sortColumnName = $arrCols[$iSortCol_0];
        $sort = 'plugin_vouchers.voucher';
        switch ($sortColumnName) {
            case 'voucher':
                $sort = 'plugin_vouchers.voucher';
                break;
            case 'purchase_date':
                $sort = 'plugin_vouchers.purchase_date';
                break;
            case 'purchase_price':
                $sort = 'plugin_vouchers.purchase_price';
                break;
            case 'status':
                $sort = 'plugin_vouchers.status';
                break;
            case 'purchase_user_username':
                $sort = 'purchase_user.username';
                break;
            case 'used_user_username':
                $sort = 'used_user.username';
                break;
        }

        $sqlClause = "WHERE 1=1 ";
        if ($filterText) {
            $filterText = strtolower($db->escape($filterText));
            $sqlClause .= "AND (LOWER(plugin_vouchers.voucher) LIKE '%" . $filterText . "%' OR ";
            $sqlClause .= "LOWER(purchase_user.username) LIKE '" . $filterText . "%' OR ";
            $sqlClause .= "LOWER(purchase_user.username) LIKE '" . $filterText . "%')";
        }

        if ($filterByUser) {
            $sqlClause .= "AND plugin_vouchers.purchase_user_id = " . (int) $filterByUser . " ";
        }

        if ($filterByPackage) {
            $sqlClause .= "AND user_level_pricing.id = " . (int) $filterByPackage . " ";
        }

        if ($filterByStatus) {
            $sqlClause .= "AND plugin_vouchers.status = " . $db->quote($filterByStatus) . " ";
        }

        if ($filterByPurchasedOnly == 1) {
            $sqlClause .= "AND plugin_vouchers.purchase_price > 0 ";
        }

        $sQL = "SELECT plugin_vouchers.id, plugin_vouchers.voucher, user_level.label AS package, "
                . "user_level_pricing.pricing_label, plugin_vouchers.purchase_date, "
                . "plugin_vouchers.purchase_price, plugin_vouchers.purchase_user_id, "
                . "purchase_user.username AS purchase_username, "
                . "used_user.username AS used_username, plugin_vouchers.status, "
                . "plugin_vouchers.used_date, plugin_vouchers.used_user_id "
                . "FROM plugin_vouchers LEFT JOIN user_level_pricing ON plugin_vouchers.user_level_pricing_id = user_level_pricing.id "
                . "LEFT JOIN user_level ON user_level_pricing.user_level_id = user_level.id "
                . "LEFT JOIN users purchase_user ON plugin_vouchers.purchase_user_id = purchase_user.id "
                . "LEFT JOIN users used_user ON plugin_vouchers.used_user_id = used_user.id ";
        $sQL .= $sqlClause . " ";
        $totalRS = $db->getRows($sQL);

        $sQL .= "ORDER BY " . $sort . " " . $db->escape($sSortDir_0) . " ";
        $sQL .= "LIMIT " . $iDisplayStart . ", " . $iDisplayLength;
        $limitedRS = $db->getRows($sQL);

        $data = array();
        if (count($limitedRS) > 0) {
            foreach ($limitedRS AS $row) {
                $lRow = array();

                $icon = 'available';
                if ($row['status'] == 'used') {
                    $icon = 'used';
                }
                if ($row['status'] == 'available') {
                    $lRow[] = '<input type="checkbox" id="cbElement' . $row['id'] . '" value="' . $row['id'] . '" onClick="toggleFileIds(this);"  class="checkbox"/>';
                }
                else {
                    $lRow[] = '';
                }

                $lRow[] = '<span style="vertical-align: middle; display: inline-block; margin-right: 5px;"><img src="' . PLUGIN_WEB_ROOT . '/vouchers/assets/img/voucher_' . $icon . '.png" width="16" height="16" title="' . UCWords($row['status']) . '" alt="' . UCWords($row['status']) . '"/></span><strong>' . AdminHelper::makeSafe($row['voucher']) . '</strong><br/>' . AdminHelper::makeSafe($row['package']) . ' (' . AdminHelper::makeSafe($row['pricing_label']) . ')';
                ;
                $lRow[] = AdminHelper::makeSafe(strlen($row['purchase_date']) ? CoreHelper::formatDate($row['purchase_date'], SITE_CONFIG_DATE_TIME_FORMAT) : '-');
                $lRow[] = SITE_CONFIG_COST_CURRENCY_SYMBOL . AdminHelper::makeSafe(number_format($row['purchase_price'], 2));
                $lRow[] = '<a href="' . ADMIN_WEB_ROOT . '/user_edit/' . (int) $row['purchase_user_id'] . '">' . AdminHelper::makeSafe($row['purchase_username']) . '</a>';
                $lRow[] = '<span class="statusText' . str_replace(" ", "", UCWords($row['status'])) . '">' . UCWords($row['status']) . ($row['status'] == 'used' ? ('&nbsp;&nbsp;<font style="color: #999;">(' . CoreHelper::formatDate($row['used_date'], SITE_CONFIG_DATE_TIME_FORMAT) . ')</font>') : '') . '</span>';
                $lRow[] = strlen($row['used_date']) ? (CoreHelper::formatDate($row['used_date'], SITE_CONFIG_DATE_TIME_FORMAT) . '<br/>by <a href="' . ADMIN_WEB_ROOT . '/user_edit.php?id=' . (int) $row['used_user_id'] . '">' . AdminHelper::makeSafe($row['used_username']) . '</a>') : '-';

                $links = array();
                if ($row['status'] == 'available') {
                    $links[] = '<a href="#" onClick="confirmDeleteVoucher(' . (int) $row['id'] . '); return false;">delete</a>';
                }
                $lRow[] = implode(" | ", $links);

                $data[] = $lRow;
            }
        }

        $resultArr = array();
        $resultArr["sEcho"] = intval($request->query->get('sEcho'));
        $resultArr["iTotalRecords"] = (int) count($totalRS);
        $resultArr["iTotalDisplayRecords"] = $resultArr["iTotalRecords"];
        $resultArr["aaData"] = $data;

        // output response
        return $this->renderJson($resultArr);
    }

    public function ajaxVoucherManageCancel() {
        // admin restrictions
        $this->restrictAdminAccess();

        // get variables
        $voucherIds = $_REQUEST['voucherIds'];

        // get instance
        $vouchersObj = PluginHelper::getInstance('vouchers');

        // prepare result
        $result = array();
        $result['error'] = false;
        $result['msg'] = '';

        if (_CONFIG_DEMO_MODE == true) {
            $result['error'] = true;
            $result['msg'] = AdminHelper::t("no_changes_in_demo_mode");
        }
        else {
            $rs = $vouchersObj->cancelVouchers($voucherIds);
            if ($rs == true) {
                $result['error'] = false;
                $result['msg'] = 'Voucher(s) deleted.';
            }
            else {
                $result['error'] = true;
                $result['msg'] = 'Could not delete the voucher(s), please try again later.';
            }
        }

        return $this->renderJson($result);
    }

    public function manageAccountBalance() {
        // admin restrictions
        $this->restrictAdminAccess();

        // for later
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $vouchersObj = PluginHelper::getInstance('vouchers');
        $vouchersSettings = $vouchersObj->settings;

        $filterByIsResellerOnly = null;
        if (isset($_REQUEST['filterByIsResellerOnly'])) {
            $filterByIsResellerOnly = (int) $_REQUEST['filterByIsResellerOnly'];
        }

        // load template
        return $this->render('admin/manage_account_balance.html', array(
                    'vouchersObj' => $vouchersObj,
                    'vouchersSettings' => $vouchersSettings,
                    'statusDetails' => $vouchersObj->getStatusList(),
                    'filterByIsResellerOnly' => $filterByIsResellerOnly,
                        ), PLUGIN_DIRECTORY_ROOT . 'vouchers/views');
    }

    public function ajaxManageAccountBalance() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        $iDisplayLength = (int) $request->query->get('iDisplayLength');
        $iDisplayStart = (int) $request->query->get('iDisplayStart');
        $sSortDir_0 = ($request->query->has('sSortDir_0') && $request->query->get('sSortDir_0') === 'asc') ? 'asc' : 'desc';
        $filterText = $_REQUEST['filterText'] ? $_REQUEST['filterText'] : null;
        $filterByIsResellerOnly = $_REQUEST['filterByIsResellerOnly'] == 'true' ? true : null;

        // setup joins
        $joins = array();

        // get sorting columns
        $iSortCol_0 = (int) $request->query->get('iSortCol_0');
        $sColumns = trim($request->query->get('sColumns'));
        $arrCols = explode(",", $sColumns);
        $sortColumnName = $arrCols[$iSortCol_0];
        $sort = 'users.username';
        switch ($sortColumnName) {
            case 'username':
                $sort = 'users.username';
                break;
            case 'email':
                $sort = 'users.email';
                break;
            case 'balance_available':
                $sort = 'plugin_vouchers_reseller.balance_available';
                break;
            case 'total_vouchers':
                $sort = '(SELECT COUNT(plugin_vouchers.id) FROM plugin_vouchers WHERE plugin_vouchers.purchase_user_id = plugin_vouchers_reseller.user_id)';
                break;
            case 'last_payment':
                $sort = 'plugin_vouchers_reseller.last_payment';
                break;
        }

        $sqlClause = "WHERE 1=1 ";
        if ($filterText) {
            $filterText = strtolower($db->escape($filterText));
            $sqlClause .= "AND (LOWER(users.username) LIKE '%" . $filterText . "%' OR ";
            $sqlClause .= "LOWER(user_level.label) = '" . $filterText . "')";
        }

        if ($filterByIsResellerOnly == 1) {
            $sqlClause .= "AND plugin_vouchers_reseller.is_reseller = 1 ";
        }

        $sQL = "SELECT plugin_vouchers_reseller.balance_available, "
                . "plugin_vouchers_reseller.is_reseller, plugin_vouchers_reseller.last_payment, "
                . "users.id, users.username, users.email, user_level.label, "
                . "(SELECT COUNT(plugin_vouchers.id) FROM plugin_vouchers WHERE plugin_vouchers.purchase_user_id = plugin_vouchers_reseller.user_id) AS total_vouchers "
                . "FROM users LEFT JOIN plugin_vouchers_reseller ON users.id = plugin_vouchers_reseller.user_id "
                . "LEFT JOIN user_level ON users.level_id = user_level.id = users.id ";
        $sQL .= $sqlClause . " ";
        $totalRS = $db->getRows($sQL);

        $sQL .= "ORDER BY " . $sort . " " . $db->escape($sSortDir_0) . " ";
        $sQL .= "LIMIT " . $iDisplayStart . ", " . $iDisplayLength;
        $limitedRS = $db->getRows($sQL);

        $data = array();
        if (count($limitedRS) > 0) {
            foreach ($limitedRS AS $row) {
                $lRow = array();

                $icon = 'local';
                $lRow[] = '<img src="' . CORE_ASSETS_WEB_ROOT . '/admin/images/icons/system/16x16/user.png" width="16" height="16" title="' . UCWords($row['status']) . '" alt="' . UCWords($row['status']) . '"/>';
                $lRow[] = AdminHelper::makeSafe($row['username']);
                $icon = 'delete';
                $action = 1;
                if ((int) $row['is_reseller'] == 1) {
                    $icon = 'accept';
                    $action = 0;
                }
                $lRow[] = '<a href="#" onClick="grantResellerAccess(' . (int) $row['id'] . ', ' . (int) $action . '); return false;"><img src="' . CORE_ASSETS_WEB_ROOT . '/admin/images/icons/system/16x16/' . $icon . '.png" width="16" height="16"/></a>';
                $lRow[] = SITE_CONFIG_COST_CURRENCY_SYMBOL . AdminHelper::makeSafe(number_format($row['balance_available'], 2));
                $lRow[] = AdminHelper::makeSafe($row['total_vouchers']);
                $lRow[] = AdminHelper::makeSafe(strlen($row['last_payment']) ? CoreHelper::formatDate($row['last_payment'], SITE_CONFIG_DATE_TIME_FORMAT) : '-');

                $links = array();
                $links[] = '<a href="#" onClick="editBalanceForm(' . (int) $row['id'] . '); return false;">edit balance</a>';
                if ($row['total_vouchers'] > 0) {
                    $links[] = '<a href="../admin/voucher_manage?filterByUser=' . (int) $row['id'] . '">vouchers</a>';
                }
                $links[] = '<a href="../admin/voucher_manage?filterByUser=' . (int) $row['id'] . '&add=1">add vouchers</a>';
                $lRow[] = implode(" | ", $links);

                $data[] = $lRow;
            }
        }

        $resultArr = array();
        $resultArr["sEcho"] = intval($request->query->get('sEcho'));
        $resultArr["iTotalRecords"] = (int) count($totalRS);
        $resultArr["iTotalDisplayRecords"] = $resultArr["iTotalRecords"];
        $resultArr["aaData"] = $data;

        // output response
        return $this->renderJson($resultArr);
    }

    public function ajaxGrantResellerProcess() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        $userId = (int) $_REQUEST['userId'];
        $is_reseller = (int) $_REQUEST['is_reseller'];

        // prepare result
        $result = array();
        $result['error'] = false;
        $result['msg'] = '';

        // validate submission
        if (_CONFIG_DEMO_MODE == true) {
            $result['error'] = true;
            $result['msg'] = AdminHelper::t("no_changes_in_demo_mode");
        }

        // should we attempt to send the newsletter?
        if ($result['error'] == false) {
            // setup logging
            LogHelper::setContext("plugin_vouchers");

            // update balance
            $resellerDetails = $db->getRow('SELECT id, is_reseller '
                    . 'FROM plugin_vouchers_reseller '
                    . 'WHERE user_id = :user_id '
                    . 'LIMIT 1', array(
                'user_id' => (int) $userId,
            ));
            if ($resellerDetails) {
                // update
                $pluginVouchersReseller = PluginVouchersReseller::loadOneById($resellerDetails['id']);
                $pluginVouchersReseller->is_reseller = (int) $is_reseller;
                $pluginVouchersReseller->save();

                // log
                LogHelper::info('Is reseller access for user id #' . (int) $userId . ' updated to ' . $is_reseller);
            }
            else {
                // insert
                $pluginVouchersReseller = PluginVouchersReseller::create();
                $pluginVouchersReseller->user_id = $userId;
                $pluginVouchersReseller->is_reseller = $is_reseller;
                $pluginVouchersReseller->save();

                // log
                LogHelper::info('Is reseller access for user id #' . (int) $userId . ' updated to ' . $is_reseller);
            }

            // update confirmation message
            $result['msg'] = 'Reseller access updated.';
        }

        return $this->renderJson($result);
    }

    public function ajaxAccountBalanceEditForm() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // prepare variables
        $balance_available = 0;
        $is_reseller = 0;

        // load the user balance
        $gUserId = (int) $_REQUEST['gUserId'];
        $sQL = "SELECT users.username, plugin_vouchers_reseller.balance_available, "
                . "plugin_vouchers_reseller.is_reseller "
                . "FROM users "
                . "LEFT JOIN plugin_vouchers_reseller ON users.id = plugin_vouchers_reseller.user_id "
                . "WHERE users.id = :id "
                . "LIMIT 1";
        $resellerDetails = $db->getRow($sQL, array(
            'id' => $gUserId,
        ));
        if ($resellerDetails) {
            $balance_available = $resellerDetails['balance_available'];
            $is_reseller = $resellerDetails['is_reseller'];
        }

        // prepare result
        $result = array();
        $result['error'] = false;
        $result['msg'] = '';
        $result['html'] = $this->getRenderedTemplate('admin/ajax/account_balance_edit_form.html', array(
            'balance_available' => $balance_available,
            'is_reseller' => $is_reseller,
            'resellerDetails' => $resellerDetails,
                ), PLUGIN_DIRECTORY_ROOT . 'vouchers/views');

        // output response
        return $this->renderJson($result);
    }

    public function ajaxAccountBalanceEditProcess() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // get instance
        $pluginObj = PluginHelper::getInstance('vouchers');
        $balance_available = (float) $_REQUEST['balance_available'];
        $gUserId = (int) $_REQUEST['gUserId'];
        $is_reseller = (int) $_REQUEST['is_reseller'];

        // prepare result
        $result = array();
        $result['error'] = false;
        $result['msg'] = '';

        // validate submission
        if (_CONFIG_DEMO_MODE == true) {
            $result['error'] = true;
            $result['msg'] = AdminHelper::t("no_changes_in_demo_mode");
        }

        // should we attempt to send the newsletter?
        if ($result['error'] == false) {
            // setup logging
            LogHelper::setContext("plugin_vouchers");

            // update balance
            $resellerDetails = $db->getRow('SELECT id, balance_available '
                    . 'FROM plugin_vouchers_reseller '
                    . 'WHERE user_id = :id '
                    . 'LIMIT 1', array(
                'id' => (int) $gUserId,
            ));
            if ($resellerDetails) {
                $oldBalance = $resellerDetails['balance_available'];

                // update
                $pluginVouchersReseller = PluginVouchersReseller::loadOneById($resellerDetails['id']);
                $pluginVouchersReseller->balance_available = $balance_available;
                $pluginVouchersReseller->is_reseller = (int) $is_reseller;
                $pluginVouchersReseller->save();

                // set transaction log
                if (($balance_available - $oldBalance) != 0) {
                    $pluginObj->createResellerTransactionEntry($resellerDetails['id'], 'admin_balance_amendment', ($balance_available - $oldBalance), "Balance adjusted by admin from " . SITE_CONFIG_COST_CURRENCY_SYMBOL . $oldBalance . " to " . SITE_CONFIG_COST_CURRENCY_SYMBOL . $balance_available . ".");
                }

                // log
                LogHelper::info('Balance for user id #' . (int) $gUserId . ' updated to ' . $balance_available);
            }
            else {
                // insert
                $pluginVouchersReseller = PluginVouchersReseller::create();
                $pluginVouchersReseller->user_id = $gUserId;
                $pluginVouchersReseller->balance_available = $balance_available;
                $pluginVouchersReseller->is_reseller = (int) $is_reseller;
                $pluginVouchersReseller->save();

                // set transaction log
                if ($balance_available != 0) {
                    $pluginObj->createResellerTransactionEntry($gUserId, 'admin_balance_amendment', $balance_available, "Initial balance set by admin to " . SITE_CONFIG_COST_CURRENCY_SYMBOL . $balance_available . ".");
                }

                // log
                LogHelper::info('Balance for user id #' . (int) $gUserId . ' updated to ' . $balance_available);
            }

            // update confirmation message
            $result['msg'] = 'Voucher balance updated.';
        }

        // output response
        return $this->renderJson($result);
    }

}
