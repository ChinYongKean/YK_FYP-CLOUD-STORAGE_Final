<?php

namespace Plugins\Vouchers;

use App\Services\PluginConfig AS CorePluginConfig;

class PluginConfig extends CorePluginConfig
{
    /**
     * Setup the plugin config.
     *
     * @var array
     */
    public $config = array(
        'plugin_name' => 'Voucher Reseller',
        'folder_name' => 'vouchers',
        'plugin_description' => 'Enable your users to resell premium accounts by purchasing discounted voucher codes.',
        'plugin_version' => '7.0',
        'required_script_version' => '5.0',
        'database_sql' => 'offline/database.sql',
    );

}
