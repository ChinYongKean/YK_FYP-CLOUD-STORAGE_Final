<?php

namespace Plugins\Vouchers\Models;

use App\Core\Model;

class PluginVouchers extends Model
{
    
}
