<?php

namespace Plugins\Vouchers\Models;

use App\Core\Model;

class PluginVouchersReseller extends Model
{
    
}
