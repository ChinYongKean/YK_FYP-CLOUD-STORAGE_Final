<?php

namespace Plugins\Vouchers\Models;

use App\Core\Model;

class PluginVouchersDiscountRange extends Model
{
    
}
