<?php

namespace Plugins\Vouchers\Models;

use App\Core\Model;

class PluginVouchersResellerTransaction extends Model
{
    
}
