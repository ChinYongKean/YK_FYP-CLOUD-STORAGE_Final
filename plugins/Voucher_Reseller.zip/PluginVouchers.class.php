<?php

// plugin namespace

namespace Plugins\Vouchers;

// core includes
use App\Core\Database;
use App\Services\Plugin;
use App\Helpers\CoreHelper;
use Plugins\Vouchers\PluginConfig;
use Plugins\Vouchers\Models\PluginVouchers AS PluginVouchersModel;
use Plugins\Vouchers\Models\PluginVouchersResellerTransaction;
use Plugins\Vouchers\Models\PluginVouchersTopupOrder;

class PluginVouchers extends Plugin
{
    public $config = null;
    public $data = null;

    public function __construct() {
        // load plugin config
        $this->config = (new PluginConfig())->getPluginConfig();
        $this->settings = $this->getPluginSettings();
    }

    public function registerRoutes(\FastRoute\RouteCollector $r) {
        // register plugin routes
        $r->addRoute(['GET', 'POST'], '/' . ADMIN_FOLDER_NAME . '/plugin/' . $this->config['folder_name'] . '/settings', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/pluginSettings');
        $r->addRoute(['GET', 'POST'], '/' . ADMIN_FOLDER_NAME . '/voucher_manage', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/voucherManage');
        $r->addRoute(['GET', 'POST'], '/' . ADMIN_FOLDER_NAME . '/ajax/voucher_manage', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxVoucherManage');
        $r->addRoute(['POST'], '/' . ADMIN_FOLDER_NAME . '/ajax/voucher_manage_cancel', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxVoucherManageCancel');
        $r->addRoute(['GET'], '/' . ADMIN_FOLDER_NAME . '/manage_account_balance', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/manageAccountBalance');
        $r->addRoute(['GET', 'POST'], '/' . ADMIN_FOLDER_NAME . '/ajax/manage_account_balance', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxManageAccountBalance');
        $r->addRoute(['POST'], '/' . ADMIN_FOLDER_NAME . '/ajax/grant_reseller_process', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxGrantResellerProcess');
        $r->addRoute(['POST'], '/' . ADMIN_FOLDER_NAME . '/ajax/account_balance_edit_form', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxAccountBalanceEditForm');
        $r->addRoute(['POST'], '/' . ADMIN_FOLDER_NAME . '/ajax/account_balance_edit_process', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxAccountBalanceEditProcess');
        $r->addRoute(['GET'], '/resellers', '\plugins\\' . $this->config['folder_name'] . '\controllers\VouchersController/resellers');
        $r->addRoute(['GET', 'POST'], '/reseller_home', '\plugins\\' . $this->config['folder_name'] . '\controllers\VouchersController/resellerHome');
        $r->addRoute(['GET'], '/ajax/reseller_home_vouchers', '\plugins\\' . $this->config['folder_name'] . '\controllers\VouchersController/ajaxResellerHomeVouchers');
        $r->addRoute(['GET'], '/ajax/reseller_home_transactions', '\plugins\\' . $this->config['folder_name'] . '\controllers\VouchersController/ajaxResellerHomeTransactions');
        
        $r->addRoute(['GET'], '/vouchers/api', '\plugins\\' . $this->config['folder_name'] . '\controllers\VouchersController/api');
        $r->addRoute(['GET'], '/vouchers/export', '\plugins\\' . $this->config['folder_name'] . '\controllers\VouchersController/export');
        
        $r->addRoute(['GET'], '/vouchers/payment_complete', '\plugins\\' . $this->config['folder_name'] . '\controllers\VouchersController/paymentComplete');
        $r->addRoute(['POST'], '/vouchers/pay', '\plugins\\' . $this->config['folder_name'] . '\controllers\VouchersController/pay');
        $r->addRoute(['POST'], '/vouchers/payment_ipn', '\plugins\\' . $this->config['folder_name'] . '\controllers\VouchersController/paymentIpn');
    }

    public function getPluginDetails() {
        return $this->config;
    }

    public function uninstall() {
        // setup database
        $db = Database::getDatabase();

        // remove plugin specific tables
        $sQL = 'DROP TABLE plugin_vouchers';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_vouchers_discount_range';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_vouchers_reseller';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_vouchers_reseller_transaction';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_vouchers_topup_order';
        $db->query($sQL);

        return parent::uninstall();
    }

    public function getStatusList() {
        return array('available', 'used');
    }

    public function generateVouchers($reseller_id, $package_pricing_id, $voucher_quantity, $purchase_source = 'user', $voucherPurchasePrice = 0) {
        $voucherCodes = array();

        // calculate purchase price
        if ($purchase_source == 'admin') {
            $voucherPurchasePrice = 0;
        }

        // loop quantity
        for ($tracker = 1; $tracker <= $voucher_quantity; $tracker++) {
            // create voucher code
            $voucherCode = $this->createVoucherCode();

            // insert into the database
            $pluginVouchers = PluginVouchersModel::create();
            $pluginVouchers->voucher = $voucherCode;
            $pluginVouchers->user_level_pricing_id = $package_pricing_id;
            $pluginVouchers->purchase_date = CoreHelper::sqlDateTime();
            $pluginVouchers->purchase_price = $voucherPurchasePrice;
            $pluginVouchers->purchase_user_id = $reseller_id;
            $rs = $pluginVouchers->save();
            if ($rs) {
                $voucherCodes[] = $voucherCode;
            }
        }

        return $voucherCodes;
    }

    public function createVoucherCode() {
        $voucher_length = (int) $this->settings['voucher_length'];
        $voucher_prepend = $this->settings['voucher_prepend'];
        if ($voucher_length == 0) {
            return false;
        }

        // create random string
        $characters = '23456789ABCDEFGHJKLMNPQRSTUVWXTZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $voucher_length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }

        return $voucher_prepend . $randomString;
    }

    public function cancelVouchers($voucherIdsArr) {
        // setup database
        $db = Database::getDatabase();

        // make sure we have a list of ids
        $sanitised = array();
        foreach ($voucherIdsArr AS $voucherId) {
            $sanitised[] = (int) $voucherId;
        }

        // delete the vouhcers
        return $db->query('DELETE '
                        . 'FROM plugin_vouchers '
                        . 'WHERE id IN (' . implode(',', $sanitised) . ') '
                        . 'AND status=\'available\'');
    }

    public function getAccountPackages() {
        // setup database
        $db = Database::getDatabase();

        // valid package ids
        $packageIds = $this->settings['available_package_pricing_id'];

        // pre-load user types
        $userTypes = $db->getRows('SELECT id, level_id, label, level_type '
                . 'FROM user_level '
                . 'ORDER BY label');
        $available_package_pricing = array();
        foreach ($userTypes AS $userType) {
            // only show 'paid' user packages
            if ($userType['level_type'] != 'paid') {
                continue;
            }

            // get pricing
            $pricing = $db->getRows('SELECT user_level_pricing.id, user_level_pricing.pricing_label, '
                    . 'user_level_pricing.period, user_level_pricing.price, '
                    . 'user_level.label '
                    . 'FROM user_level_pricing '
                    . 'LEFT JOIN user_level ON user_level_pricing.user_level_id = user_level.id '
                    . 'WHERE user_level_id = ' . (int) $userType['id'] . ' '
                    . 'AND user_level_pricing.id IN (' . implode(',', $packageIds) . ') '
                    . 'ORDER BY user_level_pricing.price');
            if (!$pricing) {
                continue;
            }

            foreach ($pricing AS $pricingItem) {
                $available_package_pricing[$pricingItem['id']] = $pricingItem;
            }
        }

        return $available_package_pricing;
    }

    public function apiErrorExit($errorCode, $errorMessage) {
        $rs = array();
        $rs['error'] = true;
        $rs['error_code'] = $errorCode;
        $rs['error_message'] = $errorMessage;
        
        return $rs;
    }

    public function createResellerTransactionEntry($reseller_user_id, $transaction_type, $amount, $description) {
        // insert into the database
        $pluginVouchersResellerTransaction = PluginVouchersResellerTransaction::create();
        $pluginVouchersResellerTransaction->reseller_user_id = $reseller_user_id;
        $pluginVouchersResellerTransaction->transaction_type = $transaction_type;
        $pluginVouchersResellerTransaction->amount = $amount;
        $pluginVouchersResellerTransaction->description = $description;
        $pluginVouchersResellerTransaction->date_created = CoreHelper::sqlDateTime();

        return $pluginVouchersResellerTransaction->save();
    }

    public function createTopupOrder($user_id, $amount) {
        // setup database
        $db = Database::getDatabase();

        // load username for later
        $username = $db->getValue('SELECT username '
                . 'FROM users '
                . 'WHERE id = :id '
                . 'LIMIT 1', array(
                    'id' => $user_id,
                ));
        if (!$username) {
            return false;
        }

        // create order hash for tracking
        $payment_hash = md5(microtime() . $user_id);

        // add order to the database
        $pluginVouchersTopupOrder = PluginVouchersTopupOrder::create();
        $pluginVouchersTopupOrder->user_id = $user_id;
        $pluginVouchersTopupOrder->payment_hash = $payment_hash;
        $pluginVouchersTopupOrder->amount = $amount;
        $pluginVouchersTopupOrder->description = "Reseller balance topup of " . SITE_CONFIG_COST_CURRENCY_SYMBOL . $amount . " for " . $username;
        $pluginVouchersTopupOrder->order_status = 'pending';
        $pluginVouchersTopupOrder->date_created = date("Y-m-d H:i:s", time());
        if ($pluginVouchersTopupOrder->save()) {
            return $pluginVouchersTopupOrder;
        }

        return false;
    }

}
