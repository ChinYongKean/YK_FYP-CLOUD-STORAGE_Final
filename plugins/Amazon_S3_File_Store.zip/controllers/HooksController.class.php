<?php

namespace Plugins\Filestores3\Controllers;

use App\Core\BaseController;
use App\Helpers\CoreHelper;
use App\Helpers\FileHelper;
use App\Helpers\PluginHelper;
use App\Helpers\LogHelper;
use App\Helpers\ThemeHelper;
use App\Models\File;

class HooksController extends BaseController
{

    public function storeFile($params = null) {
        // load plugin details
        $pluginDetails = PluginHelper::pluginSpecificConfiguration('filestores3');
        $pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);

        /*
         * available params
         * 
         * $params['file_path'];
         * $params['file'];
         * $params['uploadServerDetails'];
         * $params['fileUpload'];
         * $params['newFilename'];
         * $params['tmpFile'];
         * $params['uploader'];
         * */

        $fileUpload = $params['fileUpload'];
        $uploadServerDetails = $params['uploadServerDetails'];
        $file_size = 0;
        if ($uploadServerDetails['serverType'] == 'amazon_s3') {
            // increase server limits
            set_time_limit(60 * 60 * 6); // 6 hours
            ini_set('memory_limit', '2000M');

            // get required classes
            require_once(PLUGIN_DIRECTORY_ROOT . 'filestores3/services/S3.php');

            // check for CURL
            if (!extension_loaded('curl') && !@dl(PHP_SHLIB_SUFFIX == 'so' ? 'curl.so' : 'php_curl.dll')) {
                // handle error
                $fileUpload->error = 'Could not load curl extension for S3 file server.';
            }
            else {
                // instantiate the class
                $s3 = new \S3($pluginSettings['aws_access_key'], $pluginSettings['aws_secret_key']);
                if (!$s3) {
                    // failed connecting
                    $fileUpload->error = 'Could not connect to S3 file server.';
                }
                else {
                    // path on s3
                    $newFilePath = substr($params['newFilename'], 0, 2) . '/' . $params['newFilename'];

                    // upload the files
                    $s3->setRegion($pluginSettings['region']);
                    $s3->setSignatureVersion($pluginSettings['api_version']);
                    $rs = $s3->putObjectFile($params['tmpFile'], $pluginSettings['bucket_name'], $newFilePath);
                    if (!$rs) {
                        // failed upload
                        $fileUpload->error = 'Failed upload to S3 file server. Please try again later.';
                    }
                    else {
                        // upload done
                        $file_size = filesize($params['tmpFile']);
                        if(!isset($params['keepTmpFile']) || ($params['keepTmpFile'] === false)) {
                            @unlink($params['tmpFile']);
                        }
                    }
                }
            }

            // on actioned
            $params['fileUpload'] = $fileUpload;
            $params['file_size'] = $file_size;
            $params['file_path'] = $newFilePath;
            $params['actioned'] = true;
            
            return $params;
        }

        return false;
    }

    public function adminServerManageAddFormList($params = null) {
        // load plugin details
        $pluginDetails = PluginHelper::pluginSpecificConfiguration('filestores3');
        $pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);

        return array(
            'filestore_key' => 'amazon_s3',
            'filestore_label' => 'Amazon S3 (bucket: ' . (isset($pluginSettings['bucket_name']) ? $pluginSettings['bucket_name'] : 'not set') . ')',
        );
    }

    public function fileDownloadGetFileContent($params = null) {
        // load plugin details
        $pluginDetails = PluginHelper::pluginSpecificConfiguration('filestores3');
        $pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);

        /*
         * available params
         * 
         * $params['fileContent'];
         * $params['downloadTracker'];
         * $params['forceDownload'];
         * $params['file'];
         * $params['doPluginIncludes'];
         * $params['storageType'];
         * $params['seekStart'];
         * $params['seekEnd'];
         * $params['speed'];
         * $params['fileOwnerUserId'];
         * $params['userPackageId'];
         * $params['downloadToken'];
         * $params['fileTransfer'];
         * */

        $file = $params['file'];
        $storageType = $params['storageType'];
        $forceDownload = $params['forceDownload'];
        if ($storageType == 'amazon_s3') {
            // get required classes
            require_once(PLUGIN_DIRECTORY_ROOT . 'filestores3/services/S3.php');

            // check for CURL
            if (!extension_loaded('curl') && !@dl(PHP_SHLIB_SUFFIX == 'so' ? 'curl.so' : 'php_curl.dll')) {
                // handle error
                $fileUpload->error = 'Could not load curl extension for S3 file server.';
            }
            else {
                // instantiate the class
                $s3 = new \S3($pluginSettings['aws_access_key'], $pluginSettings['aws_secret_key']);
                if (!$s3) {
                    // failed connecting
                    $fileUpload->error = 'Could not connect to S3 file server.';
                }
                else {
                    // set region and other info
                    $s3->setRegion($pluginSettings['region']);
                    $s3->setSignatureVersion($pluginSettings['api_version']);
                    
                    // load plugin details
                    $pluginObj = PluginHelper::getInstance('filestores3');
                    $pluginDetails = PluginHelper::pluginSpecificConfiguration('filestores3');
                    $pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);

                    // use direct url if the option is enabled
                    if ((int)$pluginSettings['direct_downloads'] === 1 && $forceDownload == true) {
                        // valid for 3 hours
                        $url = $s3->getAuthenticatedURL('yetishare-v5-beta-test.s3.amazonaws.com', $file->getLocalFilePath(), (60*60*3), true, ((int)$pluginSettings['direct_downloads_use_https'] === 1), array(
                            'response-content-disposition' => ($params['fileTransfer']===true?'attachment; ':'').'filename='.$file->originalFilename,
                            'response-content-type' => $file->fileType,
                        ));
                        LogHelper::info("Using direct link to file in storage: ".$url);
                        
                        // update stats before we hand off to Wasabi
                        $file->postDownloadStats($params['fileOwnerUserId'], $params['userPackageId']);
                        
                        // finish off any plugins
                        $file->postDownloadComplete($params['forceDownload'], $params['fileOwnerUserId'], $params['userPackageId'], $params['doPluginIncludes'], $params['downloadToken'], $params['downloadTracker']);

                        // redirect to url
                        return $this->redirect($url);
                    }

                    // get file content in proxy mode
                    $s3Object = $s3->getObject($pluginSettings['bucket_name'], $file->getLocalFilePath(), false, (int) $params['seekStart']);
                    if ((int) $s3Object->code === 200 || (int) $s3Object->code === 206) {
                        if ($forceDownload == true) {
                            echo $s3Object->body;
                        }
                        else {
                            $fileContent = $s3Object->body;
                        }
                    }
                }
            }

            // on actioned
            $params['fileContent'] = $fileContent;
            $params['actioned'] = true;
            
            return $params;
        }

        return false;
    }
    
    public function processFileRemoval($params = null) {
        /*
         * available params
         * 
         * $params['actioned'];
         * $params['uploadServerDetails'];
         * $params['queueRow'];
         * $params['storageType'];
         * $params['filePath'];
         * */

        $storageType = $params['storageType'];
        if ($storageType == 'amazon_s3') {
            // prepare variables
            $queueRow = $params['queueRow'];
            $filePath = $params['filePath'];

            // get required classes
            require_once(PLUGIN_DIRECTORY_ROOT . 'filestores3/services/S3.php');

            // check for CURL
            if (!extension_loaded('curl') && !@dl(PHP_SHLIB_SUFFIX == 'so' ? 'curl.so' : 'php_curl.dll')) {
                // handle error
                $params['errorMsg'] = 'Could not load curl extension for S3 file server.';
            }
            else {
                // load plugin details
                $pluginObj = PluginHelper::getInstance('filestores3');
                $pluginDetails = PluginHelper::pluginSpecificConfiguration('filestores3');
                $pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);

                // instantiate the class
                $s3 = new \S3($pluginSettings['aws_access_key'], $pluginSettings['aws_secret_key']);
                if (!$s3) {
                    // failed connecting
                    $params['errorMsg'] = 'Could not connect to S3 file server.';
                }
                else {
                    // set region and other info
                    $s3->setRegion($pluginSettings['region']);
                    $s3->setSignatureVersion($pluginSettings['api_version']);

                    // delete the file
                    $rs = $s3->deleteObject($pluginSettings['bucket_name'], $filePath);
                    if (!$rs) {
                        // failed delete
                        $params['errorMsg'] = 'Failed to remove file from S3 file server. Please try again later.';
                    }
                }
            }

            // on actioned
            $params['actioned'] = true;
            
            return $params;
        }
        
        return false;
    }

}
