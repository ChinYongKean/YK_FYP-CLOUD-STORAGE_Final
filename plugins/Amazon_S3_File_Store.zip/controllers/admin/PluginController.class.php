<?php

namespace Plugins\Filestores3\Controllers\Admin;

use App\Core\Database;
use App\Controllers\Admin\PluginController AS CorePluginController;
use App\Helpers\AdminHelper;
use App\Helpers\PluginHelper;
use App\Models\Plugin;

class PluginController extends CorePluginController
{

    public function pluginSettings() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // load plugin details
        $folderName = 'filestores3';
        $plugin = Plugin::loadOneByClause('folder_name = :folder_name', array(
                    'folder_name' => $folderName,
        ));

        if (!$plugin) {
            return $this->redirect(ADMIN_WEB_ROOT . '/plugin_manage?error=' . urlencode('There was a problem loading the plugin details.'));
        }

        // prepare variables
        $plugin_enabled = (int) $plugin->plugin_enabled;
        $aws_access_key = '';
        $aws_secret_key = '';
        $bucket_name = '';
        $region = '';
        $api_version = 'v4';
        $direct_downloads = 1;
        $direct_downloads_use_https = 1;

        // load existing settings
        if (strlen($plugin->plugin_settings)) {
            $plugin_settings = json_decode($plugin->plugin_settings, true);
            if ($plugin_settings) {
                $aws_access_key = $plugin_settings['aws_access_key'];
                $aws_secret_key = $plugin_settings['aws_secret_key'];
                $bucket_name = $plugin_settings['bucket_name'];
                $region = $plugin_settings['region'];
                $api_version = strlen($plugin_settings['api_version']) ? $plugin_settings['api_version'] : 'v2';
                $direct_downloads = strlen($plugin_settings['direct_downloads']) ? (int) $plugin_settings['direct_downloads'] : 1;
                $direct_downloads_use_https = strlen($plugin_settings['direct_downloads_use_https']) ? (int) $plugin_settings['direct_downloads_use_https'] : 1;
            }
        }

        // handle page submissions
        if ($request->request->has('submitted')) {
            // get variables
            $plugin_enabled = (int) $request->request->get('plugin_enabled');
            $plugin_enabled = $plugin_enabled != 1 ? 0 : 1;
            $aws_access_key = trim($_REQUEST['aws_access_key']);
            $aws_secret_key = trim($_REQUEST['aws_secret_key']);
            $bucket_name = trim($_REQUEST['bucket_name']);
            $region = $_REQUEST['region'];
            $api_version = trim($_REQUEST['api_version']);
            $direct_downloads = (int) $_REQUEST['direct_downloads'];
            $direct_downloads_use_https = (int) $_REQUEST['direct_downloads_use_https'];

            // validate submission
            if (_CONFIG_DEMO_MODE == true) {
                AdminHelper::setError(AdminHelper::t('no_changes_in_demo_mode', 'No change permitted in demo mode.'));
            }
            if ($plugin_enabled === 1) {
                if (strlen($aws_access_key) == 0) {
                    AdminHelper::setError(AdminHelper::t("plugin_filestores3_please_enter_your_aws_access_key", "Please enter your AWS access key."));
                }
                elseif (strlen($aws_secret_key) == 0) {
                    AdminHelper::setError(AdminHelper::t("plugin_filestores3_please_enter_your_aws_secret_key", "Please enter your AWS secret key."));
                }
                elseif (strlen($bucket_name) == 0) {
                    AdminHelper::setError(AdminHelper::t("plugin_filestores3_please_enter_your_bucket_name", "Please enter your bucket name."));
                }

                // try to authenticate the details
                if (AdminHelper::isErrors() == false) {
                    // get required classes
                    require_once(PLUGIN_DIRECTORY_ROOT . 'filestores3/services/S3.php');

                    // check that we can connect
                    $s3 = new \S3($aws_access_key, $aws_secret_key);
                    if (!$s3) {
                        // failed connecting
                        AdminHelper::setError(AdminHelper::t("plugin_filestores3_could_not_autheticate_access_details", "Could not connect to S3 using the keys you entered, please try again."));
                    }
                    else {
                        // check bucket
                        $s3->setRegion($region);
                        $s3->setSignatureVersion($api_version);
                        $s3->setExceptions(true);
                        try {
                            $s3->getBucket($bucket_name);
                        }
                        catch (\S3Exception $ex) {
                            // failed getting bucket
                            AdminHelper::setError($ex->getMessage());
                        }
                    }
                }
            }

            // update the settings
            if (AdminHelper::isErrors() == false) {
                // compile new settings
                $settingsArr = array();
                $settingsArr['aws_access_key'] = $aws_access_key;
                $settingsArr['aws_secret_key'] = $aws_secret_key;
                $settingsArr['bucket_name'] = $bucket_name;
                $settingsArr['region'] = $region;
                $settingsArr['api_version'] = $api_version;
                $settingsArr['direct_downloads'] = $direct_downloads;
                $settingsArr['direct_downloads_use_https'] = $direct_downloads_use_https;

                // update the plugin settings
                $plugin->plugin_enabled = $plugin_enabled;
                $plugin->plugin_settings = json_encode($settingsArr);
                $plugin->save();

                // update plugin config
                PluginHelper::loadPluginConfigurationFiles(true);

                // set onscreen alert
                AdminHelper::setSuccess('Plugin settings updated.');
            }
        }

        if (_CONFIG_DEMO_MODE == true) {
            $aws_secret_key = '**********************************';
        }

        // load template
        return $this->render('admin/plugin_settings.html', array(
                    'pluginName' => $plugin->plugin_name,
                    'yesNoOptions' => array(
                        0 => 'No',
                        1 => 'Yes'),
                    'apiVersionOptions' => array(
                        'v2' => 'v2',
                        'v4' => 'v4 (Try first if you\'re unsure)'),
                    'regionOptions' => array(
                        'us-east-2' => 'US East (Ohio)',
                        'us-east-1' => 'US East (N. Virginia)',
                        'us-west-1' => 'US West (N. California)',
                        'us-west-2' => 'US West (Oregon)',
                        'af-south-1' => 'Africa (Cape Town)',
                        'ap-east-1' => 'Asia Pacific (Hong Kong)',
                        'ap-south-1' => 'Asia Pacific (Mumbai)',
                        'ap-northeast-3' => 'Asia Pacific (Osaka-Local)',
                        'ap-northeast-2' => 'Asia Pacific (Seoul)',
                        'ap-southeast-1' => 'Asia Pacific (Singapore)',
                        'ap-southeast-2' => 'Asia Pacific (Sydney)',
                        'ap-northeast-1' => 'Asia Pacific (Tokyo)',
                        'ca-central-1' => 'Canada (Central)',
                        'cn-north-1' => 'China (Beijing)',
                        'cn-northwest-1' => 'China (Ningxia)',
                        'eu-central-1' => 'Europe (Frankfurt)',
                        'eu-west-1' => 'Europe (Ireland)',
                        'eu-west-2' => 'Europe (London)',
                        'eu-south-1' => 'Europe (Milan)',
                        'eu-west-3' => 'Europe (Paris)',
                        'eu-north-1' => 'Europe (Stockholm)',
                        'me-south-1' => 'Middle East (Bahrain)',
                        'sa-east-1' => 'South America (São Paulo)'),
                    'plugin_enabled' => $plugin_enabled,
                    'aws_access_key' => $aws_access_key,
                    'aws_secret_key' => $aws_secret_key,
                    'bucket_name' => $bucket_name,
                    'region' => $region,
                    'api_version' => $api_version,
                    'direct_downloads' => $direct_downloads,
                    'direct_downloads_use_https' => $direct_downloads_use_https,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

}
