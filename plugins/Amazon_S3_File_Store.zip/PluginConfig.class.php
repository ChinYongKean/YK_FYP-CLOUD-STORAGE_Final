<?php

namespace Plugins\Filestores3;

use App\Services\PluginConfig AS CorePluginConfig;

class PluginConfig extends CorePluginConfig
{
    /**
     * Setup the plugin config.
     *
     * @var array
     */
    public $config = array(
        'plugin_name' => 'Amazon S3 File Storage',
        'folder_name' => 'filestores3',
        'plugin_description' => 'Store all your files on Amazon S3.',
        'plugin_version' => '8.0',
        'required_script_version' => '5.0',
    );

}
