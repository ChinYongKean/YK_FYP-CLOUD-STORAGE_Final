<?php

// plugin namespace
namespace Plugins\Filestores3;

// core includes
use App\Services\Plugin;
use App\Helpers\CoreHelper;
use App\Helpers\FileActionHelper;
use App\Helpers\FileHelper;
use App\Models\File;
use Plugins\Filestores3\PluginConfig;

class PluginFilestores3 extends Plugin
{
    public $config = null;
    public $data = null;
    public $settings = null;

    public function __construct() {
        // load plugin config
        $this->config = (new PluginConfig())->getPluginConfig();
    }
    
    public function registerRoutes(\FastRoute\RouteCollector $r) {
        // register plugin routes
        $r->addRoute(['GET', 'POST'], '/'.ADMIN_FOLDER_NAME.'/plugin/'.$this->config['folder_name'].'/settings', '\plugins\\'.$this->config['folder_name'].'\controllers\admin\PluginController/pluginSettings');
    }
    
    public function getPluginDetails() {
        return $this->config;
    }

    public function install() {
        return parent::install();
    }
}
