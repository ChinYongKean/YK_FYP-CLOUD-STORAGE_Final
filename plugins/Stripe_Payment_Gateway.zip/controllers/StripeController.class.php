<?php

namespace Plugins\Stripe\Controllers;

use App\Core\BaseController;
use App\Core\Database;
use App\Models\File;
use App\Models\Order;
use App\Models\PaymentLog;
use App\Models\User;
use App\Helpers\CoreHelper;
use App\Helpers\LogHelper;
use App\Helpers\OrderHelper;
use App\Helpers\PluginHelper;
use App\Helpers\UserHelper;

class StripeController extends BaseController
{

    public function upgradeBox($params = array()) {
        // pickup request for later
        $request = $this->getRequest();

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('stripe');
        $settings = $pluginConfig['data']['plugin_settings'];
        $settingsArr = json_decode($settings, true);

        // load pricing info
        $db = Database::getDatabase();
        $user_level_pricing = $db->getRow('SELECT * '
                . 'FROM user_level_pricing '
                . 'WHERE id = :id '
                . 'LIMIT 1', array(
            'id' => (int) $params['user_level_pricing_id'],
        ));
        $key = $user_level_pricing['id'];
        $amount = $user_level_pricing['price'];

        // load user
        $Auth = $this->getAuth();
        $user = User::loadOneById($Auth->id);

        // load template
        return $this->render('upgrade_box.html', array_merge($params, array(
                    'folder_name' => 'stripe',
                    'gateway_label' => 'Stripe',
                    'i' => $request->query->has('i') ? $request->query->get('i') : '',
                    'f' => $request->query->has('f') ? $request->query->get('f') : '',
                    'key' => $key,
                    'amount' => $amount,
                    'user' => $user,
                    'settingsArr' => $settingsArr,
                    'from' => $request->query->has('from') ? $request->query->get('from') : '',
                    'ulpid' => $request->query->has('ulpid') ? $request->query->get('ulpid') : '',
                        )), PLUGIN_DIRECTORY_ROOT . 'stripe/views');
    }

    public function pay($params = array()) {
        // pickup request for later
        $request = json_decode(file_get_contents('php://input'), true);
        $db = Database::getDatabase();

        // load dependencies
        require_once(PLUGIN_DIRECTORY_ROOT . 'stripe/libraries/stripe/init.php');

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('stripe');
        $pluginSettings = $pluginConfig['data']['plugin_settings'];

        $payment_type = 'card';
        $secret_key = '';
        $publishable_key = '';
        if (strlen($pluginSettings)) {
            $pluginSettingsArr = json_decode($pluginSettings, true);
            $payment_type = isset($pluginSettingsArr['payment_type']) ? $pluginSettingsArr['payment_type'] : $payment_type;
            $secret_key = $pluginSettingsArr['secret_key'];
            $publishable_key = $pluginSettingsArr['publishable_key'];
        }

        \Stripe\Stripe::setApiKey($secret_key);

        if (!isset($request['user_level_pricing_id'])) {
            // fail
            return $this->renderJson([
                        'error' => array(
                            'message' => 'Failed to create order, please try again later.'
                        ),
            ]);
        }

        // require login
        if ((int) $request['i']) {
            $user = User::loadOneByClause('identifier = :identifier', array(
                        'identifier' => $request['i']
            ));
            if (!$user) {
                // fail
                return $this->renderJson([
                            'error' => array(
                                'message' => 'Failed to create order, please try again later.'
                            ),
                ]);
            }

            // setup variables for later
            $userId = $user->id;
            $username = $user->username;
            $userEmail = $user->email;
        }
        else {
            if (($response = $this->requireLogin('/register', 1)) !== false) {
                // fallback
                return $this->renderJson([
                            'redirect' => true,
                            'error' => array(
                                'message' => 'Failed to create order, please try again later.'
                            ),
                ]);
            }

            // setup variables for later
            $Auth = $this->getAuth();
            $userId = $Auth->id;
            $username = $Auth->username;
            $userEmail = $Auth->email;
        }

        $userLevelPricingId = (int) $request['user_level_pricing_id'];

        // check if we have a referring file
        $fileId = null;
        if (isset($request['f'])) {
            $file = File::loadOneByShortUrl($request->request->get('f'));
            if ($file) {
                $fileId = $file->id;
            }
        }

        // create order entry
        $order = OrderHelper::createByPackageId($userId, $userLevelPricingId, $fileId);
        if ($order) {
            $userLevelPricing = $db->getRow('SELECT * '
                    . 'FROM user_level_pricing '
                    . 'WHERE id = :id '
                    . 'LIMIT 1', array(
                'id' => (int) $userLevelPricingId,
            ));
            $chargeDays = CoreHelper::convertStringDatePeriodToDays($userLevelPricing['period']);

            try {
                $checkout_session = \Stripe\Checkout\Session::create([
                            'customer_email' => $userEmail,
                            'payment_method_types' => [$payment_type],
                            'line_items' => [
                                [
                                    'name' => $order->description,
                                    'amount' => $order->amount * 100,
                                    'currency' => strtolower(SITE_CONFIG_COST_CURRENCY_CODE),
                                    'quantity' => 1,
                                ]
                            ],
                            'mode' => 'payment',
                            'success_url' => WEB_ROOT . '/payment_complete',
                            'cancel_url' => WEB_ROOT . '/upgrade',
                            'client_reference_id' => $order->payment_hash,
                ]);
            }
            catch (\Exception $e) {
                // handle failures
                return $this->renderJson([
                            'error' => array(
                                'message' => $e->getMessage()
                            ),
                ]);
            }

            return $this->renderJson(['id' => $checkout_session->id]);
        }

        // fallback
        return $this->renderJson([
                    'error' => array(
                        'message' => 'Failed to create order, please try again later.'
                    ),
        ]);
    }

    public function paymentIpn($params = array()) {
        // pickup request for later
        $request = $this->getRequest();
        $payload = @file_get_contents('php://input');

        // log response
        LogHelper::setContext('stripe');
        LogHelper::info('Received called back on IPN: ' . $payload);

        // load dependencies
        require_once(PLUGIN_DIRECTORY_ROOT . 'stripe/libraries/stripe/init.php');

        // logs
        LogHelper::info('Loaded Stripe library.');

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('stripe');
        $pluginSettings = $pluginConfig['data']['plugin_settings'];

        $secret_key = '';
        $publishable_key = '';
        $signing_secret = '';
        if (strlen($pluginSettings)) {
            $pluginSettingsArr = json_decode($pluginSettings, true);
            $secret_key = $pluginSettingsArr['secret_key'];
            $publishable_key = $pluginSettingsArr['publishable_key'];
            $signing_secret = $pluginSettingsArr['signing_secret'];
        }

        // Set your secret key. Remember to switch to your live secret key in production!
        // See your keys here: https://dashboard.stripe.com/account/apikeys
        \Stripe\Stripe::setApiKey($secret_key);

        // logs
        LogHelper::info('Instantiated Stripe library.');

        $sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'];
        $event = null;

        // logs
        LogHelper::info('Found Stripe signature header: ' . $sig_header);

        try {
            $event = \Stripe\Webhook::constructEvent(
                            $payload, $sig_header, $signing_secret
            );
        }
        catch (\UnexpectedValueException $e) {
            // logs
            LogHelper::error('UnexpectedValueException exception.');

            // Invalid payload
            return $this->renderEmpty200Response();
        }
        catch (\Stripe\Exception\SignatureVerificationException $e) {
            // logs
            LogHelper::error('SignatureVerificationException exception.');

            // Invalid signature
            return $this->renderEmpty200Response();
        }

        // Handle the checkout.session.completed event
        if ($event->type == 'checkout.session.completed') {
            $session = $event->data->object;

            // logs
            LogHelper::info('Reached checkout.session.completed (1)');

            // Fulfill the purchase
            return $this->completeOrder($session);
        }

        switch ($event->type) {
            case 'checkout.session.completed':
                $session = $event->data->object;

                // logs
                LogHelper::info('Reached checkout.session.completed (2)');
                LogHelper::info('Payment status: ' . $session->payment_status);

                // Check if the order is paid (e.g., from a card payment)
                //
                // A delayed notification payment will have an `unpaid` status, as
                // you're still waiting for funds to be transferred from the customer's
                // account.
                if ($session->payment_status == 'paid') {
                    // Fulfill the purchase
                    return $this->completeOrder($session);
                }

                break;

            case 'checkout.session.async_payment_succeeded':
                $session = $event->data->object;

                // logs
                LogHelper::info('Reached checkout.session.async_payment_succeeded');

                // Fulfill the purchase
                return $this->completeOrder($session);

                break;

            case 'checkout.session.async_payment_failed':
                $session = $event->data->object;

                // logs
                LogHelper::info('Reached checkout.session.async_payment_failed');

                break;
        }

        return $this->renderEmpty200Response();
    }

    private function completeOrder($session) {
        // pickup tracker
        $paymentTracker = $session->client_reference_id;

        // log
        LogHelper::info('Order is complete, loading based on order tracker "' . $paymentTracker . '"');

        // load order
        $order = OrderHelper::loadByPaymentTracker($paymentTracker);
        if ($order) {
            // log
            LogHelper::info('Loaded order id "' . $order->id . '" - ' . print_r($order, true));

            // make sure the order is pending
            if ($order->order_status == 'completed') {
                // order has already been completed
                LogHelper::info('Failed - order has already been completed');

                return $this->renderEmpty200Response();
            }

            $extendedDays = $order->days;
            $userId = $order->user_id;
            $upgradeUserId = $order->upgrade_user_id;
            $orderId = $order->id;

            // retain all posted gateway parameters
            $gatewayVars = "";
            foreach ($_REQUEST AS $k => $v) {
                $gatewayVars .= $k . " => " . $v . "\n";
            }

            // insert payment log
            $paymentLog = PaymentLog::create();
            $paymentLog->user_id = $userId;
            $paymentLog->date_created = date("Y-m-d H:i:s", time());
            $paymentLog->amount = $session->amount_total / 100;
            $paymentLog->currency_code = $session->currency;
            $paymentLog->from_email = $session->customer_email;
            $paymentLog->to_email = '';
            $paymentLog->description = $order->description;
            $paymentLog->request_log = $gatewayVars;
            $paymentLog->payment_method = 'Stripe';
            $paymentLog->save();

            // make sure the amount paid matched what we expect
            if ($paymentLog->amount != $order->amount) {
                // order amounts did not match
                LogHelper::info('Failed - order amounts did not match (RCD: ' . $paymentLog->amount . ' vs EXP: ' . $order->amount . ')');

                return $this->renderEmpty200Response();
            }

            // update order status to paid
            $order->order_status = 'completed';
            if ($order->save() === false) {
                // failed to update order
                LogHelper::info('Failed - failed to update order');

                return $this->renderEmpty200Response();
            }

            // log
            LogHelper::info('Updated order, extending account.');

            // extend/upgrade user
            $rs = UserHelper::upgradeUserByPackageId($userId, $order);
            if ($rs === false) {
                // failed to update user
                LogHelper::info('Failed - failed to update user');

                return $this->renderEmpty200Response();
            }

            // log
            LogHelper::info('Account upgrade process complete.');

            // append any plugin includes
            PluginHelper::callHook('postUpgradePaymentIpn', array(
                'order' => $order,
            ));
        }
        else {
            LogHelper::error('Could not load order based on payment tracker.');
        }

        return true;
    }

}
