<?php

namespace Plugins\Stripe\Controllers\Admin;

use App\Core\Database;
use App\Controllers\Admin\PluginController AS CorePluginController;
use App\Helpers\AdminHelper;
use App\Helpers\PluginHelper;
use App\Models\Plugin;

class PluginController extends CorePluginController
{

    public function pluginSettings() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // load plugin details
        $folderName = 'stripe';
        $plugin = Plugin::loadOneByClause('folder_name = :folder_name', array(
                    'folder_name' => $folderName,
        ));

        if (!$plugin) {
            return $this->redirect(ADMIN_WEB_ROOT . '/plugin_manage?error=' . urlencode('There was a problem loading the plugin details.'));
        }

        // prepare variables
        $plugin_enabled = (int) $plugin->plugin_enabled;
        $payment_type = 'card';
        $secret_key = '';
        $publishable_key = '';
        $signing_secret = '';

        // load existing settings
        if (strlen($plugin->plugin_settings)) {
            $plugin_settings = json_decode($plugin->plugin_settings, true);
            if ($plugin_settings) {
                $payment_type = isset($plugin_settings['payment_type'])?$plugin_settings['payment_type']:$payment_type;
                $secret_key = $plugin_settings['secret_key'];
                $publishable_key = $plugin_settings['publishable_key'];
                $signing_secret = $plugin_settings['signing_secret'];
                if (_CONFIG_DEMO_MODE == true) {
                    $secret_key = '[hidden]';
                    $publishable_key = '[hidden]';
                    $signing_secret = '[hidden]';
                }
            }
        }

        // handle page submissions
        if ($request->request->has('submitted')) {
            // get variables
            $plugin_enabled = (int) $request->request->get('plugin_enabled');
            $plugin_enabled = $plugin_enabled != 1 ? 0 : 1;
            $payment_type = $_REQUEST['payment_type'];
            $secret_key = trim($_REQUEST['secret_key']);
            $publishable_key = trim($_REQUEST['publishable_key']);
            $signing_secret = trim($_REQUEST['signing_secret']);

            // validate submission
            if (_CONFIG_DEMO_MODE == true) {
                AdminHelper::setError(AdminHelper::t('no_changes_in_demo_mode', 'No change permitted in demo mode.'));
            }
            elseif (strlen($secret_key) == 0) {
                AdminHelper::setError(AdminHelper::t("please_enter_your_secret_key", "Please enter your Stripe API secret key."));
            }

            // update the settings
            if (AdminHelper::isErrors() == false) {
                // compile new settings
                $settingsArr = array();
                $settingsArr['payment_type'] = $payment_type;
                $settingsArr['secret_key'] = $secret_key;
                $settingsArr['publishable_key'] = $publishable_key;
                $settingsArr['signing_secret'] = $signing_secret;

                // update the plugin settings
                $plugin->plugin_enabled = $plugin_enabled;
                $plugin->plugin_settings = json_encode($settingsArr);
                $plugin->save();

                // set onscreen alert
                PluginHelper::loadPluginConfigurationFiles(true);
                AdminHelper::setSuccess('Plugin settings updated.');
            }
        }

        // load template
        return $this->render('admin/plugin_settings.html', array(
                    'pluginName' => $plugin->plugin_name,
                    'yesNoOptions' => array(
                        0 => 'No',
                        1 => 'Yes'),
                    'paymentTypeOptions' => array(
                        'card' => 'Card Payments (default)',
                        'p24' => 'Przelewy24 (only EUR or PLN supported)',
                    ),
                    'plugin_enabled' => $plugin_enabled,
                    'payment_type' => $payment_type,
                    'secret_key' => $secret_key,
                    'publishable_key' => $publishable_key,
                    'signing_secret' => $signing_secret,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

}
