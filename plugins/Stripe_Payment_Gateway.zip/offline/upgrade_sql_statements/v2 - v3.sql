CREATE TABLE IF NOT EXISTS `plugin_stripe_subscription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `period_days` int(11) NOT NULL,
  `stripe_customer_id` varchar(100) COLLATE utf8_bin NOT NULL,
  `stripe_subscription_id` varchar(100) COLLATE utf8_bin NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;
ALTER TABLE  `plugin_stripe_subscription` ADD  `user_level_pricing_id` INT( 11 ) NULL AFTER  `period_days`;
