<?php

namespace Plugins\Stripe;

use App\Services\PluginConfig AS CorePluginConfig;

class PluginConfig extends CorePluginConfig
{
    /**
     * Setup the plugin config.
     *
     * @var array
     */
    public $config = array(
        'plugin_name' => 'Stripe Payment Integration',
        'folder_name' => 'stripe',
        'plugin_description' => 'Accept payments using Stripe.',
        'plugin_version' => '16.0',
        'required_script_version' => '5.0',
        'database_sql' => 'offline/database.sql',
    );

}
