<?php

namespace Plugins\Uploadwidget\Controllers;

use App\Core\BaseController;
use App\Core\Database;
use App\Helpers\PluginHelper;

class HooksController extends BaseController
{

    public function uploaderSuccess($params = null) {
        /*
         * available params
         * 
         * $params['file'];
         * $params['tmpFile'];
         * */

        // find the file
        if (isset($params['file'])) {
            $file = $params['file'];

            // check this upload came from the upload widget
            if ((isset($_REQUEST['uploadSource'])) && ($_REQUEST['uploadSource'] === 'uploadwidget')) {
                // load plugin details
                $pluginDetails = PluginHelper::pluginSpecificConfiguration('uploadwidget');
                $pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);

                // if we have the user and/or folder set, update the file details
                $uploadUser = (int) $pluginSettings['upload_user'];
                $uploadFolder = (int) $pluginSettings['upload_folder'];

                if ($uploadUser > 0) {
                    // get database connection
                    $db = Database::getDatabase();

                    // update file
                    $db->query('UPDATE file '
                            . 'SET userId = :userId, '
                            . 'folderId ' . ($uploadFolder > 0 ? ('= ' . $uploadFolder) : ('= NULL')) . ' '
                            . 'WHERE id = :id '
                            . 'LIMIT 1', array(
                                'userId' => (int)$uploadUser,
                                'id' => (int)$file->id,
                            ));
                }
            }
        }

        // return false so other plugin hooks will be called, if set
        return false;
    }

}
