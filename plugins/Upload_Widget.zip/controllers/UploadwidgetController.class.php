<?php

namespace Plugins\Uploadwidget\Controllers;

use App\Core\BaseController;
use App\Models\File;
use App\Models\Order;
use App\Models\PaymentLog;
use App\Models\User;
use App\Helpers\CoreHelper;
use App\Helpers\CrossSiteActionHelper;
use App\Helpers\FileHelper;
use App\Helpers\LogHelper;
use App\Helpers\OrderHelper;
use App\Helpers\PluginHelper;
use App\Helpers\UserHelper;

class UploadwidgetController extends BaseController
{
    public function embedLarge() {
        return $this->_embed('large');
    }
    
    public function embedLargeNh() {
        return $this->_embed('large_nh');
    }
    
    public function embedMinimal() {
        return $this->_embed('minimal');
    }
    
    private function _embed($template) {
        // pickup request
        $folderName = 'uploadwidget';

        // load plugin details
        $pluginDetails = PluginHelper::pluginSpecificConfiguration($folderName);
        $pluginConfig = $pluginDetails['config'];
        $pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);

        // if plugin not installed 
        if (!$pluginConfig) {
            return $this->renderContent('Upload widget unavailable, please <a href="' . WEB_ROOT . '" target="_blank">go here</a> for our main site.');
        }

        // if plugin disabled
        if (PluginHelper::pluginEnabled($folderName) == false) {
            return $this->renderContent('Upload widget unavailable, please <a href="' . WEB_ROOT . '" target="_blank">go here</a> for our main site.');
        }

        // whether to allow chunked uploaded. Recommend to keep as true unless you're experiencing issues.
        define('USE_CHUNKED_UPLOADS', true);

        // asset path
        define('PLUGIN_ASSET_PATH', PLUGIN_WEB_ROOT . '/' . $folderName . '/assets/');

        // get Auth
        $Auth = $this->getAuth();

        // max allowed upload size & max permitted urls
        $maxUploadSize = (int) UserHelper::getMaxUploadFilesize();
        $maxPermittedUrls = (int) UserHelper::getMaxRemoteUrls();

        // get accepted file types
        $acceptedFileTypes = UserHelper::getAcceptedFileTypes();

        // whether to allow uploads or not
        $showUploads = true;
        if (UserHelper::getAllowedToUpload() == false) {
            $showUploads = false;
        }

        // prepare server upload url
        $serverUploadUrl = FileHelper::getUploadUrl();
        $uploadAction = null;
        if ($serverUploadUrl) {
            $uploadAction = CrossSiteActionHelper::appendUrl($serverUploadUrl . '/ajax/file_upload_handler?r=' . htmlspecialchars(_CONFIG_SITE_HOST_URL) . '&p=' . htmlspecialchars(_CONFIG_SITE_PROTOCOL));
        }

        // load template
        return $this->render('embed/'.$template.'.html', array(
                    'Auth' => $Auth,
                    'maxUploadSize' => $maxUploadSize,
                    'maxPermittedUrls' => $maxPermittedUrls,
                    'acceptedFileTypes' => $acceptedFileTypes,
                    'showUploads' => $showUploads,
                    'uploadAction' => $uploadAction,
                    'maxUploadSize' => UserHelper::getMaxUploadFilesize(),
                    'maxUploadSizeBoth' => CoreHelper::formatSize(UserHelper::getMaxUploadFilesize(), 'both'),
                    'userAllowedToUpload' => UserHelper::getAllowedToUpload(),
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }
    
    

}
