<?php

namespace Plugins\Uploadwidget\Controllers\Admin;

use App\Core\Database;
use App\Controllers\Admin\PluginController AS CorePluginController;
use App\Helpers\AdminHelper;
use App\Helpers\PluginHelper;
use App\Models\Plugin;

class PluginController extends CorePluginController
{

    public function pluginSettings() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // load plugin details
        $folderName = 'uploadwidget';
        $plugin = Plugin::loadOneByClause('folder_name = :folder_name', array(
                    'folder_name' => $folderName,
        ));

        if (!$plugin) {
            return $this->redirect(ADMIN_WEB_ROOT . '/plugin_manage?error=' . urlencode('There was a problem loading the plugin details.'));
        }

        // path base
        define('PLUGIN_EMBED_PATH', WEB_ROOT . '/uploadwidget/');
        define('PLUGIN_ASSET_PATH', PLUGIN_WEB_ROOT . '/uploadwidget/assets/css/');

        // prepare variables
        $plugin_enabled = (int) $plugin->plugin_enabled;
        $upload_user = 0;
        $upload_folder = 0;

        // load existing settings
        if (strlen($plugin->plugin_settings)) {
            $plugin_settings = json_decode($plugin->plugin_settings, true);
            if ($plugin_settings) {
                $upload_user = (int) $plugin_settings['upload_user'];
                $upload_folder = (int) $plugin_settings['upload_folder'];
            }
        }

        // load list of users for select - only paid and above
        $userOptions = $db->getRows('SELECT id, username '
                . 'FROM users '
                . 'WHERE level_id >= 2 '
                . 'ORDER BY username ASC '
                . 'LIMIT 1000');

        // handle page submissions
        if ($request->request->has('submitted')) {
            // get variables
            $plugin_enabled = (int) $request->request->get('plugin_enabled');
            $plugin_enabled = $plugin_enabled != 1 ? 0 : 1;
            $upload_user = (int) $_REQUEST['upload_user'];
            $upload_folder = (int) $_REQUEST['upload_folder'];

            // validate submission
            if (_CONFIG_DEMO_MODE == true) {
                AdminHelper::setError(AdminHelper::t('no_changes_in_demo_mode', 'No change permitted in demo mode.'));
            }

            // update the settings
            if (AdminHelper::isErrors() == false) {
                // compile new settings
                $settingsArr = array();
                $settingsArr['upload_user'] = $upload_user;
                $settingsArr['upload_folder'] = $upload_folder;

                // update the plugin settings
                $plugin->plugin_enabled = $plugin_enabled;
                $plugin->plugin_settings = json_encode($settingsArr);
                $plugin->save();

                // set onscreen alert
                PluginHelper::loadPluginConfigurationFiles(true);
                AdminHelper::setSuccess('Plugin settings updated.');
            }
        }

        // load template
        return $this->render('admin/plugin_settings.html', array(
                    'pluginName' => $plugin->plugin_name,
                    'yesNoOptions' => array(
                        0 => 'No',
                        1 => 'Yes'),
                    'largeUploaderIframeHtml' => '<iframe src="'.PLUGIN_EMBED_PATH.'embed/large" width="100%" height="340" frameborder="0"></iframe>',
                    'minimalUploaderIframeHtml' => '<iframe src="'.PLUGIN_EMBED_PATH.'embed/minimal" width="100%" height="144" frameborder="0"></iframe>',
                    'largeNHUploaderIframeHtml' => '<iframe src="'.PLUGIN_EMBED_PATH.'embed/large_nh" width="100%" height="236" frameborder="0"></iframe>',
                    'userOptions' => $userOptions,
                    'plugin_enabled' => $plugin_enabled,
                    'upload_user' => $upload_user,
                    'upload_folder' => $upload_folder,
                    'PLUGIN_EMBED_PATH' => PLUGIN_EMBED_PATH,
                    'PLUGIN_ASSET_PATH' => PLUGIN_ASSET_PATH,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

}
