<?php

namespace Plugins\Uploadwidget;

use App\Services\PluginConfig AS CorePluginConfig;

class PluginConfig extends CorePluginConfig
{
    /**
     * Setup the plugin config.
     *
     * @var array
     */
    public $config = array(
        'plugin_name' => 'Upload Widget',
        'folder_name' => 'uploadwidget',
        'plugin_description' => 'Embed a file uploader directly on your own website.',
        'plugin_version' => '7.0',
        'required_script_version' => '5.0',
    );

}
