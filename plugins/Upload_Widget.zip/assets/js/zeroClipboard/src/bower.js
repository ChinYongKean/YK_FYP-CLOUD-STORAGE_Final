{
  "name": "{{name}}",
  "version": "{{version}}",
  "main": ["./ZeroClipboard.js", "./ZeroClipboard.swf"]
}