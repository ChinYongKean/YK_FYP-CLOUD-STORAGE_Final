function browserXHR2Support()
{
    if (new XMLHttpRequest().upload)
    {
        return true;
    }

    return false;
}

function bytesToSize(bytes, precision)
{
    var kilobyte = 1024;
    var megabyte = kilobyte * 1024;
    var gigabyte = megabyte * 1024;
    var terabyte = gigabyte * 1024;

    if ((bytes >= 0) && (bytes < kilobyte)) {
        return bytes + ' B';

    } else if ((bytes >= kilobyte) && (bytes < megabyte)) {
        return (bytes / kilobyte).toFixed(precision) + ' KB';

    } else if ((bytes >= megabyte) && (bytes < gigabyte)) {
        return (bytes / megabyte).toFixed(precision) + ' MB';

    } else if ((bytes >= gigabyte) && (bytes < terabyte)) {
        return (bytes / gigabyte).toFixed(precision) + ' GB';

    } else if (bytes >= terabyte) {
        return (bytes / terabyte).toFixed(precision) + ' TB';

    } else {
        return bytes + ' B';
    }
}

function humanReadableTime(seconds)
{
    var numhours = Math.floor(((seconds % 31536000) % 86400) / 3600);
    var numminutes = Math.floor((((seconds % 31536000) % 86400) % 3600) / 60);
    var numseconds = Math.floor((((seconds % 31536000) % 86400) % 3600) % 60);

    rs = '';
    if (numhours > 0)
    {
        rs += numhours + " hour";
        if (numhours != 1)
        {
            rs += "s";
        }
        rs += " ";
    }
    if (numminutes > 0)
    {
        rs += numminutes + " minute";
        if (numminutes != 1)
        {
            rs += "s";
        }
        rs += " ";
    }
    rs += numseconds + " second";
    if (numseconds != 1)
    {
        rs += "s";
    }

    return rs;
}

function delay(callback) {
    // do nothing
}

function viewFileLinksAlert()
{
    fileUrlText = '';
    if (fileUrls.length > 0)
    {
        for (var i = 0; i < fileUrls.length; i++)
        {
            fileUrlText += fileUrls[i] + "\n";
        }
    }

    alert(fileUrlText);
}