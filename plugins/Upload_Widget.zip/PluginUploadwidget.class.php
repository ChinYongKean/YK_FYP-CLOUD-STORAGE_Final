<?php

// plugin namespace
namespace Plugins\Uploadwidget;

// core includes
use App\Services\Plugin;
use Plugins\Uploadwidget\PluginConfig;

class PluginUploadwidget extends Plugin
{
    public $config = null;
    public $data = null;
    public $settings = null;

    public function __construct() {
        // load plugin config
        $this->config = (new PluginConfig())->getPluginConfig();
    }

    public function registerRoutes(\FastRoute\RouteCollector $r) {
        // register plugin routes
        $r->addRoute(['GET', 'POST'], '/'.ADMIN_FOLDER_NAME.'/plugin/'.$this->config['folder_name'].'/settings', '\plugins\\'.$this->config['folder_name'].'\controllers\admin\PluginController/pluginSettings');
        $r->addRoute(['GET'], '/'.$this->config['folder_name'].'/embed/large', '\plugins\\'.$this->config['folder_name'].'\controllers\\'.ucwords($this->config['folder_name']).'Controller/embedLarge');
        $r->addRoute(['GET'], '/'.$this->config['folder_name'].'/embed/minimal', '\plugins\\'.$this->config['folder_name'].'\controllers\\'.ucwords($this->config['folder_name']).'Controller/embedMinimal');
        $r->addRoute(['GET'], '/'.$this->config['folder_name'].'/embed/large_nh', '\plugins\\'.$this->config['folder_name'].'\controllers\\'.ucwords($this->config['folder_name']).'Controller/embedLargeNh');
        
        // routes for legacy purposes
        $r->addRoute(['GET'], '/plugins/'.$this->config['folder_name'].'/site/_embed_large.php', '\plugins\\'.$this->config['folder_name'].'\controllers\\'.ucwords($this->config['folder_name']).'Controller/embedLarge');
        $r->addRoute(['GET'], '/plugins/'.$this->config['folder_name'].'/site/_embed_minimal.php', '\plugins\\'.$this->config['folder_name'].'\controllers\\'.ucwords($this->config['folder_name']).'Controller/embedMinimal');
        $r->addRoute(['GET'], '/plugins/'.$this->config['folder_name'].'/site/_embed_large_nh.php', '\plugins\\'.$this->config['folder_name'].'\controllers\\'.ucwords($this->config['folder_name']).'Controller/embedLargeNh');
    }
    
    public function getPluginDetails() {
        return $this->config;
    }

}
