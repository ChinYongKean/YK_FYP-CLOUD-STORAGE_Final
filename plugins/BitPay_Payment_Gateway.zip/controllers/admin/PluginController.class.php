<?php

namespace Plugins\Bitpay\Controllers\Admin;

use App\Core\Database;
use App\Controllers\Admin\PluginController AS CorePluginController;
use App\Helpers\AdminHelper;
use App\Helpers\PluginHelper;
use App\Models\Plugin;

class PluginController extends CorePluginController
{

    public function pluginSettings() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // load plugin details
        $folderName = 'bitpay';
        $plugin = Plugin::loadOneByClause('folder_name = :folder_name', array(
                    'folder_name' => $folderName,
        ));

        if (!$plugin) {
            return $this->redirect(ADMIN_WEB_ROOT . '/plugin_manage?error=' . urlencode('There was a problem loading the plugin details.'));
        }

        // prepare variables
        $plugin_enabled = (int) $plugin->plugin_enabled;
        $api_key = '';
        $enable_sandbox_mode = 0;

        // load existing settings
        if (strlen($plugin->plugin_settings)) {
            $plugin_settings = json_decode($plugin->plugin_settings, true);
            if ($plugin_settings) {
                $api_key = $plugin_settings['api_key'];
                $enable_sandbox_mode = (int) $plugin_settings['enable_sandbox_mode'];
                if (_CONFIG_DEMO_MODE == true) {
                    $api_key = '[HIDDEN]';
                }
            }
        }

        // handle page submissions
        if ($request->request->has('submitted')) {
            // get variables
            $plugin_enabled = (int) $request->request->get('plugin_enabled');
            $plugin_enabled = $plugin_enabled != 1 ? 0 : 1;
            $api_key = trim($_REQUEST['api_key']);
            $enable_sandbox_mode = (int) $request->request->get('enable_sandbox_mode');

            // validate submission
            if (_CONFIG_DEMO_MODE == true) {
                AdminHelper::setError(AdminHelper::t('no_changes_in_demo_mode', 'No change permitted in demo mode.'));
            }
            elseif (strlen($api_key) == 0) {
                AdminHelper::setError(AdminHelper::t("please_enter_your_api_key", "Please enter your API key."));
            }

            // update the settings
            if (AdminHelper::isErrors() == false) {
                // compile new settings
                $settingsArr = array();
                $settingsArr['api_key'] = $api_key;
                $settingsArr['enable_sandbox_mode'] = $enable_sandbox_mode;

                // update the plugin settings
                $plugin->plugin_enabled = $plugin_enabled;
                $plugin->plugin_settings = json_encode($settingsArr);
                $plugin->save();

                // set onscreen alert
                PluginHelper::loadPluginConfigurationFiles(true);
                AdminHelper::setSuccess('Plugin settings updated.');
            }
        }

        // load template
        return $this->render('admin/plugin_settings.html', array(
                    'pluginName' => $plugin->plugin_name,
                    'yesNoOptions' => array(
                        0 => 'No',
                        1 => 'Yes'),
                    'sandboxOptions' => array(
                        0 => 'Live Transactions - Use this on your live site',
                        1 => 'Sandbox Mode - For testing only, these payments wont actually be charged'),
                    'plugin_enabled' => $plugin_enabled,
                    'api_key' => $api_key,
                    'enable_sandbox_mode' => $enable_sandbox_mode,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

}
