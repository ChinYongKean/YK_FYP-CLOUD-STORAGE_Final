<?php

namespace Plugins\Bitpay\Controllers;

use App\Core\BaseController;
use App\Models\File;
use App\Models\Order;
use App\Models\PaymentLog;
use App\Models\User;
use App\Helpers\CoreHelper;
use App\Helpers\LogHelper;
use App\Helpers\OrderHelper;
use App\Helpers\PluginHelper;
use App\Helpers\UserHelper;
use Plugins\Bitpay\Libraries\Bitpaysdklight\Client;
use Plugins\Bitpay\Libraries\Bitpaysdklight\Env;
use Plugins\Bitpay\Libraries\Bitpaysdklight\Model\Invoice\Invoice;
use Plugins\Bitpay\Libraries\Bitpaysdklight\Exceptions\InvoiceCreationException;

class BitpayController extends BaseController
{

    public function upgradeBox($params = array()) {
        // pickup request for later
        $request = $this->getRequest();

        // load template
        return $this->render('upgrade_box.html', array_merge($params, array(
                    'folder_name' => 'bitpay',
                    'gateway_label' => 'BitPay',
                    'i' => $request->query->has('i') ? $request->query->get('i') : '',
                    'f' => $request->query->has('f') ? $request->query->get('f') : '',
                        )), PLUGIN_DIRECTORY_ROOT . 'bitpay/views');
    }

    public function pay($params = array()) {
        // pickup request for later
        $request = $this->getRequest();

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('bitpay');
        $pluginSettings = $pluginConfig['data']['plugin_settings'];
        $apiKey = '';
        $enableSandboxMode = 0;
        if (strlen($pluginSettings)) {
            $pluginSettingsArr = json_decode($pluginSettings, true);
            $apiKey = $pluginSettingsArr['api_key'];
            $enableSandboxMode = (int) $pluginSettingsArr['enable_sandbox_mode'];
        }

        if (!$request->request->has('user_level_pricing_id')) {
            return $this->redirect(WEB_ROOT);
        }

        // require login
        if ($request->request->has('i') && strlen($request->request->get('i'))) {
            $user = User::loadOneByClause('identifier = :identifier', array(
                        'identifier' => $request->request->get('i')
            ));
            if (!$user) {
                return $this->redirect(CoreHelper::getCoreSitePath() . "/error?e=" . urlencode('Could not load user based on identifier, please contact support.'));
            }

            // setup variables for later
            $userId = $user->id;
            $username = $user->username;
            $userEmail = $user->email;
        }
        else {
            if (($response = $this->requireLogin('/register', 1)) !== false) {
                return $response;
            }

            // setup variables for later
            $Auth = $this->getAuth();
            $userId = $Auth->id;
            $username = $Auth->username;
            $userEmail = $Auth->email;
        }

        $userLevelPricingId = (int) $request->request->get('user_level_pricing_id');

        // check if we have a referring file
        $fileId = null;
        if ($request->request->has('f') && strlen($request->request->get('f'))) {
            $file = File::loadOneByShortUrl($request->request->get('f'));
            if ($file) {
                $fileId = $file->id;
            }
        }

        // create order entry
        $order = OrderHelper::createByPackageId($userId, $userLevelPricingId, $fileId);
        if ($order) {
            // setup bitpay
            $bitpay = new Client($apiKey, $enableSandboxMode === 1 ? Env::Test : Env::Prod);

            try {
                $invoice = $bitpay->createInvoice(new Invoice($order->amount, SITE_CONFIG_COST_CURRENCY_CODE));
            }
            catch (InvoiceCreationException $ex) {
                return $this->renderContent('Error creating BitPay invoice: ' . $ex->getMessage());
            }

            // set other properties
            $invoice->setRedirectURL(WEB_ROOT . '/payment_complete');
            $invoice->setNotificationURL(WEB_ROOT . '/bitpay/payment_ipn');
            $invoice->setTransactionSpeed('low');
            $invoice->setFullNotifications(false);
            $invoice->setItemDesc($order->description);
            $invoice->setBuyerProvidedEmail($userEmail);
            $invoice->setPosData($order->payment_hash);

            // redirect to bitpay
            return $this->redirect($invoice->getURL());
        }

        // fallback
        return $this->redirect(CoreHelper::getCoreSitePath() . "/error?e=" . urlencode('Failed creating order, please try again later.'));
    }

    public function paymentIpn($params = array()) {
        // pickup request for later
        $request = $this->getRequest();

        // log response
        LogHelper::setContext('bitpay');
        LogHelper::info('Received called back on IPN (request): ' . print_r($_REQUEST, true));
        LogHelper::info('Received called back on IPN (php://input): ' . file_get_contents("php://input"));

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('bitpay');
        $pluginSettings = $pluginConfig['data']['plugin_settings'];
        $apiKey = '';
        $enableSandboxMode = 0;
        if (strlen($pluginSettings)) {
            $pluginSettingsArr = json_decode($pluginSettings, true);
            $apiKey = $pluginSettingsArr['api_key'];
            $enableSandboxMode = (int) $pluginSettingsArr['enable_sandbox_mode'];
        }

        // get response
        $post = file_get_contents("php://input");
        $responseArr = json_decode($post, true);
        $responseArr['posData'] = json_decode($responseArr['posData'], true);

        // make sure payment has completed and it's for the correct BitPay account
        $xTransId = $responseArr['id'];
        $paymentTracker = $responseArr['posData'][0];
        if (in_array($responseArr['status'], array('complete', 'confirmed'))) {
            // load order using custom payment tracker hash
            $paymentTracker = $request->request->get('custom');
            $order = OrderHelper::loadByPaymentTracker($paymentTracker);
            if ($order) {
                $extendedDays = $order->days;
                $userId = $order->user_id;
                $upgradeUserId = $order->upgrade_user_id;
                $orderId = $order->id;

                // retain all posted gateway parameters
                $gatewayVars = "";
                foreach ($_REQUEST AS $k => $v) {
                    $gatewayVars .= $k . " => " . $v . "\n";
                }

                // insert payment log
                $paymentLog = PaymentLog::create();
                $paymentLog->user_id = $userId;
                $paymentLog->date_created = date("Y-m-d H:i:s", time());
                $paymentLog->amount = $order->amount;
                $paymentLog->currency_code = 'BTC';
                $paymentLog->from_email = '';
                $paymentLog->to_email = '';
                $paymentLog->description = $order->description;
                $paymentLog->request_log = $gatewayVars;
                $paymentLog->payment_method = 'BitPay';
                $paymentLog->save();

                // make sure the order is pending
                if ($order->order_status == 'completed') {
                    // order has already been completed
                    LogHelper::info('Failed - order has already been completed');

                    return $this->renderEmpty200Response();
                }

                // update order status to paid
                $order->order_status = 'completed';
                if ($order->save() === false) {
                    // failed to update order
                    LogHelper::info('Failed - failed to update order');

                    return $this->renderEmpty200Response();
                }

                // extend/upgrade user
                $rs = UserHelper::upgradeUserByPackageId($userId, $order);
                if ($rs === false) {
                    // failed to update user
                    LogHelper::info('Failed - failed to update user');

                    return $this->renderEmpty200Response();
                }

                // append any plugin includes
                PluginHelper::callHook('postUpgradePaymentIpn', array(
                    'order' => $order,
                ));
            }
        }
        
        return $this->renderEmpty200Response();
    }

}
