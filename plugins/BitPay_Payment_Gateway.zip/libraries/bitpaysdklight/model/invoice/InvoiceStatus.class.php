<?php


namespace Plugins\Bitpay\Libraries\Bitpaysdklight\Model\Invoice;


interface InvoiceStatus
{
    const New       = "new";
    const Paid      = "paid";
    const Confirmed = "confirmed";
    const Complete  = "complete";
    const Expired   = "expired";
    const Invalid   = "invalid";
}