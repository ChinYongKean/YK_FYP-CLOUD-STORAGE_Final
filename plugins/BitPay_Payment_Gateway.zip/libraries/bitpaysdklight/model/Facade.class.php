<?php


namespace Plugins\Bitpay\Libraries\Bitpaysdklight\Model;


interface Facade
{
    const Merchant = "merchant";
    const Payroll  = "payroll";
}