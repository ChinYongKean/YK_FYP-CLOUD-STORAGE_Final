<?php

// plugin namespace

namespace Plugins\Fileleech;

// core includes
use App\Core\Database;
use App\Services\Plugin;
use Plugins\Fileleech\PluginConfig;

class PluginFileleech extends Plugin
{
    public $config = null;
    public $data = null;

    public function __construct() {
        // load plugin config
        $this->config = (new PluginConfig())->getPluginConfig();
        $this->settings = $this->getPluginSettings();
    }

    public function registerRoutes(\FastRoute\RouteCollector $r) {
        // register plugin routes
        $r->addRoute(['GET', 'POST'], '/' . ADMIN_FOLDER_NAME . '/plugin/' . $this->config['folder_name'] . '/settings', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/pluginSettings');
        $r->addRoute(['GET', 'POST'], '/' . ADMIN_FOLDER_NAME . '/plugin/' . $this->config['folder_name'] . '/ajax/site_manage_add_form', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxSiteManageAddForm');
        $r->addRoute(['GET', 'POST'], '/' . ADMIN_FOLDER_NAME . '/plugin/' . $this->config['folder_name'] . '/ajax/site_manage_add_process', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxSiteManageAddProcess');

        $r->addRoute(['GET', 'POST'], '/' . ADMIN_FOLDER_NAME . '/plugin/' . $this->config['folder_name'] . '/ajax/login_manage_add_form', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxLoginManageAddForm');
        $r->addRoute(['GET', 'POST'], '/' . ADMIN_FOLDER_NAME . '/plugin/' . $this->config['folder_name'] . '/ajax/login_manage_add_process', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxLoginManageAddProcess');
    }

    public function getPluginDetails() {
        return $this->config;
    }

    public function uninstall() {
        // setup database
        $db = Database::getDatabase();

        // remove plugin specific tables
        $sQL = 'DROP TABLE plugin_fileleech_access_detail';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_fileleech_download';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_fileleech_site';
        $db->query($sQL);

        return parent::uninstall();
    }

    function fileLeechConvertToBytes($formattedSize) {
        $size = (int)substr($formattedSize, 0, strlen($formattedSize) - 1);
        switch (strtoupper(substr($formattedSize, strlen($formattedSize) - 1, 1))) {
            case 'G':
                return ceil($size * 1024 * 1024 * 1024);
                break;
            case 'M':
                return ceil($size * 1024 * 1024);
                break;
            case 'K':
                return ceil($size * 1024);
                break;
            case 'B':
                return ceil($size);
                break;
        }

        return ceil($size);
    }

}
