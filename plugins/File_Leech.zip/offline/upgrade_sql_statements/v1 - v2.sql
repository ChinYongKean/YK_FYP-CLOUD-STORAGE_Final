ALTER TABLE  `plugin_fileleech_download` CHANGE  `user_ip_address`  `user_ip_address` VARCHAR( 45 ) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL;
