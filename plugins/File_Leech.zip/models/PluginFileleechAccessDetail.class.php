<?php

namespace Plugins\Fileleech\Models;

use App\Core\Model;

class PluginFileleechAccessDetail extends Model
{
    
}
