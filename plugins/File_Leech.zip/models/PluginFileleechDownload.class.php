<?php

namespace Plugins\Fileleech\Models;

use App\Core\Model;

class PluginFileleechDownload extends Model
{
    
}
