<?php

namespace Plugins\Fileleech;

use App\Services\PluginConfig AS CorePluginConfig;

class PluginConfig extends CorePluginConfig
{
    /**
     * Setup the plugin config.
     *
     * @var array
     */
    public $config = array(
        'plugin_name' => 'File Leech',
        'folder_name' => 'fileleech',
        'plugin_description' => 'Leech files from other file hosting sites.',
        'plugin_version' => '10.0',
        'required_script_version' => '5.0',
        'database_sql' => 'offline/database.sql',
    );

}
