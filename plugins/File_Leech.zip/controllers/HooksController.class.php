<?php

namespace Plugins\Fileleech\Controllers;

use App\Core\BaseController;
use App\Core\Database;
use App\Helpers\CoreHelper;
use App\Helpers\FileHelper;
use App\Helpers\FileServerHelper;
use App\Helpers\LogHelper;
use App\Helpers\PluginHelper;
use App\Helpers\TranslateHelper;
use App\Helpers\UploaderHelper;
use App\Helpers\UserHelper;
use App\Models\User;
use App\Services\Uploader;
use Plugins\Fileleech\Models\PluginFileleechDownload;

class HooksController extends BaseController
{

    public function fileManagerTab($params = null) {
        // get user
        $Auth = $this->getAuth();

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('fileleech');
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);

        // check show tab setting
        $showTab = false;
        if ($pluginSettings['show_leech_tab'] == 1) {
            $showTab = true;
        }

        // check user can access it
        $userAllowed = false;
        if (($Auth->level_id == 0) && ($pluginSettings['enabled_non_user'] == 1)) {
            $userAllowed = true;
        }
        elseif (($Auth->level_id == 1) && ($pluginSettings['enabled_free_user'] == 1)) {
            $userAllowed = true;
        }
        elseif (($Auth->level_id >= 2) && ($pluginSettings['enabled_paid_user'] == 1)) {
            $userAllowed = true;
        }
        if ($userAllowed == false) {
            $showTab = false;
        }

        if ($showTab === false) {
            return false;
        }

        return array(
            'ftpupload' => array(
                'anchor' => 'fileLeech',
                'icon' => 'glyphicon glyphicon-import',
                'label' => TranslateHelper::t('plugin_fileleech_file_leech', 'File Leech'),
            ),
        );
    }

    public function fileManagerTabContent($params = null) {
        // get user
        $Auth = $this->getAuth();

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('fileleech');
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);

        // check show tab setting
        $showTab = false;
        if ($pluginSettings['show_leech_tab'] == 1) {
            $showTab = true;
        }

        // check user can access it
        $userAllowed = false;
        if (($Auth->level_id == 0) && ($pluginSettings['enabled_non_user'] == 1)) {
            $userAllowed = true;
        }
        elseif (($Auth->level_id == 1) && ($pluginSettings['enabled_free_user'] == 1)) {
            $userAllowed = true;
        }
        elseif (($Auth->level_id >= 2) && ($pluginSettings['enabled_paid_user'] == 1)) {
            $userAllowed = true;
        }
        if ($userAllowed == false) {
            $showTab = false;
        }

        if ($showTab === false) {
            return false;
        }

        // load template
        return array(
            'response_html' => $this->getRenderedTemplate('file_manager_tab_content.html', array(
                'maxPermittedUrls' => (int) UserHelper::getMaxRemoteUrls(),
                'maxUploadSize' => (int) UserHelper::getMaxUploadFilesize(),
                'acceptedFileTypes' => UserHelper::getAcceptedFileTypes(),
                'uploadUrl' => FileHelper::getUploadUrl(),
                'pluginConfig' => $pluginConfig,
                    ), PLUGIN_DIRECTORY_ROOT . 'fileleech/views')
        );
    }

    public function urlUploadHandler($params = null) {
        // get database connection
        $db = Database::getDatabase();

        // get url sections
        $urlParts = parse_url($params['url']);
        $siteName = strtolower($urlParts['host']);
        $urlDownloadData = isset($params['urlDownloadData']) ? $params['urlDownloadData'] : null;

        if ($params['rowId']) {
            $rowId = (int) $params['rowId'];
        }
        else {
            $rowId = (int) $_REQUEST['rowId'];
        }

        // check if we can leech the file
        $foundSiteDetails = null;
        $siteDetails = $db->getRows('SELECT * '
                . 'FROM plugin_fileleech_site');
        foreach ($siteDetails AS $siteDetail) {
            if (strpos($siteName, strtolower($siteDetail['site_url'])) !== false) {
                $foundSiteDetails = $siteDetail;
            }
        }

        if ($foundSiteDetails === null) {
            return false;
        }

        // get user
        if ($urlDownloadData) {
            $userId = $urlDownloadData['user_id'];
        }
        else {
            $Auth = $this->getAuth();
            $userId = $Auth->id;
        }

        $user = User::loadOneById($userId);
        $userLevel = UserHelper::getLevelIdFromPackageId($user->level_id);

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('fileleech');
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);
        $pluginObj = PluginHelper::getInstance('fileleech');

        // make sure the user is allowed to leech files
        $userAllowed = false;
        if (($userLevel == 0) && ($pluginSettings['enabled_non_user'] == 1)) {
            $userAllowed = true;
        }
        elseif (($userLevel == 1) && ($pluginSettings['enabled_free_user'] == 1)) {
            $userAllowed = true;
        }
        elseif (($userLevel >= 2) && ($pluginSettings['enabled_paid_user'] == 1)) {
            $userAllowed = true;
        }

        // make sure the user isn't above their leech limits
        if ($userAllowed == true) {
            switch ($userLevel) {
                case 0:
                    $leechDownloadTrafficLimit = (int) $pluginSettings['max_download_traffic_non_user'];
                    $leechDownloadVolumeLimit = (int) $pluginSettings['max_download_volume_non_user'];
                    break;
                case 1:
                    $leechDownloadTrafficLimit = (int) $pluginSettings['max_download_traffic_free_user'];
                    $leechDownloadVolumeLimit = (int) $pluginSettings['max_download_volume_free_user'];
                    break;
                default:
                    $leechDownloadTrafficLimit = (int) $pluginSettings['max_download_traffic_paid_user'];
                    $leechDownloadVolumeLimit = (int) $pluginSettings['max_download_volume_paid_user'];
                    break;
            }

            // get total already downloaded based on IP
            $restrictionError = null;
            $totalFilesize24Hour = (int) $db->getValue('SELECT SUM(filesize) '
                            . 'FROM plugin_fileleech_download '
                            . 'WHERE user_ip_address = ' . $db->quote(CoreHelper::getUsersIPAddress()) . ' '
                            . 'AND date_download > DATE_SUB(NOW(), INTERVAL 24 HOUR)');
            if (($leechDownloadTrafficLimit > 0) && ($leechDownloadTrafficLimit * 1048576 <= $totalFilesize24Hour)) {
                $restrictionError = TranslateHelper::t('plugin_fileleech_leech_limit_reached', 'Leeching download size reached for today.');
            }
            else {
                $totalDownloads24Hour = (int) $db->getValue('SELECT COUNT(id) '
                                . 'FROM plugin_fileleech_download '
                                . 'WHERE user_ip_address = ' . $db->quote(CoreHelper::getUsersIPAddress()) . ' '
                                . 'AND date_download > DATE_SUB(NOW(), INTERVAL 24 HOUR)');
                if (($leechDownloadVolumeLimit > 0) && ($leechDownloadVolumeLimit <= $totalDownloads24Hour)) {
                    $restrictionError = TranslateHelper::t('plugin_fileleech_leech_volume_reached', 'Leeching volume reached for today.');
                }
            }

            // end with error
            if ($restrictionError !== null) {
                // allow sub-domains for remote file servers
                echo CoreHelper::getDocumentDomainScript();
                $upload_handler = new Uploader();
                $fileUploadError = CoreHelper::createUploadError(t('plugin_fileleech_error', 'Error!'), $restrictionError);
                $fileUploadError = json_decode($fileUploadError, true);
                $fileUploadError = $fileUploadError[0];
                $fileUploadError['rowId'] = $rowId;
                $upload_handler->remote_url_event_callback(array("done" => $fileUploadError));
                exit;
            }
        }

        // user can leech
        if ($userAllowed == true) {
            // setup logging
            LogHelper::setContext('plugin_fileleech');

            // setup plowdown path
            $plowDownPath = isset($pluginSettings['plowdown_path']) ? $pluginSettings['plowdown_path'] : '/usr/local/bin/plowdown';
            define('PLOWDOWN_PATH', $plowDownPath);
            LogHelper::info('Plowdown path set as: ' . PLOWDOWN_PATH);

            // make imput safe
            $safeUrl = $params['url'];
            $safeUrl = str_replace('&&', '', $safeUrl);
            $safeUrl = str_replace(';', '', $safeUrl);

            // load random login details
            $cmd = null;
            $totalItems = (int) $db->getValue('SELECT COUNT(id) '
                            . 'FROM plugin_fileleech_access_detail '
                            . 'WHERE site_id = ' . (int) $foundSiteDetails['id']);
            if ($totalItems > 0) {
                // get random
                $loginDetails = $db->getRow('SELECT * '
                        . 'FROM plugin_fileleech_access_detail '
                        . 'WHERE site_id = ' . (int) $foundSiteDetails['id'] . ' '
                        . 'LIMIT ' . (mt_rand(1, $totalItems) - 1) . ', 1');

                // create download url for plowdown
                $cmd = PLOWDOWN_PATH . ' --max-retries=5 --no-plowsharerc --timeout=60 --temp-rename --output-directory=' . FileServerHelper::getCurrentServerFileStoragePath() . '_tmp/ -a \'' . $loginDetails['username'] . ':' . $loginDetails['password'] . '\' ' . $safeUrl . ' 2>&1';
            }

            // fallback
            if ($cmd === null) {
                // prepare command
                $cmd = PLOWDOWN_PATH . ' --max-retries=5 --no-plowsharerc --timeout=60 --temp-rename --output-directory=' . FileServerHelper::getCurrentServerFileStoragePath() . '_tmp/ ' . $safeUrl . ' 2>&1';
            }

            // attempt to download file
            $lastLine = '';
            $logMessage = '';
            $foundTransferData = false;
            $transferStartStr = '  % Total    % Received';
            LogHelper::info('Cmd: ' . $cmd);
            if (($fp = popen($cmd, "r"))) {
                // 1KB of initial data, required by Webkit browsers
                echo "<span>" . str_repeat("0", 1000) . "</span>";

                // allow sub-domains for remote file servers
                echo CoreHelper::getDocumentDomainScript();

                // stream result
                $localData = '';
                while (!feof($fp)) {
                    $results = fgets($fp, 100);

                    $localData .= $results;
                    $logMessage .= $results;

                    // should we update progress
                    if ($foundTransferData == true) {
                        // get total size and download progress
                        $localData = str_replace("\r", "\n", $localData);
                        $lines = explode("\n", $localData);
                        if (COUNT($lines) >= 2) {
                            $lastFullLine = $lines[COUNT($lines) - 2];
                        }

                        // remove extra spaces
                        $lastFullLine = str_replace(array('   ', '  '), ' ', $lastFullLine);
                        $lastFullLine = str_replace(array('   ', '  '), ' ', $lastFullLine);
                        $lastFullLine = str_replace(array('   ', '  '), ' ', $lastFullLine);
                        if (substr($lastFullLine, 0, 1) == ' ') {
                            $lastFullLine = substr($lastFullLine, 1);
                        }

                        // extract progress
                        $lastLinePrepExp = explode(" ", $lastFullLine);
                        $downloadSize = $pluginObj->fileLeechConvertToBytes($lastLinePrepExp[1]);
                        $downloadedSize = $pluginObj->fileLeechConvertToBytes($lastLinePrepExp[3]);
                        if ($downloadSize > 0) {
                            // output progress on screen
                            $arrParams = array('upload_source' => 'remote');
                            if ($urlDownloadData) {
                                $arrParams = array(
                                    'folder_id' => (int) $urlDownloadData['folder_id'],
                                    'user_id' => (int) $urlDownloadData['user_id'],
                                    'background_queue_id' => (int) $urlDownloadData['id'],
                                    'max_file_size' => UserHelper::getMaxUploadFilesize($user->level_id),
                                    'upload_source' => 'leech',
                                );
                            }
                            $upload_handler = new Uploader($arrParams);
                            $upload_handler->remote_url_event_callback(array("progress" => array("loaded" => $downloadedSize, "total" => $downloadSize, "rowId" => (int) $rowId)));

                            if ((int) $urlDownloadData['id']) {
                                $percent = ceil(($downloadedSize / $downloadSize) * 100);
                                $db->query('UPDATE remote_url_download_queue '
                                        . 'SET downloaded_size=' . $db->escape($downloadedSize) . ', '
                                        . 'total_size=' . $db->escape($downloadSize) . ', '
                                        . 'download_percent=' . (int) $percent . ' '
                                        . 'WHERE id=' . (int) $urlDownloadData['id'] . ' '
                                        . 'LIMIT 1');
                            }
                        }
                        unset($lines);
                    }
                    elseif (strpos($localData, $transferStartStr) !== false) {
                        $foundTransferData = true;
                    }
                }
                pclose($fp);

                // log response
                if (strlen($logMessage)) {
                    LogHelper::info($logMessage);
                    LogHelper::revertContext();
                }

                // get path in last line
                $lines = explode("\n", $localData);
                $lastLine = $lines[COUNT($lines) - 2];
                $localFilePath = str_replace("\n", "", $lastLine);

                // assume the last line is the file path
                $arrParams = array('upload_source' => 'remote');
                if ($urlDownloadData) {
                    $arrParams = array(
                        'folder_id' => (int) $urlDownloadData['folder_id'],
                        'user_id' => (int) $urlDownloadData['user_id'],
                        'background_queue_id' => (int) $urlDownloadData['id'],
                        'max_file_size' => UserHelper::getMaxUploadFilesize($user->level_id),
                        'upload_source' => 'leech',
                    );
                }
                $upload_handler = new Uploader($arrParams);

                if (!file_exists($localFilePath)) {
                    // handle errors
                    $fileUploadError = CoreHelper::createUploadError(TranslateHelper::t('plugin_fileleech_error', 'Error!'), $localFilePath);
                    $fileUploadError = json_decode($fileUploadError, true);
                    $fileUploadError = $fileUploadError[0];
                    $fileUploadError['rowId'] = $rowId;
                    $upload_handler->remote_url_event_callback(array("done" => $fileUploadError));
                    exit;
                }

                // file has been downloaded, move into storage
                $fileDetails = pathinfo($localFilePath);
                $fileName = $fileDetails['filename'];
                if (strlen($fileDetails['extension'])) {
                    $fileName .= '.' . $fileDetails['extension'];
                }

                // get mime type
                $mimeType = FileHelper::estimateMimeTypeFromExtension($fileName, 'application/octet-stream');
                if (($mimeType == 'application/octet-stream') && (class_exists('finfo', false))) {
                    $finfo = new \finfo;
                    $mimeType = $finfo->file($localFilePath, FILEINFO_MIME);
                }

                $fileUpload = new \stdClass();
                $fileUpload->name = $fileName;
                $fileUpload->size = filesize($localFilePath);
                $fileUpload->type = $mimeType;
                $fileUpload->error = null;
                $fileUpload->rowId = $rowId;
                $fileUpload->requestUrl = $params['url'];
                $fileUpload = $upload_handler->moveIntoStorage($fileUpload, $localFilePath);

                // make sure file has been removed
                @unlink($localFilePath);

                // no error, add success html
                if ($fileUpload->error === null) {
                    $fileUpload->success_result_html = UploaderHelper::generateSuccessHtml($fileUpload);

                    if ((int) $urlDownloadData['id']) {
                        $db->query('UPDATE remote_url_download_queue '
                                . 'SET job_status=\'complete\', '
                                . 'finished=NOW(), '
                                . 'new_file_id=' . (int) $upload_handler->fileUpload->file_id . ' '
                                . 'WHERE id=' . (int) $urlDownloadData['id'] . ' '
                                . 'LIMIT 1');
                    }
                }
                else {
                    $fileUpload->error_result_html = UploaderHelper::generateErrorHtml($fileUpload);

                    if ((int) $urlDownloadData['id']) {
                        $db->query('UPDATE remote_url_download_queue '
                                . 'SET job_status=\'failed\', '
                                . 'finished=NOW(), '
                                . 'notes=' . $db->quote($upload_handler->fileUpload->error) . ' '
                                . 'WHERE id=' . (int) $urlDownloadData['id'] . ' '
                                . 'LIMIT 1');
                    }
                }

                $upload_handler->remote_url_event_callback(array("done" => $fileUpload));
                exit;
            }
        }
    }

    public function uploaderSuccessResultHtml($params = null) {
        $fileUpload = $params['fileUpload'];
        if (isset($fileUpload->requestUrl)) {
            // get database connection
            $db = Database::getDatabase();

            // get url sections
            $urlParts = parse_url($fileUpload->requestUrl);
            $siteName = strtolower($urlParts['host']);

            // check if we can leech the file
            $foundSiteDetails = null;
            $siteDetails = $db->getRows('SELECT * '
                    . 'FROM plugin_fileleech_site');
            foreach ($siteDetails AS $siteDetail) {
                if (strpos(strtolower($siteDetail['site_url']), $siteName) !== false) {
                    $foundSiteDetails = $siteDetail;
                }
            }

            if ($foundSiteDetails !== null) {
                // log download for site usage restrictions
                $pluginFileleechDownload = PluginFileleechDownload::create();
                $pluginFileleechDownload->site_id = $foundSiteDetails['id'];
                $pluginFileleechDownload->file_url = $fileUpload->requestUrl;
                $pluginFileleechDownload->filesize = $fileUpload->size;
                $pluginFileleechDownload->user_id = null;
                $Auth = $this->getAuth();
                if ($Auth->loggedIn()) {
                    $pluginFileleechDownload->user_id = (int) $Auth->id;
                }
                $pluginFileleechDownload->user_ip_address = CoreHelper::getUsersIPAddress();
                $pluginFileleechDownload->date_download = CoreHelper::sqlDateTime();
                $pluginFileleechDownload->save();
            }
        }
    }

}
