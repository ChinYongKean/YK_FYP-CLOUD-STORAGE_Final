<?php

namespace Plugins\Fileleech\Controllers;

use App\Core\BaseController;

class FileleechController extends BaseController
{

}
