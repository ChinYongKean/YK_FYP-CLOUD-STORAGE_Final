<?php

namespace Plugins\Fileleech\Controllers\Admin;

use App\Core\Database;
use App\Controllers\Admin\PluginController AS CorePluginController;
use App\Helpers\AdminHelper;
use App\Helpers\CoreHelper;
use App\Helpers\PluginHelper;
use App\Helpers\LogHelper;
use App\Models\Plugin;
use Plugins\Fileleech\Models\PluginFileleechSite;
use Plugins\Fileleech\Models\PluginFileleechAccessDetail;

class PluginController extends CorePluginController
{

    public function pluginSettings() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // load plugin details
        $folderName = 'fileleech';
        $plugin = Plugin::loadOneByClause('folder_name = :folder_name', array(
                    'folder_name' => $folderName,
        ));

        if (!$plugin) {
            return $this->redirect(ADMIN_WEB_ROOT . '/plugin_manage?error=' . urlencode('There was a problem loading the plugin details.'));
        }

        // clear old download logs, kept for 3 months
        $db->query('DELETE FROM plugin_fileleech_download '
                . 'WHERE date_download < DATE_SUB(NOW(), INTERVAL 3 MONTH)');

        // load premium site details
        $siteDetails = $db->getRows('SELECT * '
                . 'FROM plugin_fileleech_site '
                . 'ORDER BY site_name ASC');

        // default params
        $plugin_enabled = (int) $plugin->plugin_enabled;
        $enabled_non_user = 1;
        $enabled_free_user = 1;
        $enabled_paid_user = 1;
        $max_download_traffic_non_user = '';
        $max_download_traffic_free_user = '';
        $max_download_traffic_paid_user = '';
        $max_download_volume_non_user = '';
        $max_download_volume_free_user = '';
        $max_download_volume_paid_user = '';
        $show_leech_tab = 1;
        $plowdown_path = '/usr/local/bin/plowdown';

        // load existing settings
        if (strlen($plugin->plugin_settings)) {
            $plugin_settings = json_decode($plugin->plugin_settings, true);
            if ($plugin_settings) {
                // load settings locally
                $enabled_free_user = $plugin_settings['enabled_free_user'];
                $enabled_paid_user = $plugin_settings['enabled_paid_user'];
                $max_download_traffic_non_user = $plugin_settings['max_download_traffic_non_user'];
                $max_download_traffic_free_user = $plugin_settings['max_download_traffic_free_user'];
                $max_download_traffic_paid_user = $plugin_settings['max_download_traffic_paid_user'];
                $max_download_volume_non_user = $plugin_settings['max_download_volume_non_user'];
                $max_download_volume_free_user = $plugin_settings['max_download_volume_free_user'];
                $max_download_volume_paid_user = $plugin_settings['max_download_volume_paid_user'];
                $show_leech_tab = $plugin_settings['show_leech_tab'];
                $plowdown_path = isset($plugin_settings['plowdown_path']) ? $plugin_settings['plowdown_path'] : $plowdown_path;
            }
        }

        // handle page submissions
        if ($request->request->has('submitted')) {
            // get variables
            $plugin_enabled = (int) $request->request->get('plugin_enabled');
            $plugin_enabled = $plugin_enabled != 1 ? 0 : 1;
            $enabled_non_user = (int) $_REQUEST['enabled_non_user'];
            $enabled_free_user = (int) $_REQUEST['enabled_free_user'];
            $enabled_paid_user = (int) $_REQUEST['enabled_paid_user'];
            $max_download_traffic_non_user = (float) $_REQUEST['max_download_traffic_non_user'];
            $max_download_traffic_free_user = (float) $_REQUEST['max_download_traffic_free_user'];
            $max_download_traffic_paid_user = (float) $_REQUEST['max_download_traffic_paid_user'];
            $max_download_volume_non_user = (float) $_REQUEST['max_download_volume_non_user'];
            $max_download_volume_free_user = (float) $_REQUEST['max_download_volume_free_user'];
            $max_download_volume_paid_user = (float) $_REQUEST['max_download_volume_paid_user'];
            $show_leech_tab = (int) $_REQUEST['show_leech_tab'];
            $plowdown_path = strlen(trim($_REQUEST['plowdown_path'])) ? trim($_REQUEST['plowdown_path']) : $plowdown_path;

            // validate submission
            if (_CONFIG_DEMO_MODE == true) {
                AdminHelper::setError(AdminHelper::t('no_changes_in_demo_mode', 'No change permitted in demo mode.'));
            }

            // update the settings
            if (AdminHelper::isErrors() == false) {
                // compile new settings
                $settingsArr = array();
                $settingsArr['enabled_non_user'] = $enabled_non_user;
                $settingsArr['enabled_free_user'] = $enabled_free_user;
                $settingsArr['enabled_paid_user'] = $enabled_paid_user;
                $settingsArr['max_download_traffic_non_user'] = $max_download_traffic_non_user;
                $settingsArr['max_download_traffic_free_user'] = $max_download_traffic_free_user;
                $settingsArr['max_download_traffic_paid_user'] = $max_download_traffic_paid_user;
                $settingsArr['max_download_volume_non_user'] = $max_download_volume_non_user;
                $settingsArr['max_download_volume_free_user'] = $max_download_volume_free_user;
                $settingsArr['max_download_volume_paid_user'] = $max_download_volume_paid_user;
                $settingsArr['show_leech_tab'] = $show_leech_tab;
                $settingsArr['plowdown_path'] = $plowdown_path;

                // update the plugin settings
                $plugin->plugin_enabled = $plugin_enabled;
                $plugin->plugin_settings = json_encode($settingsArr);
                $plugin->save();

                // reload plugin cache
                PluginHelper::loadPluginConfigurationFiles(true);
                AdminHelper::setSuccess('Plugin settings updated.');
            }
        }

        // prepare site details for view
        foreach ($siteDetails AS $k => $siteDetail) {
            // get stats
            $siteDetails[$k]['_totalDownloads24Hour'] = (int) $db->getValue('SELECT COUNT(id) '
                            . 'FROM plugin_fileleech_download '
                            . 'WHERE site_id = :site_id '
                            . 'AND date_download > DATE_SUB(NOW(), INTERVAL 24 HOUR)', array(
                        'site_id' => (int) $siteDetail['id'],
            ));
            $siteDetails[$k]['_totalDownloads30Days'] = (int) $db->getValue('SELECT COUNT(id) '
                            . 'FROM plugin_fileleech_download '
                            . 'WHERE site_id = :site_id '
                            . 'AND date_download > DATE_SUB(NOW(), INTERVAL 30 DAY)', array(
                        'site_id' => (int) $siteDetail['id'],
            ));
            $siteDetails[$k]['_totalFilesize24Hour'] = (int) $db->getValue('SELECT SUM(filesize) '
                            . 'FROM plugin_fileleech_download '
                            . 'WHERE site_id = :site_id '
                            . 'AND date_download > DATE_SUB(NOW(), INTERVAL 24 HOUR)', array(
                        'site_id' => (int) $siteDetail['id'],
            ));
            $siteDetails[$k]['_totalFilesize30Days'] = (int) $db->getValue('SELECT SUM(filesize) '
                            . 'FROM plugin_fileleech_download '
                            . 'WHERE site_id = :site_id '
                            . 'AND date_download > DATE_SUB(NOW(), INTERVAL 30 DAY)', array(
                        'site_id' => (int) $siteDetail['id'],
            ));

            // prepare min account type details
            $siteDetails[$k]['_minAccountType'] = '';
            $siteDetails[$k]['_totalLoginAvailable'] = '-';
            if ($siteDetail['min_account_type'] == 'free') {
                $siteDetails[$k]['_minAccountType'] = '<span title="A free account is required for leeching." style="color: #5BA85B;">(free)</span>';
                $siteDetails[$k]['_totalLoginAvailable'] = (int) $db->getValue('SELECT COUNT(id) FROM plugin_fileleech_access_detail WHERE site_id = ' . (int) $siteDetail['id']);
                $siteDetails[$k]['_totalLoginAvailable'] = '<a href="#" onClick="editSiteLoginForm(' . $siteDetail['id'] . '); return false;">' . $siteDetails[$k]['_totalLoginAvailable'] . '</a>';
            }
            elseif ($siteDetail['min_account_type'] == 'paid') {
                $siteDetails[$k]['_minAccountType'] = '<span title="A paid account is required for leeching." style="color: #D17519;">(paid)</span>';
                $siteDetails[$k]['_totalLoginAvailable'] = (int) $db->getValue('SELECT COUNT(id) FROM plugin_fileleech_access_detail WHERE site_id = ' . (int) $siteDetail['id']);
                $siteDetails[$k]['_totalLoginAvailable'] = '<a href="#" onClick="editSiteLoginForm(' . $siteDetail['id'] . '); return false;">' . $siteDetails[$k]['_totalLoginAvailable'] . '</a>';
            }
        }

        // load template
        return $this->render('admin/plugin_settings.html', array(
                    'pluginName' => $plugin->plugin_name,
                    'yesNoOptions' => array(
                        0 => 'No',
                        1 => 'Yes'),
                    'plugin_enabled' => $plugin_enabled,
                    'enabled_non_user' => $enabled_non_user,
                    'enabled_free_user' => $enabled_free_user,
                    'enabled_paid_user' => $enabled_paid_user,
                    'max_download_traffic_non_user' => $max_download_traffic_non_user,
                    'max_download_traffic_free_user' => $max_download_traffic_free_user,
                    'max_download_traffic_paid_user' => $max_download_traffic_paid_user,
                    'max_download_volume_non_user' => $max_download_volume_non_user,
                    'max_download_volume_free_user' => $max_download_volume_free_user,
                    'max_download_volume_paid_user' => $max_download_volume_paid_user,
                    'show_leech_tab' => $show_leech_tab,
                    'plowdown_path' => $plowdown_path,
                    'siteDetails' => $siteDetails,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function ajaxSiteManageAddForm() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // prepare variables
        $siteName = '';
        $siteUrl = '';
        $minAccountType = 'paid';

        // is this an edit?
        $gEditSiteId = null;
        $formType = 'add the';
        $extraDetail = 'Note: The site must be supported by plowshare. You can <a href="https://github.com/mcrapet/plowshare-modules-legacy" target="_blank">check here</a> for supported download sites. Also note that any which require captcha verification on logged in users can not be supported.';
        if (isset($_REQUEST['gEditSiteId'])) {
            $gEditSiteId = (int) $_REQUEST['gEditSiteId'];
            if ($gEditSiteId) {
                $siteDetails = $db->getRow("SELECT * "
                        . "FROM plugin_fileleech_site "
                        . "WHERE id = :id "
                        . "LIMIT 1", array(
                    'id' => $gEditSiteId,
                ));
                if ($siteDetails) {
                    $siteName = $siteDetails['site_name'];
                    $siteUrl = $siteDetails['site_url'];
                    $minAccountType = $siteDetails['min_account_type'];

                    $formType = 'update';
                    $extraDetail = '';
                }
            }
        }

        // prepare result
        $result = array();
        $result['error'] = false;
        $result['msg'] = '';
        $result['html'] = $this->getRenderedTemplate('admin/ajax/site_manage_add_form.html', array(
            'siteName' => $siteName,
            'siteUrl' => $siteUrl,
            'minAccountType' => $minAccountType,
            'formType' => $formType,
            'extraDetail' => $extraDetail,
            'minAccountTypeOptions' => array(
                'none' => 'None',
                'free' => 'Free',
                'paid' => 'Paid',
            ),
                ), PLUGIN_DIRECTORY_ROOT . 'fileleech/views');

        // output response
        return $this->renderJson($result);
    }

    public function ajaxSiteManageAddProcess() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // get variables
        $siteName = trim($_REQUEST['site_name']);
        $siteUrl = trim(strtolower($_REQUEST['site_url']));
        $siteUrl = str_replace(array('http://', 'https://'), '', $siteUrl);
        if (substr($siteUrl, 0, 3) == 'www') {
            $siteUrl = substr($siteUrl, 3, strlen($siteUrl));
        }
        $existingSiteId = null;
        if (isset($_REQUEST['existing_site_id'])) {
            $existingSiteId = (int) $_REQUEST['existing_site_id'];
        }
        $minAccountType = trim(strtolower($_REQUEST['min_account_type']));

        // prepare result
        $result = array();
        $result['error'] = false;
        $result['msg'] = '';

        // validate submission
        if (strlen($siteName) == 0) {
            $result['error'] = true;
            $result['msg'] = AdminHelper::t("plugin_fileleech_enter_site_name", "Please enter the site name to use as a label.");
        }
        elseif (strlen($siteUrl) == 0) {
            $result['error'] = true;
            $result['msg'] = AdminHelper::t("plugin_fileleech_enter_site_url", "Please enter the site url.");
        }
        elseif (_CONFIG_DEMO_MODE == true) {
            $result['error'] = true;
            $result['msg'] = AdminHelper::t("no_changes_in_demo_mode");
        }

        if (strlen($result['msg']) == 0) {
            $row = $db->getRow('SELECT id '
                    . 'FROM plugin_fileleech_site '
                    . 'WHERE site_name = :site_name '
                    . 'AND id != :id', array(
                'site_name' => $siteName,
                'id' => $existingSiteId,
            ));

            if (is_array($row)) {
                $result['error'] = true;
                $result['msg'] = AdminHelper::t("plugin_fileleech_label_already_in_use", "A site with that name already exists, please choose another.");
            }
            else {
                if ($existingSiteId > 0) {
                    // update the existing record
                    $pluginFileleechSite = PluginFileleechSite::loadOneById($existingSiteId);
                    $pluginFileleechSite->site_name = $siteName;
                    $pluginFileleechSite->site_url = $siteUrl;
                    $pluginFileleechSite->min_account_type = $minAccountType;
                    $pluginFileleechSite->save();

                    $result['error'] = false;
                    $result['msg'] = 'Site \'' . $siteName . '\' updated.';
                }
                else {
                    // add the entry
                    $pluginFileleechSite = PluginFileleechSite::create();
                    $pluginFileleechSite->site_name = $siteName;
                    $pluginFileleechSite->site_url = $siteUrl;
                    $pluginFileleechSite->min_account_type = $minAccountType;
                    if (!$pluginFileleechSite->save()) {
                        $result['error'] = true;
                        $result['msg'] = AdminHelper::t("plugin_fileleech_error_problem_record", "There was a problem adding the site, please try again.");
                    }
                    else {
                        $result['error'] = false;
                        $result['msg'] = 'Site \'' . $siteName . '\' has been added. Now set any paid account logins for the leeching to work.';
                    }
                }
            }
        }

        return $this->renderJson($result);
    }

    public function ajaxLoginManageAddForm() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // prepare variables
        $gEditSiteId = (int) $_REQUEST['gEditSiteId'];
        $siteDetails = $db->getRow("SELECT * "
                . "FROM plugin_fileleech_site "
                . "WHERE id = :id", array(
            'id' => $gEditSiteId,
        ));

        if ($siteDetails) {
            $siteName = $siteDetails['site_name'];
            $siteUrl = $siteDetails['site_url'];
            $minAccountType = $siteDetails['min_account_type'];
        }

        // load existing logins
        $loginDetailsStr = '';
        $loginDetails = $db->getRows("SELECT username, password "
                . "FROM plugin_fileleech_access_detail "
                . "WHERE site_id = :site_id", array(
            'site_id' => $gEditSiteId,
        ));

        if ($loginDetails) {
            foreach ($loginDetails AS $loginDetail) {
                $loginDetailsStr .= $loginDetail['username'] . '|' . $loginDetail['password'] . "\n";
            }
        }

        if (_CONFIG_DEMO_MODE == true) {
            $loginDetailsStr = 'hidden_in|demo_mode';
        }

        // prepare min account type details
        $minAccountType = 'no account';
        if ($minAccountType == 'free') {
            $minAccountType = 'at least a free account';
        }
        elseif ($minAccountType == 'paid') {
            $minAccountType = 'a paid account';
        }

        // prepare result
        $result = array();
        $result['error'] = false;
        $result['msg'] = '';
        $result['html'] = $this->getRenderedTemplate('admin/ajax/login_manage_add_form.html', array(
            'siteName' => $siteName,
            'siteUrl' => $siteUrl,
            'minAccountType' => $minAccountType,
            'loginDetailsStr' => $loginDetailsStr,
                ), PLUGIN_DIRECTORY_ROOT . 'fileleech/views');

        // output response
        return $this->renderJson($result);
    }

    public function ajaxLoginManageAddProcess() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // get variables
        $existing_site_id = (int) $_REQUEST['existing_site_id'];
        $login_details    = trim($_REQUEST['login_details']);
        $login_details    = str_replace(array("\n\r", "\r", "\n\n"), "\n", $login_details);

        // prepare result
        $result = array();
        $result['error'] = false;
        $result['msg'] = '';

        // validate submission
        if (_CONFIG_DEMO_MODE == true)
        {
            $result['error'] = true;
            $result['msg']   = AdminHelper::t("no_changes_in_demo_mode");
        }
        elseif (strlen($login_details) > 0)
        {
            // make sure we have the correct format
            $rows = explode("\n", $login_details);
            foreach ($rows AS $row)
            {
                if (strlen($row) == 0)
                {
                    continue;
                }

                // check items
                $items = explode('|', $row);
                if (COUNT($items) != 2)
                {
                    $result['error'] = true;
                    $result['msg']   = AdminHelper::t("plugin_fileleech_logins_incorrect_format", "Logins are in the wrong format, please check.");
                }
            }
        }

        if (strlen($result['msg']) == 0)
        {
            // remove existing logins
            $db->query('DELETE '
                    . 'FROM plugin_fileleech_access_detail '
                    . 'WHERE site_id = :site_id', array(
                        'site_id' => $existing_site_id,
                    ));

            // add logins
            $rows = explode("\n", $login_details);
            foreach ($rows AS $row)
            {
                if (strlen($row) == 0)
                {
                    continue;
                }

                // check items
                $items = explode('|', $row);
                if (COUNT($items) == 2)
                {
                    // add the file server
                    $pluginFileleechAccessDetail = PluginFileleechAccessDetail::create();
                    $pluginFileleechAccessDetail->site_id  = $existing_site_id;
                    $pluginFileleechAccessDetail->username = trim($items[0]);
                    $pluginFileleechAccessDetail->password = trim($items[1]);
                    $pluginFileleechAccessDetail->save();
                }
            }
        }

        return $this->renderJson($result);
    }

}
