<?php

namespace Plugins\Archivemanager\Models;

use App\Core\Model;

class PluginArchiveManagerQueue extends Model
{
    
}
