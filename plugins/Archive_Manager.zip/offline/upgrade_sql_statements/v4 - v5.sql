ALTER TABLE `plugin_archive_manager_queue` ADD `convert_host` VARCHAR(100) NULL AFTER `status`, ADD INDEX (`convert_host`);
