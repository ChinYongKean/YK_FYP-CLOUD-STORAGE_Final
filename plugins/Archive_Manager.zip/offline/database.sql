CREATE TABLE IF NOT EXISTS `plugin_archive_manager_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `file_id` int(11) DEFAULT NULL,
  `to_folder_id` int(11) DEFAULT NULL,
  `action_type` enum('extract','archive_zip','archive_rar','split','join') COLLATE utf8_bin NOT NULL DEFAULT 'extract',
  `additional_data` text COLLATE utf8_bin NOT NULL,
  `date_scheduled` datetime NOT NULL,
  `status` enum('pending','processing','cancelled','failed','completed') COLLATE utf8_bin NOT NULL DEFAULT 'pending',
  `convert_host` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `date_started` datetime DEFAULT NULL,
  `date_finished` datetime DEFAULT NULL,
  `notes` text COLLATE utf8_bin,
  PRIMARY KEY (`id`),
  KEY `convert_host` (`convert_host`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;