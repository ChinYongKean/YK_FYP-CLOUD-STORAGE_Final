<?php

/*
 * Title: Extract, Archive, Split and Join Script.
 * Author: YetiShare.com
 * Period: Run by cron every minute or as required. (it won't trigger a new
 * instance until the last one is finished)
 * 
 * Description:
 * Script to process any pending archives or extracts via the YetiShare
 * archivemanager plugin. It can be run on a different server than the main site
 * as long as the script codebase is available.
 * 
 * How To Call:
 * On the command line via PHP, like this:
 * php process_archive_queue.cron.php
 * 
 */

namespace Plugins\Archivemanager\Tasks;

// include framework
use App\Core\Database;
use App\Core\Framework;
use App\Helpers\BackgroundTaskHelper;
use App\Helpers\CoreHelper;
use App\Helpers\FileHelper;
use App\Helpers\FileServerHelper;
use App\Helpers\FileServerContainerHelper;
use App\Helpers\InternalNotificationHelper;
use App\Helpers\PluginHelper;
use App\Helpers\LogHelper;
use App\Helpers\TranslateHelper;
use App\Helpers\ValidationHelper;
use App\Models\File;
use App\Models\FileFolder;
use App\Models\User;
use phpseclib\Net\SFTP;
use phpseclib\Crypt\RSA;

require_once(realpath(dirname(__FILE__) . '/../../../app/core/Framework.class.php'));

// setup light environment
Framework::runLight();

// ignore memory limits
ini_set('memory_limit', '-1');

// get database
$db = Database::getDatabase();

// background task logging
BackgroundTaskHelper::start();

// setup logging
LogHelper::setContext('plugin-archive-manager-queue');

$databaseHost = _CONFIG_DB_HOST;
$databaseUser = _CONFIG_DB_USER;
$databasePass = _CONFIG_DB_PASS;
$databaseName = _CONFIG_DB_NAME;

define('ON_SCRIPT_INSTALL', true);
define('SERVER_NAME_FOR_LOGS', _CONFIG_SITE_HOST_URL);

define("DATABASE_HOST", $databaseHost);
define("DATABASE_USER", $databaseUser);
define("DATABASE_PASS", $databasePass);
define("DATABASE_NAME", $databaseName);

/*
 * Connect database and load config from plugin settings.
 */
try {
    $db = dbConnect();
    if ($db) {
        $stmt = $db->query("SELECT * "
                . "FROM plugin "
                . "WHERE folder_name='archivemanager' "
                . "LIMIT 1");
        $pluginDetails = $stmt->fetch(\PDO::FETCH_ASSOC);
        $pluginSettings = $pluginDetails['plugin_settings'];
        if ($pluginSettings) {
            $pluginSettingsArr = json_decode($pluginSettings, true);
        }
    }
}
catch (Exception $e) {
    echo "\n" . $e->getMessage() . "\n";

    // logs
    LogHelper::error($e->getMessage());
    LogHelper::breakInLogFile();

    // background task logging
    BackgroundTaskHelper::end();
    exit;
}

/*
 * General config.
 */
// change this to set the maximum queue items that can be done at once.
define("MAX_CONCURRENT_PROCESSES", $pluginSettingsArr['max_conversions']);

// get binary paths
define("SERVER_PATH_ZIP", (isset($pluginSettingsArr['server_path_zip']) && strlen($pluginSettingsArr['server_path_zip']))?($pluginSettingsArr['server_path_zip']):'');
define("SERVER_PATH_RAR", (isset($pluginSettingsArr['server_path_rar']) && strlen($pluginSettingsArr['server_path_rar']))?($pluginSettingsArr['server_path_rar']):'');

// show output, used for debugging
define("SHOW_OUTPUT", true);

// local paths, shouldn't need changed
define("SCRIPT_ROOT_FOLDER", dirname(__FILE__));
define("CACHE_PATH", CACHE_DIRECTORY_ROOT . '/plugins/archivemanager');

/*
 * Main conversion code.
 */

// php script timeout for long conversions (12 hours)
set_time_limit(60 * 60 * 12);

// report simple running errors
error_reporting(E_ERROR | E_WARNING | E_PARSE);

// make sure the local cache path exists
if (!file_exists(CACHE_PATH)) {
    mkdir(CACHE_PATH, 0777, true);
}

// make sure shell_exec is available
if (!function_exists('shell_exec')) {
    output("Error: The PHP function shell_exec() is not available and may be blocked within your php.ini file. Please check and try again.\n");

    // logs
    LogHelper::breakInLogFile();

    // background task logging
    BackgroundTaskHelper::end();
    exit;
}

// required for compatibility for pre PHP5.5
if (!function_exists('curl_file_create')) {

    function curl_file_create($filename, $mimetype = '', $postname = '') {
        return "@$filename;filename="
                . ($postname ?: basename($filename))
                . ($mimetype ? ";type=$mimetype" : '');
    }

}

// connect db and get any pending rows
try {
    $db = new \PDO('mysql:host=' . DATABASE_HOST . ';dbname=' . DATABASE_NAME . ';charset=utf8', DATABASE_USER, DATABASE_PASS);
    if ($db) {
        // fail any which have been processing for more than 1 day, sorts occasional issues with timeouts
        $stmt = $db->query("UPDATE plugin_archive_manager_queue "
                . "SET status='failed', "
                . "date_finished=NOW() "
                . "WHERE status='processing' "
                . "AND date_started < NOW() - INTERVAL 1 DAY");

        // make sure there's none being processed
        $stmt = $db->query("SELECT COUNT(id) AS total "
                . "FROM plugin_archive_manager_queue "
                . "WHERE status='processing'");
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        if ((int) $row['total'] >= MAX_CONCURRENT_PROCESSES) {
            // max concurrent
            output("Already " . (int) $row['total'] . " queue item(s) processing.\n");

            // logs
            LogHelper::breakInLogFile();

            // background task logging
            BackgroundTaskHelper::end();
            exit;
        }

        // check for pending processes
        $stmt = $db->query("SELECT * "
                . "FROM plugin_archive_manager_queue "
                . "WHERE status='pending' "
                . "ORDER BY date_scheduled ASC "
                . "LIMIT 1");
        $pendingRow = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$pendingRow) {
            output("No pending queue items found.\n", true);

            // background task logging
            BackgroundTaskHelper::end();
            exit;
        }
    }
}
catch (Exception $e) {
    output("\n");
    output("ERROR: " . $e->getMessage() . "\n");
    output("\n");

    // logs
    LogHelper::breakInLogFile();

    // background task logging
    BackgroundTaskHelper::end();
    exit;
}

// log
output("Found 1 pending queue item, id #" . $pendingRow['id'] . ".\n");
define("TEMP_CACHE_PATH", CACHE_PATH . '/' . $pendingRow['id']);
if (!file_exists(TEMP_CACHE_PATH)) {
    @mkdir(TEMP_CACHE_PATH, 0777, true);
}

// set to processing
$db->query("UPDATE plugin_archive_manager_queue "
        . "SET status='processing', "
        . "date_started=NOW() "
        . "WHERE id=" . $pendingRow['id'] . " "
        . "AND status='pending' "
        . "LIMIT 1");

// check action
output("Found '" . $pendingRow['action_type'] . "' action.\n");
switch ($pendingRow['action_type']) {
    // EXTRACT
    case 'extract':
        // load file record
        $stmt = $db->query("SELECT * "
                . "FROM file "
                . "WHERE id=" . $pendingRow['file_id'] . " "
                . "AND status='active' "
                . "LIMIT 1");
        $file = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$file) {
            // log
            output("Error: Could not load file data. It may be inactive or missing.\n");

            // set to failed
            $db->query("UPDATE plugin_archive_manager_queue "
                    . "SET status='failed', "
                    . "date_started=NOW(), "
                    . "date_finished=NOW(), "
                    . "notes='Error: Could not load file data. It may be inactive or missing.' "
                    . "WHERE id=" . $pendingRow['id'] . " "
                    . "LIMIT 1");

            // logs
            LogHelper::breakInLogFile();

            // background task logging
            BackgroundTaskHelper::end();
            exit;
        }

        // log
        output("Getting file from storage...\n");

        // grab file
        $localFile = getFileContent($db, $file);
        if (!$localFile) {
            // log
            output("Error: Could not get file contents.\n");

            // set to failed
            $db->query("UPDATE plugin_archive_manager_queue "
                    . "SET status='failed', "
                    . "date_finished=NOW(), "
                    . "notes='Error: Could not get file contents, please check the system logs within the admin area for more details.' "
                    . "WHERE id=" . $pendingRow['id'] . " "
                    . "LIMIT 1");

            // logs
            LogHelper::breakInLogFile();

            // background task logging
            BackgroundTaskHelper::end();
            exit;
        }

        // get filetype
        $fileType = strtolower($file['extension']);
        if (!in_array($fileType, array('zip', 'rar'))) {
            // log
            output("Error: File is an unsupported type (" . $fileType . ").\n");
            $db->query("UPDATE plugin_archive_manager_queue "
                    . "SET status='failed', "
                    . "date_finished=NOW(), "
                    . "notes='Error: File is an unsupported type (" . $fileType . ")' "
                    . "WHERE id=" . $pendingRow['id'] . " "
                    . "LIMIT 1");

            // logs
            LogHelper::breakInLogFile();

            // background task logging
            BackgroundTaskHelper::end();
            exit;
        }

        // log
        output("Extracting " . $fileType . " file...\n");

        // setup command
        define('TEMP_NEW_FILE_PATH', TEMP_CACHE_PATH . '/' . md5($pendingRow['id'] . microtime() . rand(11111, 99999)));
        @mkdir(TEMP_NEW_FILE_PATH, 0777, true);

        if ($fileType == 'zip') {
            $unzipPathCmd = SERVER_PATH_ZIP.'unzip ' . $localFile . ' -d ' . TEMP_NEW_FILE_PATH;
        }
        else {
            $unzipPathCmd = SERVER_PATH_RAR.'unrar e ' . $localFile . ' ' . TEMP_NEW_FILE_PATH;
        }

        // output to screen
        $notesMessage = "Command:\n";
        $notesMessage .= $unzipPathCmd . "\n\n";
        output($notesMessage);

        if (SHOW_OUTPUT != 1) {
            $unzipPathCmd .= ' 2>&1';
        }

        $output = shell_exec($unzipPathCmd);

        // prepare notes
        $notesMessage .= "Result:\n";
        $notesMessage .= $output;
        output($notesMessage);
        output("\n");

        // remove original zip file
        unlink($localFile);

        // import files
        $rs = importFiles(TEMP_NEW_FILE_PATH, $pendingRow, $pendingRow['to_folder_id']);
        if (!$rs) {
            $db->query("UPDATE plugin_archive_manager_queue "
                    . "SET status='failed', "
                    . "date_finished=NOW(), "
                    . "notes='Error: Could not extract and import files, please check the system logs within the admin area for more details.' "
                    . "WHERE id=" . $pendingRow['id'] . " "
                    . "LIMIT 1");

            // logs
            LogHelper::breakInLogFile();

            // background task logging
            BackgroundTaskHelper::end();
            exit;
        }

        // create account notification
        $folderUrl = WEB_ROOT . '/account';
        if ((int) $pendingRow['to_folder_id']) {
            $folder = FileFolder::loadOneById($pendingRow['to_folder_id']);
            $folderUrl = $folder->getFolderUrl();
        }
        $content = TranslateHelper::t('plugin_archivemanager_internal_notify_split', 'Your archive [[[ARCHIVE_NAME]]] has been extracted. Click here to view the folder it\'s within.', array('ARCHIVE_NAME' => ValidationHelper::safeOutputToScreen($file['originalFilename'])));
        InternalNotificationHelper::add($pendingRow['user_id'], $content, 'entypo-thumbs-up', $folderUrl);

        break;

    // ARCHIVE
    case 'archive_zip':
    case 'archive_rar':

        $notesMessage = '';

        // log
        output("Getting files from storage...\n");

        // load files
        $rowDataArr = json_decode($pendingRow['additional_data'], true);
        $fileIds = $rowDataArr['file_ids'];
        $stmt = $db->query('SELECT * '
                . 'FROM file '
                . 'WHERE id IN (' . implode(',', $fileIds) . ') '
                . 'AND status = "active" '
                . 'AND userId = ' . $pendingRow['user_id']);
        $fileArr = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        if (COUNT($fileArr) == 0) {
            // log
            output("Error: Could not load any files to archive.\n");

            // set to failed
            $db->query("UPDATE plugin_archive_manager_queue "
                    . "SET status='failed', "
                    . "date_finished=NOW(), "
                    . "notes='Error: Could not load any files to archive, please check the system logs within the admin area for more details.' "
                    . "WHERE id=" . $pendingRow['id'] . " "
                    . "LIMIT 1");

            // logs
            LogHelper::breakInLogFile();

// background task logging
            BackgroundTaskHelper::end();
            exit;
        }

        // temp path for files being zipped
        $filePathDirectory = md5($pendingRow['id'] . microtime() . rand(11111, 99999));
        define('TEMP_NEW_FILE_PATH', TEMP_CACHE_PATH . '/' . $filePathDirectory);
        @mkdir(TEMP_NEW_FILE_PATH, 0777, true);

        $localFileArr = array();
        foreach ($fileArr AS $fileArrItem) {
            // grab file
            $localFile = getFileContent($db, $fileArrItem);
            if (!$localFile) {
                // log
                output("Error: Could not get file contents " . $fileArrItem['originalFilename'] . ".\n");
                $notesMessage .= "Error: Could not get file contents. File: " . $fileArrItem['originalFilename'] . " #" . $file['id'];
            }
            else {
                // rename to actual filename
                $originalFilename = $fileArrItem['originalFilename'];
                $originalFilename = str_replace(array('\'', '../', './', '\\', '"', ')', '('), '', $originalFilename);
                if (strlen($originalFilename) == 0) {
                    $originalFilename = rand(100000, 999999);
                }

                $newName = TEMP_NEW_FILE_PATH . '/' . $originalFilename;
                if (file_exists($newName)) {
                    @unlink($newName);
                }

                // rename to the original filename
                $rs = rename($localFile, $newName);
                if ($rs) {
                    $localFileArr[] = $newName;
                }
                else {
                    // log
                    output("Error: Got file contents but could not rename to " . $newName . ".\n");
                    $notesMessage .= "Error: Got file contents but could not rename to " . $newName;
                    @unlink($localFile);
                }
            }
        }

        // log
        output("Archiving files...\n");
        $archiveFilename = $rowDataArr['archive_filename'];
        $archiveFilename = str_replace(array('"', '\'', '\\', '/', ':', ';', '%', '"', ')', '('), '', $archiveFilename);
        if ($pendingRow['action_type'] == 'archive_zip') {
            $newArchivePath = TEMP_CACHE_PATH . '/' . $archiveFilename . '.zip';

            // ensure archive doesn't already exist
            if (file_exists($newArchivePath)) {
                @unlink($newArchivePath);
            }

            // double check path exists to ensure something hasn't gone wrong and it's reverted to another folder
            if (!file_exists(TEMP_NEW_FILE_PATH)) {
                $db->query("UPDATE plugin_archive_manager_queue "
                        . "SET status='failed', "
                        . "date_finished=NOW(), "
                        . "notes='Error: Path of extracted files disappeared. Script halted.' "
                        . "WHERE id=" . $pendingRow['id'] . " "
                        . "LIMIT 1");

                // logs
                LogHelper::breakInLogFile();

                // background task logging
                BackgroundTaskHelper::end();
                exit;
            }

            // do we have a password to set
            $passwordCmd = '';
            if (strlen($rowDataArr['access_password'])) {
                $password = str_replace(array('"', ' '), '', $rowDataArr['access_password']);
                $passwordCmd = '--password "' . $password . '" ';
            }

            // handle compression options
            $compressCmd = '';
            if ($rowDataArr['archive_compression']) {
                if ((int) $rowDataArr['archive_compression'] > 0) {
                    $compressLevelZip = ((int) $rowDataArr['archive_compression'] * 2) - 1;
                    if ($compressLevelZip > 9) {
                        $compressLevelZip = 9;
                    }

                    if ($compressLevelZip >= 1) {
                        $compressCmd = '-' . (int) $compressLevelZip . ' ';
                    }
                }
            }
            $zipPathCmd = 'cd "' . TEMP_NEW_FILE_PATH . '" && '.SERVER_PATH_ZIP.'zip ' . $passwordCmd . $compressCmd . '-r "' . $newArchivePath . '" "./"';
        }
        else {
            $newArchivePath = TEMP_CACHE_PATH . '/' . $archiveFilename . '.rar';

            // ensure archive doesn't already exist
            if (file_exists($newArchivePath)) {
                @unlink($newArchivePath);
            }

            if (!file_exists(TEMP_NEW_FILE_PATH)) {
                $db->query("UPDATE plugin_archive_manager_queue "
                        . "SET status='failed', "
                        . "date_finished=NOW(), "
                        . "notes='Error: Path of extracted files disappeared. Script halted.' "
                        . "WHERE id=" . $pendingRow['id'] . " "
                        . "LIMIT 1");

                // logs
                LogHelper::breakInLogFile();

                // background task logging
                BackgroundTaskHelper::end();
                exit;
            }

            // do we have a password to set
            $passwordCmd = '';
            if (strlen($rowDataArr['access_password'])) {
                $password = str_replace(array('"', ' '), '', $rowDataArr['access_password']);
                $passwordCmd = '-p' . $password . ' ';
            }

            // handle compression options
            $compressCmd = '';
            if ($rowDataArr['archive_compression']) {
                $compressLevelRar = (int) $rowDataArr['archive_compression'];
                if ($compressLevelRar > 5) {
                    $compressLevelRar = 5;
                }

                $compressCmd = '-m' . (int) $compressLevelRar . ' ';
            }

            // handle recovery record
            $recoverCmd = '';
            if ((int) $rowDataArr['archive_create_recovery_record'] == 1) {
                $recoverCmd = '-rr ';
            }

            $zipPathCmd = 'cd "' . TEMP_NEW_FILE_PATH . '" && '.SERVER_PATH_RAR.'rar a ' . $passwordCmd . $compressCmd . $recoverCmd . '-r "' . $newArchivePath . '" "./"';
        }

        // output to screen
        $notesMessage = "Command:\n";
        $notesMessage .= $zipPathCmd . "\n\n";
        output($notesMessage);

        if (SHOW_OUTPUT != 1) {
            $zipPathCmd .= ' 2>&1';
        }

        $output = shell_exec($zipPathCmd);

        // prepare notes
        $notesMessage .= "Result:\n";
        $notesMessage .= $output;
        output($notesMessage);
        output("\n");

        // remove original files
        foreach ($localFileArr AS $localFileArrItem) {
            @unlink($localFileArrItem);
        }

        // send into storage via curl
        output("Archive created.\n");
        define('SAVED_FILESIZE', filesize($newArchivePath));
        output("Moving into storage... (" . SAVED_FILESIZE . " bytes)\n");
        $rs = importFile($newArchivePath, $pendingRow, $pendingRow['to_folder_id']);

        // delete new archive
        unlink($newArchivePath);
        @rmdir(TEMP_NEW_FILE_PATH);

        if (!$rs) {
            $db->query("UPDATE plugin_archive_manager_queue "
                    . "SET status='failed', "
                    . "date_finished=NOW(), "
                    . "notes='Error: Could not re-upload the compressed file, please check the system logs within the admin area for more details.' "
                    . "WHERE id=" . $pendingRow['id'] . " "
                    . "LIMIT 1");

            // logs
            LogHelper::breakInLogFile();

            // background task logging
            BackgroundTaskHelper::end();
            exit;
        }

        // should we delete the original files
        if ((int) $rowDataArr['delete_original_files'] == 1) {
            foreach ($fileArr AS $fileArrItem) {
                // delete file
                $fileObj = File::hydrateSingleRecord($fileArrItem);
                $fileObj->removeByUser();
            }
        }

        // create account notification
        $folderUrl = WEB_ROOT . '/account';
        if ((int) $pendingRow['to_folder_id']) {
            $folder = FileFolder::loadOneById($pendingRow['to_folder_id']);
            $folderUrl = $folder->getFolderUrl();
        }
        $content = TranslateHelper::t('plugin_archivemanager_internal_notify_archive', 'Your new archive has been created. Click here to view the folder it\'s within.');
        InternalNotificationHelper::add($pendingRow['user_id'], $content, 'entypo-thumbs-up', $folderUrl);

        break;

    // SPLIT
    case 'split':
        // load file record
        $stmt = $db->query("SELECT * "
                . "FROM file "
                . "WHERE id=" . $pendingRow['file_id'] . " "
                . "AND status='active' "
                . "LIMIT 1");
        $file = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$file) {
            // log
            output("Error: Could not load file data. It may be inactive or missing.\n");

            // set to failed
            $db->query("UPDATE plugin_archive_manager_queue "
                    . "SET status='failed', "
                    . "date_started=NOW(), "
                    . "date_finished=NOW(), "
                    . "notes='Error: Could not load file data. It may be inactive or missing, please check the system logs within the admin area for more details.' "
                    . "WHERE id=" . $pendingRow['id'] . " "
                    . "LIMIT 1");

            // logs
            LogHelper::breakInLogFile();

            // background task logging
            BackgroundTaskHelper::end();
            exit;
        }

        // log
        output("Getting file from storage...\n");

        // grab file
        $localFile = getFileContent($db, $file);
        if (!$localFile) {
            // log
            output("Error: Could not get file contents.\n");

            // set to failed
            $db->query("UPDATE plugin_archive_manager_queue "
                    . "SET status='failed', "
                    . "date_finished=NOW(), "
                    . "notes='Error: Could not get file contents, please check the system logs within the admin area for more details.' "
                    . "WHERE id=" . $pendingRow['id'] . " "
                    . "LIMIT 1");

            // logs
            LogHelper::breakInLogFile();

            // background task logging
            BackgroundTaskHelper::end();
            exit;
        }

        // additional data
        $rowDataArr = json_decode($pendingRow['additional_data'], true);

        // log
        output("Splitting file...\n");

        // setup command
        define('TEMP_NEW_FILE_PATH', TEMP_CACHE_PATH . '/' . md5($pendingRow['id'] . microtime() . rand(11111, 99999)));
        @mkdir(TEMP_NEW_FILE_PATH, 0777, true);

        // prepare split command
        $splitSize = (float) $rowDataArr['split_size'];
        if ($splitSize < 1468006) {
            $splitSize = 1468006;
        }

        $originalFilename = $file['originalFilename'];
        $originalFilename = str_replace(array('\'', '../', './', '\\', '"', '\'', '%', '&', '*'), '', $originalFilename);
        $cmd = SERVER_PATH_ZIP.'split -d -a 3 -b ' . $splitSize . ' "' . $localFile . '" "' . TEMP_NEW_FILE_PATH . '/' . basename($originalFilename) . '."';

        // output to screen
        $notesMessage = "Command:\n";
        $notesMessage .= $cmd . "\n\n";
        output($notesMessage);

        if (SHOW_OUTPUT != 1) {
            $cmd .= ' 2>&1';
        }

        $output = shell_exec($cmd);

        // prepare notes
        $notesMessage .= "Result:\n";
        $notesMessage .= $output;
        output($notesMessage);
        output("\n");

        // remove original zip file
        unlink($localFile);

        // import files
        $rs = importFiles(TEMP_NEW_FILE_PATH, $pendingRow, $pendingRow['to_folder_id']);
        if (!$rs) {
            $db->query("UPDATE plugin_archive_manager_queue "
                    . "SET status='failed', "
                    . "date_finished=NOW(), "
                    . "notes='Error: Could not extract and import files, please check the system logs within the admin area for more details.' "
                    . "WHERE id=" . $pendingRow['id'] . " "
                    . "LIMIT 1");

            // logs
            LogHelper::breakInLogFile();

            // background task logging
            BackgroundTaskHelper::end();
            exit;
        }

        // create account notification
        $folderUrl = WEB_ROOT . '/account';
        if ((int) $pendingRow['to_folder_id']) {
            $folder = FileFolder::loadOneById($pendingRow['to_folder_id']);
            $folderUrl = $folder->getFolderUrl();
        }
        $content = TranslateHelper::t('plugin_archivemanager_internal_notify_split', 'Your file [[[FILE_NAME]]] has been split in parts. Click here to view the folder it\'s within.', array('FILE_NAME' => ValidationHelper::safeOutputToScreen($file['originalFilename'])));
        InternalNotificationHelper::add($pendingRow['user_id'], $content, 'entypo-thumbs-up', $folderUrl);

        break;

    // JOIN
    case 'join':
        $notesMessage = '';

        // log
        output("Getting files from storage...\n");

        // load files
        $rowDataArr = json_decode($pendingRow['additional_data'], true);
        $fileIds = $rowDataArr['file_ids'];
        $stmt = $db->query('SELECT * '
                . 'FROM file '
                . 'WHERE id IN (' . implode(',', $fileIds) . ') '
                . 'AND status = "active" '
                . 'AND userId = ' . $pendingRow['user_id'] . ' '
                . 'ORDER BY originalFilename ASC');
        $fileArr = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        if (COUNT($fileArr) == 0) {
            // log
            output("Error: Could not load any files to join.\n");

            // set to failed
            $db->query("UPDATE plugin_archive_manager_queue "
                    . "SET status='failed', "
                    . "date_finished=NOW(), "
                    . "notes='Error: Could not load any files to join, please check the system logs within the admin area for more details.' "
                    . "WHERE id=" . $pendingRow['id'] . " "
                    . "LIMIT 1");

            // logs
            LogHelper::breakInLogFile();

            // background task logging
            BackgroundTaskHelper::end();
            exit;
        }

        // temp path for files being zipped
        $filePathDirectory = md5($pendingRow['id'] . microtime() . rand(11111, 99999));
        define('TEMP_NEW_FILE_PATH', TEMP_CACHE_PATH . '/' . $filePathDirectory);
        @mkdir(TEMP_NEW_FILE_PATH, 0777, true);

        $localFileArr = array();
        $finalFilename = '';
        foreach ($fileArr AS $fileArrItem) {
            // grab file
            $finalFilename = substr($fileArrItem['originalFilename'], 0, strlen($fileArrItem['originalFilename']) - 4);
            $localFile = getFileContent($db, $fileArrItem);
            if (!$localFile) {
                // log
                output("Error: Could not get file contents " . $fileArrItem['originalFilename'] . ".\n");
                $notesMessage .= "Error: Could not get file contents. File: " . $fileArrItem['originalFilename'] . " #" . $file['id'];
            }
            else {
                // rename to actual filename
                $originalFilename = $fileArrItem['originalFilename'];
                $originalFilename = str_replace(array('\'', '../', './', '\\', '"', ')', '('), '', $originalFilename);
                if (strlen($originalFilename) == 0) {
                    $originalFilename = rand(100000, 999999);
                }

                $newName = TEMP_NEW_FILE_PATH . '/' . $originalFilename;
                if (file_exists($newName)) {
                    @unlink($newName);
                }

                // rename to the original filename
                $rs = rename($localFile, $newName);
                if ($rs) {
                    $localFileArr[] = $newName;
                }
                else {
                    // log
                    output("Error: Got file contents but could not rename to " . $newName . ".\n");
                    $notesMessage .= "Error: Got file contents but could not rename to " . $newName;
                    @unlink($localFile);
                }
            }
        }

        // log
        output("Joining files...\n");
        $archiveFilename = $finalFilename;
        $archiveFilename = str_replace(array('"', '\'', '\\', '/', ':', ';', '%', '"', ')', '('), '', $archiveFilename);

        $newFilePath = TEMP_CACHE_PATH . '/' . $archiveFilename;

        // ensure archive doesn't already exist
        if (file_exists($newFilePath)) {
            @unlink($newFilePath);
        }

        // double check path exists to ensure something hasn't gone wrong and it's reverted to another folder
        if (!file_exists(TEMP_NEW_FILE_PATH)) {
            $db->query("UPDATE plugin_archive_manager_queue "
                    . "SET status='failed', "
                    . "date_finished=NOW(), "
                    . "notes='Error: Path of downloaded files disappeared. Script halted.' "
                    . "WHERE id=" . $pendingRow['id'] . " "
                    . "LIMIT 1");

            // logs
            LogHelper::breakInLogFile();

            // background task logging
            BackgroundTaskHelper::end();
            exit;
        }

        if (count($localFileArr) === 0) {
            $db->query("UPDATE plugin_archive_manager_queue "
                    . "SET status='failed', "
                    . "date_finished=NOW(), "
                    . "notes='Error: Failed getting files to join.' "
                    . "WHERE id=" . $pendingRow['id'] . " "
                    . "LIMIT 1");

            // logs
            LogHelper::breakInLogFile();

            // background task logging
            BackgroundTaskHelper::end();
            exit;
        }

        $joinPathCmd = 'cat "' . implode('" "', $localFileArr) . '" > "' . $newFilePath . '"';

        // output to screen
        $notesMessage = "Command:\n";
        $notesMessage .= $joinPathCmd . "\n\n";
        output($notesMessage);

        if (SHOW_OUTPUT != 1) {
            $joinPathCmd .= ' 2>&1';
        }

        $output = shell_exec($joinPathCmd);

        // prepare notes
        $notesMessage .= "Result:\n";
        $notesMessage .= $output;
        output($notesMessage);
        output("\n");

        // remove original files
        foreach ($localFileArr AS $localFileArrItem) {
            @unlink($localFileArrItem);
        }

        // send into storage via curl
        output("File joined.\n");
        define('SAVED_FILESIZE', filesize($newFilePath));
        output("Moving into storage... (" . SAVED_FILESIZE . " bytes)\n");
        $rs = importFile($newFilePath, $pendingRow, $pendingRow['to_folder_id']);

        // delete new archive and
        unlink($newFilePath);
        @rmdir(TEMP_NEW_FILE_PATH);

        if (!$rs) {
            $db->query("UPDATE plugin_archive_manager_queue "
                    . "SET status='failed', "
                    . "date_finished=NOW(), "
                    . "notes='Error: Could not re-upload the joined file, please check the system logs within the admin area for more details.' "
                    . "WHERE id=" . $pendingRow['id'] . " "
                    . "LIMIT 1");

            // logs
            LogHelper::breakInLogFile();

            // background task logging
            BackgroundTaskHelper::end();
            exit;
        }

        // create account notification
        $folderUrl = WEB_ROOT . '/account';
        if ((int) $pendingRow['to_folder_id']) {
            $folder = FileFolder::loadOneById($pendingRow['to_folder_id']);
            $folderUrl = $folder->getFolderUrl();
        }
        $content = TranslateHelper::t('plugin_archivemanager_internal_notify_join', 'Your new joined file has been created. Click here to view the folder it\'s within.');
        InternalNotificationHelper::add($pendingRow['user_id'], $content, 'entypo-thumbs-up', $folderUrl);
        break;
}

// log
output("Completed queue item, id #" . $pendingRow['id'] . ".\n");

// remove cache dir
@rmdir(TEMP_CACHE_PATH);

// update database to completed, reconnect to stop db connection timeout issues
$db = new \PDO('mysql:host=' . DATABASE_HOST . ';dbname=' . DATABASE_NAME . ';charset=utf8', DATABASE_USER, DATABASE_PASS);
$db->query("UPDATE plugin_archive_manager_queue "
        . "SET status='completed', "
        . "date_finished=NOW(), "
        . "notes='' "
        . "WHERE id=" . $pendingRow['id'] . " "
        . "LIMIT 1");

// logs
LogHelper::breakInLogFile();

// background task logging
BackgroundTaskHelper::end();
exit;

/*
 * Functions
 */

function output($msg, $skipLogs = false) {
    if (SHOW_OUTPUT == 1) {
        echo $msg;
    }

    // log to file
    if ($skipLogs === false) {
        LogHelper::info($msg);
    }
}

function getFileContent($db, $file) {
    // setup local cached file
    $localFilename = md5(microtime()) . '.' . $file['extension'];
    $localFilePath = CACHE_PATH . '/' . $localFilename;

    // setup file object
    $fileObj = File::hydrateSingleRecord($file);

    // get remote file path
    $remoteFilePath = $fileObj->getFullFilePath();

    // figure out server storage setup
    $uploadServerDetails = loadServer($db, $file);
    $storageType = $uploadServerDetails['serverType'];
    
    // call plugin hooks
    $params = PluginHelper::callHook('fileDownloadGetFileContent', array(
                'actioned' => false,
                'file' => $fileObj,
                'storageType' => $storageType,
                'forceDownload' => false,
                'seekStart' => 0,
    ));

    // exit if we're done processing the item
    if ($params['actioned'] === true) {
        // save to local temp file
        file_put_contents($localFilePath, $params['fileContent']);

        return $localFilePath;
    }

    // use ssh to get contents of 'local' files
    if (($storageType == 'local') || ($storageType == 'direct')) {
        // first try getting the file locally
        $done = false;
        if ((ON_SCRIPT_INSTALL == true) && file_exists($remoteFilePath)) {
            $done = copy($remoteFilePath, $localFilePath);
            if ($done) {
                return $localFilePath;
            }
        }

        // try over ssh
        if ($done == false) {
            // get SSH details
            $serverDetails = getDirectFileServerSSHDetails($file['serverId']);
            if ($serverDetails) {
                $sshHost = $serverDetails['ssh_host'];
                $sshPort = $serverDetails['ssh_port'];
                $sshUser = $serverDetails['ssh_username'];
                $sshPass = $serverDetails['ssh_password'];
                $sshKey = $serverDetails['ssh_key'];
                $sshAuthType = $serverDetails['ssh_authentication_type'];
            }

            if (strlen($sshPort) == 0) {
                $sshPort = 22;
            }
            
            // if we're connecting using keys, prepare it
            if($sshAuthType === 'ssh_key') {
                $auth = new RSA();
                $auth->loadKey($sshKey);
            }
            else {
                $auth = $sshPass;
            }

            // connect to 'local' storage via SSH
            $sftp = new SFTP($sshHost, $sshPort, 20);
            if (!$sftp->login($sshUser, $auth)) {
                output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Failed logging into " . $sshHost . " (port: " . $sshPort . ") via SSH..\n");

                return false;
            }

            // get file
            $rs = $sftp->get($remoteFilePath, $localFilePath);
            if ($rs) {
                return $localFilePath;
            }
        }

        output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Failed getting file: " . $remoteFilePath . "\n");

        return false;
    }

    // ftp
    if ($storageType == 'ftp') {
        // connect via ftp
        $conn_id = ftp_connect($uploadServerDetails['ipAddress'], $uploadServerDetails['ftpPort'], 30);
        if ($conn_id === false) {
            output('[' . SERVER_NAME_FOR_LOGS . ']: Could not connect to ' . $uploadServerDetails['ipAddress'] . ' to upload file.');
            return false;
        }

        // authenticate
        $login_result = ftp_login($conn_id, $uploadServerDetails['ftpUsername'], $uploadServerDetails['ftpPassword']);
        if ($login_result === false) {
            output('[' . SERVER_NAME_FOR_LOGS . ']: Could not login to ' . $uploadServerDetails['ipAddress'] . ' with supplied credentials.');
            return false;
        }

        // get content
        $ret = ftp_get($conn_id, $localFilePath, $remoteFilePath, FTP_BINARY);
        while ($ret == FTP_MOREDATA) {
            $ret = ftp_nb_continue($conn_id);
        }
    }

    // check for file via Flysystem
    if (substr($storageType, 0, 10) == 'flysystem_') {
        $filesystem = FileServerContainerHelper::init($uploadServerDetails['id']);
        if (!$filesystem) {
            output(t('classuploader_could_not_setup_adapter_to_download', 'Could not setup adapter to download file.'));
            return false;
        }
        else {
            // check the file exists
            try {
                // get file path
                $fullPath = $fileObj->getFullFilePath();

                // check for the file
                $rs = $filesystem->has($fullPath);
                if (!$rs) {
                    output('Could not locate the file. Please contact support or try again.');
                    return false;
                }
            }
            catch (Exception $e) {
                output($e->getMessage());
                return false;
            }
        }

        // handle download using flysystem
        try {
            // create stream to handle larger files
            $handle = $filesystem->readStream($fullPath);

            // move to starting position
            fseek($handle, $seekStart);

            // save to local temp file
            $handleNew = fopen($localFilePath, 'wb');
            if ($handleNew) {
                while (!feof($handle)) {
                    fwrite($handleNew, fread($handle, 1024 * 8), 1024 * 8);
                }
            }

            fclose($handle);
            fclose($handleNew);
        }
        catch (Exception $e) {
            output($e->getMessage());

            return false;
        }
    }

    if (file_exists($localFilePath) && (filesize($localFilePath) > 0)) {
        return $localFilePath;
    }

    output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Failed getting file: " . $remoteFilePath . "\n");

    return false;
}

function loadServer($db, $file) {
    // load the server the file is on
    if ((int) $file['serverId']) {
        // load from the db
        $db = dbConnect();
        $stmt = $db->query("SELECT * "
                . "FROM file_server "
                . "WHERE id = " . (int) $file['serverId']);
        $uploadServerDetails = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$uploadServerDetails) {
            return false;
        }

        return $uploadServerDetails;
    }

    return false;
}

function getDirectFileServerSSHDetails($serverId) {
    // get direct file server ssh details
    $directFileServers = FileServerHelper::getFileServerAccessDetails();
    if (COUNT($directFileServers) == 0) {
        return false;
    }

    foreach ($directFileServers AS $directFileServer) {
        if ($directFileServer['file_server_id'] == $serverId) {
            return $directFileServer;
        }
    }

    return false;
}

function dbConnect() {
    return new \PDO('mysql:host=' . DATABASE_HOST . ';dbname=' . DATABASE_NAME . ';charset=utf8', DATABASE_USER, DATABASE_PASS);
}

function importFiles($pathToImport, $queueData, $folderIdOverride = null) {
    // get database
    $db = Database::getDatabase();

    // setup parent folder id
    $folderIdLocal = $queueData['to_folder_id'];
    if ($folderIdOverride) {
        $folderIdLocal = $folderIdOverride;
    }

    // get all files in folder
    $items = CoreHelper::getDirectoryListing($pathToImport);
    foreach ($items AS $item) {
        // ignore symbolic links - security 1st!
        if (!is_link($item)) {
            // double check it's part of the extracted folder
            $item = realpath($item);
            if (substr($item, 0, strlen(TEMP_NEW_FILE_PATH)) == TEMP_NEW_FILE_PATH) {
                // if directory
                if (is_dir($item)) {
                    // add folder
                    $folderName = basename($item);
                    $childFolderId = (int) $db->getValue('SELECT id '
                                    . 'FROM file_folder '
                                    . 'WHERE userId = ' . (int) $queueData['user_id'] . ' '
                                    . 'AND folderName = ' . $db->quote($folderName) . ' '
                                    . 'AND parentId ' . ((int) $folderIdLocal == 0 ? ' IS NULL' : ('=' . (int) $folderIdLocal)) . ' '
                                    . 'LIMIT 1');
                    if (!$childFolderId) {
                        $db->query('INSERT INTO file_folder '
                                . '(folderName, isPublic, userId, parentId) '
                                . 'VALUES (:folderName, :isPublic, :userId, :parentId)', array('folderName' => $folderName, 'isPublic' => 1, 'userId' => (int) $queueData['user_id'], 'parentId' => $folderIdLocal));
                        $childFolderId = $db->insertId();
                    }

                    // check for sub files/folders
                    importFiles($item, $queueData, $childFolderId);
                }
                else {
                    // upload using curl
                    $rs = importFile($item, $queueData, $folderIdLocal);
                }
            }
        }

        // delete item
        unlink($item);
    }

    // delete path
    rmdir($pathToImport);

    return true;
}

function importFile($filePath, $queueData, $folderIdOverride) {
    // get api key
    $db = Database::getDatabase();
    $coreAuth = User::loadOneById($queueData['user_id']);
    $apiKey = $coreAuth->apikey;
    if (strlen($apiKey) == 0) {
        $apiKey = $db->getValue("SELECT apikey "
                . "FROM users "
                . "WHERE id = " . (int) $coreAuth->id . " "
                . "LIMIT 1");
        if (!$apiKey) {
            // no api key so add it
            $apiKey = md5(microtime() . $coreAuth->id . microtime());
            $db->query('UPDATE users '
                    . 'SET apikey = ' . $db->quote($apiKey) . ' '
                    . 'WHERE id = ' . (int) $coreAuth->id . ' '
                    . 'AND username = ' . $db->quote($coreAuth->username) . ' '
                    . 'LIMIT 1');
        }
    }

    // filename
    $filename = basename($filePath);

    // prepare the params
    $post = array();
    $post['folderId'] = $folderIdOverride == NULL ? -1 : $folderIdOverride;
    $post['api_key'] = $apiKey;
    $post['username'] = $coreAuth->username;
    $post['action'] = 'upload';
    $post['files'] = curl_file_create($filePath, null, $filename);

    // simulate posting the file using curl
    $url = FileHelper::getUploadUrl() . '/api_upload_handler';
    output('Curl request to: ' . $url);
    output("\n");
    output('Curl params: ' . print_r($post, true));

    // **** IMPORTANT ****
    // if upload files are not being received ensure the max upload limits
    // within php.ini are raised. This will cause the files to silently fail
    // if they are set too low.

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_VERBOSE, 1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    //$headers = array(
    //    'Transfer-Encoding: chunked',
    //);
    //curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    //curl_setopt($ch, CURLOPT_PROGRESSFUNCTION, 'curlProgress');
    curl_setopt($ch, CURLOPT_NOPROGRESS, false);
    //curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
    $msg = curl_exec($ch);
    $error = '';

    // output header
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $header = substr($msg, 0, $header_size);
    $msg = substr($msg, $header_size);

    output("Curl header response: \n");
    output($header);
    output("\n\n");

    if (curl_errno($ch)) {
        $error = 'Error uploading file to ' . $url . ': ' . curl_error($ch);
    }
    else {
        // try to read the json response
        if (strlen($msg) == 0) {
            $error = 'Error uploading file. No response received from: ' . $url;
        }
        else {
            $responseArr = json_decode($msg, true);
            if (is_array($responseArr)) {
                // got data as array
                if (isset($responseArr[0]['error'])) {
                    $error = 'Error on: ' . $url . '. ' . $responseArr[0]['error'] . ' ' . $msg;
                }
            }
            else {
                $error = 'Failed reading response from: ' . $url . '. Response: ' . $msg;
            }
        }
    }

    // error
    if (strlen($error)) {
        // log
        output($error);

        return false;
    }

    // if we've got this part assume everything has gone well and we have file info in $responseArr
    output('Result: ' . print_r($responseArr, true));

    // close curl
    curl_close($ch);

    return true;
}

function curlProgress($resource, $download_size = 0, $downloaded = 0, $upload_size = 0, $uploaded = 0) {
    if ($upload_size > 0) {
        $percent = floor($upload_size / SAVED_FILESIZE * 100);
        if (queueFunctions::$progressTracker <= $percent) {
            output('Uploaded ' . $percent . "% (" . $upload_size . " / " . SAVED_FILESIZE . ")\n");
            queueFunctions::$progressTracker = $percent + 1;
        }
    }
}

class queueFunctions
{
    public static $progressTracker = -1;

}
