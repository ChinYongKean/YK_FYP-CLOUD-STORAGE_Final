<?php

namespace Plugins\Archivemanager\Controllers\Admin;

use App\Core\Database;
use App\Controllers\Admin\PluginController AS CorePluginController;
use App\Helpers\AdminHelper;
use App\Helpers\CoreHelper;
use App\Helpers\PluginHelper;
use App\Models\Plugin;

class PluginController extends CorePluginController
{

    public function pluginSettings() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // load plugin details
        $folderName = 'archivemanager';
        $plugin = Plugin::loadOneByClause('folder_name = :folder_name', array(
                    'folder_name' => $folderName,
        ));

        if (!$plugin) {
            return $this->redirect(ADMIN_WEB_ROOT . '/plugin_manage?error=' . urlencode('There was a problem loading the plugin details.'));
        }

        $plugin_enabled = (int) $plugin->plugin_enabled;
        $max_conversions = 1;
        $server_path_zip = '';
        $server_path_rar = '';

        // load existing settings
        if (strlen($plugin->plugin_settings)) {
            $plugin_settings = json_decode($plugin->plugin_settings, true);
            if ($plugin_settings) {
                $max_conversions = (int) $plugin_settings['max_conversions'];
                $server_path_zip = $plugin_settings['server_path_zip'];
                $server_path_rar = $plugin_settings['server_path_rar'];
            }
        }

        // handle page submissions
        if ($request->request->has('submitted')) {
            // get variables
            $plugin_enabled = (int) $request->request->get('plugin_enabled');
            $plugin_enabled = $plugin_enabled != 1 ? 0 : 1;
            $max_conversions = (int) $_REQUEST['max_conversions'];
            $server_path_zip = rtrim(trim($_REQUEST['server_path_zip']), '/');
            $server_path_rar = rtrim(trim($_REQUEST['server_path_rar']), '/');

            // validate submission
            if (_CONFIG_DEMO_MODE == true) {
                AdminHelper::setError(AdminHelper::t('no_changes_in_demo_mode', 'No change permitted in demo mode.'));
            }
            elseif ($plugin_enabled === 1) {
                if ($max_conversions === 0) {
                    AdminHelper::setError(AdminHelper::t("plugin_archivemanager_max_concurrent_queue_items_can_not_be_zero", "Max concurrent queue items to process can not be zero."));
                }
                elseif ((substr($server_path_zip, strlen($server_path_zip)-3, 3) === 'zip') || (substr($server_path_zip, strlen($server_path_zip)-5, 5) === 'unzip')) {
                    AdminHelper::setError("Do not include the zip binary on the end of the zip server path. It should look something like '/usr/bin/'");
                }
                elseif ((substr($server_path_rar, strlen($server_path_rar)-3, 3) === 'rar') || (substr($server_path_rar, strlen($server_path_rar)-5, 5) === 'unrar')) {
                    AdminHelper::setError("Do not include the rar binary on the end of the rar server path. It should look something like '/usr/local/bin/'");
                }
            }

            // update the settings
            if (AdminHelper::isErrors() == false) {
                $server_path_zip = strlen($server_path_zip)?($server_path_zip.'/'):'';
                $server_path_rar = strlen($server_path_rar)?($server_path_rar.'/'):'';
                
                // compile new settings
                $settingsArr = array();
                $settingsArr['max_conversions'] = $max_conversions;
                $settingsArr['server_path_zip'] = $server_path_zip;
                $settingsArr['server_path_rar'] = $server_path_rar;

                // update the plugin settings
                $plugin->plugin_enabled = $plugin_enabled;
                $plugin->plugin_settings = json_encode($settingsArr);
                $plugin->save();

                // reload plugin cache
                PluginHelper::loadPluginConfigurationFiles(true);

                // set onscreen alert
                AdminHelper::setSuccess('Plugin settings updated.');
            }
        }

        // check for curl
        if (function_exists('curl_version') === false) {
            AdminHelper::setError(AdminHelper::t("plugin_archivemanager_curl_required", "Could not find Curl functions in your PHP configuration. Please contact your host to enable Curl otherwise this plugin wont work."));
        }

        // load template
        return $this->render('admin/plugin_settings.html', array(
                    'pluginName' => $plugin->plugin_name,
                    'yesNoOptions' => array(
                        0 => 'No',
                        1 => 'Yes'),
                    'plugin_enabled' => $plugin_enabled,
                    'max_conversions' => $max_conversions,
                    'server_path_zip' => $server_path_zip,
                    'server_path_rar' => $server_path_rar,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function archiveManage() {
        // admin restrictions
        $this->restrictAdminAccess();

        // for later
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $archivemanagerObj = PluginHelper::getInstance('archivemanager');
        $archivemanagerSettings = $archivemanagerObj->settings;

        // process submits
        if ($request->query->has('cancel')) {
            $db->query('UPDATE plugin_archive_manager_queue '
                    . 'SET status = "cancelled" '
                    . 'WHERE id = :id '
                    . 'LIMIT 1', array(
                'id' => $request->query->get('cancel'),
            ));
            AdminHelper::setSuccess('Conversion job cancelled.');
        }
        elseif ($request->query->has('redo')) {
            $db->query('UPDATE plugin_archive_manager_queue '
                    . 'SET status = "pending" '
                    . 'WHERE id = :id '
                    . 'LIMIT 1', array(
                'id' => $request->query->get('redo'),
            ));
            AdminHelper::setSuccess('Conversion job re-scheduled.');
        }

        // overview stats
        $totalPending = (int) $db->getValue("SELECT COUNT(id) AS total "
                        . "FROM plugin_archive_manager_queue "
                        . "WHERE status = 'pending'");
        $totalFailedLast3Days = (int) $db->getValue("SELECT COUNT(id) AS total "
                        . "FROM plugin_archive_manager_queue "
                        . "WHERE status = 'pending' "
                        . "AND date_started BETWEEN NOW() - INTERVAL 3 DAY AND NOW()");
        $totalConversions = (int) $db->getValue("SELECT COUNT(id) AS total "
                        . "FROM plugin_archive_manager_queue "
                        . "WHERE status = 'completed'");
        $totalConversionsLast3Days = (int) $db->getValue("SELECT COUNT(id) AS total "
                        . "FROM plugin_archive_manager_queue "
                        . "WHERE status = 'completed' "
                        . "AND date_finished BETWEEN NOW() - INTERVAL 3 DAY AND NOW()");

        // load template
        return $this->render('admin/archive_manage.html', array(
                    'archivemanagerObj' => $archivemanagerObj,
                    'archivemanagerSettings' => $archivemanagerSettings,
                    'statusDetails' => $archivemanagerObj->getStatusList(),
                    'totalPending' => $totalPending,
                    'totalFailedLast3Days' => $totalFailedLast3Days,
                    'totalConversions' => $totalConversions,
                    'totalConversionsLast3Days' => $totalConversionsLast3Days,
                        ), PLUGIN_DIRECTORY_ROOT . 'archivemanager/views');
    }

    public function ajaxArchiveManage() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        $iDisplayLength = (int) $request->query->get('iDisplayLength');
        $iDisplayStart = (int) $request->query->get('iDisplayStart');
        $sSortDir_0 = ($request->query->has('sSortDir_0') && $request->query->get('sSortDir_0') === 'asc') ? 'asc' : 'desc';
        $filterText = $request->query->has('filterText') ? $request->query->get('filterText') : null;
        $filterByStatus = $request->query->has('filterByStatus') ? $request->query->get('filterByStatus') : '';

        // setup joins
        $joins = array();

        // get sorting columns
        $iSortCol_0 = (int) $request->query->get('iSortCol_0');
        $sColumns = trim($request->query->get('sColumns'));
        $arrCols = explode(",", $sColumns);
        $sortColumnName = $arrCols[$iSortCol_0];
        $sort = 'date_scheduled';
        switch ($sortColumnName) {
            case 'date_scheduled':
                $sort = 'plugin_archive_manager_queue.date_scheduled';
                break;
            case 'status':
                $sort = 'plugin_archive_manager_queue.status';
                break;
            case 'date_started':
                $sort = 'plugin_archive_manager_queue.date_started';
                break;
        }

        $sqlClause = 'WHERE 1=1';
        if ($filterText) {
            $sqlClause .= " AND file.originalFilename = " . $db->quote($filterText);
        }

        if ($filterByStatus) {
            $sqlClause .= " AND plugin_archive_manager_queue.status = " . $db->quote($filterByStatus);
        }

        $totalRS = $db->getValue("SELECT COUNT(plugin_archive_manager_queue.id) AS total "
                . "FROM plugin_archive_manager_queue "
                . "LEFT JOIN file ON plugin_archive_manager_queue.file_id = file.id "
                . $sqlClause);
        $limitedRS = $db->getRows("SELECT plugin_archive_manager_queue.*, "
                . "file.originalFilename, shortUrl "
                . "FROM plugin_archive_manager_queue "
                . "LEFT JOIN file ON plugin_archive_manager_queue.file_id = file.id "
                . $sqlClause . " "
                . "ORDER BY " . $sort . " " . $db->escape($sSortDir_0) . " "
                . "LIMIT " . $iDisplayStart . ", " . $iDisplayLength);

        $data = array();
        if (count($limitedRS) > 0) {
            foreach ($limitedRS AS $converterItem) {
                $lRow = array();
                $lRow[] = '<img src="' . PLUGIN_WEB_ROOT . '/archivemanager/assets/img/icons/16px.png" width="16" height="16" title="queue item" alt="queue item"/>';
                $lRow[] = CoreHelper::formatDate($converterItem['date_scheduled'], SITE_CONFIG_DATE_TIME_FORMAT);
                $lRow[] = UCWords(str_replace("_", " ", $converterItem['action_type']));
                $lRow[] = strlen($converterItem['originalFilename']) ? ('<a href="' . ADMIN_WEB_ROOT . '/file_manage?filterText=' . urlencode($converterItem['shortUrl']) . '">' . $converterItem['originalFilename'] . '</a>') : '<span style="color: #cccccc;">[many]</span>';
                $lRow[] = UCWords(str_replace("_", " ", $converterItem['status']));
                $lRow[] = CoreHelper::formatDate($converterItem['date_started'], SITE_CONFIG_DATE_TIME_FORMAT);

                $links = array();
                if ($converterItem['status'] == 'pending') {
                    $links[] = '<a href="archive_manage?cancel=' . $converterItem['id'] . '" onClick="return confirm(\'Are you sure you want to cancel this item?\');">cancel</a>';
                }
                if ($converterItem['status'] == 'processing') {
                    $links[] = '<a href="archive_manage?redo=' . $converterItem['id'] . '" onClick="return confirm(\'Are you sure you want to reset this item?\');">reset</a>';
                }
                if (($converterItem['status'] == 'completed') || ($converterItem['status'] == 'failed')) {
                    $links[] = '<a href="archive_manage?redo=' . $converterItem['id'] . '" onClick="return confirm(\'Are you sure you want to redo this item?\');">set pending</a>';
                }
                if (strlen($converterItem['notes'])) {
                    $links[] = '<a href="#" onClick="' . htmlspecialchars('alert(' . json_encode($converterItem['notes']) . ');') . ' return false;">notes</a>';
                }
                $lRow[] = implode(" | ", $links);

                $data[] = $lRow;
            }
        }

        $resultArr = array();
        $resultArr["sEcho"] = intval($request->query->get('sEcho'));
        $resultArr["iTotalRecords"] = (int) $totalRS;
        $resultArr["iTotalDisplayRecords"] = $resultArr["iTotalRecords"];
        $resultArr["aaData"] = $data;

        // output response
        return $this->renderJson($resultArr);
    }

}
