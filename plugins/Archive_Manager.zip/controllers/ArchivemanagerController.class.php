<?php

namespace Plugins\Archivemanager\Controllers;

use App\Core\BaseController;
use App\Core\Database;
use App\Helpers\CoreHelper;
use App\Helpers\FileFolderHelper;
use App\Helpers\NotificationHelper;
use App\Helpers\TranslateHelper;
use App\Helpers\ValidationHelper;
use App\Models\File;
use App\Models\User;
use Plugins\Archivemanager\Models\PluginArchiveManagerQueue;

class ArchivemanagerController extends BaseController
{

    public function ajaxAccountAddToArchive() {
        // require user login
        if (($response = $this->requireLogin()) !== false) {
            return $response;
        }

        // for later
        $request = $this->getRequest();
        $db = Database::getDatabase();
        $Auth = $this->getAuth();

        // get params
        $fileIds = $request->request->get('fileIds');
        $folderId = $request->request->get('folderId');
        if (count($fileIds) == 0) {
            // exit
            return $this->render404();
        }

        // secure the ids
        $fileIdArr = array();
        foreach ($fileIds AS $fileId) {
            $fileIdArr[] = (int) $fileId;
        }

        // make sure the logged in user owns the files
        $total = (int) $db->getValue('SELECT COUNT(id) AS total '
                        . 'FROM file '
                        . 'WHERE userId = :userId '
                        . 'AND id IN (' . implode(',', $fileIdArr) . ')', array(
                    'userId' => (int) $Auth->id,
        ));
        if ($total != count($fileIds)) {
            // exit
            return $this->render404();
        }

        // load folder structure as array
        $folderListing = FileFolderHelper::loadAllActiveForSelect($Auth->id);

        // create default name
        $archiveName = 'Archive ' . date("YmdHis");

        // load template
        return $this->render('ajax/account_add_to_archive.html', array(
                    'yesNoOptions' => array(
                        0 => 'No',
                        1 => 'Yes',
                    ),
                    'compressionOptions' => array(
                        0 => TranslateHelper::t("plugin_archivemanager_create_compression_level_0", "0 (no compression)"),
                        1 => TranslateHelper::t("plugin_archivemanager_create_compression_level_1", "1"),
                        2 => TranslateHelper::t("plugin_archivemanager_create_compression_level_2", "2"),
                        3 => TranslateHelper::t("plugin_archivemanager_create_compression_level_3", "3 (default)"),
                        4 => TranslateHelper::t("plugin_archivemanager_create_compression_level_4", "4"),
                        5 => TranslateHelper::t("plugin_archivemanager_create_compression_level_5", "5 (maximum compression)"),
                    ),
                    'deleteOrginalFilesOptions' => array(
                        0 => TranslateHelper::t('plugin_archivemanager_delete_no_files_kept', 'No (selected files will be kept)'),
                        1 => TranslateHelper::t('plugin_archivemanager_delete_yes_after_archiving', 'Yes (selected files will be removed after creating the archive)')
                    ),
                    'folderListing' => $folderListing,
                    'archiveName' => $archiveName,
                    'total' => $total,
                    'folderId' => $folderId,
                    'fileIdArr' => $fileIdArr,
                        ), PLUGIN_DIRECTORY_ROOT . 'archivemanager/views');
    }

    public function ajaxAccountAddToArchiveProcess() {
        // require user login
        if (($response = $this->requireLogin()) !== false) {
            return $response;
        }

        // for later
        $request = $this->getRequest();
        $db = Database::getDatabase();
        $Auth = $this->getAuth();

        // load files and check ownership
        $fileIds = explode('|', $request->request->get('fileIds'));
        $fileIdsArr = array();
        foreach ($fileIds AS $fileId) {
            $file = File::loadOneById($fileId);
            if ($file) {
                if ($file->userId === $Auth->id) {
                    $fileIdsArr[] = $fileId;
                }
            }
        }

        // make sure the logged in user owns the files
        if (count($fileIdsArr) == 0) {
            // exit
            return $this->render404();
        }

        // load folder structure as array
        $folderListing = FileFolderHelper::loadAllActiveForSelect($Auth->id);

        // handle submission
        $archive_compression = (int) trim($request->request->get('archive_compression'));
        $archive_create_recovery_record = (int) trim($request->request->get('archive_create_recovery_record'));
        $archive_type = trim($request->request->get('archive_type'));
        if ($archive_type != 'zip') {
            $archive_type = 'rar';
        }
        $delete_original_files = (int) trim($request->request->get('delete_original_files'));
        $folder = (int) trim($request->request->get('folder'));
        $archive_filename = trim($request->request->get('archive_filename'));
        $archive_filename = str_replace(array('"', '\'', '\\', '/', ':', ';', '%'), '', $archive_filename);
        $password = trim($request->request->get('password'));

        if (_CONFIG_DEMO_MODE == true) {
            NotificationHelper::setError(TranslateHelper::t("no_changes_in_demo_mode"));
        }
        elseif (strlen($archive_filename) == 0) {
            NotificationHelper::setError(TranslateHelper::t("plugin_archivemanager_add_to_archive_set_file_title", "Please set an archive filename."));
        }

        // no errors
        if (!NotificationHelper::isErrors()) {
            if ($folder == 0) {
                $folder = null;
            }

            if (strlen($password) === 0) {
                $password = null;
            }

            // insert data
            $dataArr = array();
            $dataArr['archive_compression'] = $archive_compression;
            $dataArr['archive_create_recovery_record'] = $archive_create_recovery_record;
            $dataArr['archive_type'] = $archive_type;
            $dataArr['delete_original_files'] = $delete_original_files;
            $dataArr['archive_filename'] = $archive_filename;
            $dataArr['access_password'] = $password;
            $dataArr['file_ids'] = $fileIdsArr;

            $pluginArchiveManagerQueue = PluginArchiveManagerQueue::create();
            $pluginArchiveManagerQueue->user_id = $Auth->id;
            $pluginArchiveManagerQueue->file_id = null;
            $pluginArchiveManagerQueue->to_folder_id = $folder;
            $pluginArchiveManagerQueue->additional_data = json_encode($dataArr);
            $pluginArchiveManagerQueue->action_type = 'archive_' . $archive_type;
            $pluginArchiveManagerQueue->date_scheduled = CoreHelper::sqlDateTime();
            $pluginArchiveManagerQueue->status = 'pending';
            if ($pluginArchiveManagerQueue->save()) {
                // success
                NotificationHelper::setSuccess(TranslateHelper::t('plugin_archivemanager_archive_scheduled', 'Files queued for archiving. Please check back in a few minutes for the archive file. You\'ll receive a notification in your account when it\'s complete.'));
            }
            else {
                NotificationHelper::setError(TranslateHelper::t("problem_updating_item", "There was a problem updating the item, please try again later."));
            }
        }

        // prepare result
        $returnJson = array();
        $returnJson['success'] = false;
        $returnJson['msg'] = TranslateHelper::t("problem_updating_item", "There was a problem updating the item, please try again later.");
        if (NotificationHelper::isErrors()) {
            // error
            $returnJson['success'] = false;
            $returnJson['msg'] = implode('<br/>', NotificationHelper::getErrors());
        }
        else {
            // success
            $returnJson['success'] = true;
            $returnJson['msg'] = implode('<br/>', NotificationHelper::getSuccess());
        }

        return $this->renderJson($returnJson);
    }

    public function ajaxAccountJoinFiles() {
        // require user login
        if (($response = $this->requireLogin()) !== false) {
            return $response;
        }

        // for later
        $request = $this->getRequest();
        $db = Database::getDatabase();
        $Auth = $this->getAuth();

        // get params
        $fileIds = $request->request->get('fileIds');
        if (count($fileIds) == 0) {
            // exit
            return $this->render404();
        }

        // secure the ids
        $fileIdArr = array();
        foreach ($fileIds AS $fileId) {
            $fileIdArr[] = (int) $fileId;
        }

        // make sure the logged in user owns the files
        $total = (int) $db->getValue('SELECT COUNT(id) AS total '
                        . 'FROM file '
                        . 'WHERE userId = :userId '
                        . 'AND id IN (' . implode(',', $fileIdArr) . ')', array(
                    'userId' => (int) $Auth->id,
        ));
        if ($total != count($fileIds)) {
            // exit
            return $this->render404();
        }

        // load folder structure as array
        $folderListing = FileFolderHelper::loadAllActiveForSelect($Auth->id);

        // get file details
        $filenames = $db->getRows('SELECT originalFilename '
                . 'FROM file WHERE '
                . 'userId = :userId '
                . 'AND id IN (' . implode(',', $fileIdArr) . ') '
                . 'ORDER BY originalFilename ASC', array(
            'userId' => (int) $Auth->id,
        ));

        // create default name
        $joinedFilename = '';
        foreach ($filenames AS $filename) {
            if (substr($filename['originalFilename'], strlen($filename['originalFilename']) - 3, 3) == '000') {
                $joinedFilename = substr($filename['originalFilename'], 0, strlen($filename['originalFilename']) - 4);
            }
        }

        $filenamesToJoin = array();
        if (strlen($joinedFilename) === 0) {
            NotificationHelper::setError(TranslateHelper::t("plugin_archivemanager_could_not_find_first_item_end", "Could not find the first item in the list of files. The first file should end with .000."));
        }
        else {
            // check we have all the files to join
            foreach ($filenames AS $filename) {
                $filenamesToJoin[] = $filename['originalFilename'];
            }

            $allOk = true;
            for ($i = 0; $i < count($filenamesToJoin); $i++) {
                if (!in_array($joinedFilename . '.' . str_pad($i, 3, '0', STR_PAD_LEFT), $filenamesToJoin)) {
                    $allOk = false;
                }
            }
            if ($allOk == false) {
                NotificationHelper::setError(TranslateHelper::t("plugin_archivemanager_could_not_find_all_items_end", "Could not find all the items to join. The first file must end with 000, next 001, then 002 etc."));
            }
        }

        // load template
        return $this->render('ajax/account_join_files.html', array(
                    'filenamesToJoin' => $filenamesToJoin,
                    'folderListing' => $folderListing,
                    'total' => $total,
                    'joinedFilename' => $joinedFilename,
                    'fileIdArr' => $fileIdArr,
                    'errors' => NotificationHelper::getErrors(),
                        ), PLUGIN_DIRECTORY_ROOT . 'archivemanager/views');
    }

    public function ajaxAccountJoinFilesProcess() {
        // require user login
        if (($response = $this->requireLogin()) !== false) {
            return $response;
        }

        // for later
        $request = $this->getRequest();
        $db = Database::getDatabase();
        $Auth = $this->getAuth();

        // load files and check ownership
        $fileIds = explode('|', $request->request->get('fileIds'));
        $fileIdsArr = array();
        foreach ($fileIds AS $fileId) {
            $file = File::loadOneById($fileId);
            if ($file) {
                if ($file->userId === $Auth->id) {
                    $fileIdsArr[] = $fileId;
                }
            }
        }

        // make sure the logged in user owns the files
        if (count($fileIdsArr) == 0) {
            // exit
            return $this->render404();
        }

        // load folder structure as array
        $folderListing = FileFolderHelper::loadAllActiveForSelect($Auth->id);

        // handle submission
        // validation
        $folder = (int) $request->request->get('folder');
        if (_CONFIG_DEMO_MODE == true) {
            NotificationHelper::setError(TranslateHelper::t("no_changes_in_demo_mode"));
        }

        if (!NotificationHelper::isErrors()) {
            // check for pending item in queue for this file
            $rs = $db->getValue('SELECT id '
                    . 'FROM plugin_archive_manager_queue '
                    . 'WHERE file_id = :file_id '
                    . 'AND status IN (\'pending\', \'processing\')', array(
                'file_id' => (int) $fileId,
            ));
            if ($rs) {
                NotificationHelper::setError(TranslateHelper::t("plugin_archivemanager_extract_file_already", "This file is already queued."));
            }
        }

        // no errors
        if (!NotificationHelper::isErrors()) {
            if ($folder == 0) {
                $folder = null;
            }

            // insert data
            $dataArr = array();
            $dataArr['file_ids'] = $fileIdsArr;

            $pluginArchiveManagerQueue = PluginArchiveManagerQueue::create();
            $pluginArchiveManagerQueue->user_id = $Auth->id;
            $pluginArchiveManagerQueue->file_id = null;
            $pluginArchiveManagerQueue->to_folder_id = $folder;
            $pluginArchiveManagerQueue->additional_data = json_encode($dataArr);
            $pluginArchiveManagerQueue->action_type = 'join';
            $pluginArchiveManagerQueue->date_scheduled = CoreHelper::sqlDateTime();
            $pluginArchiveManagerQueue->status = 'pending';
            if ($pluginArchiveManagerQueue->save()) {
                // success
                NotificationHelper::setSuccess(TranslateHelper::t('plugin_archivemanager_join_scheduled', 'Files queued for joining. Please check back in a few minutes for the file. You\'ll receive a notification in your account when it\'s complete.'));
            }
            else {
                NotificationHelper::setError(TranslateHelper::t("problem_updating_item", "There was a problem updating the item, please try again later."));
            }
        }

        // prepare result
        $returnJson = array();
        $returnJson['success'] = false;
        $returnJson['msg'] = TranslateHelper::t("problem_updating_item", "There was a problem updating the item, please try again later.");
        if (NotificationHelper::isErrors()) {
            // error
            $returnJson['success'] = false;
            $returnJson['msg'] = implode('<br/>', NotificationHelper::getErrors());
        }
        else {
            // success
            $returnJson['success'] = true;
            $returnJson['msg'] = implode('<br/>', NotificationHelper::getSuccess());
        }

        return $this->renderJson($returnJson);
    }

    public function ajaxAccountSplitFile() {
        // require user login
        if (($response = $this->requireLogin()) !== false) {
            return $response;
        }

        // for later
        $request = $this->getRequest();
        $db = Database::getDatabase();
        $Auth = $this->getAuth();

        // get params
        $fileId = $request->request->get('fileId');
        $file = File::loadOneById($fileId);
        if (!$file) {
            // exit
            return $this->render404();
        }

        // make sure the logged in user owns this file
        if ($file->userId != $Auth->id) {
            // exit
            return $this->render404();
        }

        // load folder structure as array
        $folderListing = FileFolderHelper::loadAllActiveForSelect($Auth->id);

        // prepare and filter available split sizes
        $splitSizes = explode('|', '1468006|5242880|10485760|20971520|52428800|104857600|209715200|524288000|771751936|1073741824|2147483648');
        $splitSizesPrepped = array();
        foreach ($splitSizes AS $k => $splitSize) {
            // calculate chunks for this size
            $chunks = ceil($file->fileSize / $splitSize);

            // don't show option if we'll end up with just 1 chunk
            if ($chunks <= 1) {
                continue;
            }

            $splitSizesPrepped[$splitSize] = CoreHelper::formatSize($splitSize) . '  (' . $chunks . ' ' . ($chunks != 1 ? TranslateHelper::t('plugin_archivemanager_split_parts', 'parts') : TranslateHelper::t('plugin_archivemanager_split_part', 'part')) . ')';
        }

        // if we have no sizes left in our list, add the filesize
        if (count($splitSizesPrepped) === 0) {
            $splitSizesPrepped[$file->fileSize] = CoreHelper::formatSize($file->fileSize) . '  (1 ' . TranslateHelper::t('plugin_archivemanager_split_part', 'part') . ')';
        }

        // load template
        return $this->render('ajax/account_split_file.html', array(
                    'split_size' => 104857600,
                    'splitSizesPrepped' => $splitSizesPrepped,
                    'file' => $file,
                    'folderListing' => $folderListing,
                        ), PLUGIN_DIRECTORY_ROOT . 'archivemanager/views');
    }

    public function ajaxAccountSplitFileProcess() {
        // require user login
        if (($response = $this->requireLogin()) !== false) {
            return $response;
        }

        // for later
        $request = $this->getRequest();
        $db = Database::getDatabase();
        $Auth = $this->getAuth();

        // load file
        $fileId = (int) $request->request->get('fileId');
        $file = File::loadOneById($fileId);
        if (!$file) {
            // exit
            return $this->render404();
        }

        // make sure the logged in user owns this file
        if ($file->userId != $Auth->id) {
            // exit
            return $this->render404();
        }

        // load folder structure as array
        $folderListing = FileFolderHelper::loadAllActiveForSelect($Auth->id);

        // handle submission
        $folder = (int) trim($request->request->get('folder'));
        $password = trim($request->request->get('password'));
        $split_size = (float) trim($request->request->get('split_size'));

        if (_CONFIG_DEMO_MODE == true) {
            NotificationHelper::setError(TranslateHelper::t("no_changes_in_demo_mode"));
        }

        if (!NotificationHelper::isErrors()) {
            // check for pending item in queue for this file
            $rs = $db->getValue('SELECT id '
                    . 'FROM plugin_archive_manager_queue '
                    . 'WHERE file_id = :file_id '
                    . 'AND status IN (\'pending\', \'processing\')', array(
                'file_id' => (int) $fileId,
            ));
            if ($rs) {
                NotificationHelper::setError(TranslateHelper::t("plugin_archivemanager_extract_file_already_extract_scheduled", "This file is already queued for extracting."));
            }
        }

        if (!NotificationHelper::isErrors()) {
            // double check size is valid
            if ($split_size < 1468006) {
                $split_size = $file->fileSize;
            }
        }

        // no errors
        if (!NotificationHelper::isErrors()) {
            if ($folder == 0) {
                $folder = null;
            }

            // insert data
            $dataArr = array();
            $dataArr['extract_file_id'] = $fileId;
            $dataArr['access_password'] = null;
            $dataArr['split_size'] = $split_size;

            $pluginArchiveManagerQueue = PluginArchiveManagerQueue::create();
            $pluginArchiveManagerQueue->user_id = $Auth->id;
            $pluginArchiveManagerQueue->file_id = $fileId;
            $pluginArchiveManagerQueue->to_folder_id = $folder;
            $pluginArchiveManagerQueue->additional_data = json_encode($dataArr);
            $pluginArchiveManagerQueue->action_type = 'split';
            $pluginArchiveManagerQueue->date_scheduled = CoreHelper::sqlDateTime();
            $pluginArchiveManagerQueue->status = 'pending';
            if ($pluginArchiveManagerQueue->save()) {
                // success
                NotificationHelper::setSuccess(TranslateHelper::t('plugin_archivemanager_split_scheduled', 'File queued for splitting. Please check back in a few minutes for the files. You\'ll receive a notification in your account when it\'s complete.'));
            }
            else {
                NotificationHelper::setError(TranslateHelper::t("problem_updating_item", "There was a problem updating the item, please try again later."));
            }
        }

        // prepare result
        $returnJson = array();
        $returnJson['success'] = false;
        $returnJson['msg'] = TranslateHelper::t("problem_updating_item", "There was a problem updating the item, please try again later.");
        if (NotificationHelper::isErrors()) {
            // error
            $returnJson['success'] = false;
            $returnJson['msg'] = implode('<br/>', NotificationHelper::getErrors());
        }
        else {
            // success
            $returnJson['success'] = true;
            $returnJson['msg'] = implode('<br/>', NotificationHelper::getSuccess());
        }

        return $this->renderJson($returnJson);
    }

    public function ajaxAccountExtractArchive() {
        // require user login
        if (($response = $this->requireLogin()) !== false) {
            return $response;
        }

        // for later
        $request = $this->getRequest();
        $Auth = $this->getAuth();

        // get params
        $fileId = $request->request->get('fileId');
        $file = File::loadOneById($fileId);
        if (!$file) {
            // exit
            return $this->render404();
        }

        // make sure the logged in user owns this file
        if ($file->userId != $Auth->id) {
            // exit
            return $this->render404();
        }

        // load folder structure as array
        $folderListing = FileFolderHelper::loadAllActiveForSelect($Auth->id);

        // load template
        return $this->render('ajax/account_extract_archive.html', array(
                    'file' => $file,
                    'folderListing' => $folderListing,
                        ), PLUGIN_DIRECTORY_ROOT . 'archivemanager/views');
    }

    public function ajaxAccountExtractArchiveProcess() {
        // require user login
        if (($response = $this->requireLogin()) !== false) {
            return $response;
        }

        // for later
        $request = $this->getRequest();
        $db = Database::getDatabase();
        $Auth = $this->getAuth();

        // load file
        $fileId = (int) $request->request->get('fileId');
        $file = File::loadOneById($fileId);
        if (!$file) {
            // exit
            return $this->render404();
        }

        // make sure the logged in user owns this file
        if ($file->userId != $Auth->id) {
            // exit
            return $this->render404();
        }

        // load folder structure as array
        $folderListing = FileFolderHelper::loadAllActiveForSelect($Auth->id);

        // handle submission
        $folder = (int) trim($request->request->get('folder'));
        $password = trim($request->request->get('password'));

        if (_CONFIG_DEMO_MODE == true) {
            NotificationHelper::setError(TranslateHelper::t("no_changes_in_demo_mode"));
        }

        if (!NotificationHelper::isErrors()) {
            // check for pending item in queue for this file
            $rs = $db->getValue('SELECT id '
                    . 'FROM plugin_archive_manager_queue '
                    . 'WHERE file_id = :file_id '
                    . 'AND status IN (\'pending\', \'processing\')', array(
                'file_id' => (int) $fileId,
            ));
            if ($rs) {
                NotificationHelper::setError(TranslateHelper::t("plugin_archivemanager_extract_file_already_extract_scheduled", "This file is already queued for extracting."));
            }
        }

        // no errors
        if (!NotificationHelper::isErrors()) {
            if ($folder == 0) {
                $folder = null;
            }

            if (strlen($password) == 0) {
                $password = null;
            }

            // insert data
            $dataArr = array();
            $dataArr['extract_file_id'] = $fileId;
            $dataArr['access_password'] = $password;

            $pluginArchiveManagerQueue = PluginArchiveManagerQueue::create();
            $pluginArchiveManagerQueue->user_id = $Auth->id;
            $pluginArchiveManagerQueue->file_id = $fileId;
            $pluginArchiveManagerQueue->to_folder_id = $folder;
            $pluginArchiveManagerQueue->additional_data = json_encode($dataArr);
            $pluginArchiveManagerQueue->action_type = 'extract';
            $pluginArchiveManagerQueue->date_scheduled = CoreHelper::sqlDateTime();
            $pluginArchiveManagerQueue->status = 'pending';
            if ($pluginArchiveManagerQueue->save()) {
                // success
                NotificationHelper::setSuccess(TranslateHelper::t('plugin_archivemanager_extract_scheduled', 'File queued for extracting. Please check back in a few minutes for the files. You\'ll receive a notification in your account when it\'s complete.'));
            }
            else {
                NotificationHelper::setError(TranslateHelper::t("problem_updating_item", "There was a problem updating the item, please try again later."));
            }
        }

        // prepare result
        $returnJson = array();
        $returnJson['success'] = false;
        $returnJson['msg'] = TranslateHelper::t("problem_updating_item", "There was a problem updating the item, please try again later.");
        if (NotificationHelper::isErrors()) {
            // error
            $returnJson['success'] = false;
            $returnJson['msg'] = implode('<br/>', NotificationHelper::getErrors());
        }
        else {
            // success
            $returnJson['success'] = true;
            $returnJson['msg'] = implode('<br/>', NotificationHelper::getSuccess());
        }

        return $this->renderJson($returnJson);
    }

}
