<?php

namespace Plugins\Archivemanager\Controllers;

use App\Core\BaseController;
use App\Core\Database;
use App\Helpers\TranslateHelper;

class HooksController extends BaseController
{

    public function adminPluginNav($params = null) {
        // output within the admin left-hand navigation
        $navigation = array(
            array('link_url' => '#', 'link_text' => 'Archive Manager', 'link_key' => 'archivemanager', 'icon_class' => 'fa fa-archive', 'children' => array(
                    array('link_url' => 'admin/archive_manage', 'link_text' => 'View Queue', 'link_key' => 'archivemanager_archive_manage'),
                    array('link_url' => 'admin/plugin/archivemanager/settings', 'link_text' => 'Plugin Settings', 'link_key' => 'newsletters_plugin_settings'),
                )),
        );

        // return array
        return $navigation;
    }

    public function fileRemoveFile($params = null) {
        /*
         * available params
         * 
         * $params['actioned'];
         * $params['filePath'];
         * $params['storageType'];
         * $params['storageLocation'];
         * $params['file'];
         * */

        // check this is a video
        $file = $params['file'];
        if (in_array(strtolower($file->extension), array('rar', 'zip'))) {
            // database
            $db = Database::getDatabase();

            // cancel any pending records from the converter queue
            $db->query('UPDATE plugin_archive_manager_queue '
                    . 'SET status = "cancelled", '
                    . 'notes="Cancelled due to file removal." '
                    . 'WHERE file_id = :file_id', array(
                'file_id' => (int) $file->id,
            ));
        }

        // return false so other plugin hooks will be called, if set
        return false;
    }

    public function accountHomeJavascript($params = null) {
        // load template
        return array(
            '_found_hook' => true,
            'response_html' => $this->getRenderedTemplate('account_home_javascript.html', array(), PLUGIN_DIRECTORY_ROOT . 'archivemanager/views')
        );
    }

    public function accountHomeFileListMenu($params = null) {
        // available params
        // $params['file']
        // check this is an archive
        $menuItems = array();
        if (in_array(strtolower($params['file']->extension), array('zip', 'rar'))) {
            // only for active files
            if ($params['file']->status == 'active') {
                $menuItems['Extract'] = array(
                    "label" => ucwords(TranslateHelper::t('account_file_details_extract_from_archive', 'Extract Files From [[[EXTENSION]]]', array(
                        'EXTENSION' => ucwords(strtolower($params['file']->extension)),
                    ))),
                    "separator_before" => true,
                    "separator_after" => false,
                    "action" => "function() { selectFile(fileId, true); extractArchivePopup(); }",
                    "icon" => "entypo-archive",
                );
            }
        }

        // for all files
        if ($params['file']->status === 'active') {
            $menuItems['Archive'] = array(
                "label" => ucwords(TranslateHelper::t('account_file_details_add_archive', 'Add to Zip/Rar')),
                "separator_before" => true,
                "separator_after" => false,
                "action" => "function() { selectFile(fileId, true); addToArchivePopup(); }",
                "icon" => "fa fa-archive",
            );
            $menuItems['Split'] = array(
                "label" => ucwords(TranslateHelper::t('account_file_details_split', 'Split File')),
                "separator_after" => false,
                "action" => "function() { selectFile(fileId, true); splitFilePopup(); }",
                "icon" => "fa fa-files-o",
            );
            $menuItems['Join'] = array(
                "label" => ucwords(TranslateHelper::t('account_file_details_join', 'Join Files')),
                "separator_after" => false,
                "action" => "function() { selectFile(fileId, true); joinFilesPopup(); }",
                "icon" => "fa fa-file-text",
            );
        }

        return $menuItems;
    }

}
