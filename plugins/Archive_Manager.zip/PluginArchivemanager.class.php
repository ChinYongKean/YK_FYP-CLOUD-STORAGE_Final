<?php

// plugin namespace

namespace Plugins\Archivemanager;

// core includes
use App\Core\Database;
use App\Services\Plugin;
use Plugins\Archivemanager\PluginConfig;

class PluginArchivemanager extends Plugin
{
    public $config = null;
    public $data = null;

    public function __construct() {
        // load plugin config
        $this->config = (new PluginConfig())->getPluginConfig();
    }

    public function registerRoutes(\FastRoute\RouteCollector $r) {
        // register plugin routes
        $r->addRoute(['GET', 'POST'], '/' . ADMIN_FOLDER_NAME . '/plugin/' . $this->config['folder_name'] . '/settings', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/pluginSettings');
        $r->addRoute(['GET'], '/' . ADMIN_FOLDER_NAME . '/archive_manage', '\plugins\\'.$this->config['folder_name'].'\controllers\admin\PluginController/archiveManage');
        $r->addRoute(['GET', 'POST'], '/' . ADMIN_FOLDER_NAME . '/ajax/archive_manage', '\plugins\\'.$this->config['folder_name'].'\controllers\admin\PluginController/ajaxArchiveManage');
        
        $r->addRoute(['GET', 'POST'], '/ajax/account_extract_archive', '\plugins\\'.$this->config['folder_name'].'\controllers\ArchivemanagerController/ajaxAccountExtractArchive');
        $r->addRoute(['POST'], '/ajax/account_extract_archive_process', '\plugins\\'.$this->config['folder_name'].'\controllers\ArchivemanagerController/ajaxAccountExtractArchiveProcess');
        
        $r->addRoute(['GET', 'POST'], '/ajax/account_add_to_archive', '\plugins\\'.$this->config['folder_name'].'\controllers\ArchivemanagerController/ajaxAccountAddToArchive');
        $r->addRoute(['POST'], '/ajax/account_add_to_archive_process', '\plugins\\'.$this->config['folder_name'].'\controllers\ArchivemanagerController/ajaxAccountAddToArchiveProcess');
        
        $r->addRoute(['GET', 'POST'], '/ajax/account_split_file', '\plugins\\'.$this->config['folder_name'].'\controllers\ArchivemanagerController/ajaxAccountSplitFile');
        $r->addRoute(['POST'], '/ajax/account_split_file_process', '\plugins\\'.$this->config['folder_name'].'\controllers\ArchivemanagerController/ajaxAccountSplitFileProcess');
        
        $r->addRoute(['GET', 'POST'], '/ajax/account_join_files', '\plugins\\'.$this->config['folder_name'].'\controllers\ArchivemanagerController/ajaxAccountJoinFiles');
        $r->addRoute(['POST'], '/ajax/account_join_files_process', '\plugins\\'.$this->config['folder_name'].'\controllers\ArchivemanagerController/ajaxAccountJoinFilesProcess');

    }

    public function getPluginDetails() {
        return $this->config;
    }

    public function uninstall() {
        // setup database
        $db = Database::getDatabase();

        // remove plugin specific tables
        $sQL = 'DROP TABLE plugin_archive_manager_queue';
        $db->query($sQL);

        return parent::uninstall();
    }
    
    public function getStatusList() {
        return array('pending', 'processing', 'completed', 'failed', 'cancelled');
    }

}
