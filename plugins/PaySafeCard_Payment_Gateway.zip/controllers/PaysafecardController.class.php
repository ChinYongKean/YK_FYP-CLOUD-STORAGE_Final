<?php

namespace Plugins\Paysafecard\Controllers;

use App\Core\BaseController;
use App\Models\File;
use App\Models\Order;
use App\Models\PaymentLog;
use App\Models\User;
use App\Helpers\CoreHelper;
use App\Helpers\LogHelper;
use App\Helpers\OrderHelper;
use App\Helpers\PluginHelper;
use App\Helpers\UserHelper;
use Plugins\Paysafecard\Libraries\SOPGClassicMerchantClient;

class PaysafecardController extends BaseController
{

    public function upgradeBox($params = array()) {
        // pickup request for later
        $request = $this->getRequest();

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('paysafecard');
        $pluginSettings = $pluginConfig['data']['plugin_settings'];
        $paymentButton = 'payment_button_1';
        if (strlen($pluginSettings)) {
            $pluginSettingsArr = json_decode($pluginSettings, true);
            if (strlen($pluginSettingsArr['payment_button'])) {
                $paymentButton = $pluginSettingsArr['payment_button'];
            }
        }

        // load template
        return $this->render('upgrade_box.html', array_merge($params, array(
                    'folder_name' => 'paysafecard',
                    'gateway_label' => 'Paysafecard',
                    'payment_button' => $paymentButton,
                    'i' => $request->query->has('i') ? $request->query->get('i') : '',
                    'f' => $request->query->has('f') ? $request->query->get('f') : '',
                        )), PLUGIN_DIRECTORY_ROOT . 'paysafecard/views');
    }

    public function pay($params = array()) {
        // pickup request for later
        $request = $this->getRequest();

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('paysafecard');
        $pluginSettings = $pluginConfig['data']['plugin_settings'];
        if (strlen($pluginSettings)) {
            $pluginSettingsArr = json_decode($pluginSettings, true);
        }

        if (!$request->request->has('user_level_pricing_id')) {
            return $this->redirect(WEB_ROOT);
        }

        // require login
        if ($request->request->has('i') && strlen($request->request->get('i'))) {
            $user = User::loadOneByClause('identifier = :identifier', array(
                        'identifier' => $request->request->get('i')
            ));
            if (!$user) {
                return $this->redirect(CoreHelper::getCoreSitePath() . "/error?e=" . urlencode('Could not load user based on identifier, please contact support.'));
            }

            // setup variables for later
            $userId = $user->id;
            $username = $user->username;
            $userEmail = $user->email;
        }
        else {
            if (($response = $this->requireLogin('/register', 1)) !== false) {
                return $response;
            }

            // setup variables for later
            $Auth = $this->getAuth();
            $userId = $Auth->id;
            $username = $Auth->username;
            $userEmail = $Auth->email;
        }

        $userLevelPricingId = (int) $request->request->get('user_level_pricing_id');

        // check if we have a referring file
        $fileId = null;
        if ($request->request->has('f') && strlen($request->request->get('f'))) {
            $file = File::loadOneByShortUrl($request->request->get('f'));
            if ($file) {
                $fileId = $file->id;
            }
        }

        //Currency
        $currency = $pluginSettingsArr['in_test_mode'] == 'yes' ? $pluginSettingsArr['currency_override'] : SITE_CONFIG_COST_CURRENCY_CODE;

        //MerchantClientId - e.g. email address
        $mCId = $pluginSettingsArr['sopg_client_id'];

        //User name
        $username = $pluginSettingsArr['sopg_username'];

        //Password
        $password = $pluginSettingsArr['sopg_password'];

        // create order entry
        $order = OrderHelper::createByPackageId($userId, $userLevelPricingId, $fileId);
        if (!$order) {
            die('Error: Problem creating order, please try again later.');
        }

        //OK-URL - ok=true
        //http://www.yourdomain.com/psc/index.php?ok=true&mtid='.$order->payment_hash
        $okUrl = rawurlencode(PLUGIN_WEB_ROOT . '/paysafecard/payment_ipn?ok=true&mtid=' . $order->payment_hash . '&cur=' . $currency . '&amo=' . $order->amount . '&days=' . $days);
        //NOK-URL - nok=true
        //http://www.yourdomain.com/psc/index.php?nok=true
        $nokUrl = rawurlencode(WEB_ROOT . '/upgrade');
        //PN-URL - pn=true
        //http://www.yourdomain.com/psc/index.php?pn=true&mtid='.$order->payment_hash
        $pnUrl = rawurlencode($currentURL . '?pn=true&mtid=' . $order->payment_hash . '&cur=' . $currency . '&amo=' . $order->amount . '&days=' . $days);
        //System language de/en
        $sysLang = 'en';
        //Debug true/false
        $debug = false;
        //Display Debug true/false
        $show_debug = false;
        //Display Errors true/false
        $show_error = false;
        //AutoCorrect true/false 
        $autoCorrect = false;
        //test or live SYSTEM
        $mode = $pluginSettingsArr['in_test_mode'] == 'yes' ? 'test' : 'live';

        //Embed class
        $test = new SOPGClassicMerchantClient($debug, $sysLang, $autoCorrect, $mode);
        //if the PHP file is called from psc,the range for the PN URL is executed.
        if (isset($_GET['pn'])) {
            //enter the access data
            $test->merchant($username, $password);
            //get current status
            $status = $test->getSerialNumbers($_GET['mtid'], $_GET['cur'], $subId = '');
            //If the return is 'execute', the amount can be debited (executeDebit)
            if ($status === 'execute') {
                $testexecute = $test->executeDebit($_GET['amo'], '1');
                if ($testexecute === true) {
                    // here user account topup -EXECUTE DEBIT SUCCESSFUL- !!!
                    $this->showDebug($show_debug, $show_error, $test, $debug);
                }
            }
            $this->showDebug($show_debug, $show_error, $test, $debug);
        }
        elseif (isset($_GET['nok'])) {
            //do nok
            $this->renderContent('Transaction aborted by user.');
        }
        //The normal first call starts here
        else {
            //Set the access data
            $test->merchant($username, $password);
            //Enter the information.
            $test->setCustomer($order->amount, $currency, $order->payment_hash, $mCId);
            //Enter URL´s.
            $test->setUrl($okUrl, $nokUrl, $pnUrl);
            //createDisposition now creates the transaction under PSC and returns the URL the client can use to make the payment.
            //The URL is generated via getCustomerPanel()!!!
            $paymentPanel = $test->createDisposition();
            if ($paymentPanel == false) {
                //regardless of the result, an info must be issued for the client.
                //echo $test->getLog() . '<br />';
                // DEBUG & ERRORS
                //$this->showDebug($show_debug, $show_error, $test, $debug);
            }
            else {
                //here the creation of the transaction was completed successfully
                //DB entry
                //Automatic forwarding either via a link or PHP function header
                //Header:
                $this->redirect($paymentPanel);
                //Link:
                //echo '<a href="' . $paymentPanel . '" target="_blank">redirecting to Payment Panel</a>';
                //$this->showDebug($show_debug, $show_error, $test, $debug);
            }
        }

        // fallback
        return $this->redirect(CoreHelper::getCoreSitePath() . "/error?e=" . urlencode('Failed creating order, please try again later.'));
    }

    private function showDebug($show_debug, $show_error, $test, $debug) {
        if ($show_debug === true OR $show_error === true) {
            echo '<div style="position: absolute; left: 0; bottom: 20px; height: 300px; width: 100%; overflow: scroll; border: 1px solid black; background: #ACACAC;">';
        }
        if ($show_debug === true) {
            echo 'DEBUG:<br /> <pre>';
            var_dump($test->debug);
            echo '</pre>';
        }
        if ($show_error === true) {
            $error = $test->getLog('error');
            if (!empty($error)) {
                echo 'DEVELOPMENT-ERRORS:<br />';
                foreach ($error as $emsg) {
                    echo $emsg['msg'] . '<br />';
                }
            }
        }
        if ($show_debug === true OR $show_error === true) {
            echo '</div>';
        }
        if ($debug === true) {
            $line = '|----- DEBUG @' . time() . ' -----|';
            foreach ($test->debug as $key => $value) {
                $line .= $key . ' : ' . $value . "\n";
            }
        }
        if ($test->getLog('error') !== 0) {
            if (!isset($line)) {
                $line = '|----- ERROR @' . time() . ' -----|';
            }
            else {
                $line .= '|----- ERROR @' . time() . ' -----|';
            }
            foreach ($test->getLog('error') as $entry) {
                $line .= serialize($entry) . "\n";
            }
        }

        echo $line;
        die();
    }

    public function paymentIpn($params = array()) {
        // pickup request for later
        $request = $this->getRequest();

        // setup logging
        LogHelper::setContext('paysafecard');
        LogHelper::info('Hit to _payment_ipn.php. ' . print_r($_REQUEST, true));

        // check for some required variables in the request
        if ((!isset($_REQUEST['ok'])) || (!isset($_REQUEST['mtid']))) {
            return $this->renderEmpty200Response();
        }

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('paysafecard');
        $pluginSettings = $pluginConfig['data']['plugin_settings'];
        if (strlen($pluginSettings)) {
            $pluginSettingsArr = json_decode($pluginSettings, true);
        }

        // make sure payment has completed
        if ($_REQUEST['ok'] == 'true') {
            //System language de/en
            $sysLang = 'en';
            //Debug true/false
            $debug = false;
            //AutoCorrect true/false 
            $autoCorrect = false;
            //test or live SYSTEM
            $mode = $pluginSettingsArr['in_test_mode'] == 'yes' ? 'test' : 'live';
            //User name
            $username = $pluginSettingsArr['sopg_username'];
            //Password
            $password = $pluginSettingsArr['sopg_password'];

            //Embed class
            $test = new SOPGClassicMerchantClient($debug, $sysLang, $autoCorrect, $mode);

            //enter the access data
            $test->merchant($username, $password);

            //get current status
            $status = $test->getSerialNumbers($_GET['mtid'], $_GET['cur'], '');

            //If the return is 'execute', the amount can be debited (executeDebit)
            if ($status === 'execute') {
                // log
                LogHelper::info('Found "execute" status.');

                $testexecute = $test->executeDebit($_GET['amo'], '1');
                if ($testexecute === true) {
                    // log
                    LogHelper::info('Execute successful.');

                    // successful payment!
                    // load order using mtid payment tracker hash
                    $paymentTracker = $_REQUEST['mtid'];
                    $order = OrderHelper::loadByPaymentTracker($paymentTracker);
                    if ($order) {
                        $extendedDays = $order->days;
                        $userId = $order->user_id;
                        $upgradeUserId = $order->upgrade_user_id;
                        $orderId = $order->id;

                        // retain all posted gateway parameters
                        $gatewayVars = "";
                        foreach ($_REQUEST AS $k => $v) {
                            $gatewayVars .= $k . " => " . $v . "\n";
                        }

                        // insert payment log
                        $paymentLog = PaymentLog::create();
                        $paymentLog->user_id = $userId;
                        $paymentLog->date_created = date("Y-m-d H:i:s", time());
                        $paymentLog->amount = $request->request->get('mc_gross');
                        $paymentLog->currency_code = $request->request->get('mc_currency');
                        $paymentLog->from_email = $request->request->get('payer_email');
                        $paymentLog->to_email = $request->request->get('business');
                        $paymentLog->description = $order->description;
                        $paymentLog->request_log = $gatewayVars;
                        $paymentLog->payment_method = 'PaySafeCard';
                        $paymentLog->save();

                        // make sure the amount paid matched what we expect
                        if ($_REQUEST['amo'] != $order->amount) {
                            // order amounts did not match
                            LogHelper::info('Failed - order amounts did not match');

                            return $this->renderEmpty200Response();
                        }

                        // make sure the order is pending
                        if ($order->order_status == 'completed') {
                            // order has already been completed
                            LogHelper::info('Failed - order has already been completed');

                            return $this->renderEmpty200Response();
                        }

                        // update order status to paid
                        $order->order_status = 'completed';
                        if ($order->save() === false) {
                            // failed to update order
                            LogHelper::info('Failed - failed to update order');

                            return $this->renderEmpty200Response();
                        }

                        // extend/upgrade user
                        $rs = UserHelper::upgradeUserByPackageId($userId, $order);
                        if ($rs === false) {
                            // failed to update user
                            LogHelper::info('Failed - failed to update user');

                            return $this->renderEmpty200Response();
                        }

                        // append any plugin includes
                        PluginHelper::callHook('postUpgradePaymentIpn', array(
                            'order' => $order,
                        ));
                    }
                }

                // log
                LogHelper::info($_GET['mtid'] . ', ' . $_GET['amo'] . ', ' . $_GET['cur']);
                LogHelper::info($test->getLog());
            }
        }

        return $this->redirect(WEB_ROOT . '/payment_complete');
    }

}
