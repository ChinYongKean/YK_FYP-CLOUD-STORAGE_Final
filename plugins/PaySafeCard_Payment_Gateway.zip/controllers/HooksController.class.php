<?php

namespace Plugins\Paysafecard\Controllers;

use App\Core\BaseController;
use App\Helpers\CoreHelper;
use App\Helpers\FileHelper;
use App\Helpers\PluginHelper;
use App\Helpers\ThemeHelper;
use App\Models\File;
use Plugins\Paysafecard\Controllers\PaysafecardController;

class HooksController extends BaseController
{

    public function upgradeBoxes($params = null) {
        // call the controller to create the upgrade box
        $paysafecardController = new PaysafecardController();
        $response = $paysafecardController->upgradeBox($params);
        
        // return response object
        return $response;
    }

}
