<?php

namespace Plugins\Paysafecard\Controllers\Admin;

use App\Core\Database;
use App\Controllers\Admin\PluginController AS CorePluginController;
use App\Helpers\AdminHelper;
use App\Helpers\PluginHelper;
use App\Models\Plugin;

class PluginController extends CorePluginController
{

    public function pluginSettings() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // load plugin details
        $folderName = 'paysafecard';
        $plugin = Plugin::loadOneByClause('folder_name = :folder_name', array(
                    'folder_name' => $folderName,
        ));

        if (!$plugin) {
            return $this->redirect(ADMIN_WEB_ROOT . '/plugin_manage?error=' . urlencode('There was a problem loading the plugin details.'));
        }

        // prepare variables
        $plugin_enabled = (int) $plugin->plugin_enabled;
        $sopg_username = '';
        $sopg_password = '';
        $payment_button = 'payment_button_1.png';
        $in_test_mode = 'no';
        $sopg_client_id = '';
        $currency_override = SITE_CONFIG_COST_CURRENCY_CODE;

        // load existing settings
        if (strlen($plugin->plugin_settings)) {
            $plugin_settings = json_decode($plugin->plugin_settings, true);
            if ($plugin_settings) {
                $sopg_username = $plugin_settings['sopg_username'];
                $sopg_password = $plugin_settings['sopg_password'];
                $sopg_client_id = $plugin_settings['sopg_client_id'];
                $payment_button = $plugin_settings['payment_button'];
                $in_test_mode = $plugin_settings['in_test_mode'];
                $currency_override = $plugin_settings['currency_override'];
            }
        }

        // handle page submissions
        if ($request->request->has('submitted')) {
            // get variables
            $plugin_enabled = (int) $request->request->get('plugin_enabled');
            $plugin_enabled = $plugin_enabled != 1 ? 0 : 1;
            $sopg_username = trim($_REQUEST['sopg_username']);
            $sopg_password = trim($_REQUEST['sopg_password']);
            $sopg_client_id = trim($_REQUEST['sopg_client_id']);
            $payment_button = trim($_REQUEST['payment_button']);
            $in_test_mode = trim($_REQUEST['in_test_mode']);
            $currency_override = trim($_REQUEST['currency_override']);

            // validate submission
            if (_CONFIG_DEMO_MODE == true) {
                AdminHelper::setError(AdminHelper::t('no_changes_in_demo_mode', 'No change permitted in demo mode.'));
            }
            elseif (strlen($sopg_username) == 0) {
                AdminHelper::setError(AdminHelper::t("please_enter_your_paysafecard_sopg_username", "Please enter your PaySafeCard username."));
            }
            elseif (strlen($sopg_password) == 0) {
                AdminHelper::setError(AdminHelper::t("please_enter_your_paysafecard_sopg_password", "Please enter your PaySafeCard password."));
            }
            elseif (strlen($sopg_client_id) == 0) {
                AdminHelper::setError(AdminHelper::t("please_enter_your_paysafecard_merchant_id", "Please enter your PaySafeCard password."));
            }

            // update the settings
            if (AdminHelper::isErrors() == false) {
                // compile new settings
                $settingsArr = array();
                $settingsArr['sopg_username'] = $sopg_username;
                $settingsArr['sopg_password'] = $sopg_password;
                $settingsArr['sopg_client_id'] = $sopg_client_id;
                $settingsArr['payment_button'] = $payment_button;
                $settingsArr['in_test_mode'] = $in_test_mode;
                $settingsArr['currency_override'] = $currency_override;

                // update the plugin settings
                $plugin->plugin_enabled = $plugin_enabled;
                $plugin->plugin_settings = json_encode($settingsArr);
                $plugin->save();

                // set onscreen alert
                PluginHelper::loadPluginConfigurationFiles(true);
                AdminHelper::setSuccess('Plugin settings updated.');
            }
        }
        
        // for view
        $currencyOptions = $db->getRows('SELECT currency_code, currency_name '
                . 'FROM country_info '
                . 'WHERE LENGTH(currency_code) > 0 '
                . 'GROUP BY currency_code '
                . 'ORDER BY currency_code');

        // load template
        return $this->render('admin/plugin_settings.html', array(
                    'pluginName' => $plugin->plugin_name,
                    'yesNoOptions' => array(
                        0 => 'No',
                        1 => 'Yes'),
                    'buttonOptions' => array(
                        'payment_button_1' => 'PaySafeCard Logo', 
                        'payment_button_2' => 'Credit Card Icons',
                    ),
                    'currencyOptions' => $currencyOptions,
                    'plugin_enabled' => $plugin_enabled,
                    'sopg_username' => $sopg_username,
                    'sopg_password' => $sopg_password,
                    'sopg_client_id' => $sopg_client_id,
                    'payment_button' => $payment_button,
                    'in_test_mode' => $in_test_mode,
                    'currency_override' => $currency_override,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

}
