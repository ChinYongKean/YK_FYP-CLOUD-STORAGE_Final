<?php

namespace Plugins\Rewards\Models;

use App\Core\Model;

class PluginRewardOutpaymentMethod extends Model
{
    
}
