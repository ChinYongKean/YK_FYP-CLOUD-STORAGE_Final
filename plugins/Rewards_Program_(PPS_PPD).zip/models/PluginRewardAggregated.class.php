<?php

namespace Plugins\Rewards\Models;

use App\Core\Model;

class PluginRewardAggregated extends Model
{
    
}
