<?php

namespace Plugins\Rewards\Controllers;

use App\Core\BaseController;
use App\Core\Database;
use App\Helpers\CoreHelper;
use App\Helpers\LogHelper;
use App\Helpers\NotificationHelper;
use App\Helpers\PluginHelper;
use App\Helpers\TranslateHelper;
use App\Helpers\UserHelper;
use App\Helpers\ValidationHelper;
use App\Models\File;
use App\Models\PaymentLog;
use Plugins\Rewards\Models\PluginRewardWithdrawRequest;
use Plugins\Rewards\Models\PluginRewardPpdCompleteDownload;

class RewardsController extends BaseController
{

    public function rewards() {
        // pickup request
        $folderName = 'rewards';
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $Auth = $this->getAuth();

        // load reward details
        $rewardsConfig = PluginHelper::pluginSpecificConfiguration($folderName);
        $rewardsSettings = json_decode($rewardsConfig['data']['plugin_settings'], true);

        $lowestValue = 0;
        $overallTotal = 0;
        $ppsSampleData = array();
        $monthlyUpgradeExample = 20;
        if ((int) $rewardsSettings['pps_enabled'] == 1) {
            $lowestValue = $db->getValue("SELECT payout_rate "
                    . "FROM plugin_reward_ppd_group_rate "
                    . "ORDER BY payout_rate ASC "
                    . "LIMIT 1");

            // PPS sample data
            for ($i = 1; $i <= 10; $i++) {
                $totalRef = $monthlyUpgradeExample * $i;
                $totalEarnings = (($totalRef * (defined('SITE_CONFIG_COST_FOR_31_DAYS_PREMIUM') ? SITE_CONFIG_COST_FOR_31_DAYS_PREMIUM : SITE_CONFIG_COST_FOR_30_DAYS_PREMIUM)) / 100) * $rewardsSettings['user_percentage'];
                $ppsSampleData[] = array(
                    'totalEarnings' => $totalEarnings,
                    'totalRef' => $totalRef,
                    'label' => date('F Y', strtotime('+' . $i . ' month')),
                );

                $overallTotal = $overallTotal + $totalEarnings;
            }
        }

        $pddRateTable = array();
        $countriesArr = array();
        $payout_ranges = array();
        if ((int) $rewardsSettings['ppd_enabled'] == 1) {
            // load ranges
            $payout_ranges = $db->getRows('SELECT * '
                    . 'FROM plugin_reward_ppd_range '
                    . 'ORDER BY from_filesize');

            // prepare rate table
            // get ppd groups
            $groups = $db->getRows('SELECT id, group_label, payout_rate '
                    . 'FROM plugin_reward_ppd_group '
                    . 'ORDER BY id');
            foreach ($groups AS $group) {
                $countryData = $db->getRows('SELECT plugin_reward_ppd_group_country.country_code, '
                        . 'plugin_reward_country_list.name '
                        . 'FROM plugin_reward_ppd_group_country '
                        . 'LEFT JOIN plugin_reward_country_list ON plugin_reward_ppd_group_country.country_code = plugin_reward_country_list.iso_alpha2 '
                        . 'WHERE group_id=' . (int) $group['id']);
                $countries = array();
                if (count($countryData)) {
                    foreach ($countryData AS $countryRow) {
                        $countries[] = $countryRow['name'];
                    }
                }

                // for no countries, assume all others
                if (count($countries) == 0) {
                    $countries[] = ucwords(TranslateHelper::t('other', 'Other'));
                }

                $countriesStr = implode(", ", $countries);
                $countriesArr[$group['group_label']] = $countriesStr;

                $pddRateTable[$group['id']] = array();
                $pddRateTable[$group['id']]['group_label'] = $group['group_label'];

                $lRates = array();
                foreach ($payout_ranges AS $payout_range) {
                    // load actual rate
                    $payout_rate = $db->getValue('SELECT payout_rate '
                            . 'FROM plugin_reward_ppd_group_rate '
                            . 'WHERE group_id = ' . (int) $group['id'] . ' '
                            . 'AND range_id = ' . $payout_range['id'] . ' '
                            . 'LIMIT 1');
                    if (!$payout_rate) {
                        $payout_rate = 0;
                    }

                    $lRates[] = $payout_rate;
                }
                $pddRateTable[$group['id']]['group_rates'] = $lRates;
            }
        }

        // load template
        return $this->render('rewards.html', array(
                    'rewardsConfig' => $rewardsConfig,
                    'rewardsSettings' => $rewardsSettings,
                    'ppsEnabled' => $rewardsSettings['pps_enabled'],
                    'ppdEnabled' => $rewardsSettings['ppd_enabled'],
                    'lowestValue' => $lowestValue,
                    'payout_ranges' => $payout_ranges,
                    'affKey' => '[AFFILIATE_ID]',
                    'overallTotal' => $overallTotal,
                    'ppsSampleData' => $ppsSampleData,
                    'monthlyUpgradeExample' => $monthlyUpgradeExample,
                    'colWidth' => count($payout_ranges) > 0 ? ceil(80 / count($payout_ranges)) : 0,
                    'countriesArr' => $countriesArr,
                    'paymentDateFormatted' => date('jS', strtotime(date('Y-m-') . $rewardsSettings['payment_date'])),
                    'pddRateTable' => $pddRateTable,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function accountRewards() {
        // require user login
        if (($response = $this->requireLogin()) !== false) {
            return $response;
        }

        // pickup request
        $folderName = 'rewards';
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $Auth = $this->getAuth();

        // check to make sure the current user has an affiliate id
        $affKey = $db->getValue("SELECT affiliate_id "
                . "FROM plugin_reward_affiliate_id "
                . "WHERE user_id = " . (int) $Auth->id . " "
                . "LIMIT 1");
        if (!$affKey) {
            $foundKey = true;

            // create key
            while ($foundKey == true) {
                $affKey = md5(time() . $Auth->id);
                $affKey = substr($affKey, 0, 16);
                $foundKey = $db->getValue("SELECT user_id "
                        . "FROM plugin_reward_affiliate_id "
                        . "WHERE affiliate_id = " . $db->quote($affKey) . " "
                        . "LIMIT 1");
            }

            // update db with new user key
            $db->query('INSERT INTO plugin_reward_affiliate_id (user_id, affiliate_id) '
                    . 'VALUES (:user_id, :affiliate_id)', array(
                'user_id' => (int) $Auth->id,
                'affiliate_id' => $affKey,
                    )
            );
        }

        // get instance
        $pluginObj = PluginHelper::getInstance($folderName);
        $pluginObj->clearPendingRewards();
        $pluginObj->aggregateRewards();
        $rewardsSettings = $pluginObj->settings;

        // get current user total PPD downloads
        $availableForWithdraw = $pluginObj->getAvailableForWithdrawByUserId($Auth->id);
        $availableForWithdrawRaw = $availableForWithdraw;
        $availableForWithdraw = substr(number_format($availableForWithdraw, 3), 0, strlen(number_format($availableForWithdraw, 3)) - 1);

        // get total aggregated rewards
        $totalAggregated = $pluginObj->getAggregatedValuePPSByUserId($Auth->id);

        // get total pending payment
        $totalPendingPayment = $pluginObj->getPendingPaymentTotalByUserId($Auth->id);
        $totalPendingPayment = number_format($totalPendingPayment, 2);

        // get total paid
        $totalPaid = $pluginObj->getPaidTotalByUserId($Auth->id);
        $totalPaidRaw = $totalPaid;
        $totalPaid = number_format($totalPaid, 2);

        // get current user total rewards
        $totalRewards = $pluginObj->getTotalPPSByUserId($Auth->id);
        $totalRewards = number_format($totalRewards, 2);

        // get current user total PPD downloads
        $totalPPDDownloads = $pluginObj->getCountPPDByUserId($Auth->id);

        // get current user total PPD downloads uncleared
        $totalPPDDownloadsUncleared = $pluginObj->getUnaggregatedCountPPDByUserId($Auth->id);

        // get current user total PPD downloads
        $totalPPDDownloadsUnclearedValue = (float) $pluginObj->getUnaggregatedValuePPDByUserId($Auth->id);
        if ($totalPPDDownloadsUnclearedValue == 0) {
            $totalPPDDownloadsUnclearedValue = number_format($totalPPDDownloadsUnclearedValue, 2);
        }

        // get payment method data
        $paymentMethods = $db->getRows('SELECT * '
                . 'FROM plugin_reward_outpayment_method '
                . 'WHERE is_enabled = 1');

        // format json into array for the view
        foreach ($paymentMethods AS $k => $paymentMethod) {
            $paymentMethods[$k]['_fields_array'] = json_decode($paymentMethod['fields_json'], true);
        }

        $pddRateTable = array();
        $countriesArr = array();
        $payout_ranges = array();
        if ((int) $rewardsSettings['ppd_enabled'] == 1) {
            // load ranges
            $payout_ranges = $db->getRows('SELECT * '
                    . 'FROM plugin_reward_ppd_range '
                    . 'ORDER BY from_filesize');

            // prepare rate table
            // get ppd groups
            $groups = $db->getRows('SELECT id, group_label, payout_rate '
                    . 'FROM plugin_reward_ppd_group '
                    . 'ORDER BY id');
            foreach ($groups AS $group) {
                $countryData = $db->getRows('SELECT plugin_reward_ppd_group_country.country_code, '
                        . 'plugin_reward_country_list.name '
                        . 'FROM plugin_reward_ppd_group_country '
                        . 'LEFT JOIN plugin_reward_country_list ON plugin_reward_ppd_group_country.country_code = plugin_reward_country_list.iso_alpha2 '
                        . 'WHERE group_id=' . (int) $group['id']);
                $countries = array();
                if (count($countryData)) {
                    foreach ($countryData AS $countryRow) {
                        $countries[] = $countryRow['name'];
                    }
                }

                // for no countries, assume all others
                if (count($countries) == 0) {
                    $countries[] = ucwords(TranslateHelper::t('other', 'Other'));
                }

                $countriesStr = implode(", ", $countries);
                $countriesArr[$group['group_label']] = $countriesStr;

                $pddRateTable[$group['id']] = array();
                $pddRateTable[$group['id']]['group_label'] = $group['group_label'];

                $lRates = array();
                foreach ($payout_ranges AS $payout_range) {
                    // load actual rate
                    $payout_rate = $db->getValue('SELECT payout_rate '
                            . 'FROM plugin_reward_ppd_group_rate '
                            . 'WHERE group_id = ' . (int) $group['id'] . ' '
                            . 'AND range_id = ' . $payout_range['id'] . ' '
                            . 'LIMIT 1');
                    if (!$payout_rate) {
                        $payout_rate = 0;
                    }

                    $lRates[] = $payout_rate;
                }
                $pddRateTable[$group['id']]['group_rates'] = $lRates;
            }
        }

        // load template
        return $this->render('account/rewards.html', array(
                    'pluginObj' => $pluginObj,
                    'rewardsConfig' => $rewardsConfig,
                    'rewardsSettings' => $rewardsSettings,
                    'ppsEnabled' => $rewardsSettings['pps_enabled'],
                    'ppdEnabled' => $rewardsSettings['ppd_enabled'],
                    'affKey' => $affKey,
                    'availableForWithdrawRaw' => $availableForWithdrawRaw,
                    'availableForWithdraw' => $availableForWithdraw,
                    'totalAggregated' => $totalAggregated,
                    'totalPendingPayment' => $totalPendingPayment,
                    'totalPaidRaw' => $totalPaidRaw,
                    'totalPaid' => $totalPaid,
                    'totalRewards' => $totalRewards,
                    'totalPPDDownloads' => $totalPPDDownloads,
                    'totalPPDDownloadsUncleared' => $totalPPDDownloadsUncleared,
                    'totalPPDDownloadsUnclearedValue' => $totalPPDDownloadsUnclearedValue,
                    'paymentMethods' => $paymentMethods,
                    'nextRewardsAggregationDateFormatted' => date('jS F Y', SITE_CONFIG_NEXT_CHECK_FOR_REWARDS_AGGREGATION),
                    'payout_ranges' => $payout_ranges,
                    'colWidth' => count($payout_ranges) > 0 ? ceil(80 / count($payout_ranges)) : 0,
                    'countriesArr' => $countriesArr,
                    'paymentDateFormatted' => date('jS', strtotime(date('Y-m-') . $rewardsSettings['payment_date'])),
                    'pddRateTable' => $pddRateTable,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    function ajaxRewardsRequestWithdrawal() {
        // require user login
        if (($response = $this->requireLogin()) !== false) {
            return $response;
        }

        // pickup request
        $folderName = 'rewards';
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $Auth = $this->getAuth();

        // setup initial params
        $params = array();
        foreach ($_REQUEST AS $k => $param) {
            $params[$k] = strip_tags(trim($param));
        }

        $result = array();
        $result['error'] = false;
        $result['msg'] = '';

        // validate payment method to stop abuse
        $paymentMethods = $db->getRows('SELECT name_key '
                . 'FROM plugin_reward_outpayment_method '
                . 'WHERE is_enabled = 1');
        $found = false;
        foreach ($paymentMethods AS $paymentMethod) {
            if ($paymentMethod['name_key'] == $params['outpayment_method']) {
                $found = true;
            }
        }
        if ($found == false) {
            $params['outpayment_method'] = 'paypal';
        }

        // get instance
        $pluginObj = PluginHelper::getInstance($folderName);
        $pluginObj->clearPendingRewards();
        $pluginObj->aggregateRewards();
        $rewardsSettings = $pluginObj->settings;

        // get rewards available for withdrawal
        $availableForWithdraw = $db->getValue("SELECT SUM(amount) AS total "
                . "FROM plugin_reward_aggregated "
                . "WHERE reward_user_id = " . (int) $Auth->id . " "
                . "AND status IN ('available')");
        $availableForWithdrawRaw = $availableForWithdraw;
        $availableForWithdraw = substr(number_format($availableForWithdraw, 3), 0, strlen(number_format($availableForWithdraw, 3)) - 1);

        // get total aggregated rewards
        $totalAggregated = (float) $db->getValue("SELECT SUM(amount) AS total "
                        . "FROM plugin_reward_aggregated "
                        . "WHERE reward_user_id = " . (int) $Auth->id);

        // double check the amount is above the threshold
        if ((float) $availableForWithdrawRaw < (float) $rewardsSettings['payment_threshold']) {
            $result['error'] = true;
            $result['msg'] = 'The amount available within your account ' . $availableForWithdraw . ' is less than the payment threshold (' . $rewardsSettings['payment_threshold'] . ').';
        }
        elseif (_CONFIG_DEMO_MODE == true) {
            $result['error'] = true;
            $result['msg'] = AdminHelper::t("no_changes_in_demo_mode");
        }
        else {
            // add payment request
            $pluginRewardWithdrawRequest = PluginRewardWithdrawRequest::create();
            $pluginRewardWithdrawRequest->reward_user_id = (int) $Auth->id;
            $pluginRewardWithdrawRequest->amount = (float) $availableForWithdrawRaw;
            $pluginRewardWithdrawRequest->requested_date = CoreHelper::sqlDateTime();
            $pluginRewardWithdrawRequest->status = 'pending';
            $pluginRewardWithdrawRequest->payment_method = $params['outpayment_method'];
            $pluginRewardWithdrawRequest->save();

            // update aggregated rewards
            $db->query("UPDATE plugin_reward_aggregated "
                    . "SET status='payment_in_progress', "
                    . "withdrawal_request_id=" . (int) $dbInsert->id . " "
                    . "WHERE reward_user_id = " . (int) $Auth->id . " "
                    . "AND status IN ('available')");

            // store outpayment details
            $jsonArr = $params;
            unset($jsonArr['outpayment_method']);
            unset($jsonArr['_page_url']);
            $jsonStr = json_encode($jsonArr);
            $db->query("UPDATE plugin_reward_affiliate_id "
                    . "SET outpayment_method=" . $db->quote($params['outpayment_method']) . ", "
                    . "method_data_json=" . $db->quote($jsonStr) . " "
                    . "WHERE user_id = " . (int) $Auth->id . " "
                    . "LIMIT 1");

            // send notification to admin
            $subject = TranslateHelper::t('rewards_request_withdrawal_email_to_admin_subject', 'Rewards withdrawal request for [[[AMOUNT]]]', array('AMOUNT' => SITE_CONFIG_COST_CURRENCY_SYMBOL . $availableForWithdraw));
            $replacements = array(
                'SITE_NAME' => SITE_CONFIG_SITE_NAME,
                'ADMIN_WEB_ROOT' => ADMIN_WEB_ROOT
            );
            $defaultContent = "Dear Admin,<br/><br/>";
            $defaultContent .= "A rewards withdrawal request has been received. Please login to [[[SITE_NAME]]] and process the request:<br/><br/>";
            $defaultContent .= "<a href='[[[ADMIN_WEB_ROOT]]]'>[[[ADMIN_WEB_ROOT]]]</a><br/><br/>";
            $defaultContent .= "Regards,<br/>";
            $defaultContent .= "[[[SITE_NAME]]] Admin";
            $htmlMsg = TranslateHelper::t('rewards_request_withdrawal_email_to_admin_content', $defaultContent, $replacements);
            CoreHelper::sendHtmlEmail(SITE_CONFIG_SITE_ADMIN_EMAIL, $subject, $htmlMsg, SITE_CONFIG_DEFAULT_EMAIL_ADDRESS_FROM, strip_tags(str_replace("<br/>", "\n", $htmlMsg)));

            $result['error'] = false;
            $result['msg'] = TranslateHelper::t("rewards_withdraw_confirmation_on_screen", "Your withdrawal request has been made. You'll receive further information once the request has been approved.");
        }

        return $this->renderJson($result);
    }

    public function ajaxAccountRewards() {
        // require user login
        if (($response = $this->requireLogin()) !== false) {
            return $response;
        }

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $Auth = $this->getAuth();

        $iDisplayLength = (int) $request->query->get('iDisplayLength');
        $iDisplayStart = (int) $request->query->get('iDisplayStart');

        // load all rewards for this account
        $totalRewards = $db->getValue('SELECT COUNT(id) AS total '
                . 'FROM plugin_reward '
                . 'WHERE reward_user_id = ' . (int) $Auth->id);

        // load filtered
        $rewards = $db->getRows('SELECT * '
                . 'FROM plugin_reward '
                . 'WHERE reward_user_id = ' . (int) $Auth->id . ' '
                . 'ORDER BY reward_date DESC '
                . 'LIMIT ' . $iDisplayStart . ',' . $iDisplayLength);

        $data = array();
        if ($rewards) {
            foreach ($rewards AS $reward) {
                $lrs = array();

                $lrs[] = CoreHelper::formatDate($reward['reward_date'], SITE_CONFIG_DATE_TIME_FORMAT);
                $lrs[] = SITE_CONFIG_COST_CURRENCY_SYMBOL . $reward['reward_amount'];
                $lrs[] = $reward['reward_percent'] . '%';
                $lrs[] = UCWords(str_replace("_", " ", $reward['status']));

                $data[] = $lrs;
            }
        }

        $resultArr = array();
        $resultArr["sEcho"] = intval($request->query->get('sEcho'));
        $resultArr["iTotalRecords"] = (int) $totalRewards;
        $resultArr["iTotalDisplayRecords"] = $resultArr["iTotalRecords"];
        $resultArr["aaData"] = $data;

        // output response
        return $this->renderJson($resultArr);
    }

    public function ajaxAccountRewardsPpd() {
        // require user login
        if (($response = $this->requireLogin()) !== false) {
            return $response;
        }

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $Auth = $this->getAuth();

        $iDisplayLength = (int) $request->query->get('iDisplayLength');
        $iDisplayStart = (int) $request->query->get('iDisplayStart');

        /// load all rewards for this account
        $totalRewards = $db->getValue('SELECT COUNT(id) AS total '
                . 'FROM plugin_reward_ppd_detail '
                . 'WHERE reward_user_id = ' . (int) $Auth->id);

        // load filtered
        $rewards = $db->getRows('SELECT *, plugin_reward_ppd_group.group_label, '
                . 'file.id AS fileId '
                . 'FROM plugin_reward_ppd_detail '
                . 'LEFT JOIN plugin_reward_ppd_group ON plugin_reward_ppd_detail.download_country_group_id = plugin_reward_ppd_group.id '
                . 'LEFT JOIN file ON plugin_reward_ppd_detail.file_id = file.id '
                . 'WHERE reward_user_id = ' . (int) $Auth->id . ' '
                . 'ORDER BY download_date DESC '
                . 'LIMIT ' . $iDisplayStart . ',' . $iDisplayLength);

        $data = array();
        if ($rewards) {
            foreach ($rewards AS $reward) {
                // load file
                $file = File::loadOneById($reward['fileId']);

                $lrs = array();
                $lrs[] = CoreHelper::formatDate($reward['download_date'], SITE_CONFIG_DATE_TIME_FORMAT);
                if ($file) {
                    $lrs[] = '<a href="' . $file->getFullShortUrl() . '">' . ValidationHelper::safeOutputToScreen($file->originalFilename, null, 38) . '</a>';
                }
                else {
                    $lrs[] = '<span style="color: #888;">[' . TranslateHelper::t('removed', 'removed') . ']</span>';
                }
                $lrs[] = $reward['group_label'];
                $lrs[] = UCWords(str_replace("_", " ", $reward['status']));

                $data[] = $lrs;
            }
        }

        $resultArr = array();
        $resultArr["sEcho"] = intval($request->query->get('sEcho'));
        $resultArr["iTotalRecords"] = (int) $totalRewards;
        $resultArr["iTotalDisplayRecords"] = $resultArr["iTotalRecords"];
        $resultArr["aaData"] = $data;

        // output response
        return $this->renderJson($resultArr);
    }

    public function nginxLogDownloadCallback() {
        // pickup request
        $db = Database::getDatabase();

        // log callback data
        LogHelper::setContext('plugin_reward_nginx_complete_download');
        LogHelper::breakInLogFile();
        LogHelper::info('Data received: ' . http_build_query($_REQUEST));

        // prepare response for inserting
        $downloadTokenExp = explode('download_token=', $_REQUEST['request_uri']);
        $downloadToken = current(explode('&', $downloadTokenExp[1]));
        if (!strlen($downloadToken)) {
            LogHelper::info('No download token found.');

            return $this->render404(false);
        }

        // initial variables
        $payPPD = false;

        // load file details
        $fileSize = -1;
        $fileUserId = NULL;
        $fileId = -1;
        $fileDetail = $db->getRow('SELECT file.fileSize, file.userId, file.id '
                . 'FROM file '
                . 'LEFT JOIN download_token ON file.id = download_token.file_id '
                . 'WHERE download_token.token=' . $db->quote($downloadToken) . ' '
                . 'LIMIT 1');
        if (!$fileDetail) {
            LogHelper::info('Could not load download token details using ' . $downloadToken);

            return $this->render404(false);
        }

        $fileSize = $fileDetail['fileSize'];
        $fileUserId = $fileDetail['userId'];
        $fileId = $fileDetail['id'];

        // if total bytes sent equals file size pay PPD
        if (strlen($_REQUEST['body_bytes_sent']) && ($fileSize == $_REQUEST['body_bytes_sent'])) {
            LogHelper::info('Filesize downloaded (' . $_REQUEST['body_bytes_sent'] . ') matches actual filesize (' . $fileSize . '). Non chunked.');
            $payPPD = true;
        }

        // log in database
        $pluginRewardPpdCompleteDownload = PluginRewardPpdCompleteDownload::create();
        $pluginRewardPpdCompleteDownload->download_token = $downloadToken;
        $pluginRewardPpdCompleteDownload->date_added = CoreHelper::sqlDateTime();
        $pluginRewardPpdCompleteDownload->download_ip = $_REQUEST['remote_addr'];
        if (strlen($_REQUEST['body_bytes_sent'])) {
            $pluginRewardPpdCompleteDownload->bytes_sent = $_REQUEST['body_bytes_sent'];
        }
        else {
            $pluginRewardPpdCompleteDownload->bytes_sent = 0;
        }
        $pluginRewardPpdCompleteDownload->pay_ppd = (int) $payPPD;
        $pluginRewardPpdCompleteDownload->save();

        // lookup for partial completed downloads for this token, required in later versions of Nginx
        if ($payPPD == false) {
            $totalDownloadedSize = $db->getValue('SELECT SUM(plugin_reward_ppd_complete_download.bytes_sent) AS total '
                    . 'FROM plugin_reward_ppd_complete_download '
                    . 'WHERE download_token=' . $db->quote($downloadToken) . ' '
                    . 'AND pay_ppd=0');
            if ($totalDownloadedSize >= $fileSize) {
                LogHelper::info('Total filesize downloaded (' . $totalDownloadedSize . ') is greater than or matches actual filesize (' . $fileSize . '). Chunked, so total sum of bytes sent.');
                $payPPD = true;
            }
        }

        if ($payPPD == true) {
            // check owner isn't the person downloading it, we don't log PPD payments
            $userDetail = $db->getRow('SELECT users.username, users.level_id AS package_id, '
                    . 'users.id '
                    . 'FROM users '
                    . 'LEFT JOIN download_token ON users.id = download_token.user_id '
                    . 'WHERE download_token.token=' . $db->quote($downloadToken) . ' '
                    . 'LIMIT 1');
            if ($userDetail) {
                $tokenUsername = $userDetail['username'];
                $tokenLevelId = UserHelper::getLevelIdFromPackageId($userDetail['package_id']);
                $tokenUserId = $userDetail['id'];

                // check downloader against file owner
                if ($tokenUserId == $fileUserId) {
                    // log
                    LogHelper::info('No PPD logged as downloaded by file owner.');
                    $payPPD = false;
                }
                elseif ($tokenLevelId >= 20) {
                    // log
                    LogHelper::info('No PPD logged as downloaded by admin user.');
                    $payPPD = false;
                }
            }
        }

        // update older records to set paid
        if ($payPPD == true) {
            $db->query('UPDATE plugin_reward_ppd_complete_download '
                    . 'SET pay_ppd=1 '
                    . 'WHERE pay_ppd=0 '
                    . 'AND download_token=' . $db->quote($downloadToken));
        }

        // log PPD if not file owner
        if ($payPPD) {
            // log
            LogHelper::info('Total file downloaded, logging PPD.');

            // rebuild plugin cache, needed as 'server' session caches plugin data so any plugin config changes are not applied
            PluginHelper::loadPluginConfigurationFiles(true);

            // include download complete process to actually log the PPD
            PluginHelper::callHook('fileDownloadComplete', array(
                'origin' => 'RewardsController.class.php',
                'forceDownload' => true,
                'fileOwnerUserId' => $tokenUserId,
                'userLevelId' => $tokenLevelId,
                'file' => File::loadOneById($fileId),
                'doPluginIncludes' => false,
                'ipOverride' => $_REQUEST['remote_addr'],
            ));
        }

        return $this->renderEmpty200Response();
    }

    public function mediaLogDownloadCallback() {
        // pickup request
        $db = Database::getDatabase();

        // log callback data
        LogHelper::setContext('plugin_reward_media_percentage_played');
        LogHelper::breakInLogFile();
        LogHelper::info('Data received: ' . http_build_query($_REQUEST));

        $downloadUrl = base64_decode($_REQUEST['tracker']);
        $percent = number_format($_REQUEST['percent'], 1);
        $downloadToken = end(explode('download_token=', $downloadUrl));
        if (!strlen($downloadToken)) {
            return $this->render404(false);
        }

        // log
        LogHelper::info('Found download token: ' . $downloadToken);

        // initial variables
        $payPPD = false;

        // load file details
        $fileSize = -1;
        $fileUserId = NULL;
        $fileId = -1;
        $fileDetail = $db->getRow('SELECT file.fileSize, file.userId, file.id '
                . 'FROM file '
                . 'LEFT JOIN download_token ON file.id = download_token.file_id '
                . 'WHERE download_token.token=' . $db->quote($downloadToken) . ' '
                . 'LIMIT 1');
        if (!$fileDetail) {
            LogHelper::info('Could not load download token details using ' . $downloadToken);

            return $this->render404(false);
        }

        $fileSize = $fileDetail['fileSize'];
        $fileUserId = $fileDetail['userId'];
        $fileId = $fileDetail['id'];
        $payPPD = true;

        // check percentage of watched file is valid
        $pluginObj = PluginHelper::getInstance('rewards');
        $ackPercentage = (int) $pluginObj->settings['ppd_media_percentage'];
        if (($ackPercentage < 1) || ($ackPercentage > 99)) {
            return $this->render404(false);
        }
        if ((float) $percent < $ackPercentage) {
            return $this->render404(false);
        }

        if ($payPPD == true) {
            // check owner isn't the person downloading it, we don't log PPD payments
            $userDetail = $db->getRow('SELECT users.username, users.level_id AS package_id, '
                    . 'users.id '
                    . 'FROM users '
                    . 'LEFT JOIN download_token ON users.id = download_token.user_id '
                    . 'WHERE download_token.token=' . $db->quote($downloadToken) . ' '
                    . 'LIMIT 1');
            if ($userDetail) {
                $tokenUsername = $userDetail['username'];
                $tokenLevelId = UserHelper::getLevelIdFromPackageId($userDetail['package_id']);
                $tokenUserId = $userDetail['id'];

                // check downloader against file owner
                if ($tokenUserId == $fileUserId) {
                    // log
                    LogHelper::info('No PPD logged as downloaded by file owner.');
                    $payPPD = false;
                }
                elseif ($tokenLevelId >= 20) {
                    // log
                    LogHelper::info('No PPD logged as downloaded by admin user.');
                    $payPPD = false;
                }
            }
        }

        // log PPD if not file owner
        if ($payPPD) {
            // log
            LogHelper::info('Media percentage reached, logging PPD.');

            // include download complete process to actually log the PPD
            PluginHelper::callHook('fileDownloadComplete', array(
                'origin' => 'logMediaPercentage.class.php',
                'forceDownload' => true,
                'fileOwnerUserId' => $tokenUserId,
                'userLevelId' => $tokenLevelId,
                'file' => File::loadOneById($fileId),
                'doPluginIncludes' => false,
                'ipOverride' => CoreHelper::getUsersIPAddress(),
            ));
        }

        return $this->renderEmpty200Response();
    }

}
