<?php

namespace Plugins\Rewards\Controllers;

use App\Core\BaseController;
use App\Core\Database;
use App\Helpers\CoreHelper;
use App\Helpers\FileServerHelper;
use App\Helpers\LogHelper;
use App\Helpers\PluginHelper;
use App\Helpers\TranslateHelper;
use App\Helpers\StatsHelper;
use App\Helpers\UserHelper;
use App\Models\User;
use Plugins\Rewards\Models\PluginReward;

class HooksController extends BaseController {

    public function adminPluginNav($params = null) {
        // output within the admin left-hand navigation
        $navigation = array(
            array('link_url' => '#', 'link_text' => 'Rewards', 'link_key' => 'rewards', 'icon_class' => 'fa fa-money', 'children' => array(
                    array('link_url' => 'admin/rewards_overview', 'link_text' => 'Overview', 'link_key' => 'rewards_overview'),
                    array('link_url' => 'admin/rewards_detailed_referral', 'link_text' => 'Referrals (pps)', 'link_key' => 'rewards_detailed_referral'),
                    array('link_url' => 'admin/rewards_detailed_download', 'link_text' => 'Downloads (ppd)', 'link_key' => 'rewards_detailed_download'),
                    array('link_url' => 'admin/rewards_aggregated_earning', 'link_text' => 'Aggregated Earnings', 'link_key' => 'rewards_aggregated_earning'),
                    array('link_url' => 'admin/rewards_payment_request', 'link_text' => 'Payment Requests', 'link_key' => 'rewards_payment_request'),
                    array('link_url' => 'admin/plugin/rewards/settings', 'link_text' => 'Plugin Settings', 'link_key' => 'rewards_plugin_settings'),
                    array('link_url' => 'admin/log_file_viewer?lType=plugin_rewards_ppd_log', 'link_text' => 'Logs - PPD', 'link_key' => 'logs_ppd'),
                )),
        );
http://mellowfish-dev/owned-scripts/yetishare/script/admin/log_file_viewer?lType=plugin_rewards_ppd_log
        // return array
        return $navigation;
    }

    /**
     * Shown on both the front-end and file manager.
     * 
     * @param type $params
     * @return type
     */
    public function siteHeaderNav($params = array()) {
        // get current user
        $Auth = $this->getAuth();

        return array(
            '_found_hook' => true,
            array(
                'link_url' => WEB_ROOT . '/' . ($Auth->loggedIn() === true ? 'account/' : '') . 'rewards',
                'link_text' => TranslateHelper::t("plugin_rewards", "Rewards"),
            ),
        );
    }

    public function fileDownloadTop($params = array()) {
        $file = isset($params['file']) ? $params['file'] : null;
        if (($file != null) && ((int) $file->userId)) {
            // load reward details
            $rewardsConfig = PluginHelper::pluginSpecificConfiguration('rewards');
            $rewardsSettings = json_decode($rewardsConfig['data']['plugin_settings'], true);

            // make sure PPS is enabled
            if ((int) $rewardsSettings['pps_enabled'] == 1) {
                // lookup user id
                $affUserId = (int) $file->userId;
                $cookieName = "source_aff_id";
                if ($affUserId) {
                    // store it within the session
                    $_SESSION['plugin_rewards_aff_user_id'] = (int) $affUserId;

                    // set the cookie for future visits
                    $cookieValue = (int) $affUserId;
                    $lifetime = (int) $rewardsSettings['pps_cookie_lifetime_days'] == 0 ? 7 : (int) $rewardsSettings['pps_cookie_lifetime_days'];
                    setcookie($cookieName, $cookieValue, time() + (86400 * (int) $lifetime), "/"); // 86400 = 1 day
                } else {
                    // remove cookie
                    setcookie($cookieName, 0, -1, "/");
                }
            }
        }

        // return false to hooks controller continues onto the next
        return false;
    }

    public function postFrameworkInit($params = array()) {
        // see if we get passed an affiliate id
        if (isset($_REQUEST['aff'])) {
            // load reward details
            $rewardsConfig = PluginHelper::pluginSpecificConfiguration('rewards');
            $rewardsSettings = json_decode($rewardsConfig['data']['plugin_settings'], true);

            // make sure PPS is enabled
            if ((int) $rewardsSettings['pps_enabled'] == 1) {
                // lookup user id
                $db = Database::getDatabase();
                $affUserId = $db->getValue('SELECT user_id '
                        . 'FROM plugin_reward_affiliate_id '
                        . 'WHERE affiliate_id=' . $db->quote(trim($_REQUEST['aff'])) . ' '
                        . 'LIMIT 1');

                if ($affUserId) {
                    // store it within the session
                    $_SESSION['plugin_rewards_aff_id'] = trim($_REQUEST['aff']);
                    $_SESSION['plugin_rewards_aff_user_id'] = (int) $affUserId;

                    // set the cookie for future visits
                    $cookieName = "source_aff_id";
                    $cookieValue = (int) $affUserId;
                    $lifetime = (int) $rewardsSettings['pps_cookie_lifetime_days'] == 0 ? 7 : (int) $rewardsSettings['pps_cookie_lifetime_days'];
                    setcookie($cookieName, $cookieValue, time() + (86400 * (int) $lifetime), "/"); // 86400 = 1 day
                }
            }
        }

        // return false to hooks controller continues onto the next
        return false;
    }

    public function fileDownloadComplete($params = array()) {
        // get current user
        $Auth = $this->getAuth();
        $db = Database::getDatabase();

        // load reward details
        $folderName = 'rewards';
        $rewardsConfig = PluginHelper::pluginSpecificConfiguration($folderName);
        $rewardsSettings = json_decode($rewardsConfig['data']['plugin_settings'], true);

        $file = $params['file'];
        $fileOwnerUserId = $params['fileOwnerUserId'];
        $currentUserLevelId = $params['userLevelId'];
        $fileOwnerLevelId = (int) $db->getValue('SELECT id '
                        . 'FROM user_level '
                        . 'WHERE level_type = "nonuser" '
                        . 'ORDER BY id ASC');
        if ($file->userId !== null) {
            $user = User::loadOneById($file->userId);
            if ($user) {
                $fileOwnerLevelId = (int) $user->level_id;
            }
        }

        $origin = isset($params['origin']) ? $params['origin'] : 'File.class.php';
        $downloadToken = (isset($params['downloadToken']) && (strlen($params['downloadToken']))) ? $params['downloadToken'] : null;
        $statusCheckOnly = isset($params['statusCheckOnly']) ? $params['statusCheckOnly'] : false;

        if ($statusCheckOnly === false) {
            // logging
            LogHelper::setContext('plugin_rewards_ppd_log');
            LogHelper::breakInLogFile();
            LogHelper::info('Request received to log PPD. (origin: ' . $origin . ', '
                    . 'use_download_complete_callback = ' . $rewardsSettings['use_download_complete_callback'] . ') '
                    . 'FileId: #' . $file->id . ', Name: ' . $file->originalFilename . ', UserLevel: ' . $currentUserLevelId . ', '
                    . 'FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                    . 'Origin: ' . $origin . ' FileOwnerId: ' . $fileOwnerUserId);
        }

        // make sure PPD is enabled
        if ((int) $rewardsSettings['ppd_enabled'] == 0) {
            LogHelper::info('PPD not enabled in plugin config, skipping.');
        } else {
            // db connection
            $db = Database::getDatabase();

            // make sure the download token allows PPD logging
            $continue = true;
            if ($downloadToken) {
                $processPPD = (int) $db->getValue('SELECT process_ppd '
                                . 'FROM download_token '
                                . 'WHERE token=' . $db->quote($downloadToken) . ' '
                                . 'LIMIT 1');
                if ($processPPD === 0) {
                    // log
                    LogHelper::info('Skipping PPD log as download_token has '
                            . 'process_ppd = ' . $processPPD . '. Token: ' . $downloadToken . ', '
                            . 'FileId: #' . $file->id . ', Name: ' . $file->originalFilename . ', '
                            . 'UserLevel: ' . $currentUserLevelId . ', FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                            . 'Origin: ' . $origin . ' '
                            . 'LoggedInUserId: ' . $fileOwnerUserId);
                    $continue = false;
                }
            }

            // check to make sure we're invoking this in the correct place
            if ($continue === true) {
                if (($origin == 'File.class.php') && ((int) $rewardsSettings['use_download_complete_callback'] == 1)) {
                    // only for nginx
                    if (FileServerHelper::nginxXAccelRedirectEnabled($file->serverId)) {
                        // log
                        LogHelper::info('Skipping PPD log from origin \'' . $origin . '\' as '
                                . 'use_download_complete_callback is enabled. '
                                . 'FileId: #' . $file->id . ', Name: ' . $file->originalFilename . ', '
                                . 'UserLevel: ' . $currentUserLevelId . ', FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                                . 'Origin: ' . $origin . ' '
                                . 'LoggedInUserId: ' . $fileOwnerUserId);
                        $continue = false;
                    }
                } elseif (($origin == 'RewardsController.class.php') && ((int) $rewardsSettings['use_download_complete_callback'] == 0)) {
                    // log
                    LogHelper::info('Skipping PPD log from origin \'' . $origin . '\' as '
                            . 'use_download_complete_callback is disabled. '
                            . 'FileId: #' . $file->id . ', Name: ' . $file->originalFilename . ', '
                            . 'UserLevel: ' . $currentUserLevelId . ', FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                            . 'Origin: ' . $origin . ' '
                            . 'LoggedInUserId: ' . $fileOwnerUserId);
                    $continue = false;
                }
            }

            // make sure the file is associated with a user
            if (((int) $file->userId > 0) && ($continue == true)) {
                // log download
                if (($fileOwnerUserId == $file->userId) || ($currentUserLevelId == 20)) {
                    // ignore - this was triggered by an admin user or file owner
                    LogHelper::info('Ignoring, this was triggered by an admin user '
                            . 'or file owner. FileId: #' . $file->id . ', '
                            . 'Name: ' . $file->originalFilename . ', UserLevel: ' . $currentUserLevelId . ', '
                            . 'FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                            . 'Origin: ' . $origin . ' LoggedInUserId: ' . $fileOwnerUserId);
                } else {
                    // make sure file owner is allowed access to PPD
                    $pluginObj = PluginHelper::getInstance($folderName);
                    if (!$pluginObj->userTypeAllowedPPDAccess($fileOwnerLevelId)) {
                        // ignore - this was triggered by an invalid user type
                        LogHelper::info('Ignoring, file belongs to a user type which '
                                . 'does not have access to PPD (Owner Level ID: '.$fileOwnerLevelId.'). FileId: #' . $file->id . ', '
                                . 'Name: ' . $file->originalFilename . ', '
                                . 'UserLevel: ' . $currentUserLevelId . ', FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                                . 'Origin: ' . $origin . ' '
                                . 'LoggedInUserId: ' . $fileOwnerUserId);
                    } else {
                        // check filesize
                        $count = false;
                        $countFilesize = (int) $rewardsSettings['ppd_min_file_size'];
                        if ($countFilesize == 0) {
                            $count = true;
                        } else {
                            // check download size counts
                            if (($countFilesize * 1024 * 1024) <= $file->fileSize) {
                                $count = true;
                            } else {
                                // log
                                LogHelper::info('Ignoring, size is less than permitted. '
                                        . 'Permitted: ' . ($countFilesize * 1024 * 1024) . '. '
                                        . 'Filesize: ' . $file->fileSize . ' FileId: #' . $file->id . ', '
                                        . 'Name: ' . $file->originalFilename . ', '
                                        . 'UserLevel: ' . $currentUserLevelId . ', FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                                        . 'Origin: ' . $origin . ' '
                                        . 'LoggedInUserId: ' . $fileOwnerUserId);
                            }
                        }
                        
                        // make sure current user is allowed in PPD
                        if ($count == true) {
                            if (!$pluginObj->userTypeLogPPD($currentUserLevelId)) {
                                // ignore - this was triggered by an invalid user type
                                LogHelper::info('Ignoring, the downloader does not meet the minimum '
                                        . 'account level for PPD logging (Current User Level ID: '.$currentUserLevelId.'). FileId: #' . $file->id . ', '
                                        . 'Name: ' . $file->originalFilename . ', '
                                        . 'UserLevel: ' . $currentUserLevelId . ', FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                                        . 'Origin: ' . $origin . ' '
                                        . 'LoggedInUserId: ' . $fileOwnerUserId);
                                
                                $count = false;
                            }
                        }

                        // log download
                        if ($count == true) {
                            // check whether the user has already downloaded today
                            $usersIp = StatsHelper::getIP();
                            if (isset($params['ipOverride'])) {
                                $usersIp = $params['ipOverride'];
                            }

                            $sql = "SELECT * "
                                    . "FROM plugin_reward_ppd_detail "
                                    . "WHERE download_ip = " . $db->quote($usersIp) . " "
                                    . "AND file_id = " . $file->id . " "
                                    . "AND DATE(download_date) = " . $db->quote(date('Y-m-d'));
                            $row = $db->getRows($sql);
                            if (count($row) == 0) {
                                // log
                                LogHelper::info('User IP: ' . $usersIp . '. Nothing '
                                        . 'found for this IP and file in the last '
                                        . '24 hours. FileId: #' . $file->id . ', '
                                        . 'Name: ' . $file->originalFilename . ', '
                                        . 'UserLevel: ' . $currentUserLevelId . ', '
                                        . 'FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                                        . 'Origin: ' . $origin . ' '
                                        . 'LoggedInUserId: ' . $fileOwnerUserId);

                                // lookup country group
                                $countryGroupId = null;
                                $rewardAmount = false;
                                $country = StatsHelper::getCountry($usersIp);

                                // log
                                LogHelper::info('User country: ' . $country . '. FileId: #' . $file->id . ', '
                                        . 'Name: ' . $file->originalFilename . ', '
                                        . 'UserLevel: ' . $currentUserLevelId . ', '
                                        . 'FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                                        . 'Origin: ' . $origin . ' '
                                        . 'LoggedInUserId: ' . $fileOwnerUserId);

                                $groupCountry = $db->getRow("SELECT id, group_id "
                                        . "FROM plugin_reward_ppd_group_country "
                                        . "WHERE country_code = " . $db->quote($country) . " "
                                        . "LIMIT 1");
                                if ($groupCountry) {
                                    $countryGroupId = $groupCountry['group_id'];

                                    // log
                                    LogHelper::info('Found country group id: ' . $countryGroupId . '. '
                                            . 'FileId: #' . $file->id . ', '
                                            . 'Name: ' . $file->originalFilename . ', '
                                            . 'UserLevel: ' . $currentUserLevelId . ', '
                                            . 'FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                                            . 'Origin: ' . $origin . ' '
                                            . 'LoggedInUserId: ' . $fileOwnerUserId);

                                    // lookup reward amount
                                    $rewardAmount = $db->getValue('SELECT plugin_reward_ppd_group_rate.payout_rate '
                                            . 'FROM plugin_reward_ppd_group_rate '
                                            . 'LEFT JOIN plugin_reward_ppd_range ON plugin_reward_ppd_group_rate.range_id = plugin_reward_ppd_range.id '
                                            . 'WHERE plugin_reward_ppd_range.from_filesize <= ' . $db->escape($file->fileSize) . ' '
                                            . 'AND plugin_reward_ppd_range.to_filesize > ' . $db->escape($file->fileSize) . ' '
                                            . 'AND plugin_reward_ppd_group_rate.group_id=' . (int) $countryGroupId . ' '
                                            . 'LIMIT 1');
                                    if (($rewardAmount === false) || (strlen($rewardAmount) == 0)) {
                                        // try upper end
                                        $rewardAmount = $db->getValue('SELECT plugin_reward_ppd_group_rate.payout_rate '
                                                . 'FROM plugin_reward_ppd_group_rate '
                                                . 'LEFT JOIN plugin_reward_ppd_range ON plugin_reward_ppd_group_rate.range_id = plugin_reward_ppd_range.id '
                                                . 'WHERE plugin_reward_ppd_range.from_filesize <= ' . $db->escape($file->fileSize) . ' '
                                                . 'AND plugin_reward_ppd_range.to_filesize IS NULL '
                                                . 'AND plugin_reward_ppd_group_rate.group_id=' . (int) $countryGroupId . ' '
                                                . 'LIMIT 1');
                                        if (($rewardAmount !== false) || (strlen($rewardAmount) > 0)) {
                                            // log
                                            LogHelper::info('Failed finding reward amount based on country '
                                                    . 'group and filesize boundaries but found at upper end: '
                                                    . 'CountryGroupId: ' . $countryGroupId . '. Reward: ' . $rewardAmount . '. '
                                                    . 'FileId: #' . $file->id . ', Name: ' . $file->originalFilename . ', '
                                                    . 'UserLevel: ' . $currentUserLevelId . ', FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                                                    . 'Origin: ' . $origin . ' '
                                                    . 'LoggedInUserId: ' . $fileOwnerUserId);
                                        }
                                    } else {
                                        // log
                                        LogHelper::info('Found reward amount based on country group id '
                                                . 'and filesize boundaries. Filesize: ' . $file->fileSize . '. '
                                                . 'CountryGroupId: ' . $countryGroupId . '. Reward: ' . $rewardAmount . '. '
                                                . 'FileId: #' . $file->id . ', Name: ' . $file->originalFilename . ', '
                                                . 'UserLevel: ' . $currentUserLevelId . ', FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                                                . 'Origin: ' . $origin . ' '
                                                . 'LoggedInUserId: ' . $fileOwnerUserId);
                                    }
                                }

                                if (($rewardAmount === false) || (strlen($rewardAmount) == 0)) {
                                    // log
                                    LogHelper::info('Payment group not found, using highest group id and '
                                            . 'rate for filesize range. Country: ' . $country . '. '
                                            . 'CountryGroupId: ' . $countryGroupId . '. '
                                            . 'Filesize: ' . $file->fileSize . '. '
                                            . 'ileId: #' . $file->id . ', Name: ' . $file->originalFilename . ', '
                                            . 'UserLevel: ' . $currentUserLevelId . ', FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                                            . 'Origin: ' . $origin . ' '
                                            . 'LoggedInUserId: ' . $fileOwnerUserId);

                                    // get fall back group
                                    $countryGroupId = $db->getValue('SELECT id '
                                            . 'FROM plugin_reward_ppd_group '
                                            . 'ORDER BY id DESC '
                                            . 'LIMIT 1');

                                    // lookup reward amount
                                    $rewardAmount = $db->getValue('SELECT plugin_reward_ppd_group_rate.payout_rate '
                                            . 'FROM plugin_reward_ppd_group_rate '
                                            . 'LEFT JOIN plugin_reward_ppd_range ON plugin_reward_ppd_group_rate.range_id = plugin_reward_ppd_range.id '
                                            . 'WHERE plugin_reward_ppd_range.from_filesize <= ' . $db->escape($file->fileSize) . ' '
                                            . 'AND plugin_reward_ppd_range.to_filesize > ' . $db->escape($file->fileSize) . ' '
                                            . 'AND plugin_reward_ppd_group_rate.group_id=' . (int) $countryGroupId . ' '
                                            . 'LIMIT 1');
                                    if (($rewardAmount === false) || (strlen($rewardAmount) == 0)) {
                                        // try upper end
                                        $rewardAmount = $db->getValue('SELECT plugin_reward_ppd_group_rate.payout_rate '
                                                . 'FROM plugin_reward_ppd_group_rate '
                                                . 'LEFT JOIN plugin_reward_ppd_range ON plugin_reward_ppd_group_rate.range_id = plugin_reward_ppd_range.id '
                                                . 'WHERE plugin_reward_ppd_range.from_filesize <= ' . $db->escape($file->fileSize) . ' '
                                                . 'AND plugin_reward_ppd_range.to_filesize IS NULL '
                                                . 'AND plugin_reward_ppd_group_rate.group_id=' . (int) $countryGroupId . ' '
                                                . 'LIMIT 1');
                                        if (($rewardAmount !== false) || (strlen($rewardAmount) > 0)) {
                                            // log
                                            LogHelper::info('Failed finding reward amount based on \'other\' '
                                                    . 'country group and filesize boundaries but found at '
                                                    . 'upper end: CountryGroupId: ' . $countryGroupId . '. '
                                                    . 'Reward: ' . $rewardAmount . '. FileId: #' . $file->id . ', '
                                                    . 'Name: ' . $file->originalFilename . ', '
                                                    . 'UserLevel: ' . $currentUserLevelId . ', FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                                                    . 'Origin: ' . $origin . ' '
                                                    . 'LoggedInUserId: ' . $fileOwnerUserId);
                                        }
                                    } else {
                                        // log
                                        LogHelper::info('Found reward amount based on \'other\' country '
                                                . 'group and filesize boundaries. Filesize: ' . $file->fileSize . '. '
                                                . 'CountryGroupId: ' . $countryGroupId . '. '
                                                . 'Reward: ' . $rewardAmount . '. FileId: #' . $file->id . ', '
                                                . 'Name: ' . $file->originalFilename . ', '
                                                . 'UserLevel: ' . $currentUserLevelId . ', FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                                                . 'Origin: ' . $origin . ' '
                                                . 'LoggedInUserId: ' . $fileOwnerUserId);
                                    }
                                }

                                if (($rewardAmount === false) || (strlen($rewardAmount) == 0)) {
                                    // log
                                    LogHelper::info('Failed fallback, unable to find any rate. '
                                            . 'CountryGroupId: ' . $countryGroupId . '. '
                                            . 'Reward: ' . $rewardAmount . '. FileId: #' . $file->id . ', '
                                            . 'Name: ' . $file->originalFilename . ', '
                                            . 'UserLevel: ' . $currentUserLevelId . ', FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                                            . 'Origin: ' . $origin . ' '
                                            . 'LoggedInUserId: ' . $fileOwnerUserId);
                                }

                                // break download $rewardAmount into thousands
                                $rewardAmount = $rewardAmount / 1000;
                                $status = 'pending';

                                // log
                                LogHelper::info('Reward / 1000 = ' . $rewardAmount . '. '
                                        . 'CountryGroupId: ' . $countryGroupId . '. '
                                        . 'FileId: #' . $file->id . ', Name: ' . $file->originalFilename . ', '
                                        . 'UserLevel: ' . $currentUserLevelId . ', FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                                        . 'Origin: ' . $origin . ' '
                                        . 'LoggedInUserId: ' . $fileOwnerUserId);

                                // make sure user is within the limits
                                $dailyIpLimit = floatval($rewardsSettings['ppd_max_by_ip']);
                                if ($dailyIpLimit > 0) {
                                    // get total downloaded already today by this IP
                                    $total = $db->getValue('SELECT SUM(reward_amount) AS total '
                                            . 'FROM plugin_reward_ppd_detail '
                                            . 'WHERE download_ip=' . $db->quote($usersIp) . ' '
                                            . 'AND download_date >= DATE_SUB(NOW(), INTERVAL 1 DAY)');
                                    if ($total >= $dailyIpLimit) {
                                        $rewardAmount = 0;
                                        $status = 'ip_limit_reached';
                                    }
                                }

                                // make sure user is within the limits
                                $dailyFileLimit = floatval($rewardsSettings['ppd_max_by_file']);
                                if ($dailyFileLimit > 0) {
                                    // get total downloaded already today by this IP
                                    $total = $db->getValue('SELECT SUM(reward_amount) AS total '
                                            . 'FROM plugin_reward_ppd_detail '
                                            . 'WHERE file_id=' . $db->escape($file->id) . ' '
                                            . 'AND download_date >= DATE_SUB(NOW(), INTERVAL 1 DAY)');
                                    if ($total >= $dailyFileLimit) {
                                        $rewardAmount = 0;
                                        $status = 'file_limit_reached';
                                    }
                                }

                                // make sure user is within the limits
                                $dailyUserLimit = floatval($rewardsSettings['ppd_max_by_user']);
                                if ($dailyUserLimit > 0) {
                                    // get total downloaded already today by this IP
                                    $total = $db->getValue('SELECT SUM(reward_amount) AS total '
                                            . 'FROM plugin_reward_ppd_detail '
                                            . 'WHERE reward_user_id=' . $db->escape($file->userId) . ' '
                                            . 'AND download_date >= DATE_SUB(NOW(), INTERVAL 1 DAY)');
                                    if ($total >= $dailyUserLimit) {
                                        $rewardAmount = 0;
                                        $status = 'user_limit_reached';
                                    }
                                }

                                // log
                                LogHelper::info('Completed checks for limitations. '
                                        . 'Status: ' . $status . ' RewardAmount: ' . $rewardAmount . '. '
                                        . $countryGroupId . '. FileId: #' . $file->id . ', '
                                        . 'Name: ' . $file->originalFilename . ', '
                                        . 'UserLevel: ' . $currentUserLevelId . ', '
                                        . 'FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                                        . 'Origin: ' . $origin . ' '
                                        . 'LoggedInUserId: ' . $fileOwnerUserId);

                                // add entry
                                $db->query("INSERT INTO plugin_reward_ppd_detail "
                                        . "(reward_user_id, download_ip, file_id, download_country_group_id, download_date, reward_amount, status) "
                                        . "VALUES (:reward_user_id, :download_ip, :file_id, :download_country_group_id, NOW(), :reward_amount, :status)", array(
                                    'reward_user_id' => $file->userId,
                                    'download_ip' => $usersIp,
                                    'file_id' => $file->id,
                                    'download_country_group_id' => $countryGroupId,
                                    'reward_amount' => $rewardAmount,
                                    'status' => $status,
                                ));

                                // log
                                LogHelper::info('PPD logged (' . $status . ' @ ' . $rewardAmount . '. '
                                        . 'Country: ' . $country . '). FileId: #' . $file->id . ', '
                                        . 'Name: ' . $file->originalFilename . ', '
                                        . 'UserLevel: ' . $currentUserLevelId . ', '
                                        . 'FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                                        . 'Origin: ' . $origin . ' '
                                        . 'LoggedInUserId: ' . $fileOwnerUserId);

                                // update stats if we're matching PPD with core site stats
                                if ((int) $rewardsSettings['ppd_match_stats'] == 1) {
                                    StatsHelper::track($file, 'plugin_rewards');
                                }
                            }
                        }
                    }
                }
            } else {
                // log
                LogHelper::info('PPD NOT logged as file owned by a user outside of the '
                        . 'PPD scheme (i.e. free) (' . $status . ' @ ' . $rewardAmount . '. '
                        . 'Country: ' . $country . '). FileId: #' . $file->id . ', '
                        . 'Name: ' . $file->originalFilename . ', FileOwnerLevelId: ' . $fileOwnerLevelId . ', '
                        . 'UserLevel: ' . $currentUserLevelId . ', '
                        . 'Origin: ' . $origin . ', FileUserId: ' . $file->userId . ', '
                        . 'LoggedInUserId: ' . $fileOwnerUserId);
            }
        }

        // return false to hooks controller continues onto the next
        return false;
    }

    public function postUpgradePaymentIpn($params = array()) {
        // load reward details
        $folderName = 'rewards';
        $rewardsConfig = PluginHelper::pluginSpecificConfiguration($folderName);
        $rewardsSettings = json_decode($rewardsConfig['data']['plugin_settings'], true);
        $pluginObj = PluginHelper::getInstance($folderName);

        // make sure PPS is enabled
        if ((int) $rewardsSettings['pps_enabled'] === 1) {
            // available params
            $order = null;
            if (isset($params['order'])) {
                $order = $params['order'];
            }

            // found order so log PPS
            if ($order) {
                // by default use the upgrade_user_id for the reward
                $rewardUserId = $order->upgrade_user_id;

                // if we've a affiliate cookie set, use this
                $cookieUserId = $pluginObj->getAffiliateUser();
                if ((int) $cookieUserId > 0) {
                    $rewardUserId = (int) $cookieUserId;
                }

                // if we know the original user, log the PPS reward
                if ((int) $rewardUserId) {
                    // add reward entry
                    $pluginReward = PluginReward::create();
                    $pluginReward->reward_user_id = $rewardUserId;
                    $pluginReward->premium_order_id = $order->id;
                    $pluginReward->reward_percent = (int) $rewardsSettings['user_percentage'];
                    $pluginReward->reward_amount = number_format(($order->amount / 100) * (int) $rewardsSettings['user_percentage'], 2);
                    $pluginReward->reward_date = date("Y-m-d H:i:s", time());
                    $pluginReward->status = 'pending';
                    $pluginReward->save();

                    // remove any affiliate cookie to tidy things up
                    $pluginObj->removeAffiliateCookie();
                }
            }
        }

        // return false to hooks controller continues onto the next
        return false;
    }

    public function postFilePreview($params = array()) {
        // load reward details
        $folderName = 'rewards';
        $rewardsConfig = PluginHelper::pluginSpecificConfiguration($folderName);
        $rewardsSettings = json_decode($rewardsConfig['data']['plugin_settings'], true);

        // make sure PPD is enabled
        if ((int) $rewardsSettings['ppd_enabled'] === 1) {
            // make sure we should log inline/views
            if ((int) $rewardsSettings['ppd_count_views'] === 1) {
                // get current user and params
                $Auth = $this->getAuth();
                $file = $params['file'];

                // call existing PPD logging
                $userPackageId = $Auth->package_id;
                PluginHelper::callHook('fileDownloadComplete', array(
                    'origin' => 'postFilePreview',
                    'forceDownload' => false,
                    'fileOwnerUserId' => $Auth->id,
                    'userLevelId' => UserHelper::getLevelIdFromPackageId($userPackageId),
                    'file' => $file,
                ));
            }
        }

        // return false to hooks controller continues onto the next
        return false;
    }

    public function preStatsHelperTrack($params = null) {
        /*
         * available params
         * 
         * $params['actioned'];
         * $params['file'];
         * $params['source'];
         * */

        $file = $params['file'];
        $source = $params['source'];

        // get current user
        $Auth = $this->getAuth();

        // only block on 'core' sources
        if ($source === 'core') {
            // load reward details
            $folderName = 'rewards';
            $rewardsConfig = PluginHelper::pluginSpecificConfiguration($folderName);
            $rewardsSettings = json_decode($rewardsConfig['data']['plugin_settings'], true);

            // make sure PPD is enabled and ppd_match_stats is set
            if ((int) $rewardsSettings['ppd_enabled'] == 1 && (int) $rewardsSettings['ppd_match_stats'] == 1) {
                // set actioned so the stats helper is not called
                $params['actioned'] = true;

                return $params;
            }
        }

        return false;
    }

}
