<?php

namespace Plugins\rewards\Controllers\Admin;

use App\Core\Database;
use App\Controllers\Admin\PluginController AS CorePluginController;
use App\Helpers\AdminHelper;
use App\Helpers\CoreHelper;
use App\Helpers\FileHelper;
use App\Helpers\FileServerHelper;
use App\Helpers\PluginHelper;
use App\Helpers\LogHelper;
use App\Helpers\TranslateHelper;
use App\Helpers\ValidationHelper;
use App\Models\Plugin;
use Plugins\Rewards\Models\PluginRewardPpdGroup;
use Plugins\Rewards\Models\PluginRewardPpdGroupCountry;
use Plugins\Rewards\Models\PluginRewardPpdGroupRate;

class PluginController extends CorePluginController
{

    public function pluginSettings() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // load plugin details
        $folderName = 'rewards';
        $plugin = Plugin::loadOneByClause('folder_name = :folder_name', array(
                    'folder_name' => $folderName,
        ));

        if (!$plugin) {
            return $this->redirect(ADMIN_WEB_ROOT . '/plugin_manage?error=' . urlencode('There was a problem loading the plugin details.'));
        }

        // prepare payment days
        $days = array();
        for ($i = 1; $i <= 28; $i++) {
            $date = strtotime(date('Y-m-') . str_pad($i, 2, "0", STR_PAD_LEFT) . ' 00:00:00');
            $days[$i] = date('jS', $date);
        }

        // get local server id
        $serverId = FileHelper::getDefaultLocalServerId();

        // pre-load countries
        $countries = $db->getRows('SELECT iso_alpha2, name '
                . 'FROM plugin_reward_country_list '
                . 'ORDER BY name');

        // pre-load ppd payout groups
        $payout_groups = $db->getRows('SELECT id, group_label, payout_rate '
                . 'FROM plugin_reward_ppd_group '
                . 'ORDER BY id');

        // if upgrade populate new rate structure
        if ($payout_groups) {
            foreach ($payout_groups AS $payout_group) {
                if ($payout_group['payout_rate'] != 0) {
                    $db->query('UPDATE plugin_reward_ppd_group_rate '
                            . 'SET payout_rate = ' . $db->quote($payout_group['payout_rate']) . ' '
                            . 'WHERE payout_rate = 0 '
                            . 'AND group_id = ' . (int) $payout_group['id']);
                    $db->query('UPDATE plugin_reward_ppd_group '
                            . 'SET payout_rate = 0 '
                            . 'WHERE id = ' . (int) $payout_group['id'] . ' LIMIT 1');
                }
            }
        }

        // pre-load ppd user types
        $user_types = $db->getRows('SELECT id, label '
                . 'FROM user_level '
                . 'WHERE level_type = \'free\' OR '
                . 'level_type = \'paid\' '
                . 'ORDER BY id');
        $user_types_inc_non = $db->getRows('SELECT id, label '
                . 'FROM user_level '
                . 'WHERE level_type = \'nonuser\' OR '
                . 'level_type = \'free\' OR '
                . 'level_type = \'paid\' '
                . 'ORDER BY id');

        // load ranges
        $payout_ranges = $db->getRows('SELECT * '
                . 'FROM plugin_reward_ppd_range '
                . 'ORDER BY from_filesize');

        // media percentage options
        $percentages = range(1, 99);
        array_unshift($percentages, "- system default (normally 100%) -");

        // default params
        $plugin_enabled = (int) $plugin->plugin_enabled;
        $payment_lead_time = 60;
        $payment_threshold = 50;
        $payment_date = '05';
        $ppd_enabled = 0;
        $ppd_group_id = array();
        $ppd_min_file_size = 10;
        $pps_enabled = 0;
        $user_percentage = 30;
        $ppd_max_by_ip = '';
        $ppd_max_by_file = '';
        $ppd_max_by_user = '';
        $ppd_user_type = array();
        $ppd_media_percentage = 0;
        $pps_cookie_lifetime_days = 7;
        $use_download_complete_callback_cloudflare = 0;
        foreach ($user_types AS $user_type) {
            $ppd_user_type[] = $user_type['id'];
        }
        $use_download_complete_callback = 0;
        $ppd_count_views = 0;
        $ppd_match_stats = 0;
        $ppd_user_type_log_ppd = array();
        foreach ($user_types_inc_non AS $user_type_inc_non) {
            $ppd_user_type_log_ppd[] = $user_type_inc_non['id'];
        }

        // load existing settings
        if (strlen($plugin->plugin_settings)) {
            $plugin_settings = json_decode($plugin->plugin_settings, true);
            if ($plugin_settings) {
                // load settings locally
                $payment_lead_time = $plugin_settings['payment_lead_time'];
                $payment_threshold = $plugin_settings['payment_threshold'];
                $payment_date = $plugin_settings['payment_date'];
                $ppd_enabled = (int) $plugin_settings['ppd_enabled'];
                if ($ppd_enabled == 1) {
                    $ppd_min_file_size = (int) $plugin_settings['ppd_min_file_size'];
                    $ppd_max_by_ip = floatval($plugin_settings['ppd_max_by_ip']);
                    if ($ppd_max_by_ip == 0) {
                        $ppd_max_by_ip = '';
                    }
                    $ppd_max_by_file = floatval($plugin_settings['ppd_max_by_file']);
                    if ($ppd_max_by_file == 0) {
                        $ppd_max_by_file = '';
                    }
                    $ppd_max_by_user = floatval($plugin_settings['ppd_max_by_user']);
                    if ($ppd_max_by_user == 0) {
                        $ppd_max_by_user = '';
                    }
                    $ppd_media_percentage = (int) $plugin_settings['ppd_media_percentage'];
                    $ppd_count_views = (int) $plugin_settings['ppd_count_views'];
                }
                $pps_enabled = (int) $plugin_settings['pps_enabled'];
                if ($pps_enabled == 1) {
                    $user_percentage = $plugin_settings['user_percentage'];
                }
                $use_download_complete_callback = (int) $plugin_settings['use_download_complete_callback'];
                if (isset($plugin_settings['ppd_user_type'])) {
                    $ppd_user_type = $plugin_settings['ppd_user_type'];
                }
                if (isset($plugin_settings['pps_cookie_lifetime_days'])) {
                    $pps_cookie_lifetime_days = (int) $plugin_settings['pps_cookie_lifetime_days'];
                }
                $use_download_complete_callback_cloudflare = 0;
                if (isset($plugin_settings['ppd_match_stats'])) {
                    $ppd_match_stats = (int) $plugin_settings['ppd_match_stats'];
                }
                if (isset($plugin_settings['ppd_user_type_log_ppd'])) {
                    $ppd_user_type_log_ppd = $plugin_settings['ppd_user_type_log_ppd'];
                }
            }
        }

        // load outpayment types
        $paymentMethods = $db->getRows('SELECT * FROM plugin_reward_outpayment_method ORDER BY label');

        // handle page submissions
        if ($request->request->has('submitted')) {
            // get variables
            $plugin_enabled = (int) $request->request->get('plugin_enabled');
            $plugin_enabled = $plugin_enabled != 1 ? 0 : 1;
            $payment_lead_time = (int) $_REQUEST['payment_lead_time'];
            $payment_lead_time = $payment_lead_time > 365 ? 365 : $payment_lead_time;
            $payment_threshold = (float) str_replace(array(SITE_CONFIG_COST_CURRENCY_SYMBOL, '$', '£'), '', $_REQUEST['payment_threshold']);
            $payment_threshold = $payment_threshold < 0 ? 0 : $payment_threshold;
            $payment_date = $_REQUEST['payment_date'];
            $ppd_enabled = (int) $_REQUEST['ppd_enabled'];
            if ($ppd_enabled == 1) {
                $ppd_min_file_size = (int) $_REQUEST['ppd_min_file_size'];
                $ppd_max_by_ip = floatval($_REQUEST['ppd_max_by_ip']);
                $ppd_max_by_file = floatval($_REQUEST['ppd_max_by_file']);
                $ppd_max_by_user = floatval($_REQUEST['ppd_max_by_user']);
                if (isset($_REQUEST['ppd_group_id'])) {
                    $ppd_group_id = $_REQUEST['ppd_group_id'];
                }
                $ppd_user_type = $_REQUEST['ppd_user_type'];
                $ppd_media_percentage = (int) $_REQUEST['ppd_media_percentage'];
                $ppd_count_views = (int) $_REQUEST['ppd_count_views'];
                $ppd_match_stats = (int) $_REQUEST['ppd_match_stats'];
                $ppd_user_type_log_ppd = $_REQUEST['ppd_user_type_log_ppd'];
            }

            $pps_enabled = (int) $_REQUEST['pps_enabled'];
            if ($pps_enabled == 1) {
                $user_percentage = (int) $_REQUEST['user_percentage'];
                $user_percentage = $user_percentage > 100 ? 100 : $user_percentage;
                $pps_cookie_lifetime_days = (int) $_REQUEST['pps_cookie_lifetime_days'];
            }
            $use_download_complete_callback = (int) $_REQUEST['use_download_complete_callback'];
            $use_download_complete_callback_cloudflare = (int) $_REQUEST['use_download_complete_callback_cloudflare'];

            // validate submission
            // validate submission
            if (_CONFIG_DEMO_MODE == true) {
                AdminHelper::setError(AdminHelper::t("no_changes_in_demo_mode"));
            }
            else {
                // validate ppd groups, payouts and countries
                $currentRow = 1;
                $oneBlank = null;
                foreach ($payout_groups AS $payout_group) {
                    $group_id = $payout_group['id'];
                    if (isset($_REQUEST['group_name_id_' . $group_id])) {
                        // pickup variables
                        $group_name = $_REQUEST['group_name_id_' . $group_id];
                        $selected_countries = $_REQUEST['selected_countries_id_' . $group_id];

                        if (strlen($group_name) == 0) {
                            AdminHelper::setError(TranslateHelper::getTranslation('rewards_plugin_error_please_enter_group_name_for_row', 'Please enter a group name for row [[[ROW_NUMBER]]]', 1, array('ROW_NUMBER' => $currentRow)));
                        }
                        elseif (!is_array($selected_countries) || count($selected_countries) == 0) {
                            // allow for 1 row with blank coutries for 'default' group.
                            if ($oneBlank == null) {
                                $oneBlank = TranslateHelper::getTranslation('rewards_plugin_error_please_select_at_least_1_country_for_row', 'Please select at least 1 country for row [[[ROW_NUMBER]]]', 1, array('ROW_NUMBER' => $currentRow));
                            }
                            else {
                                if ($oneBlank != -1) {
                                    AdminHelper::setError($oneBlank);
                                    $oneBlank = -1;
                                }
                                AdminHelper::setError(TranslateHelper::getTranslation('rewards_plugin_error_please_select_at_least_1_country_for_row', 'Please select at least 1 country for row [[[ROW_NUMBER]]]', 1, array('ROW_NUMBER' => $currentRow)));
                            }
                        }
                    }

                    $currentRow++;
                }
            }

            // more validation
            if (AdminHelper::isErrors() == false) {
                if ($ppd_enabled == 1) {
                    if (!is_array($ppd_user_type) || count($ppd_user_type) == 0) {
                        AdminHelper::setError(AdminHelper::t("plugin_rewards_admin_please_choose_at_least_1_user_type", "Please choose at least 1 user type to apply PPD logging to."));
                    }
                }
            }

            // update the settings
            if (AdminHelper::isErrors() == false) {
                // compile new settings
                $settingsArr = array();
                $settingsArr['payment_lead_time'] = $payment_lead_time;
                $settingsArr['payment_threshold'] = number_format($payment_threshold, 2);
                $settingsArr['payment_date'] = $payment_date;
                $settingsArr['ppd_enabled'] = (int) $ppd_enabled;
                if ($ppd_enabled == 1) {
                    $settingsArr['ppd_min_file_size'] = (int) $ppd_min_file_size;
                    $settingsArr['ppd_max_by_ip'] = floatval($ppd_max_by_ip);
                    $settingsArr['ppd_max_by_file'] = floatval($ppd_max_by_file);
                    $settingsArr['ppd_max_by_user'] = floatval($ppd_max_by_user);
                    $settingsArr['ppd_user_type'] = $ppd_user_type;
                    $settingsArr['ppd_media_percentage'] = (int) $ppd_media_percentage;
                    $settingsArr['ppd_count_views'] = (int) $ppd_count_views;
                    $settingsArr['ppd_match_stats'] = (int)$ppd_match_stats;
                    $settingsArr['ppd_user_type_log_ppd'] = $ppd_user_type_log_ppd;
                }
                $settingsArr['pps_enabled'] = (int) $pps_enabled;
                if ($pps_enabled == 1) {
                    $settingsArr['user_percentage'] = $user_percentage;
                    if ((int) $pps_cookie_lifetime_days == 0) {
                        $pps_cookie_lifetime_days = 7;
                    }
                    $settingsArr['pps_cookie_lifetime_days'] = $pps_cookie_lifetime_days;
                }
                $settingsArr['use_download_complete_callback'] = $use_download_complete_callback;
                $settingsArr['use_download_complete_callback_cloudflare'] = $use_download_complete_callback_cloudflare;

                if ($ppd_enabled == 1) {
                    foreach ($payout_groups AS $payout_group) {
                        $group_id = $payout_group['id'];
                        if (isset($_REQUEST['group_name_id_' . $group_id])) {
                            // pickup variables
                            $group_name = $_REQUEST['group_name_id_' . $group_id];
                            $selected_countries = $_REQUEST['selected_countries_id_' . $group_id];

                            // update group info
                            $pluginRewardPpdGroup = PluginRewardPpdGroup::loadOneById($group_id);
                            $pluginRewardPpdGroup->group_label = $group_name;
                            $pluginRewardPpdGroup->save();

                            // set group countries
                            $db->query('DELETE '
                                    . 'FROM plugin_reward_ppd_group_country '
                                    . 'WHERE group_id = ' . (int) $group_id);
                            if (is_array($selected_countries) && count($selected_countries)) {
                                foreach ($selected_countries AS $selected_country) {
                                    $pluginRewardPpdGroupCountry = PluginRewardPpdGroupCountry::create();
                                    $pluginRewardPpdGroupCountry->group_id = (int) $group_id;
                                    $pluginRewardPpdGroupCountry->country_code = $selected_country;
                                    $pluginRewardPpdGroupCountry->save();
                                }
                            }

                            // update rates
                            foreach ($payout_ranges AS $k => $payout_range) {
                                // get rate
                                $payout_rate = $_REQUEST['payout_rate_id_' . $payout_range['id'] . '_group_id_' . $group_id];

                                // load group rate record
                                $groupRate = $db->getValue('SELECT id '
                                        . 'FROM plugin_reward_ppd_group_rate '
                                        . 'WHERE group_id = ' . (int) $group_id . ' '
                                        . 'AND range_id = ' . $payout_range['id'] . ' '
                                        . 'LIMIT 1');
                                if (!$groupRate) {
                                    // insert
                                    $pluginRewardPpdGroupRate = PluginRewardPpdGroupRate::create();
                                }
                                else {
                                    // update
                                    $pluginRewardPpdGroupRate = PluginRewardPpdGroupRate::loadOneById($groupRate);
                                }

                                $pluginRewardPpdGroupRate->group_id = $group_id;
                                $pluginRewardPpdGroupRate->range_id = $payout_range['id'];
                                $pluginRewardPpdGroupRate->payout_rate = $payout_rate;
                                $pluginRewardPpdGroupRate->save();
                            }
                        }
                    }
                }

                // update payment active methods
                $db->query('UPDATE plugin_reward_outpayment_method '
                        . 'SET is_enabled = 0');
                foreach ($_REQUEST['withdrawal_methods'] AS $withdrawal_method_id) {
                    $db->query('UPDATE plugin_reward_outpayment_method '
                            . 'SET is_enabled = 1 '
                            . 'WHERE id = ' . (int) $withdrawal_method_id . ' '
                            . 'LIMIT 1');
                }

                // update the plugin settings
                $plugin->plugin_enabled = $plugin_enabled;
                $plugin->plugin_settings = json_encode($settingsArr);
                $plugin->save();

                // reload plugin cache
                PluginHelper::loadPluginConfigurationFiles(true);
                AdminHelper::setSuccess('Plugin settings updated.');
            }
        }

        // append other info to payout_groups
        if (count($payout_groups)) {
            foreach ($payout_groups AS $k => $payout_group) {
                // load existing countries
                $group_countries = $db->getRows('SELECT country_code '
                        . 'FROM plugin_reward_ppd_group_country '
                        . 'WHERE group_id = ' . (int) $payout_group['id']);
                $group_country_arr = array();
                if ($group_countries) {
                    foreach ($group_countries AS $group_country) {
                        $group_country_arr[] = $group_country['country_code'];
                    }
                }

                $group_id = $payout_group['id'];
                $group_name = $payout_group['group_label'];
                $payout_rate = $payout_group['payout_rate'];

                // pickup existing submit
                if (count($ppd_group_id)) {
                    $group_name = $_REQUEST['group_name_id_' . $group_id];
                    $payout_rate = $_REQUEST['payout_rate_id_' . $group_id];
                    $group_country_arr = $_REQUEST['selected_countries_id_' . $group_id];
                }

                $payout_groups[$k]['_group_name'] = $group_name;
                $payout_groups[$k]['_payout_rate'] = $payout_rate;
                $payout_groups[$k]['_group_country_arr'] = $group_country_arr;

                $payout_groups[$k]['_payout_ranges'] = $payout_ranges;
                foreach ($payout_groups[$k]['_payout_ranges'] AS $i => $payout_range) {
                    $payoutRate = $db->getValue('SELECT payout_rate '
                            . 'FROM plugin_reward_ppd_group_rate '
                            . 'WHERE group_id = ' . (int) $group_id . ' '
                            . 'AND range_id = ' . $payout_range['id'] . ' '
                            . 'LIMIT 1');
                    if (!$payoutRate) {
                        $payoutRate = 0;
                    }
                    $payout_groups[$k]['_payout_ranges'][$i]['_payout_rate'] = $payoutRate;
                }
            }
        }

        // load template
        return $this->render('admin/plugin_settings.html', array(
                    'pluginName' => $plugin->plugin_name,
                    'yesNoOptions' => array(
                        0 => 'No',
                        1 => 'Yes'),
                    'imagesCountPPDOptions' => array(
                        0 => 'No (Just Downloads)',
                        1 => 'Yes (Downloads & Views)',
                    ),
                    'plugin_enabled' => $plugin_enabled,
                    'days' => $days,
                    'fileServer' => $fileServer,
                    'nginxAdvancedDownloadsEnabled' => FileServerHelper::nginxXAccelRedirectEnabled($serverId),
                    'apacheAdvancedDownloadsEnabled' => FileServerHelper::apacheXSendFileEnabled($serverId),
                    'countries' => $countries,
                    'payout_groups' => $payout_groups,
                    'user_types' => $user_types,
                    'user_types_inc_non' => $user_types_inc_non,
                    'payout_ranges' => $payout_ranges,
                    'percentages' => $percentages,
                    'paymentMethods' => $paymentMethods,
                    'payment_lead_time' => $payment_lead_time,
                    'payment_threshold' => $payment_threshold,
                    'payment_date' => $payment_date,
                    'ppd_enabled' => $ppd_enabled,
                    'ppd_group_id' => $ppd_group_id,
                    'ppd_min_file_size' => $ppd_min_file_size,
                    'pps_enabled' => $pps_enabled,
                    'user_percentage' => $user_percentage,
                    'ppd_max_by_ip' => $ppd_max_by_ip,
                    'ppd_max_by_file' => $ppd_max_by_file,
                    'ppd_max_by_user' => $ppd_max_by_user,
                    'ppd_user_type' => $ppd_user_type,
                    'ppd_media_percentage' => $ppd_media_percentage,
                    'pps_cookie_lifetime_days' => $pps_cookie_lifetime_days,
                    'ppd_match_stats' => $ppd_match_stats,
                    'ppd_user_type_log_ppd' => $ppd_user_type_log_ppd,
                    'use_download_complete_callback_cloudflare' => $use_download_complete_callback_cloudflare,
                    'use_download_complete_callback' => $use_download_complete_callback,
                    'ppd_count_views' => $ppd_count_views,
                    'AdminHelper' => new AdminHelper(),
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function rewardsOverview() {
        // admin restrictions
        $this->restrictAdminAccess();

        // for later
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // get instance
        $folderName = 'rewards';
        $pluginObj = PluginHelper::getInstance($folderName);
        $pluginObj->clearPendingRewards();
        $pluginObj->aggregateRewards();
        $pluginObj->pruneData();

        // load stats
        $totalPPS = $pluginObj->getTotalPPS();
        $totalPPD = $pluginObj->getTotalPPD();
        $totalPendingPayment = $pluginObj->getPendingPaymentTotal();
        $totalPaid = $pluginObj->getPaidTotal();

        // load all users
        $sQL = "SELECT id, username AS selectValue "
                . "FROM users "
                . "WHERE level_id > 0 "
                . "ORDER BY username";
        $userDetails = $db->getRows($sQL);

        $filterByStatus = '';
        if (isset($_REQUEST['filterByStatus'])) {
            $filterByStatus = (int) $_REQUEST['filterByStatus'];
        }

        $filterByUser = null;
        if (isset($_REQUEST['filterByUser'])) {
            $filterByUser = (int) $_REQUEST['filterByUser'];
        }

        // load template
        return $this->render('admin/rewards_overview.html', array(
                    'statusDetails' => $pluginObj->getStatusList(),
                    'totalPPS' => $totalPPS,
                    'totalPPD' => $totalPPD,
                    'totalPendingPayment' => $totalPendingPayment,
                    'totalPaid' => $totalPaid,
                    'userDetails' => $userDetails,
                    'filterByStatus' => $filterByStatus,
                    'filterByUser' => $filterByUser,
                    'pluginObj' => $pluginObj,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function ajaxRewardsOverview() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $folderName = 'rewards';
        $pluginObj = PluginHelper::getInstance($folderName);

        $iDisplayLength = (int) $request->query->get('iDisplayLength');
        $iDisplayStart = (int) $request->query->get('iDisplayStart');
        $sSortDir_0 = ($request->query->has('sSortDir_0') && $request->query->get('sSortDir_0') === 'asc') ? 'asc' : 'desc';
        $filterText = strlen($_REQUEST['filterText']) ? $_REQUEST['filterText'] : false;

        // get sorting columns
        $iSortCol_0 = (int) $request->query->get('iSortCol_0');
        $sColumns = trim($request->query->get('sColumns'));
        $arrCols = explode(",", $sColumns);
        $sortColumnName = $arrCols[$iSortCol_0];
        $sort = 'users.username';
        switch ($sortColumnName) {
            case 'username':
                $sort = "users.username";
                break;
            case 'total_pps':
                $sort = "(SELECT IFNULL(SUM(reward_amount), 0) AS total FROM plugin_reward WHERE reward_user_id = users.id AND status IN ('pending', 'cleared'))";
                break;
            case 'total_ppd':
                $sort = "(SELECT IFNULL(SUM(reward_amount), 0) AS total FROM plugin_reward_ppd_detail WHERE reward_user_id = users.id AND status IN ('pending', 'cleared', 'aggregated'))";
                break;
            case 'overall_total':
                $sort = "((SELECT IFNULL(SUM(reward_amount), 0) AS total FROM plugin_reward WHERE reward_user_id = users.id AND status IN ('pending', 'cleared'))+(SELECT IFNULL(SUM(reward_amount), 0) AS total FROM plugin_reward_ppd_detail WHERE reward_user_id = users.id AND status IN ('pending', 'cleared', 'aggregated')))";
                break;
            case 'total_paid':
                $sort = "(SELECT SUM(amount) AS total FROM plugin_reward_withdraw_request WHERE reward_user_id = users.id AND status='paid')";
                break;
            case 'total_outstanding':
                $sort = "(((SELECT IFNULL(SUM(reward_amount), 0) AS total FROM plugin_reward WHERE reward_user_id = users.id AND status IN ('pending', 'cleared'))+(SELECT IFNULL(SUM(reward_amount), 0) AS total FROM plugin_reward_ppd_detail WHERE reward_user_id = users.id AND status IN ('pending', 'cleared', 'aggregated')))-(SELECT IFNULL(SUM(amount), 0) AS total FROM plugin_reward_withdraw_request WHERE reward_user_id = users.id AND status='paid'))";
                break;
        }

        $sqlClause = "WHERE level_id > 0 ";
        if ($filterText) {
            $filterText = strtolower($db->escape($filterText));
            $sqlClause .= "AND (LOWER(users.username) LIKE '%" . $filterText . "%') ";
        }

        $totalRS = $db->getValue("SELECT COUNT(users.id) AS total "
                . "FROM users " . $sqlClause);
        $sQL = "SELECT users.id AS user_id, users.username, ";
        $sQL .= "(SELECT IFNULL(SUM(reward_amount), 0) AS total FROM plugin_reward WHERE reward_user_id = users.id AND status IN ('pending', 'cleared')) AS total_pps, ";
        $sQL .= "(SELECT IFNULL(SUM(reward_amount), 0) AS total FROM plugin_reward_ppd_detail WHERE reward_user_id = users.id AND status IN ('pending', 'cleared', 'aggregated')) AS total_ppd, ";
        $sQL .= "(SELECT SUM(amount) AS total FROM plugin_reward_withdraw_request WHERE reward_user_id = users.id AND status='paid') AS total_paid ";
        $sQL .= "FROM users " . $sqlClause . " ORDER BY " . $sort . " " . $db->escape($sSortDir_0) . " LIMIT " . $iDisplayStart . ", " . $iDisplayLength;
        $limitedRS = $db->getRows($sQL);

        $data = array();
        if (count($limitedRS) > 0) {
            foreach ($limitedRS AS $reward) {
                $lRow = array();
                $lRow[] = '<img src="' . PLUGIN_WEB_ROOT . '/rewards/assets/img/icons/16px.png" width="16" height="16" title="rewards" alt="rewards"/>';
                $lRow[] = $reward['username'];
                $lRow[] = SITE_CONFIG_COST_CURRENCY_SYMBOL . $pluginObj->formatAmount($reward['total_pps']);
                $lRow[] = SITE_CONFIG_COST_CURRENCY_SYMBOL . $pluginObj->formatAmount($reward['total_ppd']);
                $lRow[] = SITE_CONFIG_COST_CURRENCY_SYMBOL . $pluginObj->formatAmount($reward['total_pps'] + $reward['total_ppd']);
                $lRow[] = SITE_CONFIG_COST_CURRENCY_SYMBOL . $pluginObj->formatAmount($reward['total_paid']);
                $lRow[] = SITE_CONFIG_COST_CURRENCY_SYMBOL . $pluginObj->formatAmount(($reward['total_pps'] + $reward['total_ppd']) - $reward['total_paid']);

                $links = array();
                $links[] = '<a href="' . ADMIN_WEB_ROOT . '/user_edit/' . (int) $reward['user_id'] . '">user</a>';
                if ($reward['total_pps'] > 0) {
                    $links[] = '<a href="rewards_detailed_referral?filterByUser=' . (int) $reward['user_id'] . '">pps</a>';
                }
                if ($reward['total_ppd'] > 0) {
                    $links[] = '<a href="rewards_detailed_download?filterByUser=' . (int) $reward['user_id'] . '">ppd</a>';
                }
                if (($reward['total_pps'] + $reward['total_ppd']) > 0) {
                    $links[] = '<a href="rewards_payment_request?filterByUser=' . (int) $reward['user_id'] . '">payments</a>';
                }
                $lRow[] = implode(" | ", $links);

                $data[] = $lRow;
            }
        }

        $resultArr = array();
        $resultArr["sEcho"] = intval($request->query->get('sEcho'));
        $resultArr["iTotalRecords"] = (int) $totalRS;
        $resultArr["iTotalDisplayRecords"] = $resultArr["iTotalRecords"];
        $resultArr["aaData"] = $data;

        // output response
        return $this->renderJson($resultArr);
    }

    public function rewardsDetailedReferral() {
        // admin restrictions
        $this->restrictAdminAccess();

        // for later
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // get instance
        $folderName = 'rewards';
        $pluginObj = PluginHelper::getInstance($folderName);
        $pluginObj->clearPendingRewards();
        $pluginObj->aggregateRewards();

        // load all users
        $sQL = "SELECT id, username AS selectValue "
                . "FROM users "
                . "WHERE level_id > 0 "
                . "ORDER BY username";
        $userDetails = $db->getRows($sQL);

        $filterByStatus = '';
        if (isset($_REQUEST['filterByStatus'])) {
            $filterByStatus = (int) $_REQUEST['filterByStatus'];
        }

        $filterByUser = null;
        if (isset($_REQUEST['filterByUser'])) {
            $filterByUser = (int) $_REQUEST['filterByUser'];
        }

        // load template
        return $this->render('admin/rewards_detailed_referral.html', array(
                    'statusDetails' => $pluginObj->getStatusList(),
                    'userDetails' => $userDetails,
                    'filterByStatus' => $filterByStatus,
                    'filterByUser' => $filterByUser,
                    'pluginObj' => $pluginObj,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function ajaxRewardsDetailedReferral() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $folderName = 'rewards';
        $pluginObj = PluginHelper::getInstance($folderName);

        $iDisplayLength = (int) $request->query->get('iDisplayLength');
        $iDisplayStart = (int) $request->query->get('iDisplayStart');
        $sSortDir_0 = ($request->query->has('sSortDir_0') && $request->query->get('sSortDir_0') === 'asc') ? 'asc' : 'desc';
        $filterByUser = strlen($_REQUEST['filterByUser']) ? (int) $_REQUEST['filterByUser'] : false;
        $filterByStatus = strlen($_REQUEST['filterByStatus']) ? $_REQUEST['filterByStatus'] : '';

        // get sorting columns
        $iSortCol_0 = (int) $request->query->get('iSortCol_0');
        $sColumns = trim($request->query->get('sColumns'));
        $arrCols = explode(",", $sColumns);
        $sortColumnName = $arrCols[$iSortCol_0];
        $sort = 'reward_date';
        switch ($sortColumnName) {
            case 'reward_date':
                $sort = 'reward_date';
                break;
            case 'user':
                $sort = 'users.username';
                break;
            case 'reward_amount':
                $sort = 'reward_amount';
                break;
            case 'original_order_number':
                $sort = 'premium_order_id';
                break;
            case 'status':
                $sort = 'status';
                break;
        }

        $sqlClause = "WHERE 1=1 ";
        if ($filterByUser) {
            $sqlClause .= " AND plugin_reward.reward_user_id = " . (int) $filterByUser;
        }

        if ($filterByStatus) {
            $sqlClause .= " AND plugin_reward.status = " . $db->quote($filterByStatus);
        }

        $totalRS = $db->getValue("SELECT COUNT(plugin_reward.id) AS total "
                . "FROM plugin_reward "
                . "LEFT JOIN users ON plugin_reward.reward_user_id = users.id "
                . $sqlClause);
        $limitedRS = $db->getRows("SELECT plugin_reward.*, users.username, "
                . "premium_order.upgrade_file_id, premium_order.upgrade_user_id "
                . "FROM plugin_reward "
                . "LEFT JOIN users ON plugin_reward.reward_user_id = users.id "
                . "LEFT JOIN premium_order ON plugin_reward.premium_order_id = premium_order.id "
                . $sqlClause . " "
                . "ORDER BY " . $sort . " " . $db->escape($sSortDir_0) . " "
                . "LIMIT " . $iDisplayStart . ", " . $iDisplayLength);

        $data = array();
        if (count($limitedRS) > 0) {
            foreach ($limitedRS AS $reward) {
                $lRow = array();
                $lRow[] = '<img src="' . PLUGIN_WEB_ROOT . '/rewards/assets/img/icons/16px.png" width="16" height="16" title="rewards" alt="rewards"/>';
                $lRow[] = CoreHelper::formatDate($reward['reward_date'], SITE_CONFIG_DATE_TIME_FORMAT);

                $rewardType = 'Unknown';
                if ((int) $reward['upgrade_file_id'] > 0) {
                    $rewardType = 'File Download';
                    $fileDetails = $db->getRow('SELECT originalFilename, shortUrl '
                            . 'FROM file '
                            . 'WHERE id=' . (int) $reward['upgrade_file_id'] . ' '
                            . 'LIMIT 1');
                    if ($fileDetails) {
                        $rewardType .= ' (<a href="' . ADMIN_WEB_ROOT . '/file_manage?filterText=' . urlencode(_CONFIG_SITE_FULL_URL . '/' . $fileDetails['shortUrl']) . '">' . $fileDetails['originalFilename'] . '</a>)';
                    }
                }
                else {
                    $rewardType = 'Direct Referral';
                    $rewardType .= ' (<a href="' . ADMIN_WEB_ROOT . '/user_edit/' . $reward['reward_user_id'] . '">' . $reward['username'] . '</a>)';
                }

                $lRow[] = $rewardType;
                $lRow[] = $reward['username'];
                $lRow[] = SITE_CONFIG_COST_CURRENCY_SYMBOL . $reward['reward_amount'] . ' (' . $reward['reward_percent'] . '%)';
                $lRow[] = '#' . $reward['premium_order_id'];
                $lRow[] = ucwords(str_replace("_", " ", $reward['status']));

                $links = array();
                if ($reward['status'] == 'pending') {
                    $links[] = '<a href="#" onClick="confirmRemoveReward(' . (int) $reward['id'] . '); return false;">cancel</a>';
                }
                $lRow[] = implode(" | ", $links);

                $data[] = $lRow;
            }
        }

        $resultArr = array();
        $resultArr["sEcho"] = intval($request->query->get('sEcho'));
        $resultArr["iTotalRecords"] = (int) $totalRS;
        $resultArr["iTotalDisplayRecords"] = $resultArr["iTotalRecords"];
        $resultArr["aaData"] = $data;

        // output response
        return $this->renderJson($resultArr);
    }

    public function ajaxRewardsDetailedReferralCancel() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        $gRewardId = (int) $_REQUEST['gRewardId'];
        $status = $_REQUEST['cancel_reason'];

        // prepare result
        $resultArr = array();
        $resultArr['error'] = false;
        $resultArr['msg'] = '';

        if (_CONFIG_DEMO_MODE == true) {
            $resultArr['error'] = true;
            $resultArr['msg'] = AdminHelper::t("no_changes_in_demo_mode");
        }
        else {
            $db->query('UPDATE plugin_reward '
                    . 'SET status = :status '
                    . 'WHERE id = :id', array(
                'status' => $status,
                'id' => $gRewardId,
                    )
            );
            if ($db->affectedRows() == 1) {
                $resultArr['error'] = false;
                $resultArr['msg'] = 'Reward cancelled.';
            }
            else {
                $resultArr['error'] = true;
                $resultArr['msg'] = 'Could not cancel the reward.';
            }
        }

        // output response
        return $this->renderJson($resultArr);
    }

    public function rewardsDetailedDownload() {
        // admin restrictions
        $this->restrictAdminAccess();

        // for later
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // get instance
        $folderName = 'rewards';
        $pluginObj = PluginHelper::getInstance($folderName);
        $pluginObj->clearPendingRewards();
        $pluginObj->aggregateRewards();
        $pluginObj->pruneData();

        // load all users
        $sQL = "SELECT id, username AS selectValue "
                . "FROM users "
                . "WHERE level_id > 0 "
                . "ORDER BY username";
        $userDetails = $db->getRows($sQL);

        $filterByStatus = '';
        if (isset($_REQUEST['filterByStatus'])) {
            $filterByStatus = (int) $_REQUEST['filterByStatus'];
        }

        $filterByUser = null;
        if (isset($_REQUEST['filterByUser'])) {
            $filterByUser = (int) $_REQUEST['filterByUser'];
        }

        // load template
        return $this->render('admin/rewards_detailed_download.html', array(
                    'yesNoOptions' => array(
                        0 => 'No',
                        1 => 'Yes'),
                    'statusDetails' => $pluginObj->getStatusList(),
                    'userDetails' => $userDetails,
                    'filterByStatus' => $filterByStatus,
                    'filterByUser' => $filterByUser,
                    'pluginObj' => $pluginObj,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function ajaxRewardsDetailedDownload() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $folderName = 'rewards';
        $pluginObj = PluginHelper::getInstance($folderName);

        $iDisplayLength = (int) $request->query->get('iDisplayLength');
        $iDisplayStart = (int) $request->query->get('iDisplayStart');
        $sSortDir_0 = ($request->query->has('sSortDir_0') && $request->query->get('sSortDir_0') === 'asc') ? 'asc' : 'desc';
        $filterByUser = strlen($_REQUEST['filterByUser']) ? (int) $_REQUEST['filterByUser'] : false;
        $filterByStatus = strlen($_REQUEST['filterByStatus']) ? $_REQUEST['filterByStatus'] : '';
        $filterByGroupData = $_REQUEST['filterByGroupData'] == 'yes' ? 'yes' : 'np';

        // get sorting columns
        $iSortCol_0 = (int) $request->query->get('iSortCol_0');
        $sColumns = trim($request->query->get('sColumns'));
        $arrCols = explode(",", $sColumns);
        $sortColumnName = $arrCols[$iSortCol_0];
        $sort = 'plugin_reward_ppd_detail.download_date';
        switch ($sortColumnName) {
            case 'download_date':
                $sort = 'plugin_reward_ppd_detail.download_date';
                break;
            case 'user':
                $sort = 'users.username';
                break;
            case 'file':
                $sort = 'file.originalFilename';
                break;
            case 'reward_group':
                $sort = 'plugin_reward_ppd_group.group_label';
                break;
            case 'status':
                $sort = 'plugin_reward_ppd_detail.status';
                break;
        }

        $sqlClause = "WHERE 1=1 ";
        if ($filterByUser) {
            $sqlClause .= " AND plugin_reward_ppd_detail.reward_user_id = " . (int) $filterByUser;
        }

        if ($filterByStatus) {
            $sqlClause .= " AND plugin_reward_ppd_detail.status = " . $db->quote($filterByStatus);
        }

        if ($filterByGroupData == 'yes') {
            $totalRS = $db->getValue("SELECT COUNT(users.id) AS total "
                    . "FROM plugin_reward_ppd_detail "
                    . "LEFT JOIN users ON plugin_reward_ppd_detail.reward_user_id = users.id "
                    . "LEFT JOIN file ON plugin_reward_ppd_detail.file_id = file.id "
                    . $sqlClause . " "
                    . "GROUP BY users.id, plugin_reward_ppd_detail.status");
            $limitedRS = $db->getRows("SELECT plugin_reward_ppd_detail.*, SUM(reward_amount) AS reward_amount, "
                    . "users.username, file.originalFilename, file.shortUrl, "
                    . "plugin_reward_ppd_group.group_label "
                    . "FROM plugin_reward_ppd_detail "
                    . "LEFT JOIN users ON plugin_reward_ppd_detail.reward_user_id = users.id "
                    . "LEFT JOIN file ON plugin_reward_ppd_detail.file_id = file.id "
                    . "LEFT JOIN plugin_reward_ppd_group ON plugin_reward_ppd_detail.download_country_group_id = plugin_reward_ppd_group.id "
                    . $sqlClause . " "
                    . "GROUP BY users.id, plugin_reward_ppd_detail.status "
                    . "ORDER BY " . $sort . " " . $db->escape($sSortDir_0) . " "
                    . "LIMIT " . $iDisplayStart . ", " . $iDisplayLength);
        }
        else {
            $totalRS = $db->getValue("SELECT COUNT(plugin_reward_ppd_detail.id) AS total "
                    . "FROM plugin_reward_ppd_detail "
                    . "LEFT JOIN users ON plugin_reward_ppd_detail.reward_user_id = users.id "
                    . "LEFT JOIN file ON plugin_reward_ppd_detail.file_id = file.id "
                    . $sqlClause);
            $limitedRS = $db->getRows("SELECT plugin_reward_ppd_detail.*, users.username, "
                    . "file.originalFilename, file.shortUrl, plugin_reward_ppd_group.group_label "
                    . "FROM plugin_reward_ppd_detail "
                    . "LEFT JOIN users ON plugin_reward_ppd_detail.reward_user_id = users.id "
                    . "LEFT JOIN file ON plugin_reward_ppd_detail.file_id = file.id "
                    . "LEFT JOIN plugin_reward_ppd_group ON plugin_reward_ppd_detail.download_country_group_id = plugin_reward_ppd_group.id "
                    . $sqlClause . " "
                    . "ORDER BY " . $sort . " " . $db->escape($sSortDir_0) . " "
                    . "LIMIT " . $iDisplayStart . ", " . $iDisplayLength);
        }

        $data = array();
        if (count($limitedRS) > 0) {
            foreach ($limitedRS AS $reward) {
                $lRow = array();
                $lRow[] = '<img src="' . PLUGIN_WEB_ROOT . '/rewards/assets/img/icons/16px.png" width="16" height="16" title="rewards" alt="rewards"/>';
                if ($filterByGroupData == 'yes') {
                    $lRow[] = '<span style="color: #aaa;">[grouped range]</span>';
                }
                else {
                    $lRow[] = CoreHelper::formatDate($reward['download_date'], SITE_CONFIG_DATE_TIME_FORMAT);
                }
                $lRow[] = $reward['username'];

                $fileName = 'File Download';
                $fileDetails = $db->getRow('SELECT originalFilename, shortUrl '
                        . 'FROM file '
                        . 'WHERE id=' . (int) $reward['file_id'] . ' '
                        . 'LIMIT 1');
                if ($fileDetails) {
                    $fileName = '<a href="' . ADMIN_WEB_ROOT . '/file_manage?filterText=' . urlencode($fileDetails['shortUrl']) . '">' . ValidationHelper::safeOutputToScreen($fileDetails['originalFilename'], null, 38) . '</a>';
                }
                $lRow[] = $fileName;

                $lRow[] = $reward['group_label'];
                $lRow[] = SITE_CONFIG_COST_CURRENCY_SYMBOL . $reward['reward_amount'];
                $lRow[] = ucwords(str_replace("_", " ", $reward['status']));

                $links = array();
                if ($filterByGroupData != 'yes') {
                    if ($reward['status'] == 'pending') {
                        $links[] = '<a href="#" onClick="confirmRemoveReward(' . (int) $reward['id'] . '); return false;">cancel</a>';
                    }
                }
                $lRow[] = implode(" | ", $links);

                $data[] = $lRow;
            }
        }

        $resultArr = array();
        $resultArr["sEcho"] = intval($request->query->get('sEcho'));
        $resultArr["iTotalRecords"] = (int) $totalRS;
        $resultArr["iTotalDisplayRecords"] = $resultArr["iTotalRecords"];
        $resultArr["aaData"] = $data;

        // output response
        return $this->renderJson($resultArr);
    }

    public function ajaxRewardsDetailedDownloadCancel() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        $gRewardId = (int) $_REQUEST['gRewardId'];

        // prepare result
        $resultArr = array();
        $resultArr['error'] = false;
        $resultArr['msg'] = '';

        if (_CONFIG_DEMO_MODE == true) {
            $resultArr['error'] = true;
            $resultArr['msg'] = AdminHelper::t("no_changes_in_demo_mode");
        }
        else {
            $db->query('UPDATE plugin_reward_ppd_detail '
                    . 'SET status = \'cancelled\' '
                    . 'WHERE id = :id', array(
                'id' => $gRewardId,
                    )
            );
            if ($db->affectedRows() == 1) {
                $resultArr['error'] = false;
                $resultArr['msg'] = 'Download reward cancelled.';
            }
            else {
                $resultArr['error'] = true;
                $resultArr['msg'] = 'Could not cancel the download reward.';
            }
        }

        // output response
        return $this->renderJson($resultArr);
    }

    public function rewardsAggregatedEarning() {
        // admin restrictions
        $this->restrictAdminAccess();

        // for later
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // get instance
        $folderName = 'rewards';
        $pluginObj = PluginHelper::getInstance($folderName);
        $pluginObj->clearPendingRewards();
        $pluginObj->aggregateRewards();

        // load all users
        $sQL = "SELECT id, username AS selectValue "
                . "FROM users "
                . "WHERE level_id > 0 "
                . "ORDER BY username";
        $userDetails = $db->getRows($sQL);

        // load all months
        $monthData = $db->getRows('SELECT period '
                . 'FROM plugin_reward_aggregated '
                . 'GROUP BY period '
                . 'ORDER BY period DESC');
        $monthOptions = array();
        if ($monthData) {
            foreach ($monthData AS $monthRow) {
                $k = date('Y-m', strtotime($monthRow['period']));
                $monthOptions[$k] = date('F Y', strtotime($monthRow['period']));
            }
        }

        $filterByStatus = '';
        if (isset($_REQUEST['filterByStatus'])) {
            $filterByStatus = (int) $_REQUEST['filterByStatus'];
        }

        $filterByUser = null;
        if (isset($_REQUEST['filterByUser'])) {
            $filterByUser = (int) $_REQUEST['filterByUser'];
        }

        $filterByMonth = null;
        if (isset($_REQUEST['filterByMonth'])) {
            $filterByMonth = $_REQUEST['filterByMonth'];
        }

        // load template
        return $this->render('admin/rewards_aggregated_earning.html', array(
                    'yesNoOptions' => array(
                        0 => 'No',
                        1 => 'Yes'),
                    'monthOptions' => $monthOptions,
                    'statusDetails' => $pluginObj->getStatusList(),
                    'userDetails' => $userDetails,
                    'filterByStatus' => $filterByStatus,
                    'filterByUser' => $filterByUser,
                    'filterByMonth' => $filterByMonth,
                    'pluginObj' => $pluginObj,
                    'nextRewardsAggregationDateFormatted' => date('jS F Y', SITE_CONFIG_NEXT_CHECK_FOR_REWARDS_AGGREGATION),
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function ajaxRewardsAggregatedEarning() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $folderName = 'rewards';
        $pluginObj = PluginHelper::getInstance($folderName);

        $iDisplayLength = (int) $request->query->get('iDisplayLength');
        $iDisplayStart = (int) $request->query->get('iDisplayStart');
        $sSortDir_0 = ($request->query->has('sSortDir_0') && $request->query->get('sSortDir_0') === 'asc') ? 'asc' : 'desc';
        $filterByUser = strlen($_REQUEST['filterByUser']) ? (int) $_REQUEST['filterByUser'] : false;
        $filterByStatus = strlen($_REQUEST['filterByStatus']) ? $_REQUEST['filterByStatus'] : '';
        $filterByMonth = strlen($_REQUEST['filterByMonth']) ? $_REQUEST['filterByMonth'] : false;

        // get sorting columns
        $iSortCol_0 = (int) $request->query->get('iSortCol_0');
        $sColumns = trim($request->query->get('sColumns'));
        $arrCols = explode(",", $sColumns);
        $sortColumnName = $arrCols[$iSortCol_0];
        $sort = 'period';
        switch ($sortColumnName) {
            case 'period':
                $sort = 'period';
                break;
            case 'user':
                $sort = 'users.username';
                break;
            case 'description':
                $sort = 'description';
                break;
            case 'amount':
                $sort = 'amount';
                break;
            case 'status':
                $sort = 'status';
                break;
        }

        $sqlClause = "WHERE 1=1 ";
        if ($filterByUser) {
            $sqlClause .= " AND plugin_reward_aggregated.reward_user_id = " . (int) $filterByUser;
        }

        if ($filterByStatus) {
            $sqlClause .= " AND plugin_reward_aggregated.status = " . $db->quote($filterByStatus);
        }

        if ($filterByMonth) {
            // get start of month
            $startMonth = strtotime($filterByMonth . '-01 00:00:00');
            $endMonth = strtotime($filterByMonth . '-' . date('t', $startMonth) . ' 23:59:59');

            $sqlClause .= ' AND UNIX_TIMESTAMP(plugin_reward_aggregated.period) >= ' . $startMonth . ' '
                    . 'AND UNIX_TIMESTAMP(plugin_reward_aggregated.period) <= ' . $endMonth;
        }

        $totalRS = $db->getValue("SELECT COUNT(plugin_reward_aggregated.id) AS total "
                . "FROM plugin_reward_aggregated "
                . "LEFT JOIN users ON plugin_reward_aggregated.reward_user_id = users.id "
                . $sqlClause);
        $limitedRS = $db->getRows("SELECT plugin_reward_aggregated.*, users.username "
                . "FROM plugin_reward_aggregated "
                . "LEFT JOIN users ON plugin_reward_aggregated.reward_user_id = users.id "
                . $sqlClause . " "
                . "ORDER BY " . $sort . " " . $db->escape($sSortDir_0) . " "
                . "LIMIT " . $iDisplayStart . ", " . $iDisplayLength);

        $data = array();
        if (count($limitedRS) > 0) {
            foreach ($limitedRS AS $reward) {
                $lRow = array();
                $lRow[] = '<img src="' . PLUGIN_WEB_ROOT . '/rewards/assets/img/icons/16px.png" width="16" height="16" title="rewards" alt="rewards"/>';
                $lRow[] = CoreHelper::formatDate(strtotime($reward['period']), SITE_CONFIG_DATE_FORMAT);
                $lRow[] = $reward['username'];
                $lRow[] = $reward['description'];
                $lRow[] = SITE_CONFIG_COST_CURRENCY_SYMBOL . $reward['amount'];
                $lRow[] = ucwords(str_replace("_", " ", $reward['status']));

                $links = array();
                $links[] = '-';
                $lRow[] = implode(" | ", $links);

                $data[] = $lRow;
            }
        }

        $resultArr = array();
        $resultArr["sEcho"] = intval($request->query->get('sEcho'));
        $resultArr["iTotalRecords"] = (int) $totalRS;
        $resultArr["iTotalDisplayRecords"] = $resultArr["iTotalRecords"];
        $resultArr["aaData"] = $data;

        // output response
        return $this->renderJson($resultArr);
    }

    public function rewardsPaymentRequest() {
        // admin restrictions
        $this->restrictAdminAccess();

        // for later
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // get instance
        $folderName = 'rewards';
        $pluginObj = PluginHelper::getInstance($folderName);
        $pluginObj->clearPendingRewards();
        $pluginObj->aggregateRewards();

        // cancels
        if (isset($_REQUEST['cancel'])) {
            // update any aggregated data
            $db->query('UPDATE plugin_reward_withdraw_request '
                    . 'SET status=\'cancelled\', '
                    . 'payment_date=NOW(), '
                    . 'payment_notes=\'Admin cancelled on ' . CoreHelper::sqlDateTime() . '\' '
                    . 'WHERE id = :id', array(
                'id' => (int) $_REQUEST['cancel'],
                    )
            );
        }

        // load all users
        $sQL = "SELECT id, username AS selectValue "
                . "FROM users "
                . "WHERE level_id > 0 "
                . "ORDER BY username";
        $userDetails = $db->getRows($sQL);

        $filterByStatus = '';
        if (isset($_REQUEST['filterByStatus'])) {
            $filterByStatus = (int) $_REQUEST['filterByStatus'];
        }

        $filterByUser = null;
        if (isset($_REQUEST['filterByUser'])) {
            $filterByUser = (int) $_REQUEST['filterByUser'];
        }

        // load template
        return $this->render('admin/rewards_payment_request.html', array(
                    'yesNoOptions' => array(
                        0 => 'No',
                        1 => 'Yes'),
                    'statusDetails' => $pluginObj->getStatusList(),
                    'userDetails' => $userDetails,
                    'filterByStatus' => $filterByStatus,
                    'filterByUser' => $filterByUser,
                    'pluginObj' => $pluginObj,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function ajaxRewardsPaymentRequest() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $folderName = 'rewards';
        $pluginObj = PluginHelper::getInstance($folderName);

        $iDisplayLength = (int) $request->query->get('iDisplayLength');
        $iDisplayStart = (int) $request->query->get('iDisplayStart');
        $sSortDir_0 = ($request->query->has('sSortDir_0') && $request->query->get('sSortDir_0') === 'asc') ? 'asc' : 'desc';
        $filterByUser = strlen($_REQUEST['filterByUser']) ? (int) $_REQUEST['filterByUser'] : false;
        $filterByStatus = strlen($_REQUEST['filterByStatus']) ? $_REQUEST['filterByStatus'] : '';

        // get sorting columns
        $iSortCol_0 = (int) $request->query->get('iSortCol_0');
        $sColumns = trim($request->query->get('sColumns'));
        $arrCols = explode(",", $sColumns);
        $sortColumnName = $arrCols[$iSortCol_0];
        $sort = 'requested_date';
        switch ($sortColumnName) {
            case 'date_requested':
                $sort = 'requested_date';
                break;
            case 'user':
                $sort = 'users.username';
                break;
            case 'amount':
                $sort = 'amount';
                break;
            case 'method':
                $sort = 'payment_method';
                break;
            case 'status':
                $sort = 'status';
                break;
        }

        $sqlClause = "WHERE 1=1 ";
        if ($filterByUser) {
            $sqlClause .= " AND plugin_reward_withdraw_request.reward_user_id = " . (int) $filterByUser;
        }

        if ($filterByStatus) {
            $sqlClause .= " AND plugin_reward_withdraw_request.status = " . $db->quote($filterByStatus);
        }

        // preload payment urls
        $paymentUrlsArr = array();
        $paymentUrls = $db->getRows('SELECT name_key, admin_payment_link '
                . 'FROM plugin_reward_outpayment_method');
        foreach ($paymentUrls AS $paymentUrl) {
            if (strlen($paymentUrl['admin_payment_link'])) {
                $paymentUrlsArr[$paymentUrl['name_key']] = $paymentUrl['admin_payment_link'];
            }
        }

        $totalRS = $db->getValue("SELECT COUNT(plugin_reward_withdraw_request.id) AS total "
                . "FROM plugin_reward_withdraw_request "
                . "LEFT JOIN users ON plugin_reward_withdraw_request.reward_user_id = users.id "
                . $sqlClause);
        $limitedRS = $db->getRows("SELECT plugin_reward_withdraw_request.*, users.username, "
                . "plugin_reward_affiliate_id.method_data_json, plugin_reward_affiliate_id.outpayment_method "
                . "FROM plugin_reward_withdraw_request "
                . "LEFT JOIN users ON plugin_reward_withdraw_request.reward_user_id = users.id "
                . "LEFT JOIN plugin_reward_affiliate_id ON users.id = plugin_reward_affiliate_id.user_id "
                . $sqlClause . " "
                . "ORDER BY " . $sort . " " . $db->escape($sSortDir_0) . " "
                . "LIMIT " . $iDisplayStart . ", " . $iDisplayLength);

        $data = array();
        if (count($limitedRS) > 0) {
            foreach ($limitedRS AS $paymentRequest) {
                $lRow = array();
                $lRow[] = '<img src="' . PLUGIN_WEB_ROOT . '/rewards/assets/img/icons/16px.png" width="16" height="16" title="request" alt="request"/>';
                $lRow[] = CoreHelper::formatDate($paymentRequest['requested_date'], SITE_CONFIG_DATE_TIME_FORMAT);
                $lRow[] = ValidationHelper::safeOutputToScreen($paymentRequest['username']);
                $lRow[] = ValidationHelper::safeOutputToScreen(ucwords($paymentRequest['payment_method']));
                $lRow[] = SITE_CONFIG_COST_CURRENCY_SYMBOL . ValidationHelper::safeOutputToScreen($paymentRequest['amount']);
                $lRow[] = ucwords(str_replace("_", " ", $paymentRequest['status']));

                $links = array();
                if ($paymentRequest['status'] == 'pending') {
                    $paymentDetailsStr = $paymentRequest['method_data_json'];
                    if (strlen($paymentDetailsStr)) {
                        $paymentDetailsArr = json_decode($paymentDetailsStr, true);
                        if ($paymentDetailsArr) {
                            $paymentDetailsStr = '';
                            foreach ($paymentDetailsArr AS $k => $v) {
                                $v = str_replace(array("\n"), '\n', $v);
                                $v = str_replace(array("\r"), '', $v);
                                $paymentDetailsStr .= ucwords(str_replace('_', ' ', ValidationHelper::safeOutputToScreen($k)));
                                $paymentDetailsStr .= ':\n\n';
                                $paymentDetailsStr .= ValidationHelper::safeOutputToScreen($v);
                                $paymentDetailsStr .= '\n';
                            }
                        }
                    }
                    $links[] = '<a href="#" onClick="setAsPaidPopup(' . (int) $paymentRequest['id'] . ',\'' . str_replace(array("'", "\""), "", ValidationHelper::safeOutputToScreen(ucwords($paymentRequest['payment_method']))) . '\',\'' . str_replace(array("'", "\""), "", ValidationHelper::safeOutputToScreen($paymentDetailsStr)) . '\', \'' . ValidationHelper::safeOutputToScreen($paymentRequest['amount']) . '\');return false;">set paid</a>';
                    if (isset($paymentUrlsArr[$paymentRequest['outpayment_method']])) {
                        // do replacements in url
                        $url = $paymentUrlsArr[$paymentRequest['outpayment_method']];
                        $url = str_replace('[[[RETURN_PAGE]]]', urlencode(ADMIN_WEB_ROOT . '/rewards_payment_request'), $url);
                        $url = str_replace('[[[ITEM_NAME]]]', urlencode('Outpayment for PPS/PPD earnings. User ' . $paymentRequest['username'] . '. Request #' . $paymentRequest['id']), $url);
                        $url = str_replace('[[[AMOUNT]]]', urlencode($paymentRequest['amount']), $url);
                        $url = str_replace('[[[CURRENCY]]]', urlencode(SITE_CONFIG_COST_CURRENCY_CODE), $url);
                        foreach ($paymentDetailsArr AS $k => $v) {
                            $url = str_replace('[[[' . strtoupper($k) . ']]]', urlencode($v), $url);
                        }

                        $links[] = '<a href="' . $url . '" onClick="alert(\'You will now be redirected to ' . ValidationHelper::safeOutputToScreen($paymentRequest['outpayment_method']) . ' to send payment. Remember that you will still need to return to this page and set this request as paid.\');">pay via ' . ValidationHelper::safeOutputToScreen($paymentRequest['outpayment_method']) . '</a>';
                    }

                    $links[] = '<a href="' . ADMIN_WEB_ROOT . '/rewards_payment_request?cancel=' . (int) $paymentRequest['id'] . '" onClick="return confirm(\'Are you sure you to cancel this payment request?\');">cancel</a>';
                }
                $lRow[] = implode(" | ", $links);

                $data[] = $lRow;
            }
        }

        $resultArr = array();
        $resultArr["sEcho"] = intval($request->query->get('sEcho'));
        $resultArr["iTotalRecords"] = (int) $totalRS;
        $resultArr["iTotalDisplayRecords"] = $resultArr["iTotalRecords"];
        $resultArr["aaData"] = $data;

        // output response
        return $this->renderJson($resultArr);
    }

    public function ajaxRewardsPaymentRequestPay() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        $gRequestId = (int) $_REQUEST['gRequestId'];
        $paypal_notes = $_REQUEST['paypal_notes'];

        // prepare result
        $resultArr = array();
        $resultArr['error'] = false;
        $resultArr['msg'] = '';

        if (_CONFIG_DEMO_MODE == true) {
            $resultArr['error'] = true;
            $resultArr['msg'] = AdminHelper::t("no_changes_in_demo_mode");
        }
        else {
            $db->query('UPDATE plugin_reward_withdraw_request '
                    . 'SET status=\'paid\', '
                    . 'payment_date = NOW(), '
                    . 'payment_notes = :payment_notes '
                    . 'WHERE id = :id', array(
                'payment_notes' => $paypal_notes,
                'id' => $gRequestId,
                    )
            );
            if ($db->affectedRows() == 1) {
                // update any aggregated data
                $db->query('UPDATE plugin_reward_aggregated '
                        . 'SET status=\'paid\', '
                        . 'payment_date=NOW() '
                        . 'WHERE withdrawal_request_id = :id', array(
                    'id' => $gRequestId,
                        )
                );

                $resultArr['error'] = false;
                $resultArr['msg'] = 'Payment request set as \'paid\'.';
            }
            else {
                $resultArr['error'] = true;
                $resultArr['msg'] = 'Could not update the payment request, please try again later.';
            }
        }

        // output response
        return $this->renderJson($resultArr);
    }

}
