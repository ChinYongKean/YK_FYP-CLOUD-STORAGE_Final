UPDATE plugin_reward_aggregated SET payment_date = '2038-01-01 00:00:00' WHERE CAST(payment_date AS CHAR(20)) = '0000-00-00 00:00:00';
ALTER TABLE `plugin_reward_aggregated` CHANGE `payment_date` `payment_date` datetime NULL AFTER `status`;
UPDATE plugin_reward_aggregated SET payment_date = NULL WHERE payment_date = '2038-01-01 00:00:00';

ALTER TABLE `plugin_reward_aggregated` DROP INDEX `reward_user_id`;
ALTER TABLE `plugin_reward_aggregated` ADD UNIQUE `period_reward_user_id_reward_type` (`period`, `reward_user_id`, `reward_type`);
