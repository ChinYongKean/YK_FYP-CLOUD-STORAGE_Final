ALTER TABLE  `plugin_reward_ppd_detail` CHANGE  `download_ip`  `download_ip` VARCHAR( 45 ) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL;
