ALTER TABLE `plugin_reward_aggregated` CHANGE `amount` `amount` FLOAT( 15, 6 ) NOT NULL;
