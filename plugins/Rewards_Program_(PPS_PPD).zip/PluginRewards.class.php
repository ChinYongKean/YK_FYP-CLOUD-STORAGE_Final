<?php

// plugin namespace

namespace Plugins\Rewards;

// core includes
use App\Core\Database;
use App\Services\Plugin;
use App\Helpers\CoreHelper;
use Plugins\Rewards\PluginConfig;
use Plugins\Rewards\Models\PluginReward;
use Plugins\Rewards\Models\PluginRewardAggregated;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class PluginRewards extends Plugin
{
    public $config = null;
    public $data = null;

    public function __construct() {
        // load plugin config
        $this->config = (new PluginConfig())->getPluginConfig();
        $this->settings = $this->getPluginSettings();
    }

    public function registerRoutes(\FastRoute\RouteCollector $r) {
        // register plugin routes
        // admin routes
        $r->addRoute(['GET', 'POST'], '/' . ADMIN_FOLDER_NAME . '/plugin/' . $this->config['folder_name'] . '/settings', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/pluginSettings');
        $r->addRoute(['GET', 'POST'], '/' . ADMIN_FOLDER_NAME . '/rewards_overview', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/rewardsOverview');
        $r->addRoute(['GET'], '/' . ADMIN_FOLDER_NAME . '/ajax/rewards_overview', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxRewardsOverview');
        $r->addRoute(['GET'], '/' . ADMIN_FOLDER_NAME . '/rewards_detailed_referral', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/rewardsDetailedReferral');
        $r->addRoute(['GET'], '/' . ADMIN_FOLDER_NAME . '/ajax/rewards_detailed_referral', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxRewardsDetailedReferral');
        $r->addRoute(['POST'], '/' . ADMIN_FOLDER_NAME . '/ajax/rewards_detailed_referral_cancel', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxRewardsDetailedReferralCancel');

        $r->addRoute(['GET'], '/' . ADMIN_FOLDER_NAME . '/rewards_detailed_download', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/rewardsDetailedDownload');
        $r->addRoute(['GET'], '/' . ADMIN_FOLDER_NAME . '/ajax/rewards_detailed_download', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxRewardsDetailedDownload');
        $r->addRoute(['POST'], '/' . ADMIN_FOLDER_NAME . '/ajax/rewards_detailed_download_cancel', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxRewardsDetailedDownloadCancel');
        
        $r->addRoute(['GET'], '/' . ADMIN_FOLDER_NAME . '/rewards_aggregated_earning', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/rewardsAggregatedEarning');
        $r->addRoute(['GET'], '/' . ADMIN_FOLDER_NAME . '/ajax/rewards_aggregated_earning', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxRewardsAggregatedEarning');
        
        $r->addRoute(['GET'], '/' . ADMIN_FOLDER_NAME . '/rewards_payment_request', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/rewardsPaymentRequest');
        $r->addRoute(['GET'], '/' . ADMIN_FOLDER_NAME . '/ajax/rewards_payment_request', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxRewardsPaymentRequest');
        $r->addRoute(['POST'], '/' . ADMIN_FOLDER_NAME . '/ajax/rewards_payment_request_pay', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxRewardsPaymentRequestPay');
        
        // front-end routes
        $r->addRoute(['GET'], '/rewards', '\plugins\\' . $this->config['folder_name'] . '\controllers\RewardsController/rewards');
        $r->addRoute(['GET', 'POST'], '/account/rewards', '\plugins\\' . $this->config['folder_name'] . '\controllers\RewardsController/accountRewards');
        $r->addRoute(['GET'], '/account/ajax/rewards', '\plugins\\' . $this->config['folder_name'] . '\controllers\RewardsController/ajaxAccountRewards');
        $r->addRoute(['GET'], '/account/ajax/rewards_ppd', '\plugins\\' . $this->config['folder_name'] . '\controllers\RewardsController/ajaxAccountRewardsPpd');
        
        $r->addRoute(['POST'], '/account/ajax/rewards_request_withdrawal', '\plugins\\' . $this->config['folder_name'] . '\controllers\RewardsController/ajaxRewardsRequestWithdrawal');
        $r->addRoute(['GET'], '/rewards/nginx_log_download_callback', '\plugins\\' . $this->config['folder_name'] . '\controllers\RewardsController/nginxLogDownloadCallback');
        $r->addRoute(['POST'], '/rewards/media_log_download_callback', '\plugins\\' . $this->config['folder_name'] . '\controllers\RewardsController/mediaLogDownloadCallback');
        
        
    }

    public function getPluginDetails() {
        return $this->config;
    }

    public function uninstall() {
        // setup database
        $db = Database::getDatabase();

        // remove plugin specific tables
        $sQL = 'DROP TABLE plugin_reward_affiliate_id';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_reward';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_reward_aggregated';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_reward_withdraw_request';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_reward_ppd_complete_download';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_reward_country_list';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_reward_outpayment_method';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_reward_ppd_detail';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_reward_ppd_group';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_reward_ppd_group_country';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_reward_ppd_group_rate';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_reward_ppd_range';
        $db->query($sQL);

        $sQL = 'DELETE FROM site_config '
                . 'WHERE config_key=\'next_check_for_rewards_aggregation\'';
        $db->query($sQL);
        $sQL = 'DELETE FROM site_config '
                . 'WHERE config_key=\'next_check_for_ppd_aggregation\'';
        $db->query($sQL);

        return parent::uninstall();
    }
    
    public function getStatusList() {
        return array('pending', 'cancelled', 'charged_back', 'refunded', 'cleared');
    }

    public function clearPendingRewards() {
        // setup database
        $db = Database::getDatabase();

        // PPS - update any rewards awaiting clearing
        $db->query("UPDATE plugin_reward "
                . "SET status = 'cleared' "
                . "WHERE status IN ('pending') "
                . "AND UNIX_TIMESTAMP(reward_date) < " . strtotime('-' . (int) $this->settings['payment_lead_time'] . ' days'));

        // PPD
        $db->query("UPDATE plugin_reward_ppd_detail "
                . "SET status = 'cleared' "
                . "WHERE status IN ('pending') "
                . "AND UNIX_TIMESTAMP(download_date) < " . strtotime('-' . (int) $this->settings['payment_lead_time'] . ' days'));
    }

    public function pruneData() {
        // setup database
        $db = Database::getDatabase();

        // remove everything older than 30 days old
        $db->query('DELETE '
                . 'FROM `plugin_reward_ppd_complete_download` '
                . 'WHERE date_added < DATE_SUB(NOW(), INTERVAL 30 DAY)');
    }

    public function aggregateRewards() {
        // setup database
        $db = Database::getDatabase();

        // make sure we should aggregate the data
        $nextCheckTimestamp = (int) SITE_CONFIG_NEXT_CHECK_FOR_REWARDS_AGGREGATION;
        if ($nextCheckTimestamp < time()) {
            // loop months and collate all cleared data older than $this->settings['payment_lead_time'] days.
            $monthToUpdate = strtotime('-' . (int) $this->settings['payment_lead_time'] . ' days');
            $monthToUpdate = strtotime(date("Y-m-01 00:00:00", $monthToUpdate));
            $monthToUpdateEnd = $monthToUpdate - 1;
            $monthToUpdateStart = strtotime(date("Y-m-01 00:00:00", $monthToUpdateEnd));

            // PPS
            $data = $db->getRows("SELECT SUM(reward_amount) AS total, "
                    . "COUNT(id) AS total_cleared, reward_user_id "
                    . "FROM plugin_reward "
                    . "WHERE UNIX_TIMESTAMP(reward_date) "
                    . "BETWEEN " . $monthToUpdateStart . " "
                    . "AND " . $monthToUpdateEnd . " "
                    . "AND status='cleared' "
                    . "GROUP BY reward_user_id");
            if ($data) {
                foreach ($data AS $row) {
                    // make sure there's no already an entry for that period under the same user
                    $rs = $db->getValue('SELECT id '
                            . 'FROM plugin_reward_aggregated '
                            . 'WHERE reward_user_id = :reward_user_id '
                            . 'AND period=\'' . date("Y-m-d H:i:s", $monthToUpdateStart) . '\' '
                            . 'AND reward_type = \'PPS\' '
                            . 'LIMIT 1', array(
                        'reward_user_id' => $row['reward_user_id'],
                    ));
                    if (!$rs) {
                        // add aggregated data to db
                        $monthName = date('F Y', $monthToUpdateStart);
                        $description = 'Cleared PPS rewards for ' . $monthName . ' (' . $row['total_cleared'] . ' item' . ($row['total_cleared'] != 1 ? 's' : '') . ')';

                        $pluginRewardAggregated = PluginRewardAggregated::create();
                        $pluginRewardAggregated->reward_user_id = $row['reward_user_id'];
                        $pluginRewardAggregated->period = date("Y-m-d H:i:s", $monthToUpdateStart);
                        $pluginRewardAggregated->amount = $row['total'];
                        $pluginRewardAggregated->description = $description;
                        $pluginRewardAggregated->aggregated_date = CoreHelper::sqlDateTime();
                        $pluginRewardAggregated->status = 'available';
                        $pluginRewardAggregated->reward_type = 'PPS';
                        $pluginRewardAggregated->save();
                    }
                }
            }

            // set next check to start of next month
            $nextCheckNew = strtotime(date("Y-m-05 00:00:00", strtotime("+1 months")));
            $db->query("UPDATE site_config "
                    . "SET config_value = :config_value "
                    . "WHERE config_key = 'next_check_for_rewards_aggregation' "
                    . "LIMIT 1", array(
                'config_value' => $nextCheckNew,
            ));
        }


        $nextCheckTimestamp = (int) SITE_CONFIG_NEXT_CHECK_FOR_PPD_AGGREGATION;
        if ($nextCheckTimestamp < time()) {
            // PPD
            $data = $db->getRows("SELECT SUM(reward_amount) AS total, "
                    . "COUNT(id) AS total_cleared, reward_user_id "
                    . "FROM plugin_reward_ppd_detail "
                    . "WHERE UNIX_TIMESTAMP(download_date) < NOW() "
                    . "AND (status='cleared' OR status='pending') "
                    . "GROUP BY reward_user_id");
            if ($data) {
                foreach ($data AS $row) {
                    $periodDateTime = strtotime(date("Y-m-d 00:00:00"));

                    // add aggregated data to db
                    $description = 'Cleared PPD rewards for ' . CoreHelper::formatDate($periodDateTime, SITE_CONFIG_DATE_FORMAT) . ' (' . $row['total_cleared'] . ' item' . ($row['total_cleared'] != 1 ? 's' : '') . ')';

                    $pluginRewardAggregated = PluginRewardAggregated::create();
                    $pluginRewardAggregated->reward_user_id = $row['reward_user_id'];
                    $pluginRewardAggregated->period = date("Y-m-d H:i:s", $periodDateTime);
                    $pluginRewardAggregated->amount = $row['total'];
                    $pluginRewardAggregated->description = $description;
                    $pluginRewardAggregated->aggregated_date = date("Y-m-d H:i:s", time());
                    $pluginRewardAggregated->status = 'available';
                    $pluginRewardAggregated->reward_type = 'PPD';
                    $pluginRewardAggregated->save();

                    // update each item
                    $db->query("UPDATE plugin_reward_ppd_detail "
                            . "SET status='aggregated' "
                            . "WHERE UNIX_TIMESTAMP(download_date) < NOW() "
                            . "AND (status='cleared' OR status='pending') AND "
                            . "reward_user_id = " . $row['reward_user_id']);
                }
            }

            // set next check to start of next month
            $nextCheckNew = strtotime(date("Y-m-d 00:00:00", strtotime("+1 day")));
            $db->query("UPDATE site_config "
                    . "SET config_value = :config_value "
                    . "WHERE config_key = 'next_check_for_ppd_aggregation' "
                    . "LIMIT 1", array(
                'config_value' => $nextCheckNew,
            ));
        }
    }

    function getCountPPDByUserId($userId) {
        // setup database
        $db = Database::getDatabase();

        // get total
        return $db->getValue("SELECT COUNT(id) AS total "
                        . "FROM plugin_reward_ppd_detail "
                        . "WHERE reward_user_id = " . (int) $userId . " "
                        . "AND status IN ('pending', 'cleared', 'aggregated')");
    }

    function getUnaggregatedCountPPDByUserId($userId) {
        // setup database
        $db = Database::getDatabase();

        // get total
        return $db->getValue("SELECT COUNT(id) AS total "
                        . "FROM plugin_reward_ppd_detail "
                        . "WHERE reward_user_id = " . (int) $userId . " "
                        . "AND status IN ('pending', 'cleared')");
    }

    function getUnaggregatedValuePPDByUserId($userId) {
        // setup database
        $db = Database::getDatabase();

        // get total
        return $db->getValue("SELECT SUM(reward_amount) AS total "
                        . "FROM plugin_reward_ppd_detail "
                        . "WHERE reward_user_id = " . (int) $userId . " "
                        . "AND status IN ('pending', 'cleared')");
    }

    function getTotalPPD() {
        // setup database
        $db = Database::getDatabase();

        // get total
        return $db->getValue("SELECT SUM(reward_amount) AS total "
                        . "FROM plugin_reward_ppd_detail "
                        . "WHERE status IN ('pending', 'cleared', 'aggregated')");
    }

    function getAvailableForWithdrawByUserId($userId) {
        // setup database
        $db = Database::getDatabase();

        // get total
        return $db->getValue("SELECT SUM(amount) AS total "
                        . "FROM plugin_reward_aggregated "
                        . "WHERE reward_user_id = " . (int) $userId . " "
                        . "AND status IN ('available')");
    }

    function getAggregatedValuePPSByUserId($userId) {
        // setup database
        $db = Database::getDatabase();

        // get total
        return $db->getValue("SELECT SUM(amount) AS total "
                        . "FROM plugin_reward_aggregated "
                        . "WHERE reward_user_id = " . (int) $userId);
    }

    function getPendingPaymentTotalByUserId($userId) {
        // setup database
        $db = Database::getDatabase();

        // get total
        return $db->getValue("SELECT SUM(amount) AS total "
                        . "FROM plugin_reward_withdraw_request "
                        . "WHERE reward_user_id = " . (int) $userId . " "
                        . "AND status='pending'");
    }

    function getPaidTotalByUserId($userId) {
        // setup database
        $db = Database::getDatabase();

        // get total
        return $db->getValue("SELECT SUM(amount) AS total "
                        . "FROM plugin_reward_withdraw_request "
                        . "WHERE reward_user_id = " . (int) $userId . " "
                        . "AND status='paid'");
    }

    function getPaidTotal() {
        // setup database
        $db = Database::getDatabase();

        // get total
        return $db->getValue("SELECT SUM(amount) AS total "
                        . "FROM plugin_reward_withdraw_request "
                        . "WHERE status='paid'");
    }

    function getPendingPaymentTotal() {
        // setup database
        $db = Database::getDatabase();

        // get total
        return $db->getValue("SELECT SUM(amount) AS total "
                        . "FROM plugin_reward_withdraw_request "
                        . "WHERE status='pending'");
    }

    function getTotalPPSByUserId($userId) {
        // setup database
        $db = Database::getDatabase();

        // get total
        return $db->getValue("SELECT SUM(reward_amount) AS total "
                        . "FROM plugin_reward "
                        . "WHERE reward_user_id = " . (int) $userId . " "
                        . "AND status IN ('pending', 'cleared')");
    }

    function getTotalPPS() {
        // setup database
        $db = Database::getDatabase();

        // get total
        return $db->getValue("SELECT SUM(reward_amount) AS total "
                        . "FROM plugin_reward "
                        . "WHERE status IN ('pending', 'cleared')");
    }

    function formatAmount($amount) {
        $amount = (float) $amount;
        $decimals = strlen(substr(strrchr($amount, "."), 1));
        if ($decimals < 2) {
            $amount = number_format($amount, 2);
        }

        return $amount;
    }

    function userTypeAllowedPPDAccess($userTypeId) {
        // if no data, assume user is allowed
        if (!isset($this->settings['ppd_user_type'])) {
            return true;
        }

        if (!is_array($this->settings['ppd_user_type'])) {
            return true;
        }

        // anything 10 or above is allowed
        if (($userTypeId >= 10) || ($userTypeId < 1)) {
            return true;
        }

        foreach ($this->settings['ppd_user_type'] AS $ppd_user_type) {
            if ($ppd_user_type == $userTypeId) {
                return true;
            }
        }

        return false;
    }
    
    function userTypeLogPPD($userTypeId) {
        // if no data, assume user is allowed
        if (!isset($this->settings['ppd_user_type_log_ppd'])) {
            return true;
        }

        if (!is_array($this->settings['ppd_user_type_log_ppd'])) {
            return true;
        }

        foreach ($this->settings['ppd_user_type_log_ppd'] AS $ppd_user_type_log_ppd) {
            if ($ppd_user_type_log_ppd == $userTypeId) {
                return true;
            }
        }

        return false;
    }
    
    public function getAffiliateUser() {
        // get request
        $request = Request::createFromGlobals();
        
        // return the affiliate id if we have it
        if($request->cookies->has('source_aff_id')) {
            return $request->cookies->get('source_aff_id');
        }
        
        return false;
    }
    
    public function removeAffiliateCookie() {
        // don't use $request->cookies as it causes issues with the output in other
        // plugins (noticed with the Byteseller IPN failing)
        if (isset($_COOKIE['source_aff_id'])) {
            unset($_COOKIE['source_aff_id']); 
            setcookie('source_aff_id', null, -1, '/'); 
        }
        
        return false;
    }

}
