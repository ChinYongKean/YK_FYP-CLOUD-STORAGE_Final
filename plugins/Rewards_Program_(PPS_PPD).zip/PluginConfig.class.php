<?php

namespace Plugins\Rewards;

use App\Services\PluginConfig AS CorePluginConfig;

class PluginConfig extends CorePluginConfig
{
    /**
     * Setup the plugin config.
     *
     * @var array
     */
    public $config = array(
        'plugin_name' => 'Rewards Program',
        'folder_name' => 'rewards',
        'plugin_description' => 'Enable your users to make money by earning a percentage of referred paid upgrades or downloading files. (PPS/PPD).',
        'plugin_version' => '29.0',
        'required_script_version' => '5.0',
        'database_sql' => 'offline/database.sql',
    );

}
