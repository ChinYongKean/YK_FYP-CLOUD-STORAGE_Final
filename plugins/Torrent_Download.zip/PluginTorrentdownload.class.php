<?php

// plugin namespace

namespace Plugins\Torrentdownload;

// core includes
use App\Services\Plugin;
use App\Core\Database;
use App\Helpers\CoreHelper;
use App\Helpers\PluginHelper;
use App\Helpers\UserHelper;
use App\Models\User;
use Plugins\Torrentdownload\PluginConfig;
use Plugins\Torrentdownload\Models\PluginTorrentdownloadTorrent;
use Plugins\Torrentdownload\Models\PluginTorrentdownloadTorrentFile;
use Plugins\Torrentdownload\Libraries\TransmissionRPC;

class PluginTorrentdownload extends Plugin
{
    public $config = null;
    public $data = null;
    public $settings = null;

    public function __construct() {
        // load plugin config
        $this->config = (new PluginConfig())->getPluginConfig();
        $this->settings = $this->getPluginSettings();
    }

    public function registerRoutes(\FastRoute\RouteCollector $r) {
        // register plugin routes
        $r->addRoute(['GET', 'POST'], '/' . ADMIN_FOLDER_NAME . '/plugin/' . $this->config['folder_name'] . '/settings', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/pluginSettings');
        $r->addRoute(['GET'], '/' . ADMIN_FOLDER_NAME . '/torrent_manage', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/torrentManage');
        $r->addRoute(['GET'], '/' . ADMIN_FOLDER_NAME . '/ajax/torrent_manage', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxTorrentManage');
        $r->addRoute(['POST'], '/' . ADMIN_FOLDER_NAME . '/ajax/torrent_remove', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxTorrentRemove');
        $r->addRoute(['POST'], '/' . ADMIN_FOLDER_NAME . '/ajax/torrent_detail', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/ajaxTorrentDetail');
        
        $r->addRoute(['POST'], '/ajax/add_torrent', '\plugins\\' . $this->config['folder_name'] . '\controllers\TorrentdownloadController/ajaxAddTorrent');
        $r->addRoute(['GET'], '/ajax/existing_torrents', '\plugins\\' . $this->config['folder_name'] . '\controllers\TorrentdownloadController/ajaxExistingTorrents');
        $r->addRoute(['POST'], '/ajax/remove_torrent', '\plugins\\' . $this->config['folder_name'] . '\controllers\TorrentdownloadController/ajaxRemoveTorrent');
    }

    public function getPluginDetails() {
        return $this->config;
    }

    public function uninstall() {
        // setup database
        $db = Database::getDatabase();

        // remove plugin specific tables
        $sQL = 'DROP TABLE plugin_torrentdownload_torrent';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_torrentdownload_torrent_file';
        $db->query($sQL);

        return parent::uninstall();
    }

    public function connectUTorrent() {
        // utorrent library
        include_once(PLUGIN_DIRECTORY_ROOT . 'torrentdownload/libraries/uTorrentRemote.class.php');

        // connect torrent
        $uTorrentHost = $this->settings['utorrent_host'] . (strlen($this->settings['utorrent_port']) ?
                (':' . $this->settings['utorrent_port']) : '');
        $uTorrent = new \uTorrentRemote($uTorrentHost, $this->settings['utorrent_username'], $this->settings['utorrent_password']);

        return $uTorrent;
    }

    public function connectTransmission() {
        // connect transmission
        $rpc = new TransmissionRPC('http://' . $this->settings['transmission_host'] . ':' . $this->settings['transmission_port'] . '/transmission/rpc', $this->settings['transmission_username'], $this->settings['transmission_password']);

        return $rpc;
    }

    public function addUpdateTorrentUtorrent($torrentDetail, $userId) {
        // setup database
        $db = Database::getDatabase();

        // get torrent hash for lookups
        $torrentHash = strtoupper($torrentDetail[0]);

        // connect uTorrent
        $uTorrent = $this->connectUTorrent();

        // check for update or add
        $existingTorrent = $db->getRow('SELECT id '
                . 'FROM plugin_torrentdownload_torrent WHERE '
                . 'user_id = :user_id '
                . 'AND torrent_hash = :torrent_hash '
                . 'AND save_status=\'downloading\' '
                . 'LIMIT 1', array(
            'user_id' => (int) $userId,
            'torrent_hash' => $torrentHash,
        ));
        if ($existingTorrent) {
            // update torrent details
            $pluginTorrentdownloadTorrent = PluginTorrentdownloadTorrent::loadOneById($existingTorrent['id']);
            $pluginTorrentdownloadTorrent->status = $torrentDetail[21];
            $pluginTorrentdownloadTorrent->torrent_name = substr($torrentDetail[2], 0, 255);
            $pluginTorrentdownloadTorrent->torrent_size = $torrentDetail[3];
            $pluginTorrentdownloadTorrent->download_percent = $torrentDetail[4];
            $pluginTorrentdownloadTorrent->downloaded = (int)$torrentDetail[5];
            $pluginTorrentdownloadTorrent->uploaded = (int)$torrentDetail[6];
            $pluginTorrentdownloadTorrent->download_speed = (int)$torrentDetail[8];
            $pluginTorrentdownloadTorrent->upload_speed = (int)$torrentDetail[9];
            $pluginTorrentdownloadTorrent->time_remaining = (int)$torrentDetail[10];
            $pluginTorrentdownloadTorrent->save_path = strlen($torrentDetail[26])?$torrentDetail[26]:'';
            $pluginTorrentdownloadTorrent->peers_connected = (int)$torrentDetail[12];
            $pluginTorrentdownloadTorrent->peers_in_swarm = (int)$torrentDetail[13];
            $pluginTorrentdownloadTorrent->seeds_connected = (int)$torrentDetail[14];
            $pluginTorrentdownloadTorrent->seeds_in_swarm = (int)$torrentDetail[15];

            $rs = $pluginTorrentdownloadTorrent->save();

            $torrentFiles = $this->getUTorrentFileListing($torrentHash);
            if (is_countable($torrentFiles[1]) && count($torrentFiles[1])) {
                // delete any existing
                $db->query('DELETE '
                        . 'FROM plugin_torrentdownload_torrent_file '
                        . 'WHERE torrent_id = :torrent_id', array(
                    'torrent_id' => (int) $existingTorrent['id'],
                        )
                );

                // add new
                foreach ($torrentFiles[1] as $torrentFile) {
                    // add torrent details into database
                    $pluginTorrentdownloadTorrentFile = PluginTorrentdownloadTorrentFile::create();
                    $pluginTorrentdownloadTorrentFile->torrent_id = substr($existingTorrent['id'], 0, 255);
                    $pluginTorrentdownloadTorrentFile->file_name = $torrentFile[0];
                    $pluginTorrentdownloadTorrentFile->filesize = $torrentFile[1];
                    $pluginTorrentdownloadTorrentFile->save();
                }
            }

            return $rs;
        }
        else {
            // add torrent details into database
            $pluginTorrentdownloadTorrent = PluginTorrentdownloadTorrent::create();
            $pluginTorrentdownloadTorrent->user_id = (int) $userId;
            $pluginTorrentdownloadTorrent->torrent_hash = $torrentHash;
            $pluginTorrentdownloadTorrent->date_added = CoreHelper::sqlDateTime();
            $pluginTorrentdownloadTorrent->status = $torrentDetail[21];
            $pluginTorrentdownloadTorrent->torrent_name = substr($torrentDetail[2], 0, 255);
            $pluginTorrentdownloadTorrent->torrent_size = $torrentDetail[3];
            $pluginTorrentdownloadTorrent->download_percent = $torrentDetail[4];
            $pluginTorrentdownloadTorrent->downloaded = (int)$torrentDetail[5];
            $pluginTorrentdownloadTorrent->uploaded = (int)$torrentDetail[6];
            $pluginTorrentdownloadTorrent->download_speed = (int)$torrentDetail[8];
            $pluginTorrentdownloadTorrent->upload_speed = (int)$torrentDetail[9];
            $pluginTorrentdownloadTorrent->time_remaining = (int)$torrentDetail[10];
            $pluginTorrentdownloadTorrent->save_path = strlen($torrentDetail[26])?$torrentDetail[26]:'';
            $pluginTorrentdownloadTorrent->peers_connected = (int)$torrentDetail[12];
            $pluginTorrentdownloadTorrent->peers_in_swarm = (int)$torrentDetail[13];
            $pluginTorrentdownloadTorrent->seeds_connected = (int)$torrentDetail[14];
            $pluginTorrentdownloadTorrent->seeds_in_swarm = (int)$torrentDetail[15];

            return $pluginTorrentdownloadTorrent->save();
        }
    }

    public function addUpdateTorrentTransmission($torrentDetail, $userId) {
        // setup database
        $db = Database::getDatabase();

        // get torrent hash for lookups
        $torrentHash = strtoupper($torrentDetail->hashString);

        // connect transmission
        $rpc = $this->connectTransmission();

        // precent progress
		$percent = 0;
		if(isset($torrentDetail->downloadedEver) && (int)$torrentDetail->downloadedEver > 0) {
			$percent = floor(($torrentDetail->downloadedEver / $torrentDetail->totalSize) * 1000);
			if ($percent > 1000) {
				$percent = 1000;
			}
		}

        // check for update or add
        $existingTorrent = $db->getRow('SELECT id '
                . 'FROM plugin_torrentdownload_torrent WHERE '
                . 'user_id = :user_id '
                . 'AND torrent_hash = :torrent_hash '
                . 'AND save_status=\'downloading\' '
                . 'LIMIT 1', array(
            'user_id' => (int) $userId,
            'torrent_hash' => $torrentHash,
        ));

        if ($existingTorrent) {
            // update torrent details
            $pluginTorrentdownloadTorrent = PluginTorrentdownloadTorrent::loadOneById($existingTorrent['id']);
            $pluginTorrentdownloadTorrent->status = $rpc->getStatusString($torrentDetail->status);
            $pluginTorrentdownloadTorrent->torrent_name = substr($torrentDetail->name, 0, 255);
            $pluginTorrentdownloadTorrent->torrent_size = isset($torrentDetail->totalSize)?$torrentDetail->totalSize:0;
            $pluginTorrentdownloadTorrent->download_percent = $percent;
            $pluginTorrentdownloadTorrent->downloaded = isset($torrentDetail->downloadedEver)?(int)$torrentDetail->downloadedEver:0;
            $pluginTorrentdownloadTorrent->uploaded = isset($torrentDetail->uploadedEver)?(int)$torrentDetail->uploadedEver:0;
            $pluginTorrentdownloadTorrent->download_speed = isset($torrentDetail->rateDownload)?(int)$torrentDetail->rateDownload:0;
            $pluginTorrentdownloadTorrent->upload_speed = isset($torrentDetail->rateUpload)?(int)$torrentDetail->rateUpload:0;
            $pluginTorrentdownloadTorrent->time_remaining = isset($torrentDetail->eta)?(int)$torrentDetail->eta:0;
            $pluginTorrentdownloadTorrent->save_path = isset($torrentDetail->downloadDir) && strlen($torrentDetail->downloadDir)?$torrentDetail->downloadDir:'';
            $pluginTorrentdownloadTorrent->peers_connected = isset($torrentDetail->peersConnected)?(int)$torrentDetail->peersConnected:0;
            $pluginTorrentdownloadTorrent->peers_in_swarm = (isset($torrentDetail->peers) && is_countable($torrentDetail->peers))?count($torrentDetail->peers):0;
            $pluginTorrentdownloadTorrent->seeds_connected = (isset($torrentDetail->webseeds) && is_countable($torrentDetail->webseeds))?count($torrentDetail->webseeds):0;
            $pluginTorrentdownloadTorrent->seeds_in_swarm = 0;

            $rs = $pluginTorrentdownloadTorrent->save();

            if (is_countable($torrentDetail->files) && count($torrentDetail->files)) {
                // delete any existing
                $db->query('DELETE '
                        . 'FROM plugin_torrentdownload_torrent_file '
                        . 'WHERE torrent_id = :torrent_id', array(
                    'torrent_id' => (int) $existingTorrent['id'],
                        )
                );

                // add new
                foreach ($torrentDetail->files as $torrentFile) {
                    // add torrent details into database
                    $pluginTorrentdownloadTorrentFile = PluginTorrentdownloadTorrentFile::create();
                    $pluginTorrentdownloadTorrentFile->torrent_id = $existingTorrent['id'];
                    $pluginTorrentdownloadTorrentFile->file_name = $torrentFile->name;
                    $pluginTorrentdownloadTorrentFile->filesize = $torrentFile->length;
                    $pluginTorrentdownloadTorrentFile->save();
                }
            }

            return $rs;
        }
        else {
            // add torrent details into database
            $pluginTorrentdownloadTorrent = PluginTorrentdownloadTorrent::create();
            $pluginTorrentdownloadTorrent->user_id = (int) $userId;
            $pluginTorrentdownloadTorrent->torrent_hash = $torrentHash;
            $pluginTorrentdownloadTorrent->date_added = CoreHelper::sqlDateTime();
            $pluginTorrentdownloadTorrent->status = $rpc->getStatusString($torrentDetail->status);
            $pluginTorrentdownloadTorrent->torrent_name = substr($torrentDetail->name, 0, 255);
            $pluginTorrentdownloadTorrent->torrent_size = isset($torrentDetail->totalSize)?$torrentDetail->totalSize:0;
            $pluginTorrentdownloadTorrent->download_percent = $percent;
            $pluginTorrentdownloadTorrent->downloaded = (int)$torrentDetail->downloadedEver;
            $pluginTorrentdownloadTorrent->uploaded = (int)$torrentDetail->uploadedEver;
            $pluginTorrentdownloadTorrent->download_speed = (int)$torrentDetail->rateDownload;
            $pluginTorrentdownloadTorrent->upload_speed = (int)$torrentDetail->rateUpload;
            $pluginTorrentdownloadTorrent->time_remaining = (int)$torrentDetail->eta;
            $pluginTorrentdownloadTorrent->save_path = strlen($torrentDetail->downloadDir)?$torrentDetail->downloadDir:'';
            $pluginTorrentdownloadTorrent->peers_connected = (int)$torrentDetail->peersConnected;
            $pluginTorrentdownloadTorrent->peers_in_swarm = (isset($torrentDetail->peers) && is_countable($torrentDetail->peers))?count($torrentDetail->peers):0;
            $pluginTorrentdownloadTorrent->seeds_connected = (isset($torrentDetail->webseeds) && is_countable($torrentDetail->webseeds))?count($torrentDetail->webseeds):0;
            $pluginTorrentdownloadTorrent->seeds_in_swarm = 0;

            return $pluginTorrentdownloadTorrent->save();
        }
    }

    public function getUTorrentFileListing($torrentHash) {
        // connect
        $uTorrent = $this->connectUTorrent();

        // get files
        return $uTorrent->GrabListOfFiles($torrentHash);
    }

    public function validateAccountLimits() {
        // setup database
        $db = Database::getDatabase();

        // load plugin details
        $pluginDetails = PluginHelper::pluginSpecificConfiguration('torrentdownload');
        $pluginConfig = $pluginDetails['config'];
        $pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);
        $pluginInstance = PluginHelper::getInstance('torrentdownload');

        // get all pending/download torrents
        $localTorrentData = $db->getRows('SELECT users.level_id, plugin_torrentdownload_torrent.id AS torrent_id, '
                . 'plugin_torrentdownload_torrent.torrent_size, plugin_torrentdownload_torrent.torrent_hash, '
                . 'plugin_torrentdownload_torrent.user_id '
                . 'FROM plugin_torrentdownload_torrent '
                . 'LEFT JOIN users ON plugin_torrentdownload_torrent.user_id = users.id '
                . 'WHERE plugin_torrentdownload_torrent.save_status=\'downloading\' '
                . 'AND plugin_torrentdownload_torrent.torrent_size > 0');
        if ($localTorrentData) {
            foreach ($localTorrentData AS $localTorrentItem) {
                $cancelTorrent = false;
                $cancelReason = null;

                // make sure the user account wont go over storage limits
                $availableStorage = UserHelper::getAvailableFileStorage($localTorrentItem['user_id']);

                // allow for unlimited storage (return value is null)
                if ($availableStorage !== null) {
                    if ($localTorrentItem['torrent_size'] > $availableStorage) {
                        $cancelTorrent = true;
                        $cancelReason = 'Error: Torrent is larger than the available space within the account.';
                    }
                }

                if ($cancelTorrent == false) {
                    // if we should check filesize against account limits
                    if ((int) $pluginSettings['use_max_upload_settings'] == 1) {
                        // load user object so we can access the account level
                        $user = User::loadOneById($localTorrentItem['user_id']);

                        // make sure the user account is allowed to upload a file this size
                        $maxUploadSize = UserHelper::getMaxUploadFilesize($user->level_id);
                        if (($maxUploadSize > 0) && ($localTorrentItem['torrent_size'] > $maxUploadSize)) {
                            $cancelTorrent = true;
                            $cancelReason = 'Error: Torrent is larger that your max permitted upload size.';
                        }
                    }
                }

                // cancel torrent
                if ($cancelTorrent == true) {
                    $this->failTorrent($localTorrentItem['torrent_id'], $cancelReason);
                }
            }
        }
    }

    public function failTorrent($torrentId, $reason = null) {
        // setup database
        $db = Database::getDatabase();

        // load torrent details
        $torrentData = $db->getRow('SELECT * '
                . 'FROM plugin_torrentdownload_torrent WHERE id = :id '
                . 'LIMIT 1', array(
            'id' => (int) $torrentId,
        ));
        if ($torrentData) {
            // load plugin details
            $pluginDetails = PluginHelper::pluginSpecificConfiguration('torrentdownload');
            $pluginConfig = $pluginDetails['config'];
            $pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);
            $pluginInstance = PluginHelper::getInstance('torrentdownload');

            // utorrent
            if ($pluginSettings['torrent_server'] == 'utorrent') {
                // remove torrent from uTorrent
                $uTorrent = $this->connectUTorrent();
                $uTorrent->ExecAction('removedata', $torrentData['torrent_hash']);
            }
            // transmission
            elseif ($pluginSettings['torrent_server'] == 'transmission') {
                // remove torrent from transmission
                $rpc = $this->connectTransmission();
                $rpc->remove($torrentData['torrent_hash'], true);
            }

            // delete local record
            $db->query('DELETE '
                    . 'FROM plugin_torrentdownload_torrent_file '
                    . 'WHERE torrent_id = :id', array(
                'id' => $torrentData['id'],
            ));
            $db->query('UPDATE plugin_torrentdownload_torrent '
                    . 'SET save_status = "cancelled", '
                    . 'status_notes = :status_notes, '
                    . 'date_completed = NOW() '
                    . 'WHERE id = :id', array(
                'id' => $torrentData['id'],
                'status_notes' => $reason,
                    )
            );
        }

        return true;
    }

}
