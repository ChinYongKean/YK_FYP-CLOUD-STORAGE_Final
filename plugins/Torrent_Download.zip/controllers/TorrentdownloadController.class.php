<?php

namespace Plugins\Torrentdownload\Controllers;

use App\Core\BaseController;
use App\Core\Database;
use App\Models\File;
use App\Models\User;
use App\Helpers\CoreHelper;
use App\Helpers\FileServerHelper;
use App\Helpers\LogHelper;
use App\Helpers\PluginHelper;
use App\Helpers\TranslateHelper;
use Plugins\Torrentdownload\Libraries\TransmissionRPC;

class TorrentdownloadController extends BaseController
{

    public function ajaxExistingTorrents() {
        // require user login
        if (($response = $this->requireLogin()) !== false) {
            return $response;
        }

        // for later
        $Auth = $this->getAuth();
        $db = Database::getDatabase();
        $folderName = 'torrentdownload';

        // load plugin details
        $pluginDetails = PluginHelper::pluginSpecificConfiguration('torrentdownload');
        $pluginConfig = $pluginDetails['config'];
        $pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);
        $pluginInstance = PluginHelper::getInstance('torrentdownload');

        // get existing torrent downloads and any recent completed
        $torrents = $db->getRows('SELECT * '
                . 'FROM plugin_torrentdownload_torrent '
                . 'WHERE ((save_status = \'downloading\' OR save_status = \'pending\') AND user_id = :user_id) '
                . 'OR (date_completed IS NOT NULL AND date_completed >= DATE_SUB(NOW(), INTERVAL 2 day) '
                . 'AND user_id = :user_id) '
                . 'ORDER BY download_percent ASC', array(
            'user_id' => (int) $Auth->id,
        ));

        // load template
        return $this->render('account/existing_torrents.html', array(
                    'torrents' => $torrents,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function ajaxAddTorrent() {
        // require user login
        if (($response = $this->requireLogin()) !== false) {
            return $response;
        }

        // for later
        $Auth = $this->getAuth();
        $db = Database::getDatabase();
        $folderName = 'torrentdownload';

        // load plugin details
        $pluginDetails = PluginHelper::pluginSpecificConfiguration('torrentdownload');
        $pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);
        $pluginInstance = PluginHelper::getInstance('torrentdownload');

        // setup initial params
        $result = array();
        $result['error'] = false;
        $result['msg'] = '';

        $torrentUrl = trim($_REQUEST['urlTorrentList']);
        $torrentFile = $_FILES['torrentFile'];
        if ((strlen($torrentUrl) == 0) && (strlen($torrentFile['name']) == 0)) {
            $result['error'] = true;
            $result['msg'] = 'No torrent url or file attached.';
        }
        else {
            // check user has not reached their concurrent limits for downloading torrents
            $allowedConcurrent = (int) $pluginSettings['max_concurrent_free'];
            if ($Auth->level_id >= 2) {
                $allowedConcurrent = (int) $pluginSettings['max_concurrent_paid'];
            }
            $concurrentTorrents = $db->getValue('SELECT count(id) AS total '
                    . 'FROM plugin_torrentdownload_torrent '
                    . 'WHERE (save_status = \'downloading\' '
                    . 'AND user_id = :user_id)', array(
                'user_id' => (int) $Auth->id,
            ));
            if ($concurrentTorrents >= $allowedConcurrent) {
                $result['error'] = true;
                $result['msg'] = 'You have reached the maximum permitted concurrent torrent downloads '
                        . 'for your account type. Please try again when some have completed downloading.';
            }

            // check user has not reached their daily limits for downloading torrents
            if ($result['error'] == false) {
                $allowedDaily = (int) $pluginSettings['max_torrents_per_day_free'];
                if ($Auth->level_id >= 2) {
                    $allowedDaily = (int) $pluginSettings['max_torrents_per_day_paid'];
                }
                $daysTorrents = $db->getValue('SELECT count(id) AS total '
                        . 'FROM plugin_torrentdownload_torrent '
                        . 'WHERE user_id = :user_id '
                        . 'AND date_added >= NOW() - INTERVAL 1 DAY', array(
                    'user_id' => (int) $Auth->id,
                ));
                if ($daysTorrents >= $allowedDaily) {
                    $result['error'] = true;
                    $result['msg'] = 'You have reached the maximum permitted daily torrent downloads for your account type. Please try again later.';
                }
            }

            // check url
            if ($result['error'] == false) {
                if (strlen($torrentUrl) > 0) {
                    // extract hash from magnet link
                    preg_match('#magnet:\?xt=urn:btih:(?<hash>.*?)&tr=(?<trackers>.*?)$#', $torrentUrl, $torrentUrlParts);
                    $torrentHash = $torrentUrlParts['hash'];
                    if (strlen($torrentHash) == 0) {
                        $result['error'] = true;
                        $result['msg'] = 'Torrent url is invalid, please check and try again.';
                    }
					
					// ensure we remove anything after hash
					if(strpos($torrentHash, '&') !== false) {
						$torrentHash = substr($torrentHash, 0, strpos($torrentHash, '&'));
					}
                }
            }

            // check file
            if (($result['error'] == false) && ($torrentFile['size'] > 1024000)) {
                $result['error'] = true;
                $result['msg'] = 'Torrent file is too large.';
            }

            if ($result['error'] == false) {
                // utorrent
                if ($pluginSettings['torrent_server'] == 'utorrent') {
                    // utorrent library
                    include_once(PLUGIN_DIRECTORY_ROOT . 'torrentdownload/libraries/uTorrentRemote.class.php');

                    // add torrent
                    $uTorrentHost = $pluginSettings['utorrent_host'] . (strlen($pluginSettings['utorrent_port']) ?
                            (':' . $pluginSettings['utorrent_port']) : '');
                    $uTorrent = new \uTorrentRemote($uTorrentHost, $pluginSettings['utorrent_username'], $pluginSettings['utorrent_password']);
                    if (strlen($torrentUrl) > 0) {
                        // torrent url
                        $torrentInfo = $uTorrent->ExecAction('add-url', null, 0, 0, $torrentUrl);
                    }
                    else {
                        // get original torrent list
                        $torrentList = $uTorrent->GrabTorrents();
                        $torrentListArr = array();
                        if (count($torrentList)) {
                            foreach ($torrentList as $torrentListItem) {
                                $torrentListArr[] = $torrentListItem[0];
                            }
                        }

                        // save torrent file into local tmp, this is needed as there is sometimes issues with permissions on the system tmp directory
                        $tmpDir = FileServerHelper::getCurrentServerFileStoragePath() . '_tmp/';
                        if (!file_exists($tmpDir)) {
                            @mkdir($tmpDir);
                        }

                        if (!file_exists($tmpDir)) {
                            $result['error'] = true;
                            $result['msg'] = TranslateHelper::t('classuploader_failed_creating_tmp_storage_folder', 'Failed creating tmp storage folder for chunked uploads. Ensure the parent folder has write permissions: [[[TMP_DIR]]]', array('TMP_DIR' => $tmpDir));
                        }

                        if (!is_writable($tmpDir)) {
                            $result['error'] = true;
                            $result['msg'] = TranslateHelper::t('classuploader_temp_storage_folder_for_uploads_not_writable', 'Temp storage folder for uploads is not writable. Ensure it has CHMOD 755 or 777 permissions: [[[TMP_DIR]]]', array('TMP_DIR' => $tmpDir));
                        }
                        $newFilename = md5($torrentFile['tmp_name']);
                        $newFilePath = $tmpDir . $newFilename;

                        move_uploaded_file($torrentFile['tmp_name'], $newFilePath);

                        // file
                        $torrentInfo = $uTorrent->ExecAction('add-file', null, 0, 0, $newFilePath);
                        if ($torrentInfo) {
                            $torrentInfoArr = json_decode($torrentInfo, true);
                            if (isset($torrentInfoArr['error'])) {
                                $result['error'] = true;
                                $result['msg'] = $torrentInfoArr['error'];
                            }
                        }

                        // delete local tmp torrent file
                        @unlink($newFilePath);

                        // get torrent hash for later on
                        $torrentInfo = $uTorrent->GrabTorrents();
                        if (is_array($torrentInfo)) {
                            if (count($torrentListArr) == count($torrentInfo)) {
                                $result['error'] = true;
                                $result['msg'] = 'Failed adding torrent file, or it may already be being downloaded. Please try again later.';
                            }
                            else {
                                foreach ($torrentInfo as $torrentInfoItem) {
                                    if (!in_array($torrentInfoItem[0], $torrentListArr)) {
                                        $torrentHash = $torrentInfoItem[0];
                                    }
                                }
                            }
                        }
                    }

                    if ($result['error'] == false) {
                        // lookup to see if it was added
                        $torrentInfo = $uTorrent->GrabTorrents();
                        if (!is_array($torrentInfo)) {
                            $result['error'] = true;
                            $result['msg'] = 'Error: Problem getting response from uTorrent on host ' . $uTorrentHost .
                                    '. Please check the host, access details and that utorrent is running.';
                        }
                        else {
                            foreach ($torrentInfo as $torrentInfoItem) {
                                if (strtoupper($torrentInfoItem[0]) == strtoupper($torrentHash)) {
                                    $rs = $pluginInstance->addUpdateTorrentUtorrent($torrentInfoItem, $Auth->id);
                                    if (!$rs) {
                                        $result['error'] = true;
                                        $result['msg'] = 'Error: Failed scheduling torrent, please try again later.';
                                    }
                                }
                            }
                        }
                    }
                }
                // transmission
                elseif ($pluginSettings['torrent_server'] == 'transmission') {
                    // connect
                    try {
                        $rpc = new TransmissionRPC('http://' . $pluginSettings['transmission_host'] . ':' . $pluginSettings['transmission_port'] . '/transmission/rpc', $pluginSettings['transmission_username'], $pluginSettings['transmission_password']);
                    }
                    catch (\TransmissionRPCException $e) {
                        $result['error'] = true;
                        $result['msg'] = 'Failed connecting to torrent server. Please try again later';
                        LogHelper::error($e->getMessage());
                    }
                    catch (\Exception $e) {
                        $result['error'] = true;
                        $result['msg'] = 'Failed connecting to torrent server. Please try again later';
                        LogHelper::error($e->getMessage());
                    }

                    if ($result['error'] == false) {
                        // add by torrent/magnet url
                        if (strlen($torrentUrl) > 0) {
                            // add torrent
                            $resultTrans = $rpc->add($torrentUrl);
                            if ($resultTrans->result == 'download directory path is not absolute') {
                                $result['error'] = true;
                                $result['msg'] = 'Error: Download directory path is not absolute, please contact support for more information.';
                            }
                            else {
                                $torrentId = $resultTrans->arguments->torrent_added->id; // hashString also available
                            }
                        }
                        // add by torrent file data
                        else {
                            // get original torrent list
                            $torrentList = $rpc->get(array(), array("id", "name", "status", "doneDate", "haveValid", "totalSize", "hashString"));
                            $torrentListArr = array();
                            if (isset($torrentList->arguments->torrents)) {
                                if (count($torrentList->arguments->torrents)) {
                                    foreach ($torrentList->arguments->torrents as $torrentListItem) {
                                        $torrentListArr[] = $torrentListItem->hashString;
                                    }
                                }
                            }

                            // save torrent file into local tmp, this is needed as there is sometimes issues with permissions on the system tmp directory
                            $tmpDir = FileServerHelper::getCurrentServerFileStoragePath() . '_tmp/';
                            if (!file_exists($tmpDir)) {
                                @mkdir($tmpDir);
                            }

                            if (!file_exists($tmpDir)) {
                                $result['error'] = true;
                                $result['msg'] = TranslateHelper::t('classuploader_failed_creating_tmp_storage_folder', 'Failed creating tmp storage folder for chunked uploads. Ensure the parent folder has write permissions: [[[TMP_DIR]]]', array('TMP_DIR' => $tmpDir));
                            }

                            if (!is_writable($tmpDir)) {
                                $result['error'] = true;
                                $result['msg'] = TranslateHelper::t('classuploader_temp_storage_folder_for_uploads_not_writable', 'Temp storage folder for uploads is not writable. Ensure it has CHMOD 755 or 777 permissions: [[[TMP_DIR]]]', array('TMP_DIR' => $tmpDir));
                            }
                            $newFilename = md5($torrentFile['tmp_name']);
                            $newFilePath = $tmpDir . $newFilename;

                            move_uploaded_file($torrentFile['tmp_name'], $newFilePath);
                            $torrentContents = file_get_contents($newFilePath);
                            @unlink($newFilePath);

                            // file
                            $resultTrans = $rpc->add_metainfo($torrentContents);
                            $torrentId = $resultTrans->arguments->torrent_added->id; // hashString also available
                            if (!$resultTrans) {
                                $result['error'] = true;
                                $result['msg'] = 'Failed adding torrent. Please try again later';
                            }

                            // get torrent hash for later on
                            $torrentInfo = $rpc->get(array(), array(
                                "id",
                                "name",
                                "status",
                                "doneDate",
                                "haveValid",
                                "totalSize",
                                "hashString"));
                            if (isset($torrentInfo->arguments->torrents)) {
                                if (count($torrentListArr) == count($torrentInfo->arguments->torrents)) {
                                    $result['error'] = true;
                                    $result['msg'] = 'Failed adding torrent file, or it may already be being downloaded. Please try again later.';
                                }
                                else {
                                    foreach ($torrentInfo->arguments->torrents as $torrentInfoItem) {
                                        if (!in_array($torrentInfoItem->hashString, $torrentListArr)) {
                                            $torrentHash = $torrentInfoItem->hashString;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if ($result['error'] == false) {
                        // lookup to see if it was added
                        $torrentInfo = $rpc->get(array(), array(
                            "id",
                            "name",
                            "status",
                            "doneDate",
                            "haveValid",
                            "totalSize",
                            "hashString",
                            "status",
                            "name",
                            "totalSize",
                            "percentDone",
                            "downloadedEver",
                            "uploadedEver",
                            "rateDownload",
                            "rateUpload",
                            "leftUntilDone",
                            "peersConnected",
                            "webseeds",
                            "files"));
                        if (!isset($torrentInfo->arguments->torrents)) {
                            $result['error'] = true;
                            $result['msg'] = 'Error: Problem getting response from Transmission on host ' . $pluginSettings['transmission_host'] .
                                    '. Please check the host, access details and that Transmission is running.';
                        }
                        else {
                            foreach ($torrentInfo->arguments->torrents as $torrentInfoItem) {
                                if (strtoupper($torrentInfoItem->hashString) == strtoupper($torrentHash)) {
                                    $rs = $pluginInstance->addUpdateTorrentTransmission($torrentInfoItem, $Auth->id);
                                    if (!$rs) {
                                        $result['error'] = true;
                                        $result['msg'] = 'Error: Failed scheduling torrent, please try again later.';
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return $this->renderJson($result);
    }

    public function ajaxRemoveTorrent() {
        // require user login
        if (($response = $this->requireLogin()) !== false) {
            return $response;
        }

        // for later
        $Auth = $this->getAuth();
        $db = Database::getDatabase();
        $folderName = 'torrentdownload';
        $gRemoveTorrentId = (int) $_REQUEST['gRemoveTorrentId'];

        // load plugin details
        $pluginDetails = PluginHelper::pluginSpecificConfiguration('torrentdownload');
        $pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);
        $pluginInstance = PluginHelper::getInstance('torrentdownload');

        // prepare result
        $result = array();
        $result['error'] = false;
        $result['msg'] = '';

        // load torrent details
        $torrentData = $db->getRow('SELECT * '
                . 'FROM plugin_torrentdownload_torrent '
                . 'WHERE id = :id '
                . 'AND user_id = :user_id '
                . 'LIMIT 1', array(
            'user_id' => (int) $Auth->id,
            'id' => (int) $gRemoveTorrentId,
        ));
        if (!$torrentData) {
            $result['error'] = true;
            $result['msg'] = TranslateHelper::t("plugin_torrentdownload_could_not_find_torrent", "Could not find torrent.");
        }
        else {
            // utorrent
            if ($pluginSettings['torrent_server'] == 'utorrent') {
                // remove torrent from uTorrent
                $uTorrent = $pluginInstance->connectUTorrent();
                $uTorrent->ExecAction('removedata', $torrentData['torrent_hash']);
            }
            // transmission
            elseif ($pluginSettings['torrent_server'] == 'transmission') {
                // remove torrent from Transmission
                $rpc = $pluginInstance->connectTransmission();
                $rpc->remove($torrentData['torrent_hash'], true);
            }

            // delete local record
            $db->query('DELETE '
                    . 'FROM plugin_torrentdownload_torrent_file '
                    . 'WHERE torrent_id = :id', array(
                'id' => $torrentData['id'],
            ));
            $db->query('DELETE '
                    . 'FROM plugin_torrentdownload_torrent '
                    . 'WHERE id = :id', array(
                'id' => $torrentData['id'],
            ));
            if ($db->affectedRows() == 1) {
                $result['error'] = false;
                $result['msg'] = 'Torrent removed.';
            }
            else {
                $result['error'] = true;
                $result['msg'] = 'Could not remove torrent, please try again later.';
            }
        }

        return $this->renderJson($result);
    }

}
