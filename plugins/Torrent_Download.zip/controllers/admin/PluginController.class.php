<?php

namespace Plugins\Torrentdownload\Controllers\Admin;

use App\Core\Database;
use App\Controllers\Admin\PluginController AS CorePluginController;
use App\Helpers\AdminHelper;
use App\Helpers\CoreHelper;
use App\Helpers\PluginHelper;
use App\Helpers\TranslateHelper;
use App\Models\Plugin;

class PluginController extends CorePluginController
{

    public function pluginSettings() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // load plugin details
        $folderName = 'torrentdownload';
        $plugin = Plugin::loadOneByClause('folder_name = :folder_name', array(
                    'folder_name' => $folderName,
        ));

        if (!$plugin) {
            return $this->redirect(ADMIN_WEB_ROOT . '/plugin_manage?error=' . urlencode('There was a problem loading the plugin details.'));
        }

        // plugin object for functions
        $pluginObj = PluginHelper::getInstance('torrentdownload');

        // prepare variables
        $plugin_enabled = (int) $plugin->plugin_enabled;
        $utorrent_host = _CONFIG_SITE_HOST_URL;

        // remove port from host, if exists
        $url_parts = parse_url($utorrent_host);
        if (!isset($url_parts['host'])) {
            $utorrent_host = $url_parts['path'];
        }
        else {
            $utorrent_host = $url_parts['host'];
        }
        $utorrent_port = '8080';
        $utorrent_username = 'admin';
        $utorrent_password = '';
        $show_torrent_tab_paid = 1;
        $show_torrent_tab = 0;
        $max_torrents_per_day_free = 5;
        $max_concurrent_free = 1;
        $max_torrents_per_day_paid = 10;
        $max_concurrent_paid = 3;
        $use_max_upload_settings = 1;
        $torrent_server = 'transmission';
        $account_packages = array();

        // transmission settings
        $transmission_host = _CONFIG_SITE_HOST_URL;

        // remove port from host, if exists
        $url_parts = parse_url($transmission_host);
        if (!isset($url_parts['host'])) {
            $transmission_host = $url_parts['path'];
        }
        else {
            $transmission_host = $url_parts['host'];
        }

        $transmission_port = '9091';
        $transmission_username = 'admin';
        $transmission_password = '';

        // load existing settings
        if (strlen($plugin->plugin_settings)) {
            $plugin_settings = json_decode($plugin->plugin_settings, true);
            if ($plugin_settings) {
                $utorrent_host = $plugin_settings['utorrent_host'];
                $utorrent_port = $plugin_settings['utorrent_port'];
                $utorrent_username = $plugin_settings['utorrent_username'];
                $utorrent_password = $plugin_settings['utorrent_password'];
                $show_torrent_tab_paid = $plugin_settings['show_torrent_tab_paid'];
                $show_torrent_tab = $plugin_settings['show_torrent_tab'];
                $max_torrents_per_day_free = $plugin_settings['max_torrents_per_day_free'];
                $max_concurrent_free = $plugin_settings['max_concurrent_free'];
                $max_torrents_per_day_paid = $plugin_settings['max_torrents_per_day_paid'];
                $max_concurrent_paid = $plugin_settings['max_concurrent_paid'];
                $use_max_upload_settings = (int) $plugin_settings['use_max_upload_settings'];
                $torrent_server = isset($plugin_settings['torrent_server']) ? $plugin_settings['torrent_server'] : 'utorrent';
                $transmission_host = isset($plugin_settings['transmission_host']) ? $plugin_settings['transmission_host'] : $transmission_host;
                $transmission_port = isset($plugin_settings['transmission_port']) ? $plugin_settings['transmission_port'] : $transmission_port;
                $transmission_username = $plugin_settings['transmission_username'];
                $transmission_password = $plugin_settings['transmission_password'];
                $account_packages = $plugin_settings['account_packages'];
            }
        }

        // handle page submissions
        if ($request->request->has('submitted')) {
            // get variables
            $plugin_enabled = (int) $request->request->get('plugin_enabled');
            $plugin_enabled = $plugin_enabled != 1 ? 0 : 1;
            $utorrent_host = strtolower(trim($_REQUEST['utorrent_host']));
            $url_parts = parse_url($utorrent_host);
            if (!isset($url_parts['host'])) {
                $utorrent_host = $url_parts['path'];
            }
            else {
                $utorrent_host = $url_parts['host'];
            }

            $utorrent_port = (int) $_REQUEST['utorrent_port'];
            $utorrent_username = trim($_REQUEST['utorrent_username']);
            $utorrent_password = trim($_REQUEST['utorrent_password']);
            $show_torrent_tab_paid = isset($_REQUEST['show_torrent_tab_paid']) ? (int) $_REQUEST['show_torrent_tab_paid'] :
                    0;
            $show_torrent_tab = isset($_REQUEST['show_torrent_tab']) ? (int) $_REQUEST['show_torrent_tab'] :
                    0;
            $max_torrents_per_day_free = (int) $_REQUEST['max_torrents_per_day_free'];
            $max_concurrent_free = (int) $_REQUEST['max_concurrent_free'];
            $max_torrents_per_day_paid = (int) $_REQUEST['max_torrents_per_day_paid'];
            $max_concurrent_paid = (int) $_REQUEST['max_concurrent_paid'];
            $use_max_upload_settings = (int) $_REQUEST['use_max_upload_settings'];
            $torrent_server = $_REQUEST['torrent_server'];

            // transmission settings
            $transmission_host = strtolower(trim($_REQUEST['transmission_host']));
            $url_parts = parse_url($transmission_host);
            if (!isset($url_parts['host'])) {
                $transmission_host = $url_parts['path'];
            }
            else {
                $transmission_host = $url_parts['host'];
            }

            $transmission_port = (int) $_REQUEST['transmission_port'];
            $transmission_username = trim($_REQUEST['transmission_username']);
            $transmission_password = trim($_REQUEST['transmission_password']);

            // validate submission
            if (_CONFIG_DEMO_MODE == true) {
                AdminHelper::setError(AdminHelper::t('no_changes_in_demo_mode', 'No change permitted in demo mode.'));
            }

            // update the settings
            if (AdminHelper::isErrors() == false) {
                // compile new settings
                $settingsArr = array();
                $settingsArr['utorrent_host'] = $utorrent_host;
                $settingsArr['utorrent_port'] = $utorrent_port;
                $settingsArr['utorrent_username'] = $utorrent_username;
                $settingsArr['utorrent_password'] = $utorrent_password;
                $settingsArr['show_torrent_tab_paid'] = $show_torrent_tab_paid;
                $settingsArr['show_torrent_tab'] = $show_torrent_tab;
                $settingsArr['max_torrents_per_day_free'] = $max_torrents_per_day_free;
                $settingsArr['max_concurrent_free'] = $max_concurrent_free;
                $settingsArr['max_torrents_per_day_paid'] = $max_torrents_per_day_paid;
                $settingsArr['max_concurrent_paid'] = $max_concurrent_paid;
                $settingsArr['use_max_upload_settings'] = $use_max_upload_settings;
                $settingsArr['torrent_server'] = $torrent_server;
                $settingsArr['transmission_host'] = strlen($transmission_host) ? $transmission_host : '9091';
                $settingsArr['transmission_port'] = $transmission_port;
                $settingsArr['transmission_username'] = $transmission_username;
                $settingsArr['transmission_password'] = $transmission_password;
                $settingsArr['account_packages'] = $account_packages;

                // update the plugin settings
                $plugin->plugin_enabled = $plugin_enabled;
                $plugin->plugin_settings = json_encode($settingsArr);
                $plugin->save();

                // set onscreen alert
                PluginHelper::loadPluginConfigurationFiles(true);
                AdminHelper::setSuccess('Plugin settings updated.');
            }
        }

        if (_CONFIG_DEMO_MODE == true) {
            $utorrent_password = '****************';
            $transmission_password = '****************';
        }

        // prep torrent gui url        
        $torrent_gui_url = "http://" . $utorrent_host . ":" . $utorrent_port . "/gui/";
        if ($torrent_server == 'transmission') {
            $torrent_gui_url = "http://" . $transmission_host . ":" . $transmission_port;
        }

        // load template
        return $this->render('admin/plugin_settings.html', array(
                    'pluginName' => $plugin->plugin_name,
                    'yesNoOptions' => array(
                        0 => 'No',
                        1 => 'Yes'),
                    'torrentEngineOptions' => array(
                        'transmission' => 'Transmission (recommended)',
                        'utorrent' => 'uTorrent',
                    ),
                    'plugin_enabled' => $plugin_enabled,
                    'utorrent_host' => $utorrent_host,
                    'utorrent_port' => $utorrent_port,
                    'utorrent_username' => $utorrent_username,
                    'utorrent_password' => $utorrent_password,
                    'show_torrent_tab_paid' => $show_torrent_tab_paid,
                    'show_torrent_tab' => $show_torrent_tab,
                    'max_torrents_per_day_free' => $max_torrents_per_day_free,
                    'max_concurrent_free' => $max_concurrent_free,
                    'max_torrents_per_day_paid' => $max_torrents_per_day_paid,
                    'max_concurrent_paid' => $max_concurrent_paid,
                    'use_max_upload_settings' => $use_max_upload_settings,
                    'torrent_server' => $torrent_server,
                    'transmission_host' => $transmission_host,
                    'transmission_port' => $transmission_port,
                    'transmission_username' => $transmission_username,
                    'transmission_password' => $transmission_password,
                    'account_packages' => $account_packages,
                    'torrent_gui_url' => $torrent_gui_url,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function torrentManage() {
        // admin restrictions
        $this->restrictAdminAccess();

        // for later
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $folderName = 'torrentdownload';

        // get instance
        $pluginObj = PluginHelper::getInstance('torrentdownload');
        $torrentPluginSettings = $pluginObj->settings;

        // prepare filters
        $statusDetails = array(
            'downloading',
            'pending',
            'processing',
            'cancelled',
            'complete');
        $filterByStatus = '';

        // prepare full utorrent host url
        $uTorrentUrl = '';
        if (isset($torrentPluginSettings['utorrent_host'])) {
            $uTorrentUrl = $torrentPluginSettings['utorrent_host'];
            if ((isset($torrentPluginSettings['utorrent_port'])) && strlen($torrentPluginSettings['utorrent_port'])) {
                $uTorrentUrl .= ':' . $torrentPluginSettings['utorrent_port'];
            }
        }

        $torrentGuiUrl = $uTorrentUrl . '/gui/';
        if ($torrentPluginSettings['torrent_server'] == 'transmission') {
            $torrentGuiUrl = $torrentPluginSettings['transmission_host'] . ":" . $torrentPluginSettings['transmission_port'];
        }

        // load template
        return $this->render('admin/torrent_manage.html', array(
                    'statusDetails' => $statusDetails,
                    'filterByStatus' => $filterByStatus,
                    'uTorrentUrl' => $uTorrentUrl,
                    'torrentGuiUrl' => $torrentGuiUrl,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function ajaxTorrentManage() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $folderName = 'torrentdownload';
        $pluginObj = PluginHelper::getInstance($folderName);

        $iDisplayLength = (int) $request->query->get('iDisplayLength');
        $iDisplayStart = (int) $request->query->get('iDisplayStart');
        $sSortDir_0 = ($request->query->has('sSortDir_0') && $request->query->get('sSortDir_0') === 'asc') ? 'asc' : 'desc';
        $filterText = $_REQUEST['filterText'] ? $_REQUEST['filterText'] : null;
        $filterByStatus = $_REQUEST['filterByStatus'] ? $_REQUEST['filterByStatus'] : null;

        // get sorting columns
        $iSortCol_0 = (int) $request->query->get('iSortCol_0');
        $sColumns = trim($request->query->get('sColumns'));
        $arrCols = explode(",", $sColumns);
        $sortColumnName = $arrCols[$iSortCol_0];
        $sort = 'plugin_torrentdownload_torrent.torrent_name';
        switch ($sortColumnName) {
            case 'torrent_name':
                $sort = 'plugin_torrentdownload_torrent.torrent_name';
                break;
            case 'size':
                $sort = 'plugin_torrentdownload_torrent.torrent_size';
                break;
            case 'status':
                $sort = 'plugin_torrentdownload_torrent.save_status';
                break;
            case 'progress':
                $sort = 'plugin_torrentdownload_torrent.download_percent';
                break;
            case 'download_speed':
                $sort = 'plugin_torrentdownload_torrent.download_speed';
                break;
            case 'time_remaining':
                $sort = 'plugin_torrentdownload_torrent.time_remaining';
                break;
            case 'user':
                $sort = 'users.username';
                break;
        }

        $sqlClause = "WHERE 1=1 ";
        if ($filterText) {
            $filterText = strtolower($db->escape($filterText));
            $sqlClause .= "AND (LOWER(plugin_torrentdownload_torrent.torrent_name) LIKE '%" .
                    $filterText . "%' OR ";
            $sqlClause .= "LOWER(plugin_torrentdownload_torrent.save_status) = '" . $filterText .
                    "' OR ";
            $sqlClause .= "LOWER(users.username) = '" . $filterText . "')";
        }

        if ($filterByStatus) {
            $sqlClause .= ' AND plugin_torrentdownload_torrent.save_status = ' . $db->quote($filterByStatus);
        }

        $sQL = "SELECT plugin_torrentdownload_torrent.*, users.username AS username "
                . "FROM plugin_torrentdownload_torrent "
                . "LEFT JOIN users ON plugin_torrentdownload_torrent.user_id=users.id ";
        $sQL .= $sqlClause . " ";
        $totalRS = $db->getRows($sQL);

        $sQL .= "ORDER BY " . $sort . " " . $db->escape($sSortDir_0) . " ";
        $sQL .= "LIMIT " . $iDisplayStart . ", " . $iDisplayLength;
        $limitedRS = $db->getRows($sQL);

        $data = array();
        if (count($limitedRS) > 0) {
            foreach ($limitedRS AS $row) {
                $timeLeft = '-';
                if (($row['time_remaining'] != -1) && ($row['time_remaining'] != 0)) {
                    $timeLeft = CoreHelper::secsToHumanReadable($row['time_remaining']);
                    $timeLeft = str_replace(' ', '', $timeLeft);
                    $timeLeft = str_replace(array(TranslateHelper::t('weeks', 'weeks'), TranslateHelper::t('week', 'week')), 'w ', $timeLeft);
                    $timeLeft = str_replace(array(TranslateHelper::t('days', 'days'), TranslateHelper::t('day', 'day')), 'd ', $timeLeft);
                    $timeLeft = str_replace(array(TranslateHelper::t('hours', 'hours'), TranslateHelper::t('hour', 'hour')), 'h ', $timeLeft);
                    $timeLeft = str_replace(array(TranslateHelper::t('minutes', 'minutes'), TranslateHelper::t('minute', 'minute')), 'm ', $timeLeft);
                    $timeLeft = str_replace(array(TranslateHelper::t('seconds', 'seconds'), TranslateHelper::t('second', 'second')), 's ', $timeLeft);
                }

                $lRow = array();
                $icon = 'blue_arrow_down.png';
                if ($row['save_status'] == 'complete') {
                    $icon = 'accept.png';
                }
                elseif ($row['save_status'] == 'cancelled') {
                    $icon = 'block.png';
                }
                $lRow[] = '<img src="' . PLUGIN_WEB_ROOT . '/torrentdownload/assets/img/' . $icon .
                        '" width="16" height="16" title="' . UCWords($row['save_status']) . '" alt="' .
                        UCWords($row['save_status']) . '"/>';
                $lRow[] = '<a href="#" onClick="viewTorrentDetails(' . (int) $row['id'] .
                        '); return false;">' . AdminHelper::makeSafe($row['torrent_name']) . '</a>';
                $lRow[] = AdminHelper::makeSafe(CoreHelper::formatSize($row['torrent_size']));
                $lRow[] = AdminHelper::makeSafe(UCWords($row['save_status']));
                $lRow[] = AdminHelper::makeSafe(number_format($row['download_percent'] / 10, 2)) . ' %';
                $lRow[] = AdminHelper::makeSafe(CoreHelper::formatSize($row['download_speed'])) .
                        's /<br/>' . AdminHelper::makeSafe(CoreHelper::formatSize($row['upload_speed'])) .
                        's';
                $lRow[] = AdminHelper::makeSafe($timeLeft);
                $lRow[] = '<a href="' . ADMIN_WEB_ROOT . '/user_edit/' . $row['user_id'] .
                        '">' . AdminHelper::makeSafe($row['username']) . '</a>';

                $links = array();
                $links[] = '<a href="#" onClick="viewTorrentDetails(' . (int) $row['id'] .
                        '); return false;">torrent info</a>';
                if ($row['save_status'] == 'downloading') {
                    $links[] = '<a href="#" onClick="confirmRemoveTorrent(' . (int) $row['id'] .
                            '); return false;">cancel download</a>';
                }
                $lRow[] = implode("<br/>", $links);

                $data[] = $lRow;
            }
        }

        $resultArr = array();
        $resultArr["sEcho"] = intval($request->query->get('sEcho'));
        $resultArr["iTotalRecords"] = (int) count($totalRS);
        $resultArr["iTotalDisplayRecords"] = $resultArr["iTotalRecords"];
        $resultArr["aaData"] = $data;

        // output response
        return $this->renderJson($resultArr);
    }

    public function ajaxTorrentRemove() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $folderName = 'torrentdownload';
        $pluginObj = PluginHelper::getInstance($folderName);

        $gRemoveTorrentId = (int) $_REQUEST['gRemoveTorrentId'];

        // load plugin details
        $pluginDetails = PluginHelper::pluginSpecificConfiguration('torrentdownload');
        $pluginConfig = $pluginDetails['config'];
        $pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);
        $pluginInstance = PluginHelper::getInstance('torrentdownload');

        // prepare result
        $result = array();
        $result['error'] = false;
        $result['msg'] = '';

        if (_CONFIG_DEMO_MODE == true) {
            $result['error'] = true;
            $result['msg'] = AdminHelper::t("no_changes_in_demo_mode");
        }
        else {
            // load torrent details
            $torrentData = $db->getRow('SELECT * '
                    . 'FROM plugin_torrentdownload_torrent '
                    . 'WHERE id = :id '
                    . 'LIMIT 1', array(
                'id' => (int) $gRemoveTorrentId,
            ));
            if (!$torrentData) {
                $result['error'] = true;
                $result['msg'] = AdminHelper::t("plugin_torrentdownload_could_not_find_torrent", "Could not find torrent.");
            }
            else {
                // utorrent
                if ($pluginSettings['torrent_server'] == 'utorrent') {
                    // remove torrent from uTorrent
                    $uTorrent = $pluginInstance->connectUTorrent();
                    $uTorrent->ExecAction('removedata', $torrentData['torrent_hash']);
                }
                // transmission
                elseif ($pluginSettings['torrent_server'] == 'transmission') {
                    // remove torrent from Transmission
                    $rpc = $pluginInstance->connectTransmission();
                    $rpc->remove($torrentData['torrent_hash'], true);
                }

                // delete local record
                $db->query('DELETE '
                        . 'FROM plugin_torrentdownload_torrent_file '
                        . 'WHERE torrent_id = :id', array(
                    'id' => $torrentData['id'],
                        )
                );
                $db->query('DELETE '
                        . 'FROM plugin_torrentdownload_torrent '
                        . 'WHERE id = :id', array(
                    'id' => $torrentData['id'],
                        )
                );
                if ($db->affectedRows() == 1) {
                    $result['error'] = false;
                    $result['msg'] = 'Torrent removed.';
                }
                else {
                    $result['error'] = true;
                    $result['msg'] = 'Could not remove torrent, please try again later.';
                }
            }
        }

        // output response
        return $this->renderJson($result);
    }

    public function ajaxTorrentDetail() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $folderName = 'torrentdownload';

        $torrentId = (int) $_REQUEST['torrentId'];

        // load torrent details
        $torrentData = $db->getRow('SELECT plugin_torrentdownload_torrent.*, users.username AS username '
                . 'FROM plugin_torrentdownload_torrent '
                . 'LEFT JOIN users ON plugin_torrentdownload_torrent.user_id = users.id '
                . 'WHERE plugin_torrentdownload_torrent.id = :id '
                . 'LIMIT 1', array(
            'id' => $torrentId,
        ));

        // get torrent contents
        $torrentFiles = $db->getRows('SELECT * '
                . 'FROM plugin_torrentdownload_torrent_file '
                . 'WHERE torrent_id = :torrent_id', array(
            'torrent_id' => (int) $torrentData['id'],
        ));

        // load template
        return $this->render('admin/torrent_detail.html', array(
                    'torrentData' => $torrentData,
                    'torrentFiles' => $torrentFiles,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

}
