<?php

namespace Plugins\Torrentdownload\Controllers;

use App\Core\BaseController;
use App\Helpers\CoreHelper;
use App\Helpers\CrossSiteActionHelper;
use App\Helpers\FileHelper;
use App\Helpers\PluginHelper;
use App\Helpers\ThemeHelper;
use App\Helpers\TranslateHelper;
use App\Models\File;
use Plugins\Torrentdownload\Controllers\TorrentdownloadController;

class HooksController extends BaseController
{

    public function adminPluginNav($params = null) {
        // output within the admin left-hand navigation
        $navigation = array(
            array('link_url' => '#', 'link_text' => 'Torrents', 'link_key' => 'torrents', 'icon_class' => 'fa fa-globe', 'children' => array(
                    array('link_url' => 'admin/torrent_manage', 'link_text' => 'View Torrents', 'link_key' => 'torrentdownload_torrent_manage'),
                    array('link_url' => 'admin/plugin/torrentdownload/settings', 'link_text' => 'Plugin Settings', 'link_key' => 'torrentdownload_plugin_settings'),
                )),
        );

        // return array
        return $navigation;
    }

    public function adminPackageOptions($params = null) {
        // output within the admin left-hand navigation
        $navigation = array(
            array('field_label' => 'Max Torrents Per Day', 'field_name' => 'max_torrents_per_day', 'default_value' => 5, 'field_description' => 'Max torrent downloads permitted per day.', 'field_type' => 'integer'),
            array('field_label' => 'Max Concurrent Torrents', 'field_name' => 'max_concurrent_torrents', 'default_value' => 1, 'field_description' => 'Max concurrent torrents.', 'field_type' => 'integer'),
            array('field_label' => 'Use Max Upload Size', 'field_name' => 'use_max_upload_size', 'default_value' => 'yes', 'field_description' => 'Users can not add torrents larger than their account max upload size.', 'field_type' => 'select', 'available_values' => '["yes", "no"]'),
        );

        // return array
        return $navigation;
    }

    public function fileManagerTab($params = null) {
        // get user
        $Auth = $this->getAuth();

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('torrentdownload');
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);
        $doRedirect = true;
        if (((int) $pluginSettings['show_torrent_tab_paid'] === 1) && ($Auth->level_id <= 1)) {
            $doRedirect = false;
        }

        $showTab = false;
        if (((int) $pluginSettings['show_torrent_tab'] === 1) || ($doRedirect == true)) {
            $showTab = true;
        }

        // exit if we're not to show the tab
        if ($showTab === false) {
            return false;
        }

        // prepare any onclick
        $onclick = '';
        if ($doRedirect === false) {
            if ($Auth->loggedIn() === true) {
                $onclick = 'window.location=\'' . WEB_ROOT . '/upgrade\';';
            }
            else {
                $onclick = 'window.location=\'' . WEB_ROOT . '/register\';';
            }
        }

        return array(
            'torrentdownload' => array(
                'anchor' => 'torrentDownload',
                'icon' => 'glyphicon glyphicon-globe',
                'label' => TranslateHelper::t('torrent', 'torrent'),
                'onclick' => $onclick,
            ),
        );
    }

    public function fileManagerTabContent($params = null) {
        // get user
        $Auth = $this->getAuth();

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('torrentdownload');
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);
        $doRedirect = true;
        $nonPaid = true;
        if (((int) $pluginSettings['show_torrent_tab_paid'] === 1) && ($Auth->level_id <= 1)) {
            $doRedirect = false;
            $nonPaid = false;
        }

        $showTab = false;
        if (((int) $pluginSettings['show_torrent_tab'] === 1) || ($Auth->level_id >= 2)) {
            $showTab = true;
        }
        
        // exit if we're not to show the tab
        if ($showTab === false) {
            return false;
        }

        // load template
        return array(
            'response_html' => $this->getRenderedTemplate('file_manager_tab_content.html', array(
                'pluginConfig' => $pluginConfig,
                'nonPaid' => $nonPaid,
                'showTab' => $showTab,
                    ), PLUGIN_DIRECTORY_ROOT . 'torrentdownload/views')
        );
    }

}
