<?php

// Cron task to sync torrent information with uTorrent
// Also imports and deletes any finished torrents.
// Should be run every minute via the command line like this:
// * * * * * php /path/to/yetishare/plugins/torrentdownload/site/track_torrents.cron.php
// This cron script needs to be run on the same server as uTorrent
// Setup uTorrent so it saves in the _tmp folder:
//   /your/home/dir/path/public_html/files/_tmp
// setup includes

namespace Plugins\Torrentdownload\Tasks;

// include framework
use App\Core\Database;
use App\Core\Framework;
use App\Helpers\BackgroundTaskHelper;
use App\Helpers\FileHelper;
use App\Helpers\LogHelper;
use App\Helpers\PluginHelper;
use App\Models\File;
use App\Services\Uploader;
use Plugins\Torrentdownload\Libraries\TransmissionRPC;

require_once(realpath(dirname(__FILE__) . '/../../../app/core/Framework.class.php'));

// setup light environment
Framework::runLight();

// get database
$db = Database::getDatabase();

// background task logging
BackgroundTaskHelper::start();

// setup logging
LogHelper::setContext('plugin_torrentdownload');

// php script timeout for long file moves (12 hours)
set_time_limit(60 * 60 * 12);

// load plugin details
$pluginDetails = PluginHelper::pluginSpecificConfiguration('torrentdownload');
$pluginConfig = $pluginDetails['config'];
$pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);
$pluginInstance = PluginHelper::getInstance('torrentdownload');

// first delete any on uTorrent which don't exist in our local database
$localTorrentHashLookup = array();
$localTorrentData = $db->getRows('SELECT id, torrent_hash '
        . 'FROM plugin_torrentdownload_torrent');
if ($localTorrentData) {
    foreach ($localTorrentData as $localTorrentDataItem) {
        $localTorrentHashLookup[] = strtoupper($localTorrentDataItem['torrent_hash']);
    }
}

// utorrent
$uTorrent = null;
if ($pluginSettings['torrent_server'] == 'utorrent') {
    // utorrent library
    require_once (PLUGIN_DIRECTORY_ROOT . 'torrentdownload/libraries/uTorrentRemote.class.php');

    // connect
    $uTorrentHost = $pluginSettings['utorrent_host'] . (strlen($pluginSettings['utorrent_port']) ?
            (':' . $pluginSettings['utorrent_port']) : '');
	try {
		$uTorrent = new \uTorrentRemote($uTorrentHost, $pluginSettings['utorrent_username'], $pluginSettings['utorrent_password']);
	}
	catch (\Exception $e) {
		die('Error: '.$e->getMessage());
	}
	
    $torrentInfo = $uTorrent->GrabTorrents();
    if (is_array($torrentInfo)) {
        foreach ($torrentInfo as $torrentInfoItem) {
            // lookup locally
            if (!in_array(strtoupper($torrentInfoItem[0]), $localTorrentHashLookup)) {
                // remove torrent from uTorrent
                $uTorrent->ExecAction('removedata', $torrentInfoItem[0]);

                // log
                LogHelper::info('Removed torrent download on uTorrent as it was not found '
                        . 'in our Yetishare database. ' . print_r($torrentInfoItem, true));
            }
        }
    }
}
// transmission
elseif ($pluginSettings['torrent_server'] == 'transmission') {
    // connect
	try {
		$rpc = new TransmissionRPC('http://' . $pluginSettings['transmission_host'] . ':' . $pluginSettings['transmission_port'] . '/transmission/rpc', $pluginSettings['transmission_username'], $pluginSettings['transmission_password']);
	}
	catch (\Exception $e) {
		die('Error: '.$e->getMessage());
	}
	
    $torrentList = $rpc->get(array(), array(
        "id",
        "name",
        "status",
        "doneDate",
        "haveValid",
        "totalSize",
        "hashString"));
    $torrentListArr = array();
    if (isset($torrentList->arguments->torrents)) {
        if (count($torrentList->arguments->torrents)) {
            foreach ($torrentList->arguments->torrents as $torrentListItem) {
                // lookup locally
                if (!in_array(strtoupper($torrentListItem->hashString), $localTorrentHashLookup)) {
                    // remove torrent from transmission
                    $rpc->remove($torrentListItem->hashString, true);

                    // log
                    LogHelper::info('Removed torrent download on Transmission as it '
                            . 'was not found in our Yetishare database. ' . print_r($torrentListItem, true));
                }
            }
        }
    }
}

// sync data for 1 minute
$repeatUntil = time() + 20; // 20 seconds
$loops = 0; // failsafe
while ((time() < $repeatUntil) && ($loops < 30)) {
    syncData($db, $pluginSettings, $uTorrent, $rpc, $pluginInstance);
    $loops++;
    sleep(5);
}

function syncData($db, $pluginSettings, $uTorrent, $rpc, $pluginInstance) {
    // sync all data
    $localTorrentData = $db->getRows('SELECT id, torrent_hash, user_id '
            . 'FROM plugin_torrentdownload_torrent '
            . 'WHERE save_status=\'downloading\'');

    // utorrent
    if ($pluginSettings['torrent_server'] == 'utorrent') {
        $torrentInfo = $uTorrent->GrabTorrents();
        if ($localTorrentData) {
            foreach ($localTorrentData as $localTorrentDataItem) {
                // get hash and lookup from actual torrents
                $torrentHash = $localTorrentDataItem['torrent_hash'];
                foreach ($torrentInfo as $torrentInfoItem) {
                    // if we've found the hash on uTorrent, sync progress
                    if (strtoupper($torrentInfoItem[0]) == $torrentHash) {
                        // sync progress
                        $pluginInstance->addUpdateTorrentUtorrent($torrentInfoItem, $localTorrentDataItem['user_id']);
                    }
                }
            }
        }
    }
    // transmission
    elseif ($pluginSettings['torrent_server'] == 'transmission') {
        // connect
        $rpc = new TransmissionRPC('http://' . $pluginSettings['transmission_host'] . ':' . $pluginSettings['transmission_port'] . '/transmission/rpc', $pluginSettings['transmission_username'], $pluginSettings['transmission_password']);
        $torrentList = $rpc->get(array(), array(
            "id",
            "name",
            "status",
            "doneDate",
            "haveValid",
            "totalSize",
            "hashString",
            "status",
            "name",
            "totalSize",
            "percentDone",
            "downloadedEver",
            "uploadedEver",
            "rateDownload",
            "rateUpload",
            "leftUntilDone",
            "peersConnected",
            "webseeds",
            "files",
            "activityDate",
            "doneDate",
            "eta",
            "peers"));
        if ($localTorrentData) {
            foreach ($localTorrentData as $localTorrentDataItem) {
                // get hash and lookup from actual torrents
                $torrentHash = $localTorrentDataItem['torrent_hash'];
				if(isset($torrentList->arguments->torrents) && $torrentList->arguments->torrents !== null) {
					foreach ($torrentList->arguments->torrents as $torrentInfoItem) {
						// if we've found the hash on Transmission, sync progress
						if (strtoupper($torrentInfoItem->hashString) == $torrentHash) {
							// sync progress
							$pluginInstance->addUpdateTorrentTransmission($torrentInfoItem, $localTorrentDataItem['user_id']);
						}
					}
				}
            }
        }
    }

    // make sure all torrents are within the account limits
    $pluginInstance->validateAccountLimits();

    // update any completed downloading
    $db->query('UPDATE plugin_torrentdownload_torrent '
            . 'SET save_status=\'pending\' '
            . 'WHERE download_percent=1000 '
            . 'AND save_status=\'downloading\'');
}

// move any into storage which have a 'save_status' of 'pending'
$finishedItems = $db->getRows('SELECT * '
        . 'FROM plugin_torrentdownload_torrent '
        . 'WHERE save_status=\'pending\' '
        . 'ORDER BY id ASC '
        . 'LIMIT 1');
if ($finishedItems) {
    LogHelper::breakInLogFile();
    foreach ($finishedItems as $finishedItem) {
        // log
        LogHelper::info('Starting import process. Found finished torrent. ' . print_r($finishedItem, true));

        // set to processing
        $db->query('UPDATE plugin_torrentdownload_torrent '
                . 'SET save_status=\'processing\' '
                . 'WHERE id = :id '
                . 'LIMIT 1', array(
            'id' => (int) $finishedItem['id'],
        ));

        // create folder in users accounts to save files
        $fileNameParts = pathinfo($finishedItem['torrent_name']);

        // consider any other users also downloading it
        $usersDownloadingTorrent = $db->getRows('SELECT id, user_id '
                . 'FROM plugin_torrentdownload_torrent '
                . 'WHERE torrent_hash = :torrent_hash', array(
            'torrent_hash' => $finishedItem['torrent_hash'],
        ));

        // create folder in users account
        $userFolders = array();
        foreach ($usersDownloadingTorrent AS $usersDownloadingTorrentItem) {
            // check for existing folder
            $folderName = isset($fileNameParts['filename']) ? $fileNameParts['filename'] : $finishedItem['torrent_name'];
            $rs = $db->getRow('SELECT id '
                    . 'FROM file_folder '
                    . 'WHERE folderName = :folderName '
                    . 'AND userId = :userId', array(
                'folderName' => $folderName,
                'userId' => (int) $usersDownloadingTorrentItem['user_id'],
            ));
            if ($rs) {
                $folderName .= ' (' . date('H:i:s') . ')';
            }

            // add folder
            $db->query('INSERT INTO file_folder '
                    . '(folderName, isPublic, userId, parentId, accessPassword) VALUES (:folderName, :isPublic, :userId, :parentId, :accessPassword)', array(
                'folderName' => $folderName,
                'isPublic' => 0,
                'userId' => (int) $usersDownloadingTorrentItem['user_id'],
                'parentId' => null,
                'accessPassword' => '',
            ));

            // get folder id
            $folderId = (int) $db->getValue('SELECT id '
                            . 'FROM file_folder '
                            . 'WHERE folderName = :folderName '
                            . 'AND userId = :userId '
                            . 'LIMIT 1', array(
                        'folderName' => $folderName,
                        'userId' => (int) $usersDownloadingTorrentItem['user_id'],
            ));

            // log
            LogHelper::info('Created new directory for torrent contents called '
                    . '"' . $folderName . '" in account #' . (int) $usersDownloadingTorrentItem['user_id'] . '.');

            // keep for later
            $userFolders[] = array(
                'user_id' => $usersDownloadingTorrentItem['user_id'],
                'folder_id' => $folderId,
            );
        }

        // get actual file list
        $fileArr = array();

        // utorrent
        if ($pluginSettings['torrent_server'] == 'utorrent') {
            $fileList = $uTorrent->GrabListOfFiles($finishedItem['torrent_hash']);
            foreach ($fileList[1] as $fileListItem) {
                $fileArr[] = $finishedItem['save_path'] . '/' . $fileListItem[0];
            }
        }
        // transmission
        elseif ($pluginSettings['torrent_server'] == 'transmission') {
            // connect
            $rpc = new TransmissionRPC('http://' . $pluginSettings['transmission_host'] . ':' . $pluginSettings['transmission_port'] . '/transmission/rpc', $pluginSettings['transmission_username'], $pluginSettings['transmission_password']);
            $torrentList = $rpc->get(array(), array("id", "name", "status", "doneDate", "haveValid", "totalSize", "hashString", "files", "downloadDir"));
            foreach ($torrentList->arguments->torrents as $torrentInfoItem) {
                // check if we have a match
                if (strtoupper($torrentInfoItem->hashString) == strtoupper($finishedItem['torrent_hash'])) {
                    // get list of files
                    if (COUNT($torrentInfoItem->files)) {
                        // store in array
                        foreach ($torrentInfoItem->files as $torrentFile) {
                            $fileArr[] = $torrentInfoItem->downloadDir . '/' . $torrentFile->name;
                        }
                    }
                }
            }
        }

        // log
        LogHelper::info('List of files to import from torrent: ' . print_r($finishedItem, true) . ' ||| ' . print_r($fileArr, true) . '.');

        // move into storage
        if (count($fileArr)) {
            // loop files
            foreach ($fileArr as $fileArrItem) {
                // log
                LogHelper::info('Attempting import of file: ' . $fileArrItem);

                $fileUpload = new \stdClass();
                $fileNameParts = explode('/', $fileArrItem);
                $realFilename = trim(end($fileNameParts));
                $fileUpload->name = $realFilename;
                $fileUpload->size = filesize($fileArrItem);
                $mimeType = FileHelper::estimateMimeTypeFromExtension($fileUpload->name, 'application/octet-stream');
                if (($mimeType == 'application/octet-stream') && (class_exists('finfo', false))) {
                    $finfo = new \finfo;
                    $mimeType = $finfo->file($fileArrItem, FILEINFO_MIME);
                }
                $fileUpload->type = $mimeType;

                $uploader = new Uploader(
                        array(
                    'folder_id' => (int) $folderId,
                    'user_id' => (int) $finishedItem['user_id'],
                        )
                );
                $uploader->options['upload_source'] = 'torrent';
                // set to copy file rather than move it (3rd param) due to possible permissions issues with the torrent engine. It gets removed later.
                $fileUpload = $uploader->moveIntoStorage($fileUpload, $fileArrItem, true);

                // log
                LogHelper::setContext('plugin_torrentdownload');
                LogHelper::info('Import result: ' . print_r($fileUpload, true));

                // success
                if ($fileUpload->error === null) {
                    // update folder
                    $shortUrl = $fileUpload->short_url;
                    $db->query('UPDATE file '
                            . 'SET userId = :userId, '
                            . 'folderId = :folderId '
                            . 'WHERE BINARY shortUrl = :shortUrl '
                            . 'LIMIT 1', array(
                        'userId' => (int) $finishedItem['user_id'],
                        'folderId' => (int) $folderId,
                        'shortUrl' => $shortUrl,
                    ));
                }

                // duplicate file for other users
                if (COUNT($userFolders) > 1) {
                    $uploadedFileObj = File::loadOneByShortUrl($shortUrl);
                    foreach ($userFolders AS $userFolder) {
                        // skip original user
                        if ($userFolder['user_id'] == (int) $finishedItem['user_id']) {
                            continue;
                        }

                        // duplicate file
                        $copiedFileObj = $uploadedFileObj->duplicateFile();
                        if ($copiedFileObj) {
                            // update folder
                            $shortUrl = $copiedFileObj->short_url;
                            $db->query('UPDATE file '
                                    . 'SET userId = :userId, '
                                    . 'folderId = :folderId '
                                    . 'WHERE BINARY shortUrl = :shortUrl '
                                    . 'LIMIT 1', array(
                                'userId' => (int) $userFolder['user_id'],
                                'folderId' => (int) $userFolder['folder_id'],
                                'shortUrl' => $shortUrl,
                            ));
                        }
                    }
                }
            }
        }
        else {
            // log
            LogHelper::error('No files found to import on torrent: ' . print_r($finishedItem, true) . ' ||| ' . print_r($fileArr, true) . '.');
        }

        // set to complete
        $db->query('UPDATE plugin_torrentdownload_torrent '
                . 'SET save_status=\'complete\', '
                . 'status=\'Stopped\', '
                . 'date_completed=NOW() '
                . 'WHERE torrent_hash = :torrent_hash', array(
            'torrent_hash' => $finishedItem['torrent_hash'],
        ));

        // log
        LogHelper::info('Finished import file process.');

        // utorrent
        if ($pluginSettings['torrent_server'] == 'utorrent') {
            // remove torrent from uTorrent
            $uTorrent->ExecAction('removedata', $finishedItem['torrent_hash']);

            // log
            LogHelper::info('Removed torrent via uTorrent.');
        }
        // transmission
        elseif ($pluginSettings['torrent_server'] == 'transmission') {
            // remove torrent from transmission
            $rpc->remove($torrentListItem->hashString, true);

            // log
            LogHelper::info('Removed torrent via Transmission.');
        }

        // log
        LogHelper::info('End of process. ' . print_r($finishedItem, true));
        LogHelper::breakInLogFile();
    }
}

// clean up old torrent data
define('TORRENT_PLUGIN_KEEP_DATA_DAYS', 90);
$db->query("DELETE FROM plugin_torrentdownload_torrent_file "
        . "WHERE torrent_id IN (SELECT id FROM plugin_torrentdownload_torrent "
        . "WHERE date_completed < DATE_SUB(NOW(), INTERVAL " . TORRENT_PLUGIN_KEEP_DATA_DAYS . " day) "
        . "AND save_status = 'complete')");
$db->query("DELETE FROM plugin_torrentdownload_torrent "
        . "WHERE date_completed < DATE_SUB(NOW(), INTERVAL " . TORRENT_PLUGIN_KEEP_DATA_DAYS . " day) "
        . "AND save_status = 'complete'");

// background task logging
BackgroundTaskHelper::end();
