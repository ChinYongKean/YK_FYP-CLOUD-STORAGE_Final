ALTER TABLE  `plugin_torrentdownload_torrent` ADD  `status_notes` VARCHAR( 255 ) NULL AFTER  `save_status`;
