<?php

namespace Plugins\Torrentdownload\Models;

use App\Core\Model;

class PluginTorrentdownloadTorrentFile extends Model
{
    
}
