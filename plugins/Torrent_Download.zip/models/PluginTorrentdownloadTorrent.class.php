<?php

namespace Plugins\Torrentdownload\Models;

use App\Core\Model;

class PluginTorrentdownloadTorrent extends Model
{
    
}
