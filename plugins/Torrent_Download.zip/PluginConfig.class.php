<?php

namespace Plugins\Torrentdownload;

use App\Services\PluginConfig AS CorePluginConfig;

class PluginConfig extends CorePluginConfig
{
    /**
     * Setup the plugin config.
     *
     * @var array
     */
    public $config = array(
        'plugin_name' => 'Torrent Download',
        'folder_name' => 'torrentdownload',
        'plugin_description' => 'Allow your users to download torrents or magnet links directly into their account.',
        'plugin_version' => '13.0',
        'required_script_version' => '5.0',
        'database_sql' => 'offline/database.sql',
    );

}
