<?php

namespace Plugins\Skrill;

use App\Services\PluginConfig AS CorePluginConfig;

class PluginConfig extends CorePluginConfig
{
    /**
     * Setup the plugin config.
     *
     * @var array
     */
    public $config = array(
        'plugin_name' => 'Skrill Payment Integration',
        'folder_name' => 'skrill',
        'plugin_description' => 'Accept payments using Skrill.',
        'plugin_version' => '5.0',
        'required_script_version' => '5.0',
    );

}
