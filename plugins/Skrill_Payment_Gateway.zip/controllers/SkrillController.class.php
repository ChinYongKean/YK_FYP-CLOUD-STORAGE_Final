<?php

namespace Plugins\Skrill\Controllers;

use App\Core\BaseController;
use App\Core\Database;
use App\Models\File;
use App\Models\Order;
use App\Models\PaymentLog;
use App\Models\User;
use App\Helpers\CoreHelper;
use App\Helpers\LogHelper;
use App\Helpers\OrderHelper;
use App\Helpers\PluginHelper;
use App\Helpers\UserHelper;

class SkrillController extends BaseController
{

    public function upgradeBox($params = array()) {
        // pickup request for later
        $request = $this->getRequest();

        // load template
        return $this->render('upgrade_box.html', array_merge($params, array(
                    'folder_name' => 'skrill',
                    'gateway_label' => 'Skrill',
                    'i' => $request->query->has('i') ? $request->query->get('i') : '',
                    'f' => $request->query->has('f') ? $request->query->get('f') : '',
                        )), PLUGIN_DIRECTORY_ROOT . 'skrill/views');
    }

    public function pay($params = array()) {
        // pickup request for later
        $request = $this->getRequest();

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('skrill');
        $pluginSettings = $pluginConfig['data']['plugin_settings'];
        $skrillEmail = '';
        if (strlen($pluginSettings)) {
            $pluginSettingsArr = json_decode($pluginSettings, true);
            $skrillEmail = $pluginSettingsArr['skrill_email'];
        }

        if (!$request->request->has('user_level_pricing_id')) {
            return $this->redirect(WEB_ROOT);
        }

        // require login
        if ($request->request->has('i') && strlen($request->request->get('i'))) {
            $user = User::loadOneByClause('identifier = :identifier', array(
                        'identifier' => $request->request->get('i')
            ));
            if (!$user) {
                return $this->redirect(CoreHelper::getCoreSitePath() . "/error?e=" . urlencode('Could not load user based on identifier, please contact support.'));
            }

            // setup variables for later
            $userId = $user->id;
            $username = $user->username;
            $userEmail = $user->email;
        }
        else {
            if (($response = $this->requireLogin('/register', 1)) !== false) {
                return $response;
            }

            // setup variables for later
            $Auth = $this->getAuth();
            $userId = $Auth->id;
            $username = $Auth->username;
            $userEmail = $Auth->email;
        }

        $userLevelPricingId = (int) $request->request->get('user_level_pricing_id');

        // check if we have a referring file
        $fileId = null;
        if ($request->request->has('f') && strlen($request->request->get('f'))) {
            $file = File::loadOneByShortUrl($request->request->get('f'));
            if ($file) {
                $fileId = $file->id;
            }
        }

        // create order entry
        $order = OrderHelper::createByPackageId($userId, $userLevelPricingId, $fileId);
        if ($order) {
            // redirect to the payment gateway
            $postUrl = 'https://pay.skrill.com';

            // get form content
            return $this->render('payment_form_redirect.html', array_merge($params, array(
                        'order' => $order,
                        'postUrl' => $postUrl,
                        'skrillEmail' => $skrillEmail,
                        'username' => $username,
                        'shortSiteName' => substr(SITE_CONFIG_SITE_NAME, 0, 30),
                            )), PLUGIN_DIRECTORY_ROOT . 'skrill/views');
        }

        // fallback
        return $this->redirect(CoreHelper::getCoreSitePath() . "/error?e=" . urlencode('Failed creating order, please try again later.'));
    }

    public function paymentIpn($params = array()) {
        // pickup request for later
        $request = $this->getRequest();

        // log response
        LogHelper::setContext('skrill');
        LogHelper::info('Received called back on IPN: ' . print_r($_REQUEST, true));

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('skrill');
        $pluginSettings = $pluginConfig['data']['plugin_settings'];
        $skrillEmail = '';
        if (strlen($pluginSettings)) {
            $pluginSettingsArr = json_decode($pluginSettings, true);
            $skrillEmail = $pluginSettingsArr['skrill_email'];
        }

        // check for some required variables in the request
        if (!$request->request->has('status') || !$request->request->has('pay_to_email')) {
            return $this->renderEmpty200Response();
        }

        // make sure payment has completed and it's for the correct Skrill account
        if (($request->request->get('status') == 2) && (strtolower($request->request->get('pay_to_email')) == $skrillEmail)) {
            // load order using custom payment tracker hash
            $paymentTracker = $request->request->get('custom');

            // log
            LogHelper::info('Order is complete, loading based on order tracker "' . $paymentTracker . '"');

            // load order
            $order = OrderHelper::loadByPaymentTracker($paymentTracker);
            if ($order) {
                // log
                LogHelper::info('Loaded order id "' . $order->id . '"');

                $extendedDays = $order->days;
                $userId = $order->user_id;
                $upgradeUserId = $order->upgrade_user_id;
                $orderId = $order->id;

                // retain all posted gateway parameters
                $gatewayVars = "";
                foreach ($_REQUEST AS $k => $v) {
                    $gatewayVars .= $k . " => " . $v . "\n";
                }

                // insert payment log
                $paymentLog = PaymentLog::create();
                $paymentLog->user_id = $userId;
                $paymentLog->date_created = date("Y-m-d H:i:s", time());
                $paymentLog->amount = $request->request->get('mb_amount');
                $paymentLog->currency_code = $request->request->get('mb_currency');
                $paymentLog->from_email = $request->request->get('pay_from_email');
                $paymentLog->to_email = $request->request->get('pay_to_email');
                $paymentLog->description = $order->description;
                $paymentLog->request_log = $gatewayVars;
                $paymentLog->payment_method = 'Skrill';
                $paymentLog->save();

                // make sure the amount paid matched what we expect
                if ($request->request->get('mb_amount') != $order->amount) {
                    // order amounts did not match
                    LogHelper::info('Failed - order amounts did not match');

                    return $this->renderEmpty200Response();
                }

                // make sure the order is pending
                if ($order->order_status == 'completed') {
                    // order has already been completed
                    LogHelper::info('Failed - order has already been completed');

                    return $this->renderEmpty200Response();
                }

                // update order status to paid
                $order->order_status = 'completed';
                if ($order->save() === false) {
                    // failed to update order
                    LogHelper::info('Failed - failed to update order');

                    return $this->renderEmpty200Response();
                }

                // log
                LogHelper::info('Updated order, extending account.');

                // extend/upgrade user
                $rs = UserHelper::upgradeUserByPackageId($userId, $order);
                if ($rs === false) {
                    // failed to update user
                    LogHelper::info('Failed - failed to update user');

                    return $this->renderEmpty200Response();
                }

                // log
                LogHelper::info('Account upgrade process complete.');

                // append any plugin includes
                PluginHelper::callHook('postUpgradePaymentIpn', array(
                    'order' => $order,
                ));
            }
        }
        else {
            // log
            LogHelper::info('Order is either not complete or Skrill email address does not match.');
        }

        return $this->renderEmpty200Response();
    }

}
