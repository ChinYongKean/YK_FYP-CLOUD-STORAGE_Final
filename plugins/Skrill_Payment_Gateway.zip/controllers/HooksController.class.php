<?php

namespace Plugins\Skrill\Controllers;

use App\Core\BaseController;
use App\Helpers\CoreHelper;
use App\Helpers\FileHelper;
use App\Helpers\PluginHelper;
use App\Helpers\ThemeHelper;
use App\Models\File;
use Plugins\Skrill\Controllers\SkrillController;

class HooksController extends BaseController
{

    public function upgradeBoxes($params = null) {
        // call the controller to create the upgrade box
        $skrillController = new SkrillController();
        $response = $skrillController->upgradeBox($params);
        
        // return response object
        return $response;
    }

}
