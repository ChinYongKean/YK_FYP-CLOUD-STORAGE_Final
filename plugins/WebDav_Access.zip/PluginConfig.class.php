<?php

namespace Plugins\Webdav;

use App\Services\PluginConfig AS CorePluginConfig;

class PluginConfig extends CorePluginConfig
{
    /**
     * Setup the plugin config.
     *
     * @var array
     */
    public $config = array(
        'plugin_name' => 'WebDav File Access (Mobile, Tablet & Desktop)',
        'folder_name' => 'webdav',
        'plugin_description' => 'View and manage your files on Mobile, Tablet & Desktop.',
        'plugin_version' => '11.0',
        'required_script_version' => '5.0',
    );

}
