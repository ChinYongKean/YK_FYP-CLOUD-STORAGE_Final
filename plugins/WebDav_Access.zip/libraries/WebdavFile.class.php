<?php

namespace Plugins\Webdav\Libraries;

use App\Core\Database;
use App\Helpers\AuthHelper;
use App\Helpers\FileHelper;
use App\Helpers\LogHelper;
use App\Models\File;
use Plugins\Webdav\Libraries\WebdavHelper;
use Sabre\DAV\File AS DavFile;
use Sabre\DAV\IProperties;

/**
 * WebdavFile
 *
 * @author Adam Wilson
 */
class WebdavFile extends DavFile implements IProperties
{
    public $fileObj;

    function __construct($fileObj) {
        $this->fileObj = $fileObj;
        $mutations = array(
            '{DAV:}isreadonly' => 1,
            '{DAV:}ishidden' => 1,
            '{urn:schemas-microsoft-com:}Win32FileAttributes' => 0,
        );
        $this->updateProperties($mutations);
    }

    function getName() {
        return $this->fileObj->originalFilename;
    }

    function updateProperties($mutations) {
        // for later
    }

    function getProperties($properties) {
        return $properties;
    }

    // call on an edit or file creation (after createFile)
    function put($data) {
        // check for rw access
        WebdavHelper::checkUserHasWrite();

        // save temp copy locally
        $tmpFName = tempnam(sys_get_temp_dir(), MD5(microtime()));
        file_put_contents($tmpFName, $data);

        // get api key
        $db = Database::getDatabase();
        $coreAuth = AuthHelper::getAuth();
        $apiKey = $coreAuth->user->apikey;
        if (strlen($apiKey) == 0) {
            $apiKey = $db->getValue("SELECT apikey "
                    . "FROM users "
                    . "WHERE id = :id "
                    . "LIMIT 1", array(
                'id' => (int) $coreAuth->user->id,
            ));
            if (!$apiKey) {
                // no api key so add it
                $apiKey = md5(microtime() . $this->userId . microtime());
                $db->query('UPDATE users '
                        . 'SET apikey = :apikey '
                        . 'WHERE id = :id '
                        . 'AND username = :username '
                        . 'LIMIT 1', array(
                    'apikey' => $apiKey,
                    'id' => (int) $coreAuth->user->id,
                    'username' => $coreAuth->user->username,
                ));
            }
        }

        // prepare the params
        $post = array();
        $post['file_id'] = $this->fileObj->id;
        $post['api_key'] = $apiKey;
        $post['username'] = $coreAuth->username;
        $post['action'] = 'update_file_content';
        //$post['files']    = '@' . $tmpFName;
        $post['files'] = curl_file_create($tmpFName, null, $this->getName());

        // simulate posting the file using curl
        $url = FileHelper::getUploadUrl() . '/api_upload_handler';
        LogHelper::info('Curl request to: ' . $url);
        LogHelper::info('Curl params: ' . print_r($post, true));

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
        curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        //curl_setopt($ch, CURLOPT_HEADER, 1);
        //$headers = array(
        //    'Transfer-Encoding: chunked',
        //);
        //curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        //curl_setopt($ch, CURLOPT_PROGRESSFUNCTION, 'curlProgress');
        curl_setopt($ch, CURLOPT_NOPROGRESS, true);
        //curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        $msg = curl_exec($ch);
        $error = '';
        if (curl_errno($ch)) {
            $error = 'Error uploading file to ' . $url . ': ' . curl_error($ch);
        }
        else {
            // try to read the json response
            if (strlen($msg) == 0) {
                $error = 'Error uploading file. No response received from: ' . $url;
            }
            else {
                $responseArr = json_decode($msg, true);
                if (is_array($responseArr)) {
                    // got data as array
                    if (isset($responseArr[0]['error'])) {
                        $error = 'Error on: ' . $url . '. ' . $responseArr[0]['error'];
                    }
                }
                else {
                    $error = 'Failed reading response from: ' . $url . '. Response: ' . $msg;
                }
            }
        }

        // close curl
        curl_close($ch);

        // clear temp file
        unlink($tmpFName);

        // error
        if (strlen($error)) {
            // log
            LogHelper::error($error);

            return true;
        }

        // if we've got this part assume everything has gone well and we have file info in $responseArr
        LogHelper::info('Result: ' . print_r($responseArr, true));

        return true;
    }

    function get() {
        // generate no limits download url
        $downloadToken = $this->fileObj->generateDirectDownloadToken(0, 0);
        if (!$downloadToken) {
            // fail
            return false;
        }

        // compile full url
        $downloadUrl = $this->fileObj->getFullShortUrl(true) . '?' . File::DOWNLOAD_TOKEN_VAR . '=' . $downloadToken;
        if ($downloadUrl) {
            $contextOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false
                )
            );

            if (!ini_get('allow_url_fopen')) {
                LogHelper::error('Config value allow_url_fopen is not enabled within php.ini, please enable this.');

                return false;
            }

            return fopen($downloadUrl, 'rb', false, stream_context_create($contextOptions));
        }

        return false;
    }

    function getSize() {
        return $this->fileObj->fileSize;
    }

    function setName($newName) {
        // check for rw access
        WebdavHelper::checkUserHasWrite();

        // setup database
        $db = Database::getDatabase();

        // check for existing file named the same
        $rs = $db->getRow('SELECT id '
                . 'FROM file '
                . 'WHERE originalFilename = :originalFilename '
                . 'AND userId = :userId '
                . 'AND id != :id '
                . 'AND folderId = :folderId '
                . 'LIMIT 1', array(
            'originalFilename' => $newName,
            'userId' => (int) $this->fileObj->userId,
            'id' => $this->fileObj->id,
            'folderId' => $this->fileObj->folderId,
        ));
        if ($rs) {
            if (COUNT($rs)) {
                throw new Exception\Conflict('File already exists called: ' . $newName);
            }
        }

        // extract extension
        $extension = strtolower(pathinfo($newName, PATHINFO_EXTENSION));

        // figure out mime type
        $mimeType = FileHelper::estimateMimeTypeFromExtension($newName);

        // rename folder in database
        $rs = $db->query('UPDATE file '
                . 'SET originalFilename = :originalFilename, '
                . 'extension = :extension, '
                . 'fileType = :fileType '
                . 'WHERE userId = :userId '
                . 'AND id = :id '
                . 'LIMIT 1', array(
            'originalFilename' => $newName,
            'extension' => $extension,
            'fileType' => $mimeType,
            'userId' => (int) $this->fileObj->userId,
            'id' => $this->fileObj->id,
        ));
        if ($rs) {
            return true;
        }

        return false;
    }

    function getContentType() {
        return $this->fileObj->fileType;
    }

    // @TODO - set to modified date when available in 'file' table
    function getLastModified() {
        return strtotime($this->fileObj->date_updated == null?$this->fileObj->uploadedDate:$this->fileObj->date_updated);
    }

    public function getETag() {
        if (strlen($this->fileObj->fileHash)) {
            //return '"' . $this->fileObj->fileHash . '"';
            return '"' . time() . $this->fileObj->fileHash . '"';
        }

        return null;
    }

    public function delete() {
        // check for rw access
        WebdavHelper::checkUserHasWrite();

        return $this->fileObj->trashByUser();
    }

}
