<?php

namespace Plugins\Webdav\Libraries;

use Sabre\DAV\Exception;

/**
 * WebdavHelper
 *
 * @author Adam Wilson
 */
class WebdavHelper
{
    public static $accessLevel = 'none';

    public static function setAccessLevel($accessLevel = 'none') {
        self::$accessLevel = $accessLevel;
    }

    public static function getAccessLevel() {
        return self::$accessLevel;
    }

    public static function checkUserHasWrite() {
        // check for demo mode
        if (_CONFIG_DEMO_MODE == true) {
            throw new Exception\Forbidden('Permission denied');
        }

        // check user has permissions
        if (self::getAccessLevel() != 'rw') {
            throw new Exception\Forbidden('Permission denied');
        }

        return true;
    }

}
