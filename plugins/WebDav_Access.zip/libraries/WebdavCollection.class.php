<?php

namespace Plugins\Webdav\Libraries;

use App\Core\Database;
use App\Helpers\AuthHelper;
use App\Helpers\FileHelper;
use App\Helpers\FileFolderHelper;
use App\Helpers\LogHelper;
use App\Helpers\UserHelper;
use App\Models\File;
use App\Models\FileFolder;
use Plugins\Webdav\Libraries\WebdavFile;
use Plugins\Webdav\Libraries\WebdavHelper;
use Sabre\DAV\Collection;
use Sabre\DAV\Exception;
use Sabre\DAV\IQuota;

/**
 * WebdavCollection
 *
 * @author Adam Wilson
 */
class WebdavCollection extends Collection implements IQuota
{
    public $folderObj;
    private $userId = null;

    function __construct($folderObj = null) {
        $this->folderObj = $folderObj;

        // core auth object
        $coreAuth = AuthHelper::getAuth();
        $this->userId = $coreAuth->id;
    }

    function getQuotaInfo() {
        // get account stats
        $totalFreeSpace = UserHelper::getAvailableFileStorage($Auth->id);

        // get total used space
        $result['totalActiveFileSize'] = FileHelper::getTotalActiveFileSizeByUser($Auth->id);

        if (!empty($result['totalActiveFileSize'])) {
            
        }
        else {
            $result['totalActiveFileSize'] = "0";
        }

        // not functioning currently
        return array($result['totalActiveFileSize'], $totalFreeSpace);
    }

    function getChildren() {
        // setup database
        $db = Database::getDatabase();

        // get folders
        $children = array();
        $folders = $db->getRows('SELECT * '
                . 'FROM file_folder '
                . 'WHERE userId = :userId '
                . 'AND parentId ' . ($this->folderObj === null ? 'IS NULL' : '= ' . $this->folderObj->id) . ' '
                . 'AND status = "active" '
                . 'ORDER BY folderName', array(
            'userId' => $this->userId,
        ));
        foreach ($folders AS $folder) {
            $folderObj = FileFolder::loadOneById($folder['id']);
            $children[] = $this->getFolderChild($folderObj);
        }

        // get files
        $files = $db->getRows('SELECT * '
                . 'FROM file '
                . 'WHERE userId = :userId '
                . 'AND status = "active" '
                . 'AND folderId ' . ($this->folderObj === null ? 'IS NULL' : '= ' . $this->folderObj->id) . ' '
                . 'AND fileSize > 0 '
                . 'AND fileSize <= :maxDownloadSize '
                . 'ORDER BY originalFilename', array(
            'userId' => $this->userId,
            'maxDownloadSize' => WEBDAV_MAX_DOWNLOAD_SIZE,
        ));
        foreach ($files AS $file) {
            $fileObj = File::hydrateSingleRecord($file);
            $children[] = $this->getFileChild($fileObj);
        }

        return $children;
    }

    function getFileChild($fileObj) {
        // double check file is owned by logged in user
        if ($fileObj->userId != $this->userId) {
            return false;
        }

        return new WebdavFile($fileObj);
    }

    function getFolderChild($folderObj) {
        // double check folder is owned by logged in user
        if ($folderObj->userId != $this->userId) {
            return false;
        }

        return new self($folderObj);
    }

    function createDirectory($folderName) {
        LogHelper::error('Hit!');
        // check for rw access
        WebdavHelper::checkUserHasWrite();

        // setup database
        $db = Database::getDatabase();

        // check parent folder
        $parentId = null;
        if ((int) $this->folderObj->id) {
            $parentId = $this->folderObj->id;
        }

        // check for existing folder
        $rs = $db->getRow('SELECT id '
                . 'FROM file_folder '
                . 'WHERE folderName = :folderName '
                . 'AND parentId ' . ((int) $parentId ? ('= ' . (int) $parentId) : 'IS NULL') . ' '
                . 'AND userId = :userId', array(
            'folderName' => $folderName,
            'userId' => $this->userId,
        ));
        if ($rs) {
            if (count($rs)) {
                throw new Exception\Conflict('Folder already exists called: ' . $folderName);
            }
        }

        // add folder
        $fileFolder = FileFolder::create();
        $fileFolder->userId = $this->userId;
        $fileFolder->addedUserId = $this->userId;
        $fileFolder->urlHash = FileFolderHelper::generateRandomFolderHash();
        $fileFolder->folderName = $folderName;
        $fileFolder->isPublic = 0;
        $fileFolder->parentId = $parentId;
        $fileFolder->watermarkPreviews = 0;
        $fileFolder->showDownloadLinks = 1;
        $fileFolder->accessPassword = null;
        $rs = $fileFolder->save();
        if($rs) {
            // ensure we've setup the sharing permissions for the new folder
            if ($parentId !== null) {
                FileFolderHelper::copyPermissionsToNewFolder($parentId, $fileFolder->id);
            }
        }
        
        return $rs;
    }

    function getName() {
        return $this->folderObj->folderName;
    }

    function setName($newName) {
        // check for rw access
        WebdavHelper::checkUserHasWrite();

        // setup database
        $db = Database::getDatabase();

        // check for existing folder
        $rs = $db->getRow('SELECT id '
                . 'FROM file_folder '
                . 'WHERE folderName = :folderName '
                . 'AND userId =:userId '
                . 'AND id != :id', array(
            'folderName' => $newName,
            'userId' => $newName,
            'id' => $this->folderObj->id,
        ));
        if ($rs) {
            if (COUNT($rs)) {
                throw new Exception\Conflict('Folder already exists called: ' . $newName);
            }
        }

        // rename folder in database
        $rs = $db->query('UPDATE file_folder '
                . 'SET folderName = :folderName, date_updated = NOW() '
                . 'WHERE userId = :userId '
                . 'AND id = :id '
                . 'LIMIT 1', array(
            'folderName' => $newName,
            'userId' => $this->userId,
            'id' => $this->folderObj->id,
        ));
        if ($rs) {
            return true;
        }

        return false;
    }

    // @TODO - set to modified date when available in file_folder table
    function getLastModified() {
        return $this->folderObj->date_updated!==null?$this->folderObj->date_updated:strtotime($this->folderObj->date_updated);
    }

    public function delete() {
        // check for rw access
        WebdavHelper::checkUserHasWrite();

        return $this->folderObj->trashByUser();
    }

    public function createFile($name, $data = null) {
        // check for rw access
        WebdavHelper::checkUserHasWrite();

        // save temp copy locally
        $tmpFName = tempnam(sys_get_temp_dir(), MD5(microtime()));
        file_put_contents($tmpFName, $data);
        
        // logs
        LogHelper::info('Uploaded tmp file size: ' . filesize($tmpFName));

        // get api key
        $db = Database::getDatabase();
        $coreAuth = AuthHelper::getAuth();
        $apiKey = $coreAuth->user->apikey;
        if (strlen($apiKey) == 0) {
            $apiKey = $db->getValue("SELECT apikey "
                    . "FROM users "
                    . "WHERE id = :id "
                    . "LIMIT 1", array(
                'id' => $coreAuth->user->id,
            ));
            if (!$apiKey) {
                // no api key so add it
                $apiKey = md5(microtime() . $this->userId . microtime());
                $db->query('UPDATE users '
                        . 'SET apikey = :apikey '
                        . 'WHERE id = :id '
                        . 'AND username = :username '
                        . 'LIMIT 1', array(
                    'apikey' => $apiKey,
                    'id' => (int) $coreAuth->user->id,
                    'username' => $coreAuth->user->username,
                ));
            }
        }

        // prepare the params
        $post = array();
        $post['folderId'] = $this->folderObj->id === null ? -1 : $this->folderObj->id;
        $post['api_key'] = $apiKey;
        $post['username'] = $coreAuth->username;
        $post['action'] = 'upload';
        $post['files'] = curl_file_create($tmpFName, null, $name);

        // simulate posting the file using curl
        $url = FileHelper::getUploadUrl() . '/api_upload_handler';
        LogHelper::info('Curl request to: ' . $url);
        LogHelper::info('Curl params: ' . print_r($post, true));

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $msg = curl_exec($ch);
        $error = '';

        if (curl_errno($ch)) {
            $error = 'Error uploading file to ' . $url . ': ' . curl_error($ch);
        }
        else {
            // try to read the json response
            if (strlen($msg) == 0) {
                $error = 'Error uploading file. No response received from: ' . $url;
            }
            else {
                $responseArr = json_decode($msg, true);
                if (is_array($responseArr)) {
                    // got data as array
                    if (isset($responseArr[0]['error'])) {
                        $error = 'Error on: ' . $url . '. ' . $responseArr[0]['error'];
                    }
                }
                else {
                    $error = 'Failed reading response from: ' . $url . '. Response: ' . $msg;
                }
            }
        }

        // close curl
        curl_close($ch);

        // clear temp file
        unlink($tmpFName);

        // error
        if (strlen($error)) {
            // log
            LogHelper::error($error);

            return true;
        }

        // if we've got this part assume everything has gone well and we have file info in $responseArr
        LogHelper::info('Result: ' . print_r($responseArr, true));

        return true;
    }

}
