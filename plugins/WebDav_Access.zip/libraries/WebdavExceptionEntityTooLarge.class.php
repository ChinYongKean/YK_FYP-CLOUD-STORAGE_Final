<?php

namespace Plugins\Webdav\Libraries;

use Sabre\DAV\Exception;

/**
 * WebdavExceptionEntityTooLarge
 *
 * @author Adam Wilson
 */
class WebdavExceptionEntityTooLarge extends Exception
{

    /**
     * Returns the HTTP status code for this exception
     *
     * @return int
     */
    public function getHTTPCode() {
        return 413;
    }

}
