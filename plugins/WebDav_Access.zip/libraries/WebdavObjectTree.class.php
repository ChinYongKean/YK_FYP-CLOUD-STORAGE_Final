<?php

namespace Plugins\Webdav\Libraries;

use App\Core\Database;
use App\Helpers\AuthHelper;
use App\Helpers\FileFolderHelper;
use App\Helpers\LogHelper;
use Plugins\Webdav\Libraries\WebdavHelper;
use Sabre\DAV\ObjectTree;
use Sabre\DAV\URLUtil;

/**
 * WebdavObjectTree
 *
 * @author Adam Wilson
 */
class WebdavObjectTree extends ObjectTree
{

    /**
     * Moves a file from one location to another
     *
     * @param string $sourcePath The path to the file which should be moved
     * @param string $destinationPath The full destination path, so not just the destination parent node
     * @return int
     */
    public function move($sourcePath, $destinationPath) {
        // check for rw access
        WebdavHelper::checkUserHasWrite();

        // core auth object
        $coreAuth = AuthHelper::getAuth();

        list($sourceDir, $sourceName) = URLUtil::splitPath($sourcePath);
        list($destinationDir, $destinationName) = URLUtil::splitPath($destinationPath);

        // same location so renamed
        if ($sourceDir === $destinationDir) {
            $renameable = $this->getNodeForPath($sourcePath);
            $renameable->setName($destinationName);
        }
        // different location so just update folder in database
        else {
            // get new folder id
            $newFolderId = FileFolderHelper::convertFolderPathToId($destinationDir, $coreAuth->id);
            $sourceFolderId = FileFolderHelper::convertFolderPathToId($sourceDir, $coreAuth->id);
            $elementNode = $this->getNodeForPath($sourcePath);
            $elementType = get_class($elementNode);

            // log
            LogHelper::info('Moving node (' . $elementType . ') from "' . $sourcePath . '" to "' . $destinationPath . '" for user id ' . (int) $coreAuth->id);

            // directory
            $db = Database::getDatabase();
            if ($elementType == 'Plugins\Webdav\Libraries\WebdavCollection') {
                // update folder in database
                $db->query('UPDATE file_folder '
                        . 'SET parentId = ' . ((int) $newFolderId ? (int) $newFolderId : 'NULL') . ', '
                        . 'date_updated = NOW() '
                        . 'WHERE userId = :userId '
                        . 'AND id = :id '
                        . 'LIMIT 1', array(
                    'userId' => (int) $coreAuth->id,
                    'id' => (int) $elementNode->folderObj->id,
                ));
            }
            else {
                // update file folder in database
                $db->query('UPDATE file '
                        . 'SET folderId = ' . ((int) $newFolderId ? (int) $newFolderId : 'NULL') . ' '
                        . 'WHERE userId = :userId '
                        . 'AND id = :id '
                        . 'LIMIT 1', array(
                    'userId' => $coreAuth->id,
                    'id' => (int) $elementNode->fileObj->id,
                ));
            }

            // update the old folder total
            if ((int) $sourceFolderId) {
                FileFolderHelper::updateFolderFilesize((int) $sourceFolderId);
            }

            // update the new folder total
            if ((int) $newFolderId) {
                FileFolderHelper::updateFolderFilesize((int) $newFolderId);
            }
        }

        $this->markDirty($sourceDir);
        $this->markDirty($destinationDir);
    }

}
