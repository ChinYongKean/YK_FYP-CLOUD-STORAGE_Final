<?php

namespace Plugins\Webdav\Controllers;

use App\Core\BaseController;
use App\Helpers\NotificationHelper;
use App\Helpers\LogHelper;
use App\Helpers\PluginHelper;
use App\Helpers\TranslateHelper;
use Plugins\Webdav\Libraries\WebdavCollection;
use Plugins\Webdav\Libraries\WebdavObjectTree;
use Plugins\Webdav\Libraries\WebdavHelper;
use Sabre\DAV;
use Sabre\DAV\Server;
use Sabre\HTTP\BasicAuth;

class WebdavController extends BaseController
{

    /**
     * Front-end webdav webpage
     * 
     * @return type
     */
    public function webdavAccess() {
        // load reward details
        $webdavConfig = PluginHelper::pluginSpecificConfiguration('webdav');
        $webdavSettings = json_decode($webdavConfig['data']['plugin_settings'], true);
        $pluginObj = PluginHelper::getInstance('webdav');

        // check access
        if ($pluginObj->getAccessLabel() == 'none') {
            NotificationHelper::setError(TranslateHelper::t('plugin_webdav_no_access', 'You currently don\'t have the ability to access files via WebDAV. Please contact us for more information.'));
        }

        // load template
        return $this->render('webdav_access.html', array(
                    'webdavSettings' => $webdavSettings,
                    'pluginObj' => $pluginObj,
                    'webdavUrl' => str_replace(_CONFIG_SITE_PROTOCOL . '://', '', WEB_ROOT) . '/webdav',
                        ), PLUGIN_DIRECTORY_ROOT . 'webdav/views');
    }

    /**
     * Entry point for all webdav requests
     * 
     * @return type
     */
    public function webdavEntryPoint($urlPart = null) {
        // only utf8
        ini_set('default_charset', 'utf-8');

        // make sure plugin is enabled
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('webdav');
        if ($pluginConfig['data']['plugin_enabled'] == 0) {
            // exit
            return $this->render404();
        }

        // get settings for later
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);

        // max size of files to show/allow (10GB)
        define('WEBDAV_MAX_DOWNLOAD_SIZE', 1024 * 1024 * 1024 * 10);

        // include sabredav
        require_once(PLUGIN_DIRECTORY_ROOT . 'webdav/libraries/sabredav/lib/Sabre/autoload.php');

        // setup logging
        LogHelper::setContext('plugin_webdav');
        LogHelper::info('Hit WebDav plugin receiver: /webdav');

        // core auth object
        $coreAuth = $this->getAuth();

        // webdav auth
        $webdavAuth = new BasicAuth();

        // clear any previous sessions for other users
        $result = $webdavAuth->getUserPass();

        // check if user already logged in
        if ($coreAuth->loggedIn() == false) {
            // log
            LogHelper::info('Not logged in, requesting access details.');

            // ensure we've received a username and password
            if (!$result) {
                $webdavAuth->requireLogin();
                LogHelper::info('Username and password not found, if you\'re using Plesk try commenting out the code within \plugins\webdav\site\control\.htaccess. ' . print_r($result, true));
                echo "Authentication required\n";
                exit;
            }

            // check username and password
            $rs = $coreAuth->attemptLogin($result[0], $result[1], false, true, null, true);
            if ($rs === false) {
                LogHelper::info('Login attempt failed for user \'' . $result[0] . '\'. This could be due to an incorrect password or the account may be blocked due to too many failed logins.');
                $webdavAuth->requireLogin();
                echo "Authentication required\n";
                exit;
            }
            else {
                LogHelper::info('Successful WebDav login for user \'' . $result[0] . '\'.');
            }
        }

        // log
        LogHelper::info('Pre second stage auth check.');

        if ($coreAuth->loggedIn() == false) {
            // log
            LogHelper::info('Authentication required.');

            $webdavAuth->requireLogin();
            echo "Authentication required\n";
            exit;
        }

        // setup access level
        $accessLevel = 'none';
        if (isset($pluginSettings['access_levels'][$coreAuth->package_id])) {
            $accessLevel = $pluginSettings['access_levels'][$coreAuth->package_id];
        }

        // log
        LogHelper::info('Access level (User: ' . $coreAuth->username . '): ' . $accessLevel);

        // if no access permitted, block
        if ($accessLevel == 'none') {
            // exit
            return $this->render403();
        }

        // log
        LogHelper::info('Passed access checks.');

        // store access level for later
        WebdavHelper::setAccessLevel($accessLevel);

        // root node
        $rootNode = new WebdavCollection(null);

        // use our own object tree for better performance and data retention, i.e. for moves, copy etc.
        $webdavRootNode = new WebdavObjectTree($rootNode);

        // the rootNode needs to be passed to the server object
        $server = new Server($webdavRootNode);

        // create base url
        $baseUrl = str_replace(_CONFIG_SITE_HOST_URL, '', _CONFIG_SITE_FULL_URL);
        $url = $baseUrl . '/webdav/';

        // set base path
        $server->setBaseUri($url);

        // make sure there is a 'data' directory, writable by the server. This directory is used to store information about locks
        $lockBackend = new DAV\Locks\Backend\File('/tmp/data.dat');
        $lockPlugin = new DAV\Locks\Plugin($lockBackend);
        $server->addPlugin($lockPlugin);

        // start
        $server->exec();
        exit;
    }

}
