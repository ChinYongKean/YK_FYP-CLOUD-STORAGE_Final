<?php

namespace Plugins\Webdav\Controllers;

use App\Core\BaseController;
use App\Helpers\PluginHelper;
use App\Helpers\TranslateHelper;

class HooksController extends BaseController
{
    /**
     * Shown on both the front-end and file manager.
     * 
     * @param type $params
     * @return type
     */
    public function siteHeaderNav($params = array()) {
        return array(
            '_found_hook' => true,
            array(
                'link_url' => WEB_ROOT.'/webdav_access',
                'link_text' => TranslateHelper::t("plugin_webdav_access", "Webdav Access"),
            ),
        );
    }

    /**
     * Used for outputting the image to webdav in the file manager
     * 
     * @param type $params
     * @return type
     */
    public function fileManagerLefthandBottom($params = array()) {
        // function disabled for now as a link is in the main navigation
        return $params;

        // pickup for later
        $pluginDetails = PluginHelper::pluginSpecificConfiguration('webdav');
        $pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);

        // load template
        return array(
            '_found_hook' => true,
            'response_html' => $this->getRenderedTemplate('file_manager_lefthand_bottom.html', array(
                'show_in_navigation' => (int) $pluginSettings['show_in_navigation'],
                    ), PLUGIN_DIRECTORY_ROOT . 'webdav/views'));
    }
    
    /**
     * Used for outputting the image to webdav in the file manager
     * 
     * @param type $params
     * @return type
     */
    public function siteFooterBelowNav($params = array()) {
        // pickup for later
        $pluginDetails = PluginHelper::pluginSpecificConfiguration('webdav');
        $pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);

        // load template
        return array(
            '_found_hook' => true,
            'response_html' => $this->getRenderedTemplate('website_footer.html', array(
                'show_in_navigation' => (int) $pluginSettings['show_in_navigation'],
                    ), PLUGIN_DIRECTORY_ROOT . 'webdav/views'));
    }

}
