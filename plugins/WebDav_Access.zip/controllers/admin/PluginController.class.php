<?php

namespace Plugins\Webdav\Controllers\Admin;

use App\Core\Database;
use App\Controllers\Admin\PluginController AS CorePluginController;
use App\Helpers\AdminHelper;
use App\Helpers\PluginHelper;
use App\Models\Plugin;

class PluginController extends CorePluginController
{

    public function pluginSettings() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // load plugin details
        $folderName = 'webdav';
        $plugin = Plugin::loadOneByClause('folder_name = :folder_name', array(
                    'folder_name' => $folderName,
        ));

        if (!$plugin) {
            return $this->redirect(ADMIN_WEB_ROOT . '/plugin_manage?error=' . urlencode('There was a problem loading the plugin details.'));
        }

        // load user types
        $userTypes = $db->getRows('SELECT id, label '
                . 'FROM user_level '
                . 'WHERE level_type != \'nonuser\' '
                . 'ORDER BY id');

        // preload list of servers for webdav connection url
        $servers = $db->getRows("SELECT fileServerDomainName, scriptPath "
                . "FROM file_server "
                . "WHERE serverType = 'direct' "
                . "ORDER BY CONCAT(fileServerDomainName, scriptPath)");
        $serversArr = array();
        $serversArr[] = WEB_ROOT . '/';
        $alt = 'https';
        if (_CONFIG_SITE_PROTOCOL == 'https') {
            $alt = 'http';
        }
        $serversArr[] = $alt . '://' . _CONFIG_SITE_FULL_URL . '/';
        if ($servers) {
            foreach ($servers AS $server) {
                $serversArr[] = _CONFIG_SITE_PROTOCOL . '://' . $server['fileServerDomainName'] . $server['scriptPath'];

                // add alt url
                $alt = 'https';
                if (_CONFIG_SITE_PROTOCOL == 'https') {
                    $alt = 'http';
                }
                $serversArr[] = $alt . '://' . $server['fileServerDomainName'] . $server['scriptPath'];
            }
        }

        // prepare variables
        $plugin_enabled = (int) $plugin->plugin_enabled;
        $access_levels = array();
        foreach ($userTypes AS $userType) {
            $access_levels[$userType['id']] = 'none';
        }
        $show_in_navigation = 1;
        $webdav_server = WEB_ROOT . '/';

        // load existing settings
        if (strlen($plugin->plugin_settings)) {
            $plugin_settings = json_decode($plugin->plugin_settings, true);
            if ($plugin_settings) {
                if (isset($plugin_settings['access_levels'])) {
                    $access_levels = $plugin_settings['access_levels'];
                }
                $show_in_navigation = $plugin_settings['show_in_navigation'];
                $webdav_server = $plugin_settings['webdav_server'];
            }
        }

        // handle page submissions
        if ($request->request->has('submitted')) {
            // get variables
            $plugin_enabled = (int) $request->request->get('plugin_enabled');
            $plugin_enabled = $plugin_enabled != 1 ? 0 : 1;
            foreach ($userTypes AS $userType) {
                $variable = 'access_' . $userType['id'];
                $access_levels[$userType['id']] = $_REQUEST[$variable];
            }
            $show_in_navigation = (int) $_REQUEST['show_in_navigation'];
            $webdav_server = $_REQUEST['webdav_server'];

            // validate submission
            if (_CONFIG_DEMO_MODE == true) {
                AdminHelper::setError(AdminHelper::t('no_changes_in_demo_mode', 'No change permitted in demo mode.'));
            }
            else {
                foreach ($userTypes AS $userType) {
                    $variable = 'access_' . $userType['id'];
                    if (strlen($_REQUEST[$variable]) == 0) {
                        AdminHelper::setError('Please select an option for ' . $userType['label']);
                    }
                }
            }

            // update the settings
            if (AdminHelper::isErrors() == false) {
                // compile new settings
                $settingsArr = array();
                $settingsArr['access_levels'] = $access_levels;
                $settingsArr['show_in_navigation'] = $show_in_navigation;
                $settingsArr['webdav_server'] = $webdav_server;

                // update the plugin settings
                $plugin->plugin_enabled = $plugin_enabled;
                $plugin->plugin_settings = json_encode($settingsArr);
                $plugin->save();

                // set onscreen alert
                PluginHelper::loadPluginConfigurationFiles(true);
                AdminHelper::setSuccess('Plugin settings updated.');
            }
        }

        // check for required modules
        if (function_exists('curl_version') == false) {
            AdminHelper::setError(AdminHelper::t("plugin_webdav_curl_required", "Could not find Curl functions in your PHP configuration. Please contact your host to enable Curl otherwise this plugin wont work."));
        }
        if (extension_loaded('mbstring') == false) {
            AdminHelper::setError(AdminHelper::t("plugin_webdav_mbstring_required", "Could not find mbstring functions in your PHP configuration. Please contact your host to enable mbstring otherwise this plugin wont work."));
        }
        if (class_exists('DOMDocument') == false) {
            AdminHelper::setError(AdminHelper::t("plugin_webdav_xml_required", "Could not find XML functions in your PHP configuration. Please contact your host to enable PHP XML otherwise this plugin wont work. In CentOS use 'yum install php-xml' to install."));
        }
        if (!ini_get('allow_url_fopen')) {
            AdminHelper::setError(AdminHelper::t("plugin_webdav_url_fopen", "Config value allow_url_fopen is not enabled within php.ini, please enable this or downloads over WebDav will not work."));
        }

        // load template
        return $this->render('admin/plugin_settings.html', array(
                    'pluginName' => $plugin->plugin_name,
                    'yesNoOptions' => array(
                        0 => 'No',
                        1 => 'Yes'),
                    'serversArr' => $serversArr,
                    'userTypes' => $userTypes,
                    'plugin_enabled' => $plugin_enabled,
                    'access_levels' => $access_levels,
                    'show_in_navigation' => $show_in_navigation,
                    'webdav_server' => $webdav_server,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

}
