<?php

// plugin namespace
namespace Plugins\Webdav;

// core includes
use App\Helpers\AuthHelper;
use App\Helpers\PluginHelper;
use App\Helpers\TranslateHelper;
use App\Services\Plugin;
use Plugins\Webdav\PluginConfig;

class PluginWebdav extends Plugin
{
    public $config = null;
    public $data = null;
    public $settings = null;

    public function __construct() {
        // load plugin config
        $this->config = (new PluginConfig())->getPluginConfig();
    }

    public function registerRoutes(\FastRoute\RouteCollector $r) {
        // register plugin routes
        $r->addRoute(['GET', 'POST'], '/'.ADMIN_FOLDER_NAME.'/plugin/'.$this->config['folder_name'].'/settings', '\plugins\\'.$this->config['folder_name'].'\controllers\admin\PluginController/pluginSettings');
        $r->addRoute(['GET', 'POST'], '/webdav_access', '\plugins\\'.$this->config['folder_name'].'\controllers\\'.ucwords($this->config['folder_name']).'Controller/webdavAccess');
        
        // set 2 routes for webdav folder as the 2nd wont catch the forward slash on the end of the path
        $webDavMethods = ['GET', 'POST', 'PUT', 'HEAD', 'DELETE', 'PATCH', 'PROPFIND', 'PROPPATCH', 'MOVE', 'COPY', 'OPTIONS', 'MKCOL', 'LOCK', 'UNLOCK'];
        $r->addRoute($webDavMethods, '/webdav/', '\plugins\\'.$this->config['folder_name'].'\controllers\\'.ucwords($this->config['folder_name']).'Controller/webdavEntryPoint');
        $r->addRoute($webDavMethods, '/webdav[/{urlPart:.+?}]', '\plugins\\'.$this->config['folder_name'].'\controllers\\'.ucwords($this->config['folder_name']).'Controller/webdavEntryPoint');
    }
    
    public function getPluginDetails() {
        return $this->config;
    }

    public function getAccessLabel()
    {
        if (_CONFIG_DEMO_MODE == true)
        {
            return ucwords(TranslateHelper::t('plugin_webdav_demo_mode_read_only', 'demo mode (read only)'));
        }
        
        $accessLevel = 'none';
        $pluginConfig   = PluginHelper::pluginSpecificConfiguration('webdav');
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);
        $coreAuth = AuthHelper::getAuth();
        if(isset($pluginSettings['access_levels'][$coreAuth->package_id]))
        {
            $accessLevel = $pluginSettings['access_levels'][$coreAuth->package_id];
        }
        
        switch($accessLevel)
        {
            case 'rw':
                return ucwords(TranslateHelper::t('plugin_webdav_read_write', 'read write access'));
            case 'ro':
                return ucwords(TranslateHelper::t('plugin_webdav_read_only', 'read only access'));
        }
        
        return ucwords(TranslateHelper::t('plugin_webdav_no_access', 'no access'));
    }
}
