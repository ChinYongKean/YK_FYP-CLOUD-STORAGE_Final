<?php

namespace Plugins\G2apay\Controllers;

use App\Core\BaseController;
use App\Models\File;
use App\Models\Order;
use App\Models\PaymentLog;
use App\Models\User;
use App\Helpers\CoreHelper;
use App\Helpers\LogHelper;
use App\Helpers\OrderHelper;
use App\Helpers\PluginHelper;
use App\Helpers\UserHelper;

class G2apayController extends BaseController
{

    public function upgradeBox($params = array()) {
        // pickup request for later
        $request = $this->getRequest();

        // load template
        return $this->render('upgrade_box.html', array_merge($params, array(
                    'folder_name' => 'g2apay',
                    'gateway_label' => 'G2aPay',
                    'i' => $request->query->has('i') ? $request->query->get('i') : '',
                    'f' => $request->query->has('f') ? $request->query->get('f') : '',
                        )), PLUGIN_DIRECTORY_ROOT . 'g2apay/views');
    }

    public function pay($params = array()) {
        // pickup request for later
        $request = $this->getRequest();

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('g2apay');
        $pluginSettings = $pluginConfig['data']['plugin_settings'];
        $your_secret = '';
        $your_api_hash = '';
        if (strlen($pluginSettings)) {
            $pluginSettingsArr = json_decode($pluginSettings, true);
            $your_secret = $pluginSettingsArr['your_secret'];
            $your_api_hash = $pluginSettingsArr['your_api_hash'];
        }

        if (!$request->request->has('user_level_pricing_id')) {
            return $this->redirect(WEB_ROOT);
        }

        // require login
        if ($request->request->has('i') && strlen($request->request->get('i'))) {
            $user = User::loadOneByClause('identifier = :identifier', array(
                        'identifier' => $request->request->get('i')
            ));
            if (!$user) {
                return $this->redirect(CoreHelper::getCoreSitePath() . "/error?e=" . urlencode('Could not load user based on identifier, please contact support.'));
            }

            // setup variables for later
            $userId = $user->id;
            $username = $user->username;
            $userEmail = $user->email;
        }
        else {
            if (($response = $this->requireLogin('/register', 1)) !== false) {
                return $response;
            }

            // setup variables for later
            $Auth = $this->getAuth();
            $userId = $Auth->id;
            $username = $Auth->username;
            $userEmail = $Auth->email;
        }

        $userLevelPricingId = (int) $request->request->get('user_level_pricing_id');

        // check if we have a referring file
        $fileId = null;
        if ($request->request->has('f') && strlen($request->request->get('f'))) {
            $file = File::loadOneByShortUrl($request->request->get('f'));
            if ($file) {
                $fileId = $file->id;
            }
        }

        // create order entry
        $order = OrderHelper::createByPackageId($userId, $userLevelPricingId, $fileId);
        if ($order) {
            // get form content
            return $this->render('payment_form_redirect.html', array_merge($params, array(
                        'order' => $order,
                        'your_api_hash' => $your_api_hash,
                        'userEmail' => $userEmail,
                        'pluginConfig' => $pluginConfig,
                            )), PLUGIN_DIRECTORY_ROOT . 'g2apay/views');
        }

        // fallback
        return $this->redirect(CoreHelper::getCoreSitePath() . "/error?e=" . urlencode('Failed creating order, please try again later.'));
    }

    public function paymentIpn($params = array()) {
        // pickup request for later
        $request = $this->getRequest();

        // log response
        LogHelper::setContext('g2apay');
        LogHelper::info('Received called back on IPN: ' . print_r($_REQUEST, true));

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('g2apay');
        $pluginSettings = $pluginConfig['data']['plugin_settings'];
        $your_secret = '';
        $your_api_hash = '';
        if (strlen($pluginSettings)) {
            $pluginSettingsArr = json_decode($pluginSettings, true);
            $your_secret = $pluginSettingsArr['your_secret'];
            $your_api_hash = $pluginSettingsArr['your_api_hash'];
        }

        // check for some required variables in the request
        if (!$request->request->has('status')) {
            return $this->renderEmpty200Response();
        }

        // make sure payment has complete
        if ($request->request->get('status') == "complete") {
            // log
            LogHelper::info('Found status of payment "complete", trying to find order.');

            // load order using custom payment tracker hash
            $paymentTracker = $_REQUEST['userOrderId'];
            $order = OrderHelper::loadByPaymentTracker($paymentTracker);
            if ($order) {
                // log
                LogHelper::info('Found order #' . $order->id . '.');

                $extendedDays = $order->days;
                $userId = $order->user_id;
                $upgradeUserId = $order->upgrade_user_id;
                $orderId = $order->id;

                // retain all posted gateway parameters
                $gatewayVars = "";
                foreach ($_REQUEST AS $k => $v) {
                    $gatewayVars .= $k . " => " . $v . "\n";
                }

                // insert payment log
                $paymentLog = PaymentLog::create();
                $paymentLog->user_id = $userId;
                $paymentLog->date_created = date("Y-m-d H:i:s", time());
                $paymentLog->amount = $request->request->get('amount');
                $paymentLog->currency_code = $request->request->get('currency');
                $paymentLog->from_email = $request->request->get('transactionId');
                $paymentLog->to_email = '';
                $paymentLog->description = $order->description;
                $paymentLog->request_log = $gatewayVars;
                $paymentLog->payment_method = 'G2aPay';
                $paymentLog->save();

                // make sure the amount paid matched what we expect
                if ($request->request->get('amount') != $order->amount) {
                    // order amounts did not match
                    LogHelper::info('Failed - order amounts did not match');

                    return $this->renderEmpty200Response();
                }

                // make sure the order is pending
                if ($order->order_status == 'completed') {
                    // order has already been completed
                    LogHelper::info('Failed - order has already been completed');

                    return $this->renderEmpty200Response();
                }

                // update order status to paid
                $order->order_status = 'completed';
                if ($order->save() === false) {
                    // failed to update order
                    LogHelper::info('Failed - failed to update order');

                    return $this->renderEmpty200Response();
                }

                // extend/upgrade user
                $rs = UserHelper::upgradeUserByPackageId($userId, $order);
                if ($rs === false) {
                    // failed to update user
                    LogHelper::info('Failed - failed to update user');

                    return $this->renderEmpty200Response();
                }

                // append any plugin includes
                PluginHelper::callHook('postUpgradePaymentIpn', array(
                    'order' => $order,
                ));
            }
        }

        return $this->renderEmpty200Response();
    }

}
