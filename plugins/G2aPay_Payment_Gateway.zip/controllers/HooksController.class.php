<?php

namespace Plugins\G2apay\Controllers;

use App\Core\BaseController;
use App\Helpers\CoreHelper;
use App\Helpers\FileHelper;
use App\Helpers\PluginHelper;
use App\Helpers\ThemeHelper;
use App\Models\File;
use Plugins\G2apay\Controllers\G2apayController;

class HooksController extends BaseController
{

    public function upgradeBoxes($params = null) {
        // call the controller to create the upgrade box
        $g2apayController = new G2apayController();
        $response = $g2apayController->upgradeBox($params);
        
        // return response object
        return $response;
    }

}
