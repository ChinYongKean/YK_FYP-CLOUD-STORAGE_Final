<?php

namespace Plugins\G2apay;

use App\Services\PluginConfig AS CorePluginConfig;

class PluginConfig extends CorePluginConfig
{
    /**
     * Setup the plugin config.
     *
     * @var array
     */
    public $config = array(
        'plugin_name' => 'G2aPay Payment Integration',
        'folder_name' => 'g2apay',
        'plugin_description' => 'Accept payments using G2aPay.',
        'plugin_version' => '5.0',
        'required_script_version' => '5.0',
    );

}
