<?php

/*
 * Title: Media converter script
 * Author: YetiShare.com
 * Period: Run by cron every minute or as required. (it won't trigger a new
 * instance until the last one is finished)
 * 
 * Description:
 * Script to process any pending video conversions to mp4 via the YetiShare
 * mediaconverter plugin. It can be run on a different server than the main site
 * as long as the server meets the requirements below.
 * 
 * How To Call:
 * On the command line via PHP, like this:
 * php process_converter_queue.cron.php
 * 
 */

namespace Plugins\Mediaconverter\Tasks;

// include framework
use App\Core\Database;
use App\Core\Framework;
use App\Helpers\BackgroundTaskHelper;
use App\Helpers\CoreHelper;
use App\Helpers\FileFolderHelper;
use App\Helpers\FileServerHelper;
use App\Helpers\FileServerContainerHelper;
use App\Helpers\LogHelper;
use App\Helpers\PluginHelper;
use App\Models\File;
use phpseclib\Net\SFTP;
use phpseclib\Crypt\RSA;

require_once(realpath(dirname(__FILE__) . '/../../../app/core/Framework.class.php'));

// setup light environment
Framework::runLight();

// ignore memory limits
ini_set('memory_limit', '-1');

// get database
$db = Database::getDatabase();

// background task logging
BackgroundTaskHelper::start();

// setup logging
LogHelper::setContext('plugin-media-converter-queue');

$databaseHost = _CONFIG_DB_HOST;
$databaseUser = _CONFIG_DB_USER;
$databasePass = _CONFIG_DB_PASS;
$databaseName = _CONFIG_DB_NAME;

define('ON_SCRIPT_INSTALL', true);

define("DATABASE_HOST", $databaseHost);
define("DATABASE_USER", $databaseUser);
define("DATABASE_PASS", $databasePass);
define("DATABASE_NAME", $databaseName);

$serverName = _CONFIG_SITE_HOST_URL;
$primaryServer = false;

// check if primiary server (for screenshot storage)
if (_CONFIG_SITE_HOST_URL == _CONFIG_CORE_SITE_HOST_URL) {
    $primaryServer = true;
}

define('ON_PRIMARY_SERVER', $primaryServer);
define('SERVER_NAME_FOR_LOGS', _CONFIG_SITE_HOST_URL);
define("CONVERT_BITRATE", "1400k");
define("CONVERT_FRAMERATE", "30");

/*
 * Connect database and load config from plugin settings.
 */
try {
    $db = dbConnect();
    if ($db) {
        $stmt = $db->query("SELECT * "
                . "FROM plugin "
                . "WHERE folder_name='mediaconverter' "
                . "LIMIT 1");
        $pluginDetails = $stmt->fetch(\PDO::FETCH_ASSOC);
        $pluginSettings = $pluginDetails['plugin_settings'];
        if ($pluginSettings) {
            $pluginSettingsArr = json_decode($pluginSettings, true);
        }
    }
}
catch (Exception $e) {
    echo "\n" . $e->getMessage() . "\n";

    // logs
    LogHelper::error($e->getMessage());
    LogHelper::breakInLogFile();

    // background task logging
    BackgroundTaskHelper::end();
    exit;
}

/*
 * For local storage this script needs to have access via SSH to the files. Set
 * the SSH details below.
 */
$localPrimaryServer = array();
$directFileServers = FileServerHelper::getFileServerAccessDetails();
foreach ($directFileServers AS $directFileServer) {
    if ($directFileServer['primary_local_server'] == true) {
        $localPrimaryServer = $directFileServer;
    }
}

if (count($localPrimaryServer)) {
    define("LOCAL_STORAGE_SSH_HOST", $localPrimaryServer['ssh_host']);
    define("LOCAL_STORAGE_SSH_USER", $localPrimaryServer['ssh_username']);
    define("LOCAL_STORAGE_SSH_PASS", $localPrimaryServer['ssh_password']);
    define("LOCAL_STORAGE_SSH_KEY", $localPrimaryServer['ssh_key']);
    define("LOCAL_STORAGE_SSH_AUTH_TYPE", $localPrimaryServer['ssh_authentication_type']);
}
else {
    define("LOCAL_STORAGE_SSH_HOST", "");
    define("LOCAL_STORAGE_SSH_USER", "");
    define("LOCAL_STORAGE_SSH_PASS", "");
    define("LOCAL_STORAGE_SSH_KEY", "");
    define("LOCAL_STORAGE_SSH_AUTH_TYPE", "");
}

/*
 * General config.
 */

// change this to set the maximum conversions that can be done at once.
define("MAX_CONCURRENT_CONVERSIONS", $pluginSettingsArr['max_conversions']);

// maximum video size, all videos are contrained to these max widths/heights
define("VIDEO_MAX_WIDTH", $pluginSettingsArr['video_size_w']);
define("VIDEO_MAX_HEIGHT", $pluginSettingsArr['video_size_h']);

// FFMPEG path
define("FFMPEG_PATH", "ffmpeg");

// show output, used for debugging
define("SHOW_OUTPUT", $pluginSettingsArr['output_messages']);

// local paths, shouldn't need changed
define("SCRIPT_ROOT_FOLDER", dirname(__FILE__));
define("CACHE_PATH", CACHE_DIRECTORY_ROOT . '/plugins/mediaconverter');
define("CACHE_SCREENSHOT_PATH", sys_get_temp_dir());
define("SCREENSHOT_PERIOD", $pluginSettingsArr['screenshot_period']); // in 2 digit format, i.e. 05 = 5 seconds.
// export file type
define("EXPORT_FILE_EXTENSION", $pluginSettingsArr['output_type']);
define("EXPORT_FILE_MIMETYPE", "video/" . $pluginSettingsArr['output_type']);

/*
 * Main conversion code.
 */

// php script timeout for long conversions (12 hours)
set_time_limit(60 * 60 * 12);

// report simple running errors
error_reporting(E_ERROR | E_WARNING | E_PARSE);

// make sure the local cache path is writable
if (!file_exists(CACHE_PATH)) {
    mkdir(CACHE_PATH, 0777, true);
}
if (!is_writable(CACHE_PATH)) {
    output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Cache path is not writable, please ensure it's set to CHMOD 755 or 777 depending on your server setup: " . CACHE_PATH . ".\n");

    // logs
    LogHelper::breakInLogFile();

    // background task logging
    BackgroundTaskHelper::end();
    exit;
}

// make sure shell_exec is available
if (!function_exists('shell_exec')) {
    output("[" . SERVER_NAME_FOR_LOGS . "]: Error: The PHP function shell_exec() is not available and may be blocked within your php.ini file. Please check and try again.\n");

    // logs
    LogHelper::breakInLogFile();

    // background task logging
    BackgroundTaskHelper::end();
    exit;
}

// make sure we have mcrypt for speed purposes
if (!extension_loaded('openssl')) {
    output("[" . SERVER_NAME_FOR_LOGS . "]: Error: OpenSSL functions not found in PHP. This script will run VERY slow if you don't enable them. Please check and try again.\n");

    // logs
    LogHelper::breakInLogFile();

    // background task logging
    BackgroundTaskHelper::end();
    exit;
}

// connect db and get any pending rows
try {
    $db = new \PDO('mysql:host=' . DATABASE_HOST . ';dbname=' . DATABASE_NAME . ';charset=utf8', DATABASE_USER, DATABASE_PASS);
    if ($db) {
        // fail any which have been converting for more than 1 day, sorts occasional issues with timeouts
        $stmt = $db->query("UPDATE plugin_mediaconverter_queue "
                . "SET status='failed', "
                . "date_finished=NOW() "
                . "WHERE status='processing' "
                . "AND date_started < NOW() - INTERVAL 1 DAY");

        // make sure there's none being processed on the current host
        $stmt = $db->prepare("SELECT COUNT(id) AS total "
                . "FROM plugin_mediaconverter_queue "
                . "WHERE status='processing' "
                . "AND convert_host = :convert_host");
        $stmt->bindValue(':convert_host', $serverName);
        $stmt->execute();
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        if ((int) $row['total'] >= MAX_CONCURRENT_CONVERSIONS) {
            // max concurrent
            output("[" . SERVER_NAME_FOR_LOGS . "]: Already " . (int) $row['total'] . " conversion(s) processing.\n");

            // logs
            LogHelper::breakInLogFile();

            // background task logging
            BackgroundTaskHelper::end();
            exit;
        }

        // check for pending conversions
        $stmt = $db->query("SELECT id, file_id, capture_video "
                . "FROM plugin_mediaconverter_queue "
                . "WHERE status='pending' "
                . "ORDER BY date_added ASC "
                . "LIMIT 1");
        $pendingRow = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$pendingRow) {
            output("[" . SERVER_NAME_FOR_LOGS . "]: No pending conversions found.\n", true);

            // background task logging
            BackgroundTaskHelper::end();
            exit;
        }
    }
}
catch (Exception $e) {
    output("\n");
    output("[" . SERVER_NAME_FOR_LOGS . "]: ERROR: " . $e->getMessage() . "\n");
    output("\n");

    // logs
    LogHelper::breakInLogFile();

    // background task logging
    BackgroundTaskHelper::end();
    exit;
}

// setup whether we should only capture the screen or do the video conversion aswell
if ($pendingRow['capture_video'] == 0) {
    // just do screenshot
    define("SCREENSHOT_ONLY", true);
}
else {
    // convert video aswell as screenshot
    define("SCREENSHOT_ONLY", false);
}

// log
output("[" . SERVER_NAME_FOR_LOGS . "]: Found 1 pending conversion, id #" . $pendingRow['id'] . ".\n");

// load file record
$stmt = $db->query("SELECT * "
        . "FROM file "
        . "WHERE id=" . $pendingRow['file_id'] . " "
        . "AND status='active' "
        . "LIMIT 1");
$file = $stmt->fetch(\PDO::FETCH_ASSOC);
if (!$file) {
    // log
    output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Could not load file data. It may be inactive or missing.\n");

    // set to failed
    $stmt = $db->prepare("UPDATE plugin_mediaconverter_queue "
            . "SET status='failed', "
            . "convert_host = :convert_host, "
            . "date_started=NOW(), "
            . "date_finished=NOW(), "
            . "notes='" . str_replace("'", "\\'", mediaConverterOutputTracker::getAsString()) . "' "
            . "WHERE id=" . $pendingRow['id'] . " "
            . "LIMIT 1");
    $stmt->bindValue(':convert_host', $serverName);
    $stmt->execute();

    // logs
    LogHelper::breakInLogFile();

    // background task logging
    BackgroundTaskHelper::end();
    exit;
}

// set to processing
$stmt = $db->prepare("UPDATE plugin_mediaconverter_queue "
        . "SET status='processing', "
        . "convert_host = :convert_host, "
        . "date_started=NOW() "
        . "WHERE id=" . $pendingRow['id'] . " "
        . "AND status='pending' "
        . "LIMIT 1");
$stmt->bindValue(':convert_host', $serverName);
$stmt->execute();

// log
output("[" . SERVER_NAME_FOR_LOGS . "]: Getting file from storage...\n");

// grab file
$localFile = getFileContent($db, $file);
if (!$localFile) {
    // log
    output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Could not get file contents.\n");

    // set to failed
    $db->query("UPDATE plugin_mediaconverter_queue "
            . "SET status='failed', "
            . "date_finished=NOW(), "
            . "notes='" . str_replace("'", "\\'", mediaConverterOutputTracker::getAsString()) . "' "
            . "WHERE id=" . $pendingRow['id'] . " "
            . "LIMIT 1");

    // logs
    LogHelper::breakInLogFile();

    // background task logging
    BackgroundTaskHelper::end();
    exit;
}

// get original video size
$originalWidth = null;
$originalHeight = null;
if (file_exists($localFile)) {
    $command = FFMPEG_PATH . ' -i ' . $localFile . ' -vstats 2>&1';
    $output = shell_exec($command);

    $result = preg_match('/[0-9]?[0-9][0-9][0-9]x[0-9][0-9][0-9][0-9]?/', $output, $regs);
    if (isset($regs[0])) {
        $vals = (explode('x', $regs[0]));
        $originalWidth = $vals[0] ? $vals[0] : null;
        $originalHeight = $vals[1] ? $vals[1] : null;
    }
}

// prepare resize, contraining proportions
$scale = '-vf "scale=' . VIDEO_MAX_WIDTH . ':trunc(ow/a/2)*2"';
if ((int) $originalWidth > 0) {
    $x_ratio = VIDEO_MAX_WIDTH / $originalWidth;
    $y_ratio = VIDEO_MAX_HEIGHT / $originalHeight;

    if (($originalWidth <= VIDEO_MAX_WIDTH) && ($originalHeight <= VIDEO_MAX_HEIGHT)) {
        $tn_width = $originalWidth;
        $tn_height = $originalHeight;
    }
    elseif (($x_ratio * $originalHeight) < VIDEO_MAX_HEIGHT) {
        $tn_height = ceil($x_ratio * $originalHeight);
        $tn_width = VIDEO_MAX_WIDTH;
    }
    else {
        $tn_width = ceil($y_ratio * $originalWidth);
        $tn_height = VIDEO_MAX_HEIGHT;
    }

    // make sure numbers are even for scaling
    if ($tn_width % 2 == 1) {
        $tn_width = $tn_width + 1;
    }
    if ($tn_height % 2 == 1) {
        $tn_height = $tn_height + 1;
    }

    $scale = '-vf "scale=' . $tn_width . ':' . $tn_height . '"';
}

// log
output("[" . SERVER_NAME_FOR_LOGS . "]: Converting file...\n");

// convert via ffmpeg
$localFileParts = pathinfo($localFile);
$convertedFilename = $localFileParts['dirname'] . '/' . $localFileParts['filename'] . '_new.' . EXPORT_FILE_EXTENSION;
$convertedFilenameFinal = $localFileParts['dirname'] . '/' . $localFileParts['filename'] . '.' . EXPORT_FILE_EXTENSION;

$videoCodec = 'libx264';
if ($pluginSettingsArr['output_type'] == 'webm') {
    $videoCodec = 'libvpx';
}

$enableExperimentalCodecsStr = '';
if ((int) $pluginSettingsArr['enable_experimental_codecs'] === 1) {
    $enableExperimentalCodecsStr = ' -strict -2';
}
               
//$conversionPathCmd      = FFMPEG_PATH . ' -i ' . $localFile . ' -vcodec '.$videoCodec.' -r '.CONVERT_FRAMERATE.' -b:v '.CONVERT_BITRATE.' -flags +aic+mv4 ' . $scale . ' ' . $convertedFilename;
// force 2 channels to fix issues with 5.1 on libvo_aacenc
$conversionPathCmd = FFMPEG_PATH . ' -i ' . $localFile . ' -vcodec ' . $videoCodec . ' -ac 2 -r ' . CONVERT_FRAMERATE . ' -b:v ' . CONVERT_BITRATE . $enableExperimentalCodecsStr . ' -flags +aic+mv4 ' . $scale . ' ' . $convertedFilename;

// should we add a watermark
if ((int) $pluginSettingsArr['watermark_enabled'] == 1) {
    // save watermark image as file
    $watermarkFile = CACHE_PATH . '/_watermark.png';
    $watermark_contents = '';
    $db = dbConnect();
    $stmt = $db->query("SELECT file_name, "
            . "image_content "
            . "FROM plugin_mediaconverter_watermark");
    $row = $stmt->fetch(\PDO::FETCH_ASSOC);
    if ($row['image_content']) {
        $watermark_contents = $row['image_content'];
    }

    if (strlen($watermark_contents)) {
        $rs = file_put_contents($watermarkFile, $watermark_contents);
        if ($rs) {
            // position
            $overlay = 'main_w-overlay_w-' . (int) $pluginSettingsArr['watermark_padding'] . ':main_h-overlay_h-' . (int) $pluginSettingsArr['watermark_padding'];
            switch ($pluginSettingsArr['watermark_position']) {
                case 'top-left':
                    $overlay = (int) $pluginSettingsArr['watermark_padding'] . ':' . (int) $pluginSettingsArr['watermark_padding'];
                    break;
                case 'top-middle':
                    $overlay = 'main_w/2-overlay_w/2:' . (int) $pluginSettingsArr['watermark_padding'];
                    break;
                case 'top-right':
                    $overlay = 'main_w-overlay_w-' . (int) $pluginSettingsArr['watermark_padding'] . ':' . (int) $pluginSettingsArr['watermark_padding'];
                    break;
                case 'right':
                    $overlay = 'main_w-overlay_w-' . (int) $pluginSettingsArr['watermark_padding'] . ':main_h/2-overlay_h/2';
                    break;
                case 'bottom-right':
                    $overlay = 'main_w-overlay_w-' . (int) $pluginSettingsArr['watermark_padding'] . ':main_h-overlay_h-' . (int) $pluginSettingsArr['watermark_padding'];
                    break;
                case 'bottom-middle':
                    $overlay = 'main_w/2-overlay_w/2:main_h-overlay_h-' . (int) $pluginSettingsArr['watermark_padding'];
                    break;
                case 'bottom-left':
                    $overlay = (int) $pluginSettingsArr['watermark_padding'] . ':main_h-overlay_h-' . (int) $pluginSettingsArr['watermark_padding'];
                    break;
                case 'left':
                    $overlay = (int) $pluginSettingsArr['watermark_padding'] . ':main_h/2-overlay_h/2';
                    break;
                case 'middle':
                    $overlay = 'main_w/2-overlay_w/2:main_h/2-overlay_h/2';
                    break;
            }

            $conversionPathCmd = FFMPEG_PATH . ' -i ' . $localFile . ' -vcodec ' . $videoCodec . ' -r ' . CONVERT_FRAMERATE . ' -b:v ' . CONVERT_BITRATE . $enableExperimentalCodecsStr . ' -flags +aic+mv4 ' . $scale . '  -vf "movie=' . $watermarkFile . ' [watermark]; [in][watermark] overlay=' . $overlay . ' [out]" ' . $convertedFilename;
        }
    }
}

if (SCREENSHOT_ONLY == false) {
    // output to screen
    output("[" . SERVER_NAME_FOR_LOGS . "]: FFMPEG Command: \n" . $conversionPathCmd);
    $output = shell_exec($conversionPathCmd);

    // prepare notes
    output("[" . SERVER_NAME_FOR_LOGS . "]: Result: \n" . $output);
    output("\n");

    // standardise response
    $success = false;
    $status = 'failed';
    if ((file_exists($convertedFilename)) && (filesize($convertedFilename) > 0)) {
        // only for mp4 files
        if ($pluginSettingsArr['output_type'] == 'mp4') {
            // log
            output("[" . SERVER_NAME_FOR_LOGS . "]: Moving MOOV atom via qt-faststart to enable streaming...\n");

            $conversionPathCmd2 = 'qt-faststart ' . $convertedFilename . ' ' . $convertedFilename . '_tmp';
            output("[" . SERVER_NAME_FOR_LOGS . "]: Qt-faststart Command: \n" . $conversionPathCmd2);

            $output2 = shell_exec($conversionPathCmd2);

            // prepare notes
            output("[" . SERVER_NAME_FOR_LOGS . "]: Result: \n" . $output2);

            // sucessfully converted for streaming
            if (file_exists($convertedFilename . '_tmp')) {
                $conversionPathCmd3 = 'mv ' . $convertedFilename . '_tmp ' . $convertedFilename;
                shell_exec($conversionPathCmd3);
            }
        }

        $success = true;
        $status = 'completed';
    }
}
else {
    // log
    output("[" . SERVER_NAME_FOR_LOGS . "]: Skipping video conversion as this queue item is only to cpature the screenshot...\n");

    $convertedFilename = $localFile;
    $success = true;
    $status = 'completed';
}

// get screenshot from new file, problem with cross server file storage for these
if ($success == true) {
    // log
    output("[" . SERVER_NAME_FOR_LOGS . "]: Getting " . SCREENSHOT_PERIOD . " second screenshot...\n");

    // thumb path
    $thumbFilename = current(explode(".", MD5($file['id'])));
    $fullThumbPath = CACHE_SCREENSHOT_PATH;
    $fullThumbPath .= '/' . $thumbFilename . '.jpg';

    // ensure it doesn't exist from a previous convert
    if (file_exists($fullThumbPath)) {
        unlink($fullThumbPath);
    }

    // handle % screenshot calculations
    $screenshotSeconds = SCREENSHOT_PERIOD;
    if ($pluginSettingsArr['screenshot_type'] === 'percent') {
        // get video length
        $videoLengthCmd = FFMPEG_PATH . ' -i ' . $convertedFilename . ' 2>&1 | grep Duration | cut -d \' \' -f 4 | sed s/,//';
        if (SHOW_OUTPUT != 1) {
            $videoLengthCmd .= ' 2>&1';
        }
        $output = trim(shell_exec($videoLengthCmd));

        // prepare notes
        $notesMessage = "Video Length Command:\n";
        $notesMessage .= $videoLengthCmd . "\n\n";
        $notesMessage .= "[" . SERVER_NAME_FOR_LOGS . "]: Result:\n";
        $notesMessage .= $output;
        output($notesMessage);
        output("\n");

        if (strlen($output) > 0) {
            // convert to seconds
            $str_time = preg_replace("/^([\d]{1,2})\:([\d]{2})$/", "00:$1:$2", $output);
            sscanf($str_time, "%d:%d:%d", $hours, $minutes, $seconds);
            $totalSeconds = $hours * 3600 + $minutes * 60 + $seconds;
            if ((int) $totalSeconds > 0) {
                // calculate the %
                $screenshotSeconds = number_format((SCREENSHOT_PERIOD / 100) * $totalSeconds, 0, '.', '');
            }
        }
    }

    // format seconds for the ffmpeg command
    $dtF = new \DateTime('@0');
    $dtT = new \DateTime("@" . $screenshotSeconds);
    $formattedSeconds = $dtF->diff($dtT)->format('%H:%I:%S');

    $thumbPathCmd = FFMPEG_PATH . ' -ss ' . $formattedSeconds . '.01 -y -i ' . $convertedFilename . ' -vframes 1 ' . $fullThumbPath;
    if (SHOW_OUTPUT != 1) {
        $thumbPathCmd .= ' 2>&1';
    }
    $output = shell_exec($thumbPathCmd);

    // prepare notes
    $notesMessage = "ScreenShot Command:\n";
    $notesMessage .= $thumbPathCmd . "\n\n";
    $notesMessage .= "[" . SERVER_NAME_FOR_LOGS . "]: Result:\n";
    $notesMessage .= $output;
    output($notesMessage);
    output("\n");

    // if screen exists, move it to the core server for storage
    if ((file_exists($fullThumbPath)) && (filesize($fullThumbPath) > 0)) {
        $remoteScriptRoot = $pluginSettingsArr['script_path_root'];
        $remoteScriptThumbPath = $remoteScriptRoot . '/cache/plugins/mediaconverter/' . $file['id'] . '/original_thumb.jpg';

        // first try setting the file locally
        $done = false;
        if (ON_PRIMARY_SERVER == true) {
            if (!file_exists($remoteScriptThumbPath)) {
                @mkdir(dirname($remoteScriptThumbPath), 0777, true);
            }
            // need as the above actually reverts to 755 on some servers
            @chmod(dirname($remoteScriptThumbPath), 0777);
            $done = rename($fullThumbPath, $remoteScriptThumbPath);
        }

        // try over ssh
        if ($done == false) {
            // if we're connecting using keys, prepare it
            if(LOCAL_STORAGE_SSH_AUTH_TYPE === 'ssh_key') {
                $auth = new RSA();
                $auth->loadKey(LOCAL_STORAGE_SSH_KEY);
            }
            else {
                $auth = LOCAL_STORAGE_SSH_PASS;
            }
            
            // connect to 'local' storage via SSH
            $sftp = new SFTP(LOCAL_STORAGE_SSH_HOST);
            if (!$sftp->login(LOCAL_STORAGE_SSH_USER, $auth)) {
                output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Failed logging into " . LOCAL_STORAGE_SSH_HOST . " via SSH to transfer screenshot.\n");
            }
            else {
                // create folder structure
                $sftp->mkdir($remoteScriptRoot . '/cache/plugins/');
                @$sftp->chmod(0777, $remoteScriptRoot . '/cache/plugins/');
                $sftp->mkdir($remoteScriptRoot . '/cache/plugins/mediaconverter/');
                @$sftp->chmod(0777, $remoteScriptRoot . '/cache/plugins/mediaconverter/');
                $sftp->mkdir($remoteScriptRoot . '/cache/plugins/mediaconverter/' . $file['id'] . '/');
                @$sftp->chmod(0777, $remoteScriptRoot . '/cache/plugins/mediaconverter/' . $file['id'] . '/');

                // set folder to chmod 777
                //$sftp->chmod(0777, $remoteScriptRoot . '/cache/plugins/mediaconverter/'.$file['id'].'/');
                // upload screen
                $rs = $sftp->put($remoteScriptThumbPath, $fullThumbPath, SFTP::SOURCE_LOCAL_FILE);
                if (!$rs) {
                    output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Failed uploading thumb to " . LOCAL_STORAGE_SSH_HOST . " via SSH. Local file: " . $fullThumbPath . ". Remote path: " . $remoteScriptThumbPath . "\n");
                }
                @unlink($fullThumbPath);

                // set file to chmod 777
                //$sftp->chmod(0777, $remoteScriptThumbPath);
            }
        }
    }
}

if (SCREENSHOT_ONLY == false) {
    // rename to match original file
    $movePathMp3 = 'mv ' . $convertedFilename . ' ' . $convertedFilenameFinal;
    shell_exec($movePathMp3);

    // reconnect to database encase it's gone away
    $db = dbConnect();

    if ($success == true) {
        // log
        output("[" . SERVER_NAME_FOR_LOGS . "]: Moving converted file into storage...\n");

        // load hash for later
        $fileHash = md5_file($convertedFilenameFinal);

        // should we keep the original file?
        if ((int) $pluginSettingsArr['keep_original'] == 1) {
            // setup new file entry
            $newOriginalFilename = str_replace(array('.' . $file['mp4'], '.' . strtoupper($file['mp4'])), '', $file['originalFilename']) . ' (converted).' . EXPORT_FILE_EXTENSION;
            $newFilePath = current(explode('/', $file['localFilePath'])) . '/' . MD5(microtime() . rand(10000, 999999) . $file['id']);
            $stmt = $db->prepare("INSERT INTO file "
                    . "(folderId, originalFilename, shortUrl, fileType, extension, "
                    . "fileSize, localFilePath, userId, totalDownload, uploadedIP, "
                    . "uploadedDate, status, deleteHash, serverId, fileHash, "
                    . "adminNotes, linkedFileId) "
                    . "VALUES (:folderId, :originalFilename, :shortUrl, :fileType, "
                    . ":extension, :fileSize, :localFilePath, :userId, :totalDownload, "
                    . ":uploadedIP, :uploadedDate, :status, :deleteHash, :serverId, "
                    . ":fileHash, :adminNotes, :linkedFileId)");

            $replacements = array(
                ':folderId' => (int) $file['folderId'] ? $file['folderId'] : null,
                ':originalFilename' => $newOriginalFilename,
                ':shortUrl' => $file['shortUrl'] . '_' . rand(1000, 9999) . '_converted',
                ':fileType' => EXPORT_FILE_MIMETYPE,
                ':extension' => EXPORT_FILE_EXTENSION,
                ':fileSize' => filesize($convertedFilenameFinal),
                ':localFilePath' => $newFilePath,
                ':userId' => $file['userId'],
                ':totalDownload' => 0,
                ':uploadedIP' => $file['uploadedIP'],
                ':uploadedDate' => $file['uploadedDate'],
                ':status' => $file['status'],
                ':deleteHash' => MD5($file['deleteHash'] . rand(10000, 99999)),
                ':serverId' => $file['serverId'],
                ':fileHash' => $fileHash,
                ':adminNotes' => 'Converted from original file id ' . $file['id'],
                ':linkedFileId' => $file['id'],
            );
            foreach ($replacements AS $k => $v) {
                $stmt->bindValue($k, $v);
            }
            if (!$stmt) {
                echo "\nPDO::errorInfo():\n";
                print_r($db->errorInfo());
            }
            $rs = $stmt->execute();

            // overwrite our file object
            $stmt = $db->query("SELECT * "
                    . "FROM file "
                    . "WHERE id=" . (int) $db->lastInsertId() . " "
                    . "LIMIT 1");
            $file = $stmt->fetch(\PDO::FETCH_ASSOC);
        }

        // upload back into storage
        $rs = setFileContent($db, $file, $convertedFilenameFinal);
        if (!$rs) {
            // log
            output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Could not set file contents back into storage: " . $convertedFilenameFinal . ".\n");

            // remove converted file
            @unlink($convertedFilenameFinal);

            // set to failed
            $db->query("UPDATE plugin_mediaconverter_queue "
                    . "SET status='failed', "
                    . "date_finished=NOW(), "
                    . "notes='" . str_replace("'", "\\'", mediaConverterOutputTracker::getAsString()) . "' "
                    . "WHERE id=" . $pendingRow['id'] . " "
                    . "LIMIT 1");

            // logs
            LogHelper::breakInLogFile();

            // background task logging
            BackgroundTaskHelper::end();
            exit;
        }

        // update existing
        if ((int) $pluginSettingsArr['keep_original'] == 0) {
            // reconnect to database encase it's gone away
            $db = dbConnect();

            // update database with new file information
            $newOriginalFilename = str_replace(array('.' . $file['extension'], '.' . strtoupper($file['extension'])), '', $file['originalFilename']) . '.' . EXPORT_FILE_EXTENSION;
            $stmt = $db->prepare("UPDATE file "
                    . "SET originalFilename=:originalFilename, "
                    . "fileType=:fileType, extension=:extension, "
                    . "fileSize=:fileSize, "
                    . "fileHash=:newFileHash "
                    . "WHERE fileHash=:oldFileHash");
            $replacements = array(
                ':originalFilename' => $newOriginalFilename,
                ':fileType' => EXPORT_FILE_MIMETYPE,
                ':extension' => EXPORT_FILE_EXTENSION,
                ':fileSize' => filesize($convertedFilenameFinal),
                ':newFileHash' => $fileHash,
                ':oldFileHash' => $file['fileHash'],
            );
            $rs = $stmt->execute($replacements);

            if (!$rs) {
                // log
                output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Could not update the remote database.\n");

                // remove converted file
                @unlink($convertedFilenameFinal);

                // set to failed
                $db->query("UPDATE plugin_mediaconverter_queue "
                        . "SET status='failed', "
                        . "date_finished=NOW(), "
                        . "notes='" . str_replace("'", "\\'", mediaConverterOutputTracker::getAsString()) . "' "
                        . "WHERE id=" . $pendingRow['id'] . " "
                        . "LIMIT 1");

                // logs
                LogHelper::breakInLogFile();

// background task logging
                BackgroundTaskHelper::end();
                exit;
            }
        }
    }
}
else {
    $success = true;
}

// log
if ($success == true) {
    // remove converted file
    @unlink($convertedFilenameFinal);

    output("[" . SERVER_NAME_FOR_LOGS . "]: Completed conversion, id #" . $pendingRow['id'] . ".\n");
    
    if ((int) $file['folderId'] > 0) {
        FileFolderHelper::updateFolderFilesize((int) $file['folderId']);
    }
}
else {
    output("[" . SERVER_NAME_FOR_LOGS . "]: Failed conversion, id #" . $pendingRow['id'] . ".\n");
}

// remove original file
@unlink($localFile);

// reconnect to database encase it's gone away
$db = dbConnect();

// update database to completed
$db->query("UPDATE plugin_mediaconverter_queue "
        . "SET status='" . $status . "', "
        . "date_finished=NOW(), "
        . "notes='" . str_replace("'", "\\'", mediaConverterOutputTracker::getAsString()) . "' "
        . "WHERE id=" . $pendingRow['id'] . " "
        . "LIMIT 1");

// logs
LogHelper::breakInLogFile();

// background task logging
BackgroundTaskHelper::end();

/*
 * Functions
 */

function output($msg, $skipLogs = false) {
    if (SHOW_OUTPUT == 1) {
        echo $msg;
    }

    // log to file
    if ($skipLogs === false) {
        LogHelper::info($msg);
    }
}

function getFileContent($db, $file) {
    // setup local cached file
    $localFilename = md5(microtime().CoreHelper::generateRandomHash()) . '.' . $file['extension'];
    $localFilePath = CACHE_PATH . '/' . $localFilename;

    // setup file object
    $fileObj = File::hydrateSingleRecord($file);

    // get remote file path
    $remoteFilePath = $fileObj->getFullFilePath();

    // figure out server storage setup
    $uploadServerDetails = loadServer($db, $file);
    $storageType = $uploadServerDetails['serverType'];

    // call plugin hooks
    $params = PluginHelper::callHook('fileDownloadGetFileContent', array(
                'actioned' => false,
                'file' => $fileObj,
                'storageType' => $storageType,
                'forceDownload' => false,
                'seekStart' => 0,
    ));

    // exit if we're done processing the item
    if ($params['actioned'] === true) {
        // save to local temp file
        file_put_contents($localFilePath, $params['fileContent']);

        return $localFilePath;
    }

    // use ssh to get contents of 'local' files
    if (($storageType == 'local') || ($storageType == 'direct')) {
        // first try getting the file locally
        $done = false;
        if ((ON_SCRIPT_INSTALL == true) && file_exists($remoteFilePath)) {
            $done = copy($remoteFilePath, $localFilePath);
            if ($done) {
                return $localFilePath;
            }
        }

        // try over ssh
        if ($done == false) {
            $sshHost = LOCAL_STORAGE_SSH_HOST;
            $sshUser = LOCAL_STORAGE_SSH_USER;
            $sshPass = LOCAL_STORAGE_SSH_PASS;
            $sshKey = LOCAL_STORAGE_SSH_KEY;
            $sshAuthType = LOCAL_STORAGE_SSH_AUTH_TYPE;

            // if 'direct' file server, get SSH details
            $serverDetails = getDirectFileServerSSHDetails($file['serverId']);
            if ($serverDetails) {
                $sshHost = $serverDetails['ssh_host'];
                $sshPort = $serverDetails['ssh_port'];
                $sshUser = $serverDetails['ssh_username'];
                $sshPass = $serverDetails['ssh_password'];
                $sshKey = $serverDetails['ssh_key'];
                $sshAuthType = $serverDetails['ssh_authentication_type'];
            }

            if (strlen($sshPort) == 0) {
                $sshPort = 22;
            }
            
            // if we're connecting using keys, prepare it
            if($sshAuthType === 'ssh_key') {
                $auth = new RSA();
                $auth->loadKey($sshKey);
            }
            else {
                $auth = $sshPass;
            }

            // connect to 'local' storage via SSH
            $sftp = new SFTP($sshHost, $sshPort, 20);
            if (!$sftp->login($sshUser, $auth)) {
                output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Failed logging into " . $sshHost . " (port: " . $sshPort . ") via SSH..\n");

                return false;
            }

            // get file
            $rs = $sftp->get($remoteFilePath, $localFilePath);
            if ($rs) {
                return $localFilePath;
            }
        }

        output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Failed getting file: " . $remoteFilePath . "\n");

        return false;
    }

    // ftp
    if ($storageType == 'ftp') {
        // connect via ftp
        $conn_id = ftp_connect($uploadServerDetails['ipAddress'], $uploadServerDetails['ftpPort'], 30);
        if ($conn_id === false) {
            output('[' . SERVER_NAME_FOR_LOGS . ']: Could not connect to ' . $uploadServerDetails['ipAddress'] . ' to upload file.');
            return false;
        }

        // authenticate
        $login_result = ftp_login($conn_id, $uploadServerDetails['ftpUsername'], $uploadServerDetails['ftpPassword']);
        if ($login_result === false) {
            output('[' . SERVER_NAME_FOR_LOGS . ']: Could not login to ' . $uploadServerDetails['ipAddress'] . ' with supplied credentials.');
            return false;
        }

        // get content
        $ret = ftp_get($conn_id, $localFilePath, $remoteFilePath, FTP_BINARY);
        while ($ret == FTP_MOREDATA) {
            $ret = ftp_nb_continue($conn_id);
        }
    }

    // check for file via Flysystem
    if (substr($storageType, 0, 10) == 'flysystem_') {
        $filesystem = FileServerContainerHelper::init($uploadServerDetails['id']);
        if (!$filesystem) {
            output(t('classuploader_could_not_setup_adapter_to_download', 'Could not setup adapter to download file.'));
            return false;
        }
        else {
            // check the file exists
            try {
                // get file path
                $fullPath = $fileObj->getFullFilePath();

                // check for the file
                $rs = $filesystem->has($fullPath);
                if (!$rs) {
                    output('Could not locate the file. Please contact support or try again.');
                    return false;
                }
            }
            catch (Exception $e) {
                output($e->getMessage());
                return false;
            }
        }

        // handle download using flysystem
        try {
            // create stream to handle larger files
            $handle = $filesystem->readStream($fullPath);

            // move to starting position
            fseek($handle, $seekStart);

            // save to local temp file
            $handleNew = fopen($localFilePath, 'wb');
            if ($handleNew) {
                while (!feof($handle)) {
                    fwrite($handleNew, fread($handle, 1024 * 8), 1024 * 8);
                }
            }

            fclose($handle);
            fclose($handleNew);
        }
        catch (Exception $e) {
            output($e->getMessage());

            return false;
        }
    }

    if (file_exists($localFilePath) && (filesize($localFilePath) > 0)) {
        return $localFilePath;
    }

    output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Failed getting file: " . $remoteFilePath . "\n");

    return false;
}

// TODO - move core
function setFileContent($db, $file, $localFilePath) {
    // setup file object
    $fileObj = File::hydrateSingleRecord($file);

    // get remote file path
    $remoteFilePath = $fileObj->getFullFilePath();

    // figure out server storage setup
    $uploadServerDetails = loadServer($db, $file);
    $storageType = $uploadServerDetails['serverType'];

    // get subfolder
    $subFolder = current(explode("/", $file['localFilePath']));
    $originalFilename = end(explode("/", $file['localFilePath']));

    // call plugin hooks
    $fileUpload = new \stdClass();
    $fileUpload->error = null;
    $params = PluginHelper::callHook('storeFile', array(
                'actioned' => false,
                'file' => $fileObj,
                'fileUpload' => $fileUpload,
                'uploadServerDetails' => $uploadServerDetails,
                'newFilename' => $originalFilename,
                'tmpFile' => $localFilePath,
                'keepTmpFile' => true,
    ));

    // exit if we're done processing the item
    if ($params['actioned'] === true) {
        return true;
    }

    // use ssh to get contents of 'local' files
    if (($storageType == 'local') || ($storageType == 'direct')) {
        // first try setting the file locally
        $done = false;
        if (ON_SCRIPT_INSTALL == true) {
            $done = copy($localFilePath, $remoteFilePath);
            if ($done) {
                return true;
            }
        }

        // try over ssh
        if ($done == false) {
            $sshHost = LOCAL_STORAGE_SSH_HOST;
            $sshUser = LOCAL_STORAGE_SSH_USER;
            $sshPass = LOCAL_STORAGE_SSH_PASS;
            $sshKey = LOCAL_STORAGE_SSH_KEY;
            $sshAuthType = LOCAL_STORAGE_SSH_AUTH_TYPE;

            // if 'direct' file server, get SSH details
            $serverDetails = getDirectFileServerSSHDetails($file['serverId']);
            if ($serverDetails) {
                $sshHost = $serverDetails['ssh_host'];
                $sshPort = $serverDetails['ssh_port'];
                $sshUser = $serverDetails['ssh_username'];
                $sshPass = $serverDetails['ssh_password'];
                $sshKey = $serverDetails['ssh_key'];
                $sshAuthType = $serverDetails['ssh_authentication_type'];
            }

            if (strlen($sshPort) == 0) {
                $sshPort = 22;
            }
            
            // if we're connecting using keys, prepare it
            if($sshAuthType === 'ssh_key') {
                $auth = new RSA();
                $auth->loadKey($sshKey);
            }
            else {
                $auth = $sshPass;
            }

            // connect to 'local' storage via SSH
            $sftp = new SFTP($sshHost, $sshPort, 20);
            if (!$sftp->login($sshUser, $auth)) {
                output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Failed logging into " . $sshHost . " (Port: " . $sshPort . ") via SSH..\n");

                return false;
            }

            // overwrite file
            $rs = $sftp->put($remoteFilePath, $localFilePath, SFTP::SOURCE_LOCAL_FILE);
            if ($rs) {
                return true;
            }

            output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Failed uploading converted file to " . LOCAL_STORAGE_SSH_HOST . " (" . $remoteFilePath . ") via SSH..\n");
        }

        output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Failed setting file: " . $remoteFilePath . "\n");

        return false;
    }

    // ftp
    if ($storageType == 'ftp') {
        // connect via ftp
        $conn_id = ftp_connect($uploadServerDetails['ipAddress'], $uploadServerDetails['ftpPort'], 30);
        if ($conn_id === false) {
            output('[' . SERVER_NAME_FOR_LOGS . ']: Could not connect to ' . $uploadServerDetails['ipAddress'] . ' to upload file.');
            return false;
        }

        // authenticate
        $login_result = ftp_login($conn_id, $uploadServerDetails['ftpUsername'], $uploadServerDetails['ftpPassword']);
        if ($login_result === false) {
            output('[' . SERVER_NAME_FOR_LOGS . ']: Could not login to ' . $uploadServerDetails['ipAddress'] . ' with supplied credentials.');
            return false;
        }

        // get content
        $rs = ftp_put($conn_id, $remoteFilePath, $localFilePath, FTP_BINARY);
        if ($rs == true) {
            return true;
        }
    }

    // upload via Flysystem
    if (substr($storageType, 0, 10) == 'flysystem_') {
        $filesystem = FileServerContainerHelper::init($uploadServerDetails['id']);
        if (!$filesystem) {
            output(t('classuploader_could_not_setup_adapter_to_download_file', 'Could not setup adapter to download file.'));

            return false;
        }

        try {
            // remove old file
            $filesystem->delete($remoteFilePath);

            // upload file
            $stream = fopen($localFilePath, 'r+');
            $rs = $filesystem->writeStream($remoteFilePath, $stream);
            if (!$rs) {
                output('Could not upload file. Please contact support or try again.');

                return false;
            }

            return true;
        }
        catch (Exception $e) {
            output($e->getMessage());

            return false;
        }
    }

    output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Failed setting file: " . $remoteFilePath . "\n");
    output("[" . SERVER_NAME_FOR_LOGS . "]: Error: Failed uploading converted file to " . $uploadServerDetails['ipAddress'] . " via FTP..\n");

    return false;
}

function loadServer($db, $file) {
    // load the server the file is on
    if ((int) $file['serverId']) {
        // load from the db
        $db = dbConnect();
        $stmt = $db->query("SELECT * "
                . "FROM file_server "
                . "WHERE id = " . (int) $file['serverId']);
        $uploadServerDetails = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$uploadServerDetails) {
            return false;
        }

        return $uploadServerDetails;
    }

    return false;
}

function getDirectFileServerSSHDetails($serverId) {
    // get direct file server ssh details
    $directFileServers = FileServerHelper::getFileServerAccessDetails();
    if (COUNT($directFileServers) == 0) {
        return false;
    }

    foreach ($directFileServers AS $directFileServer) {
        if ($directFileServer['file_server_id'] == $serverId) {
            return $directFileServer;
        }
    }

    return false;
}

function dbConnect() {
    $db = new \PDO('mysql:host=' . DATABASE_HOST . ';dbname=' . DATABASE_NAME . ';charset=utf8', DATABASE_USER, DATABASE_PASS);
    $db->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);

    return $db;
}

// output tracking for logs in the database
class mediaConverterOutputTracker
{
    public static $output = array();

    static function add($str) {
        self::$output[] = $str;
    }

    static function getAsString() {
        return implode("\n", self::$output);
    }

}
