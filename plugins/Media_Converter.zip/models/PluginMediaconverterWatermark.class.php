<?php

namespace Plugins\Mediaconverter\Models;

use App\Core\Model;

class PluginMediaconverterWatermark extends Model
{
    
}
