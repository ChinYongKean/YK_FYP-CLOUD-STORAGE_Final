<?php

namespace Plugins\Mediaconverter\Models;

use App\Core\Model;

class PluginMediaconverterQueue extends Model
{
    
}
