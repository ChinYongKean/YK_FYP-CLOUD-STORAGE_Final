<?php

// plugin namespace

namespace Plugins\Mediaconverter;

// core includes
use App\Core\Database;
use App\Helpers\CoreHelper;
use App\Helpers\FileActionHelper;
use App\Helpers\FileHelper;
use App\Helpers\FileServerHelper;
use App\Models\File;
use App\Services\Plugin;
use Plugins\Mediaconverter\PluginConfig;
use Plugins\Mediaconverter\Models\PluginMediaconverterQueue;

class PluginMediaconverter extends Plugin
{
    public $config = null;
    public $data = null;

    public function __construct() {
        // load plugin config
        $this->config = (new PluginConfig())->getPluginConfig();
        $this->cachePath = CACHE_DIRECTORY_ROOT . '/plugins/mediaconverter/';
    }

    public function registerRoutes(\FastRoute\RouteCollector $r) {
        // register plugin routes
        $r->addRoute(['GET', 'POST'], '/' . ADMIN_FOLDER_NAME . '/plugin/' . $this->config['folder_name'] . '/settings', '\plugins\\' . $this->config['folder_name'] . '\controllers\admin\PluginController/pluginSettings');
        $r->addRoute(['GET', 'POST'], '/' . ADMIN_FOLDER_NAME . '/conversion_manage', '\plugins\\'.$this->config['folder_name'].'\controllers\admin\PluginController/conversionManage');
        $r->addRoute(['GET', 'POST'], '/' . ADMIN_FOLDER_NAME . '/ajax/conversion_manage', '\plugins\\'.$this->config['folder_name'].'\controllers\admin\PluginController/ajaxConversionManage');
        $r->addRoute(['GET'], '/cache/plugins/mediaconverter/{fileId}/{width:[0-9]+}x{height:[0-9]+}_{method}_{pluginSettingsHash}.{extension}', '\plugins\\'.$this->config['folder_name'].'\controllers\MediaconverterController/resizeThumb');
    }

    public function getPluginDetails() {
        return $this->config;
    }

    public function uninstall() {
        // setup database
        $db = Database::getDatabase();

        // remove plugin specific tables
        $sQL = 'DROP TABLE plugin_mediaconverter_queue';
        $db->query($sQL);
        $sQL = 'DROP TABLE plugin_mediaconverter_watermark';
        $db->query($sQL);

        return parent::uninstall();
    }
    
    public function getStatusList() {
        return array('pending', 'processing', 'completed', 'failed', 'cancelled');
    }
    
    public function deleteMediaCache($fileId) {
        // queue for delete
        $serverId = FileHelper::getDefaultLocalServerId();
        if ($serverId) {
            // queue cache for delete on local server
            $docRoot = FileServerHelper::getDocRoot($serverId);
            $cacheFilePath = $docRoot . '/cache/plugins/mediaconverter/' . $fileId . '/original_thumb.jpg';
            FileActionHelper::queueDeleteFile($serverId, $cacheFilePath, $fileId);
        }
    }

    public function duplicateMediaCache($fromFileId, $toFileId) {
        // get cache paths
        $fromCacheFilePath = $this->cachePath . $fromFileId . '/';
        $toCacheFilePath = $this->cachePath . $toFileId . '/';

        // @TODO - queue for moving
    }

    public function scheduleForConverting(File $file, $convertVideo = true, $captureScreen = true) {
        // schedule for converting
        $pluginMediaconverterQueue = PluginMediaconverterQueue::create();
        $pluginMediaconverterQueue->file_id = $file->id;
        $pluginMediaconverterQueue->status = 'pending';
        $pluginMediaconverterQueue->date_added = CoreHelper::sqlDateTime();
        $pluginMediaconverterQueue->capture_video = (int) $convertVideo;
        $pluginMediaconverterQueue->capture_screen = (int) $captureScreen;

        return $pluginMediaconverterQueue->save();
    }
    
    public function createThumbCacheUrl($fileArr, $thumbnailWidth, $thumbnailHeight, $method = 'cropped', $extension = 'jpg') {
        $pluginSettings = $this->getPluginSettings();
        $cacheFileName = (int)$fileArr['id'].'/'.(int) $thumbnailWidth . 'x' . (int) $thumbnailHeight . '_' . $method.'_'. md5(json_encode($pluginSettings)) . '.jpg';

        return CACHE_WEB_ROOT . '/plugins/mediaconverter/' . $cacheFileName;
    }

}
