<?php

namespace Plugins\Mediaconverter;

use App\Services\PluginConfig AS CorePluginConfig;

class PluginConfig extends CorePluginConfig
{
    /**
     * Setup the plugin config.
     *
     * @var array
     */
    public $config = array(
        'plugin_name' => 'Media Converter',
        'folder_name' => 'mediaconverter',
        'plugin_description' => 'Convert various video formats to mp4, flv or webm.',
        'plugin_version' => '28.0',
        'required_script_version' => '5.0',
        'database_sql' => 'offline/database.sql',
    );

}
