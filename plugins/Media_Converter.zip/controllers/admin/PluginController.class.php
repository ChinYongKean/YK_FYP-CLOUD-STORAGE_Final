<?php

namespace Plugins\Mediaconverter\Controllers\Admin;

use App\Core\Database;
use App\Controllers\Admin\PluginController AS CorePluginController;
use App\Helpers\AdminHelper;
use App\Helpers\CoreHelper;
use App\Helpers\PluginHelper;
use App\Models\File;
use App\Models\Plugin;
use Plugins\Mediaconverter\Models\PluginMediaconverterWatermark;

class PluginController extends CorePluginController
{

    public function pluginSettings() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // load plugin details
        $folderName = 'mediaconverter';
        $plugin = Plugin::loadOneByClause('folder_name = :folder_name', array(
                    'folder_name' => $folderName,
        ));

        if (!$plugin) {
            return $this->redirect(ADMIN_WEB_ROOT . '/plugin_manage?error=' . urlencode('There was a problem loading the plugin details.'));
        }

        $defaultSupportedFileExtensions = 'avi,3gp,ogg,mpg,mpeg,mov,mj2,flv,wmv,webm,mp4,m4v';

        $plugin_enabled = (int) $plugin->plugin_enabled;
        $max_conversions = 1;
        $video_size_w = 640;
        $video_size_h = 320;
        $output_messages = 1;
        $convert_files = $defaultSupportedFileExtensions;
        $output_type = 'mp4';
        $watermark_enabled = 0;
        $watermark_contents = '';
        $watermark_filename = '';
        $watermark_position = 'bottom-right';
        $watermark_padding = 10;
        $script_path_root = DOC_ROOT;
        $keep_original = 0;
        $convert_videos = 1;
        $screenshot_type = 'seconds';
        $screenshot_period = 15;
        $enable_experimental_codecs = 1;

        // load existing settings
        if (strlen($plugin->plugin_settings)) {
            $plugin_settings = json_decode($plugin->plugin_settings, true);
            if ($plugin_settings) {
                $max_conversions = (int) $plugin_settings['max_conversions'];
                $video_size_w = (int) $plugin_settings['video_size_w'];
                $video_size_h = (int) $plugin_settings['video_size_h'];
                $output_messages = (int) $plugin_settings['output_messages'];
                $convert_files = $plugin_settings['convert_files'];
                $output_type = $plugin_settings['output_type'];
                $watermark_enabled = (int) $plugin_settings['watermark_enabled'];
                $watermark_position = $plugin_settings['watermark_position'];
                $watermark_padding = (int) $plugin_settings['watermark_padding'];
                $keep_original = (int) $plugin_settings['keep_original'];
                $convert_videos = isset($plugin_settings['convert_videos']) ? (int) $plugin_settings['convert_videos'] : 1;
                $screenshot_type = isset($plugin_settings['screenshot_type']) ? $plugin_settings['screenshot_type'] : $screenshot_type;
                $screenshot_period = isset($plugin_settings['screenshot_period']) ? $plugin_settings['screenshot_period'] : $screenshot_period;
                $enable_experimental_codecs = isset($plugin_settings['enable_experimental_codecs']) ? $plugin_settings['enable_experimental_codecs'] : $enable_experimental_codecs;

                // load watermark
                if ($watermark_enabled == 1) {
                    $watermark = $db->getRow("SELECT file_name, image_content FROM plugin_mediaconverter_watermark");
                    if ($watermark) {
                        $watermark_contents = $watermark['image_content'];
                        $watermark_filename = $watermark['file_name'];
                    }
                    else {
                        $watermark_enabled = 0;
                    }
                }
            }
        }

        // handle page submissions
        if ($request->request->has('submitted')) {
            // get variables
            $plugin_enabled = (int) $request->request->get('plugin_enabled');
            $plugin_enabled = $plugin_enabled != 1 ? 0 : 1;
            $max_conversions = (int) $_REQUEST['max_conversions'];
            $video_size_w = (int) $_REQUEST['video_size_w'];
            $video_size_h = (int) $_REQUEST['video_size_h'];
            $output_messages = (int) $_REQUEST['output_messages'];
            $convert_files = str_replace(array(".", " "), "", strtolower(trim($_REQUEST['convert_files'])));
            $output_type = $_REQUEST['output_type'];
            $watermark_enabled = (int) $_REQUEST['watermark_enabled'];
            $watermark_position = $_REQUEST['watermark_position'];
            $watermark_padding = (int) $_REQUEST['watermark_padding'];
            $keep_original = (int) $_REQUEST['keep_original'];
            $convert_videos = (int) $_REQUEST['convert_videos'];
            $screenshot_type = $_REQUEST['screenshot_type'];
            $screenshot_period = (int) $_REQUEST['screenshot_period'];
            $enable_experimental_codecs = (int) $_REQUEST['enable_experimental_codecs'];

            // validate submission
            if (_CONFIG_DEMO_MODE == true) {
                AdminHelper::setError(AdminHelper::t('no_changes_in_demo_mode', 'No change permitted in demo mode.'));
            }
            elseif ($plugin_enabled == 1) {
                if ($max_conversions == 0) {
                    AdminHelper::setError(AdminHelper::t("plugin_mediaconverter_max_concurrent_conversions_can_not_be_zero", "Max concurrent conversions can not be zero."));
                }
                elseif ($video_size_w == 0) {
                    AdminHelper::setError(AdminHelper::t("plugin_mediaconverter_set_max_video_width", "Please set the maximum video width."));
                }
                elseif ($video_size_h == 0) {
                    AdminHelper::setError(AdminHelper::t("plugin_mediaconverter_set_max_video_height", "Please set the maximum video height."));
                }
                elseif (strlen($convert_files) == 0) {
                    AdminHelper::setError(AdminHelper::t("plugin_mediaconverter_set_file_extensions", "Please set the file types to convert. i.e. avi,3gp,ogg"));
                }
                elseif ($watermark_enabled == 1) {
                    // new uploaded image
                    if (strlen($_FILES["watermark_image"]["name"])) {
                        // make sure we've got an image
                        $file = $_FILES["watermark_image"]["name"];
                        $extension = strtolower(end(explode(".", $file)));
                        if ($extension != 'png') {
                            AdminHelper::setError(AdminHelper::t("plugin_image_viewer_watermark_must_be_a_png", "Watermark image must be a png image."));
                        }
                        else {
                            $watermark_filename = $_FILES["watermark_image"]["name"];
                            $watermark_contents = file_get_contents($_FILES["watermark_image"]["tmp_name"]);
                        }
                    }
                }
                else {
                    $watermark_contents = '';
                    $watermark_filename = '';
                }
            }

            // update the settings
            if (AdminHelper::isErrors() == false) {
                // compile new settings
                $settingsArr = array();
                $settingsArr['max_conversions'] = $max_conversions;
                $settingsArr['video_size_w'] = $video_size_w;
                $settingsArr['video_size_h'] = $video_size_h;
                $settingsArr['output_messages'] = $output_messages;
                $settingsArr['ssh_host'] = '';
                $settingsArr['ssh_user'] = '';
                $settingsArr['ssh_password'] = '';
                $settingsArr['convert_files'] = $convert_files;
                $settingsArr['output_type'] = $output_type;
                $settingsArr['watermark_enabled'] = (int) $watermark_enabled;
                $settingsArr['watermark_position'] = $watermark_position;
                $settingsArr['watermark_padding'] = (int) $watermark_padding;
                $settingsArr['script_path_root'] = $script_path_root;
                $settingsArr['keep_original'] = $keep_original;
                $settingsArr['convert_videos'] = $convert_videos;
                $settingsArr['screenshot_type'] = $screenshot_type;
                $settingsArr['screenshot_period'] = $screenshot_period;
                $settingsArr['enable_experimental_codecs'] = $enable_experimental_codecs;

                // update the plugin settings
                $plugin->plugin_enabled = $plugin_enabled;
                $plugin->plugin_settings = json_encode($settingsArr);
                $plugin->save();

                // update watermark, delete exists
                $db->query("DELETE FROM plugin_mediaconverter_watermark");
                $pluginMediaConverterWatermark = PluginMediaconverterWatermark::create();
                $pluginMediaConverterWatermark->file_name = $watermark_filename;
                $pluginMediaConverterWatermark->image_content = $watermark_contents;
                $pluginMediaConverterWatermark->save();

                // reload plugin cache
                PluginHelper::loadPluginConfigurationFiles(true);

                // set onscreen alert
                AdminHelper::setSuccess('Plugin settings updated.');
            }
        }

        // check for curl
        if (function_exists('curl_version') === false) {
            AdminHelper::setError(AdminHelper::t("plugin_mediaconverter_curl_required", "Could not find Curl functions in your PHP configuration. Please contact your host to enable Curl otherwise this plugin wont work."));
        }

        // load template
        return $this->render('admin/plugin_settings.html', array(
                    'pluginName' => $plugin->plugin_name,
                    'yesNoOptions' => array(
                        0 => 'No',
                        1 => 'Yes'),
                    'watermarkPositionOptions' => array(
                        'top-left' => 'Top-Left',
                        'top-middle' => 'Top-Middle',
                        'top-right' => 'Top-Right',
                        'right' => 'Right',
                        'bottom-right' => 'Bottom-Right',
                        'bottom-middle' => 'Bottom-Middle',
                        'bottom-left' => 'Bottom-Left',
                        'left' => 'Left',
                        'middle' => 'Middle',
                    ),
                    'convertVideosOptions' => array(
                        0 => 'No (just capture the video screenshot)',
                        1 => 'Yes (convert videos and capture the video screenshot)',
                    ),
                    'outputTypeOptions' => array('mp4' => 'MP4 (default)',
                        'flv' => 'FLV',
                        'webm' => 'WEBM',
                    ),
                    'screenshotTypeOptions' => array(
                        'seconds' => 'Take After x Seconds',
                        'percent' => 'Take After x Percent',
                    ),
                    'plugin_enabled' => $plugin_enabled,
                    'max_conversions' => $max_conversions,
                    'video_size_w' => $video_size_w,
                    'video_size_h' => $video_size_h,
                    'output_messages' => $output_messages,
                    'convert_files' => $convert_files,
                    'output_type' => $output_type,
                    'watermark_enabled' => $watermark_enabled,
                    'watermark_contents' => $watermark_contents,
                    'watermark_contents_base64' => strlen($watermark_contents) ? base64_encode($watermark_contents) : '',
                    'watermark_filename' => $watermark_filename,
                    'watermark_position' => $watermark_position,
                    'watermark_padding' => $watermark_padding,
                    'script_path_root' => $script_path_root,
                    'keep_original' => $keep_original,
                    'convert_videos' => $convert_videos,
                    'screenshot_type' => $screenshot_type,
                    'screenshot_period' => $screenshot_period,
                    'enable_experimental_codecs' => $enable_experimental_codecs,
                    'defaultSupportedFileExtensions' => $defaultSupportedFileExtensions,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function conversionManage() {
        // admin restrictions
        $this->restrictAdminAccess();

        // for later
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $mediaconverterObj = PluginHelper::getInstance('mediaconverter');

        // process submits
        $file_short_urls = '';
        $file_convert_type = 'video';
        if ($request->query->has('cancel')) {
            $db->query('UPDATE plugin_mediaconverter_queue '
                    . 'SET status = "cancelled" '
                    . 'WHERE id = :id '
                    . 'LIMIT 1', array(
                'id' => $request->query->get('cancel'),
            ));
            AdminHelper::setSuccess('Conversion job cancelled.');
        }
        elseif ($request->query->has('redo')) {
            $db->query('UPDATE plugin_mediaconverter_queue '
                    . 'SET status = "pending" '
                    . 'WHERE id = :id '
                    . 'LIMIT 1', array(
                'id' => $request->query->get('redo'),
            ));
            AdminHelper::setSuccess('Conversion job re-scheduled.');
        }
        elseif ($request->request->has('file_short_urls')) {
            $file_short_urls = trim($request->request->get('file_short_urls'));
            $file_convert_type = trim($request->request->get('file_convert_type'));
            if (strlen($file_short_urls)) {
                // load plugin details
                $pluginConfig = PluginHelper::pluginSpecificConfiguration('mediaconverter');
                $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);

                // total stats
                $totalQueued = 0;
                $totalFailed = 0;
                $failedItems = array();

                // break apart to allow for multiple files
                $fileShortUrls = explode(",", $file_short_urls);
                foreach ($fileShortUrls AS $fileShortUrl) {
                    // load file
                    $fileShortUrl = trim($fileShortUrl);
                    $file = File::loadOneByShortUrl($fileShortUrl);
                    if (!$file) {
                        $totalFailed++;
                        $failedItems[] = $fileShortUrl;
                    }
                    else {
                        // check file type
                        $fileTypes = explode(",", strtolower($pluginSettings['convert_files']));

                        // make sure it's active and a video file
                        if (($file->status == 'active') && (in_array(strtolower($file->extension), $fileTypes))) {
                            // inital params
                            $convertVideo = true;
                            $captureScreen = true;
                            if ($file_convert_type == 'screenshot') {
                                $convertVideo = false;
                            }

                            // add to queue
                            $rs = $mediaconverterObj->scheduleForConverting($file, $convertVideo, $captureScreen);
                            if ($rs) {
                                $totalQueued++;
                            }
                            else {
                                $totalFailed++;
                                $failedItems[] = $fileShortUrl;
                            }
                        }
                        else {
                            $totalFailed++;
                            $failedItems[] = $fileShortUrl;
                        }
                    }
                }

                // output
                if ($totalFailed > 0) {
                    AdminHelper::setError('There was a problem adding ' . $totalFailed . ' item(s) to the queue, please try again later. If you submitted more items, these have been successfully added. Failed items:<br/><br/>' . implode(', ', $failedItems));
                }
                else {
                    AdminHelper::setSuccess('Video(s) queued for conversion/screen capture.');
                }
            }
        }

        // overview stats
        $totalPending = (int) $db->getValue("SELECT COUNT(id) AS total "
                        . "FROM plugin_mediaconverter_queue "
                        . "WHERE status = 'pending'");
        $totalFailedLast3Days = (int) $db->getValue("SELECT COUNT(id) AS total "
                        . "FROM plugin_mediaconverter_queue "
                        . "WHERE status = 'pending' "
                        . "AND date_started BETWEEN NOW() - INTERVAL 3 DAY AND NOW()");
        $totalConversions = (int) $db->getValue("SELECT COUNT(id) AS total "
                        . "FROM plugin_mediaconverter_queue "
                        . "WHERE status = 'completed'");
        $totalConversionsLast3Days = (int) $db->getValue("SELECT COUNT(id) AS total "
                        . "FROM plugin_mediaconverter_queue "
                        . "WHERE status = 'completed' "
                        . "AND date_finished BETWEEN NOW() - INTERVAL 3 DAY AND NOW()");


        // load template
        return $this->render('admin/conversion_manage.html', array(
                    'mediaconverterObj' => $mediaconverterObj,
                    'statusDetails' => $mediaconverterObj->getStatusList(),
                    'totalPending' => $totalPending,
                    'totalFailedLast3Days' => $totalFailedLast3Days,
                    'totalConversions' => $totalConversions,
                    'totalConversionsLast3Days' => $totalConversionsLast3Days,
                    'scheduleConversionOptions' => array(
                        'video' => 'Convert Video & Capture Screenshot',
                        'screenshot' => 'Capture Screenshot Only',
                    ),
                        ), PLUGIN_DIRECTORY_ROOT . 'mediaconverter/views');
    }

    public function ajaxConversionManage() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        $iDisplayLength = (int) $request->query->get('iDisplayLength');
        $iDisplayStart = (int) $request->query->get('iDisplayStart');
        $sSortDir_0 = ($request->query->has('sSortDir_0') && $request->query->get('sSortDir_0') === 'asc') ? 'asc' : 'desc';
        $filterText = $request->query->has('filterText') ? $request->query->get('filterText') : null;
        $filterByStatus = $request->query->has('filterByStatus') ? $request->query->get('filterByStatus') : '';

        // setup joins
        $joins = array();

        // get sorting columns
        $iSortCol_0 = (int) $request->query->get('iSortCol_0');
        $sColumns = trim($request->query->get('sColumns'));
        $arrCols = explode(",", $sColumns);
        $sortColumnName = $arrCols[$iSortCol_0];
        $sort = 'date_added';
        switch ($sortColumnName) {
            case 'date_added':
                $sort = 'plugin_mediaconverter_queue.date_added';
                break;
            case 'status':
                $sort = 'plugin_mediaconverter_queue.status';
                break;
            case 'date_started':
                $sort = 'plugin_mediaconverter_queue.date_started';
                break;
        }

        $sqlClause = 'WHERE 1=1';
        if ($filterText) {
            $sqlClause .= " AND file.originalFilename = " . $db->quote($filterText);
        }

        if ($filterByStatus) {
            $sqlClause .= " AND plugin_mediaconverter_queue.status = " . $db->quote($filterByStatus);
        }

        $totalRS = $db->getValue("SELECT COUNT(plugin_mediaconverter_queue.id) AS total "
                . "FROM plugin_mediaconverter_queue "
                . "LEFT JOIN file ON plugin_mediaconverter_queue.file_id = file.id "
                . $sqlClause);
        $limitedRS = $db->getRows("SELECT plugin_mediaconverter_queue.*, "
                . "file.originalFilename, shortUrl "
                . "FROM plugin_mediaconverter_queue "
                . "LEFT JOIN file ON plugin_mediaconverter_queue.file_id = file.id "
                . $sqlClause . " "
                . "ORDER BY " . $sort . " " . $db->escape($sSortDir_0) . " "
                . "LIMIT " . $iDisplayStart . ", " . $iDisplayLength);

        $data = array();
        if (count($limitedRS) > 0) {
            foreach ($limitedRS AS $converterItem) {
                $lRow = array();
                $lRow[] = '<img src="' . PLUGIN_WEB_ROOT . '/mediaconverter/assets/img/icons/16px.png" width="16" height="16" title="queue item" alt="queue item"/>';
                $lRow[] = CoreHelper::formatDate($converterItem['date_added'], SITE_CONFIG_DATE_TIME_FORMAT);
                $lRow[] = strlen($converterItem['originalFilename']) ? ('<a href="' . ADMIN_WEB_ROOT . '/file_manage?filterText=' . urlencode($converterItem['shortUrl']) . '">' . $converterItem['originalFilename'] . '</a>') : '<span style="color: #cccccc;">[not found]</span>';
                $icon = 'accept';
                if ($converterItem['capture_video'] == 0) {
                    $icon = 'delete';
                }
                $lRow[] = '<img src="' . CORE_ASSETS_ADMIN_WEB_ROOT . '/images/icons/system/16x16/' . $icon . '.png"/>';
                $icon = 'accept';
                if ($converterItem['capture_screen'] == 0) {
                    $icon = 'delete';
                }
                $lRow[] = '<img src="' . CORE_ASSETS_ADMIN_WEB_ROOT . '/images/icons/system/16x16/' . $icon . '.png"/>';
                $lRow[] = ucwords(str_replace("_", " ", $converterItem['status']));
                $lRow[] = CoreHelper::formatDate($converterItem['date_started'], SITE_CONFIG_DATE_TIME_FORMAT);

                $links = array();
                if ($converterItem['status'] == 'pending') {
                    $links[] = '<a href="conversion_manage?cancel=' . $converterItem['id'] . '" onClick="return confirm(\'Are you sure you want to cancel this conversion?\');">cancel</a>';
                }
                if ($converterItem['status'] == 'processing') {
                    $links[] = '<a href="conversion_manage?redo=' . $converterItem['id'] . '" onClick="return confirm(\'Are you sure you want to reset this conversion?\');">reset</a>';
                }
                if (($converterItem['status'] == 'completed') || ($converterItem['status'] == 'failed')) {
                    $links[] = '<a href="conversion_manage?redo=' . $converterItem['id'] . '" onClick="return confirm(\'Are you sure you want to redo this conversion?\');">set pending</a>';
                }
                if (strlen($converterItem['notes'])) {
                    $links[] = '<a href="#" onClick="' . htmlspecialchars('alert(' . json_encode($converterItem['notes']) . ');') . ' return false;">notes</a>';
                }
                $lRow[] = implode(" | ", $links);

                $data[] = $lRow;
            }
        }

        $resultArr = array();
        $resultArr["sEcho"] = intval($request->query->get('sEcho'));
        $resultArr["iTotalRecords"] = (int) $totalRS;
        $resultArr["iTotalDisplayRecords"] = $resultArr["iTotalRecords"];
        $resultArr["aaData"] = $data;

        // output response
        return $this->renderJson($resultArr);
    }

}
