<?php

namespace Plugins\Mediaconverter\Controllers;

use App\Core\BaseController;
use App\Core\Database;
use App\Helpers\CacheHelper;
use App\Helpers\CoreHelper;
use App\Helpers\FileHelper;
use App\Helpers\FileFolderHelper;
use App\Helpers\PluginHelper;
use App\Helpers\NotificationHelper;
use App\Helpers\TranslateHelper;
use App\Helpers\ValidationHelper;
use App\Models\File;
use App\Models\User;
use Plugins\Mediaconverter\Models\PluginMediaconverterQueue;

class MediaconverterController extends BaseController
{

    /**
     * This function gets hit when the cached version of the resized
     * image does not exist. It simply redirects to the PHP script which generates
     * it
     * 
     * @return type
     */
    public function resizeThumb($fileId, $width, $height, $method, $pluginSettingsHash, $extension) {
        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('mediaconverter');
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);

        // validation
        if (($method != 'padded') && ($method != 'middle')) {
            $method = 'cropped';
        }

        // validate width & height
        if (($width == 0) || ($height == 0)) {
            return $this->outputVideoFileIcon();
        }

        // memory saver
        if (($width > 5000) || ($height > 5000)) {
            return $this->outputVideoFileIcon();
        }

        // try to load the file object
        $file = null;
        if ($fileId) {
            $file = File::loadOneById($fileId);
        }

        // load file details
        if (!$file) {
            // no file found
            return $this->outputVideoFileIcon();
        }

        // if this is a child file, override with the parent
        if ((int) $file->linkedFileId) {
            $file = File::loadOneById((int) $file->linkedFileId);
        }

        // cache paths
        $cacheFolderPath = 'plugins/mediaconverter/' . (int) $file->id . '/';
        $cacheFileName = (int) $width . 'x' . (int) $height . '_' . $method . '_' . md5(json_encode($pluginSettings)) . '.jpg';
        $fullCachePath = $cacheFolderPath . $cacheFileName;

        // check for cache
        if (!CacheHelper::checkCacheFileExists($fullCachePath)) {
            // check for original image
            $originalImagePath = CACHE_DIRECTORY_ROOT . '/plugins/mediaconverter/' . (int) $file->id . '/original_thumb.jpg';
            if (!file_exists($originalImagePath)) {
                return $this->outputVideoFileIcon();
            }

            // load image 
            require_once(CORE_FRAMEWORK_LIBRARIES_ROOT . '/image_resizer/CustomSimpleImage.php');
            $img = new \CustomSimpleImage();
            $rs = $img->load_from_image_content(file_get_contents($originalImagePath));
            if (!$rs) {
                // failed reading image
                if (($width > 160) || ($height > 160)) {
                    return $this->outputVideoFileIconLarge();
                }
                else {
                    return $this->outputVideoFileIcon();
                }
            }

            if ($method == 'middle') {
                $img->thumbnail($width, $height);
            }
            elseif ($method == 'padded') {
                $img->padded_image($width, $height);
            }
            elseif ($method == 'cropped') {
                $img->best_fit($width, $height);
            }
            else {
                $img->resize($width, $height);
            }

            // save image
            ob_start();
            $img->output($extension, 90);
            $imageContent = ob_get_clean();
            $rs = CacheHelper::saveCacheToFile($fullCachePath, $imageContent);

            if (!$rs) {
                // failed saving cache (or caching disabled), just output icon
                return $this->outputVideoFileIcon();
            }
        }

        return $this->renderFileContent(CacheHelper::getCacheFromFile($fullCachePath), array(
                    'Content-Type' => 'image/jpeg',
        ));
    }

    private function outputVideoFileIcon() {
        $url = FileHelper::getIconPreviewImageUrlLarge(array('extension' => 'mp4'), false, false);

        return $this->renderFileContent(file_get_contents($url), array(
                    'Content-Type' => 'image/jpeg',
        ));
    }

    private function outputVideoFileIconLarge() {
        $url = FileHelper::getIconPreviewImageUrl(array('extension' => 'mp4'), false, 512);

        return $this->renderFileContent(file_get_contents($url), array(
                    'Content-Type' => 'image/jpeg',
        ));
    }

}
