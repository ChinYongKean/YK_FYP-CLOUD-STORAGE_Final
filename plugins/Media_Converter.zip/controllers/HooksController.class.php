<?php

namespace Plugins\Mediaconverter\Controllers;

use App\Core\BaseController;
use App\Core\Database;
use App\Helpers\PluginHelper;
use App\Helpers\TranslateHelper;
use App\Model\File;

class HooksController extends BaseController
{

    public function adminPluginNav($params = null) {
        // output within the admin left-hand navigation
        $navigation = array(
            array('link_url' => '#', 'link_text' => 'Media Converter', 'link_key' => 'mediaconverter', 'icon_class' => 'fa fa-film', 'children' => array(
                    array('link_url' => 'admin/conversion_manage', 'link_text' => 'View Queue', 'link_key' => 'mediaconverter_conversion_manage'),
                    array('link_url' => 'admin/plugin/mediaconverter/settings', 'link_text' => 'Plugin Settings', 'link_key' => 'mediaconverter_plugin_settings'),
                )),
        );

        // return array
        return $navigation;
    }

    public function fileRemoveFile($params = null) {
        /*
         * available params
         * 
         * $params['actioned'];
         * $params['filePath'];
         * $params['storageType'];
         * $params['storageLocation'];
         * $params['file'];
         * */

        // check this is a video
        $file = $params['file'];
        if (in_array(strtolower($file->extension), array('mp4', 'flv', 'webm', 'avi', 'divx', 'mkv', 'ogg', 'ogv', 'm4v', 'mp3', 'wav', 'm4a', 'wmv'))) {
            // database
            $db = Database::getDatabase();

            // cancel any pending records from the converter queue
            $db->query('UPDATE plugin_mediaconverter_queue '
                    . 'SET status = "cancelled", '
                    . 'notes="Cancelled due to file removal." '
                    . 'WHERE file_id = :file_id', array(
                'file_id' => (int) $file->id,
            ));

            // load plugin details
            $pluginObj = PluginHelper::getInstance('mediaconverter');

            // queue any screenshot cache for delete
            $pluginObj->deleteMediaCache($file->id);
        }

        // return false so other plugin hooks will be called, if set
        return false;
    }

    public function uploaderSuccess($params = null) {
        /*
         * available params
         * 
         * $params['file'];
         * $params['tmpFile'];
         * */

        // check this is a video
        if (isset($params['file'])) {
            $file = $params['file'];
            $pluginConfig = PluginHelper::pluginSpecificConfiguration('mediaconverter');
            $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);

            // check file type
            $fileTypes = explode(",", strtolower($pluginSettings['convert_files']));
            if (in_array(strtolower($file->extension), $fileTypes)) {
                // inital params
                $convertVideo = true;
                $captureScreen = true;
                if ((int) $pluginSettings['convert_videos'] == 0) {
                    $convertVideo = false;
                }

                $pluginObj = PluginHelper::getInstance('mediaconverter');
                $pluginObj->scheduleForConverting($file, $convertVideo, $captureScreen);
            }
        }

        // return false so other plugin hooks will be called, if set
        return false;
    }

    public function filePreviewPageNotice($params = null) {
        /*
         * available params
         * 
         * $params['file'];
         * */
        $db = Database::getDatabase();

        // see if the file has a pending conversion
        $queueState = $db->getValue('SELECT status '
                . 'FROM plugin_mediaconverter_queue '
                . 'WHERE file_id = :file_id '
                . 'LIMIT 1', array(
            'file_id' => $params['file']->id,
        ));
        $message = null;
        if ($queueState === 'pending') {
            $message = TranslateHelper::t('media_converter_item_pending', 'This video is awaiting conversion, please check back again later.');
        }
        elseif ($queueState === 'processing') {
            $message = TranslateHelper::t('media_converter_item_processing', 'This video is in the process of being converted, please check back again soon.');
        }

        if ($message !== null) {
            return array(
                'alert_message' => $message,
            );
        }

        // fallback
        return false;
    }

    public function fileIconPreviewImageUrl($params = null) {

        // check this is a video
        if (in_array(strtolower($params['fileArr']['extension']), array('mp4', 'flv', 'webm'))) {
            $pluginObj = PluginHelper::getInstance('mediaconverter');
            $pluginDetails = PluginHelper::pluginSpecificConfiguration('mediaconverter');
            $pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);
            
            // only for active files
            if ($params['fileArr']['status'] == 'active') {
                $w = 99;
                if((int)$params['width'])
                {
                    $w = (int)$params['width'];
                }

                $h = 60;
                if((int)$params['height'])
                {
                    $h = (int)$params['height'];
                }

                $m = 'middle';
                if (isset($params['type'])) {
                    $m = trim($params['type']);
                }
                
                // override method with larger images
                if($w > 200) {
                    $m = 'croppped';
                }

                $params['iconUrl'] = $pluginObj->createThumbCacheUrl($params['fileArr'], $w, $h, $m);

                return $params;
            }
        }

        return false;
    }
}
