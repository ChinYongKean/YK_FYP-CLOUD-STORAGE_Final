ALTER TABLE `plugin_mediaconverter_queue` ADD `convert_host` VARCHAR(100) NULL AFTER `status`, ADD INDEX (`convert_host`);
