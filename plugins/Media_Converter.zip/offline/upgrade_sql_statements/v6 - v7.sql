UPDATE language_key SET languageKey = 'media_converter_item_processing' WHERE languageKey = 'media_converter_item_pricessing';
