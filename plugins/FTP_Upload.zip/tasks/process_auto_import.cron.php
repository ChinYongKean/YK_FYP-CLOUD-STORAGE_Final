<?php

/*
 * Title: FTP Auto Import Script
 * Author: YetiShare.com
 * Period: Run by cron every minute or as required.
 * 
 * Description:
 * Script to iterate over every FTP account and check for pending files. It will
 * monitor for changes in the files, if found it assumes these are still uploading,
 * otherwise the file is imported.
 * 
 * How To Call:
 * On the command line via PHP, like this:
 * php process_auto_import.cron.php
 * 
 * Requirements:
 * - PHP 7.0+.
 * - MySQL PDO module enabled in PHP.
 * - FTP module enabled in PHP.
 * - MySQL connectivity to main site database.
 */

namespace Plugins\Ftpupload\Tasks;

// include framework
use App\Core\Database;
use App\Core\Framework;
use App\Helpers\BackgroundTaskHelper;
use App\Helpers\CoreHelper;
use App\Helpers\PluginHelper;
use App\Helpers\UserHelper;
use App\Models\BackgroundTask;
use App\Models\User;

require_once(realpath(dirname(__FILE__) . '/../../../app/core/Framework.class.php'));

// setup light environment
Framework::runLight();

// get database
$db = Database::getDatabase();

// core constants - these aren't loaded by default as the runLight() call above doesn't do it
define('SITE_IMAGE_PATH', SITE_THEME_WEB_ROOT.SITE_CONFIG_SITE_THEME.'/assets/images');

// make sure the task isn't already running
$backgroundTask = BackgroundTask::loadOne('task', 'process_auto_import.cron.php');
if($backgroundTask) {
	if($backgroundTask->status == 'running') {
		// if task was last updated 2 hours ago, set to finished
		if (strtotime('-2 hours') > strtotime($backgroundTask->last_update)) {
			$backgroundTask->last_update = CoreHelper::sqlDateTime();
			$backgroundTask->status = 'finished';
			$backgroundTask->save();
		}
		else {
			// exit
			die('Task already running under another process, exiting.');
		}
	}
}

// background task logging
BackgroundTaskHelper::start();

// load plugin details
$pluginObj = PluginHelper::getInstance('ftpupload');
$pluginConfig = PluginHelper::pluginSpecificConfiguration('ftpupload');
$pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);

// prep the ftp host
$ftpHost = strlen($pluginSettings['ftp_host_override']) ? $pluginSettings['ftp_host_override'] : $pluginSettings['connection_cpanel_host'];

// track when the script started, we only want it to run for 90 seconds so there's no overlaps
$startTime = time();

// get a list of all FTP accounts, only do 20 at a time
$ftpAccounts = $db->getRows('SELECT * '
        . 'FROM plugin_ftp_account '
        . 'ORDER BY last_import_check '
        . 'ASC LIMIT 100');

if ($ftpAccounts) {
    foreach ($ftpAccounts AS $ftpAccount) {
        // exist if we've reached 50 seconds running time
        if ((time() - $startTime) > 50) {
            die('Reached max running time of script.');
        }

        // connect via ftp
        $connId = ftp_connect($ftpHost, 21, 10);
        if ($connId === false) {
            // failed connecting
            $db->query("UPDATE plugin_ftp_account "
                    . "SET last_import_check=NOW(), "
                    . "last_import_check_notes='FTP ERROR: Failed connecting to " . $ftpHost . " via FTP.' "
                    . "WHERE id = :id "
                    . "LIMIT 1", array(
                'id' => (int) $ftpAccount['id'],
            ));
            continue;
        }

        // get the connection details
        $ftpUser = $ftpAccount['ftp_user'];
        if ((isset($pluginSettings['append_username'])) && (strlen($pluginSettings['append_username']))) {
            $ftpUser .= '@' . $pluginSettings['append_username'];
        }

		echo "Doing ".$ftpUser."...\n";
        $ftpPassword = $ftpAccount['ftp_password'];
        $ftpPath = $ftpAccount['ftp_path'];

        // authenticate
        $login_result = ftp_login($connId, $ftpUser, $ftpPassword);
        if ($login_result === false) {
            // failed connecting
            $db->query("UPDATE plugin_ftp_account "
                    . "SET last_import_check=NOW(), "
                    . "last_import_check_notes='Error connecting or authenticating account.' "
                    . "WHERE id = :id "
                    . "LIMIT 1", array(
                'id' => (int) $ftpAccount['id'],
            ));
			
			// close ftp connection
			ftp_close($connId);
			
            continue;
        }
		
		echo "Logged in.\n";
        
        // passive mode
        if((int)$pluginSettings['connection_use_passive_mode'] === 1) {
            ftp_pasv($connId, true);
			
			echo "Set passive mode.\n";
        }

        // check for files
        $fileListing = ftp_nlist($connId, '.');
		
		echo "Got directory listing.\n";

        // load user
        $user = User::loadOneById($ftpAccount['user_id']);
        if (!$user) {
            // failed loading user
            $db->query("UPDATE plugin_ftp_account "
                    . "SET last_import_check=NOW(), "
                    . "last_import_check_notes='Error loading the associated user account.' "
                    . "WHERE id = :id "
                    . "LIMIT 1", array(
                'id' => (int) $ftpAccount['id'],
            ));
            continue;
        }

        // get accepted file types
        $acceptedFileTypes = UserHelper::getAcceptedFileTypes($user->level_id);
        $acceptedFileTypesRegex = '/(\.|\/)(' . str_replace(".", "", implode("|", $acceptedFileTypes)) . ')$/i';

        // loop result
        $files = array();
        if (count($fileListing)) {
            foreach ($fileListing AS $fileListingItem) {
                $fileListingItem = utf8_encode($fileListingItem);
                if ((in_array($fileListingItem, $pluginObj->getIgnorePathList())) || (strpos($fileListingItem, '.', 1) === false)) {
                    continue;
                }

                if (count($acceptedFileTypes)) {
                    if (!preg_match($acceptedFileTypesRegex, $fileListingItem)) {
                        $blockedFiles[] = $fileListingItem;
                        continue;
                    }
                }

                $files[] = $fileListingItem;
            }
        }

        // loop files and check whether they've finished uploading
        if (count($files)) {
            foreach ($files AS $file) {
                // make sure the filesize > 0
                $remoteFilesize = (int) ftp_size($connId, utf8_decode($file));
                if ($remoteFilesize == 0) {
                    continue;
                }

                //  get the last modified time
                $buff = ftp_mdtm($connId, utf8_decode($file));
                if ($buff != -1) {
                    if ((time() - $buff) > 60) {
                        // assume this file has finished uploading since it's not
                        // been modified in the last minute
						echo "Importing file \"".$file."\"...\n";
                        echo $pluginObj->handleFileTransfer($file, $ftpAccount['user_id']);
                        echo 'Imported: ' . $file . "\n";
                    }
                }
            }
        }

        // close ftp connection
        ftp_close($connId);

        // update the account last check
        $db->query("UPDATE plugin_ftp_account "
                . "SET last_import_check=NOW(), "
                . "last_import_check_notes='' "
                . "WHERE id = :id "
                . "LIMIT 1", array(
            'id' => (int) $ftpAccount['id'],
        ));
    }
}

// background task logging
BackgroundTaskHelper::end();
