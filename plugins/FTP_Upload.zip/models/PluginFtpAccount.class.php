<?php

namespace Plugins\Ftpupload\Models;

use App\Core\Model;

class PluginFtpAccount extends Model
{
    
}
