<?php

namespace Plugins\Ftpupload;

use App\Services\PluginConfig AS CorePluginConfig;

class PluginConfig extends CorePluginConfig
{
    /**
     * Setup the plugin config.
     *
     * @var array
     */
    public $config = array(
        'plugin_name' => 'FTP Upload Support',
        'folder_name' => 'ftpupload',
        'plugin_description' => 'Enable your users to upload files using an FTP client.',
        'plugin_version' => '13.0',
        'required_script_version' => '5.0',
        'database_sql' => 'offline/database.sql',
    );

}
