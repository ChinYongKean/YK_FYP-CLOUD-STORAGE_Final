ALTER TABLE `plugin_ftp_account` ADD `last_import_check` datetime NULL;
ALTER TABLE `plugin_ftp_account` ADD `last_import_check_notes` text NULL;
