<?php

namespace Plugins\Ftpupload\Controllers;

use App\Core\BaseController;
use App\Core\Database;
use App\Helpers\CrossSiteActionHelper;
use App\Helpers\FileHelper;
use App\Helpers\PluginHelper;
use App\Helpers\TranslateHelper;

class HooksController extends BaseController
{

    public function adminPluginNav($params = null) {
        // output within the admin left-hand navigation
        $navigation = array(
            array('link_url' => '#', 'link_text' => 'FTP Upload', 'link_key' => 'ftpupload', 'icon_class' => 'fa fa-clone', 'children' => array(
                    array('link_url' => 'admin/ftp_accounts', 'link_text' => 'FTP Accounts', 'link_key' => 'ftpupload_ftp_accounts'),
                    array('link_url' => 'admin/plugin/ftpupload/settings', 'link_text' => 'Plugin Settings', 'link_key' => 'ftpupload_plugin_settings'),
                )),
        );

        // return array
        return $navigation;
    }

    public function fileManagerTab($params = null) {
        // get user
        $Auth = $this->getAuth();

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('ftpupload');
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);
        $doRedirect = true;
        if (((int) $pluginSettings['paid_only'] === 1) && ($Auth->level_id <= 1)) {
            $doRedirect = false;
        }

        $showTab = false;
        if (((int) $pluginSettings['show_ftp_tab'] === 1) || ($doRedirect == true)) {
            $showTab = true;
        }

        // exit if we're not to show the tab
        if ($showTab === false) {
            return false;
        }

        // prepare any onclick
        $onclick = '';
        if ($doRedirect === false) {
            if ($Auth->loggedIn() === true) {
                $onclick = 'window.location=\'' . WEB_ROOT . '/upgrade\';';
            }
            else {
                $onclick = 'window.location=\'' . WEB_ROOT . '/register\';';
            }
        }

        return array(
            'ftpupload' => array(
                'anchor' => 'ftpUpload',
                'icon' => 'glyphicon glyphicon-export',
                'label' => TranslateHelper::t('ftp_upload', 'ftp upload'),
                'onclick' => $onclick,
            ),
        );
    }

    public function fileManagerTabContent($params = null) {
        // get user
        $Auth = $this->getAuth();

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('ftpupload');
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);
        $doRedirect = true;
        if (((int) $pluginSettings['paid_only'] === 1) && ($Auth->level_id <= 1)) {
            $doRedirect = false;
        }

        $showTab = false;
        if (((int) $pluginSettings['show_ftp_tab'] === 1) || ($doRedirect == true)) {
            $showTab = true;
        }

        // exit if we're not to show the tab
        if ($showTab === false) {
            return false;
        }

        // load template
        return array(
            'response_html' => $this->getRenderedTemplate('file_manager_tab_content.html', array(
                'pluginConfig' => $pluginConfig,
                'doRedirect' => $doRedirect,
                'ftpUploadHandlerUrl' => CrossSiteActionHelper::appendUrl(FileHelper::getUploadUrl() . '/ajax/ftp_upload_handler'),
                    ), PLUGIN_DIRECTORY_ROOT . 'ftpupload/views')
        );
    }

    public function adminUserEdit($params = null) {
        // available params
        // User $params['user']
        
        // if they have are not active, make sure we get rid of any ftp account
        if($params['user']->status !== 'active')
        {
            $pluginObj = PluginHelper::getInstance('ftpupload');
            $pluginObj->deleteFTPAccount($params['user']->id);
        }
        
        // no need to action anything else
        return false;
    }
}
