<?php

namespace Plugins\Ftpupload\Controllers;

use App\Core\Database;
use App\Core\BaseController;
use App\Helpers\BannedIpHelper;
use App\Helpers\CoreHelper;
use App\Helpers\CrossSiteActionHelper;
use App\Helpers\PluginHelper;
use App\Helpers\UserHelper;

class FtpuploadController extends BaseController
{

    public function ajaxGetFtpAccountDetail() {
        // for later
        $request = $this->getRequest();
        $Auth = $this->getAuth();

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('ftpupload');
        $pluginObj = PluginHelper::getInstance('ftpupload');
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);

        // whether to show content or not
        $showContent = true;
        if (($pluginSettings['paid_only'] == 1) && ($Auth->level_id <= 1)) {
            $showContent = false;
        }

        if (($showContent == true) && ($Auth->loggedIn() == false || $Auth->level_id === 0)) {
            $showContent = false;
        }

        // load template
        return $this->renderJson(array(
                    'response_html' => $this->getRenderedTemplate('ajax/get_ftp_account_detail.html', array(
                        'pluginConfig' => $pluginConfig,
                        'pluginSettings' => $pluginSettings,
                        'showContent' => $showContent,
                        'pluginObj' => $pluginObj,
                        'ftpDetails' => $showContent ? $pluginObj->getFTPAccountDetails($Auth->id) : null,
                        'maxUploadSize' => (int) UserHelper::getMaxUploadFilesize(),
                        'acceptedFileTypes' => UserHelper::getAcceptedFileTypes(),
                        'ftpHost' => strlen($pluginSettings['ftp_host_override']) ? $pluginSettings['ftp_host_override'] : $pluginSettings['connection_cpanel_host'],
                            ), PLUGIN_DIRECTORY_ROOT . 'ftpupload/views'))
        );
    }

    public function ajaxGetPendingFiles() {
        // require user login
        if (($response = $this->requireLogin()) !== false) {
            return $response;
        }

        // for later
        $Auth = $this->getAuth();
        $db = Database::getDatabase();

        // load plugin details
        $pluginConfig = PluginHelper::pluginSpecificConfiguration('ftpupload');
        $pluginObj = PluginHelper::getInstance('ftpupload');
        $pluginSettings = json_decode($pluginConfig['data']['plugin_settings'], true);

        // get ftp details
        $ftpAcc = $pluginObj->getFTPAccountDetails($Auth->id);
        if ($ftpAcc['success'] == false) {
            return $this->renderContent('');
        }

        // check for pending files, connect via ftp
        $ftpHost = strlen($pluginSettings['ftp_host_override']) ? $pluginSettings['ftp_host_override'] : $pluginSettings['connection_cpanel_host'];
        $conn_id = ftp_connect($ftpHost, 21, 10);
        if ($conn_id === false) {
            return $this->renderContent("FTP ERROR: Failed connecting to " . $ftpHost . " via FTP.<br/><br/>");
        }

        // authenticate
        $username = $ftpAcc['ftp_user'];
        if ((isset($pluginSettings['append_username'])) && (strlen($pluginSettings['append_username']))) {
            $username = $ftpAcc['ftp_user'] . '@' . $pluginSettings['append_username'];
        }
        $login_result = ftp_login($conn_id, $username, $ftpAcc['ftp_password']);
        if ($login_result === false) {
            return $this->renderContent("FTP ERROR: Could not authenticate with FTP server " . $ftpHost . " with user " . $username . "<br/><br/>");
        }
        
        // passive mode
        if((int)$pluginSettings['connection_use_passive_mode'] === 1) {
            ftp_pasv($conn_id, true);
        }

        // look for any uploaded files
        $file_listing = ftp_nlist($conn_id, '.');

        // get accepted file types
        $acceptedFileTypes = UserHelper::getAcceptedFileTypes();
        $acceptedFileTypesRegex = '/(\.|\/)(' . str_replace(".", "", implode("|", $acceptedFileTypes)) . ')$/i';

        // loop result
        $files = array();
        $blockedFiles = array();
        if ($file_listing !== false) {
            foreach ($file_listing AS $file_listing_item) {
                $file_listing_item = utf8_encode($file_listing_item);
                if ((in_array($file_listing_item, $pluginObj->getIgnorePathList())) || (strpos($file_listing_item, '.', 1) === false)) {
                    continue;
                }

                if (count($acceptedFileTypes)) {
                    if (!preg_match($acceptedFileTypesRegex, $file_listing_item)) {
                        $blockedFiles[] = $file_listing_item;
                        continue;
                    }
                }

                // only allow files with extensions
                $files[] = $file_listing_item;
            }
        }

        // close ftp connection
        ftp_close($conn_id);

        // load template
        return $this->renderJson(array(
                    'response_html' => $this->getRenderedTemplate('ajax/get_pending_files.html', array(
                        'pluginConfig' => $pluginConfig,
                        'pluginSettings' => $pluginSettings,
                        'files' => $files,
                        'pluginObj' => $pluginObj,
                        'blockedFiles' => $blockedFiles,
                        'maxUploadSize' => (int) UserHelper::getMaxUploadFilesize(),
                            ), PLUGIN_DIRECTORY_ROOT . 'ftpupload/views'))
        );
    }

    public function ajaxFtpUploadHandler() {
        // to allow cross domain access
        CoreHelper::allowCrossSiteAjax();

        error_reporting(E_ALL | E_STRICT);

        // process csaKeys and authenticate user
        $request = $this->getRequest();
        $csaKey1 = trim($request->query->get('csaKey1'));
        $csaKey2 = trim($request->query->get('csaKey2'));
        if (strlen($csaKey1) && strlen($csaKey2)) {
            CrossSiteActionHelper::setAuthFromKeys($csaKey1, $csaKey2, false);
        }

        // require user login
        if (($response = $this->requireLogin()) !== false) {
            return $response;
        }

        // double check if user can upload
        if (UserHelper::getAllowedToUpload() === false) {
            return $this->renderContent(CoreHelper::createUploadError(t('unavailable', 'Unavailable.'), t('uploading_has_been_disabled', 'Uploading has been disabled.')));
        }

        // check for banned ip
        $bannedIP = BannedIpHelper::getBannedType();
        if (strtolower($bannedIP) === "uploading") {
            return $this->renderContent(CoreHelper::createUploadError(t('unavailable', 'Unavailable.'), t('uploading_has_been_disabled', 'Uploading has been disabled.')));
        }

        // check that the user has not reached their max permitted uploads
        $fileRemaining = UserHelper::getRemainingFilesToday();
        if ($fileRemaining == 0) {
            return $this->renderContent(CoreHelper::createUploadError(t('max_uploads_reached', 'Max uploads reached.'), t('reached_maximum_uploads', 'You have reached the maximum permitted uploads for today.')));
        }

        // check the user hasn't reached the maximum storage on their account
        $Auth = $this->getAuth();
        if ((UserHelper::getAvailableFileStorage($Auth->id) !== null) && UserHelper::getAvailableFileStorage($Auth->id) <= 0) {
            return $this->renderContent(CoreHelper::createUploadError(t('file_upload_space_full', 'File upload space full.'), t('file_upload_space_full_text', 'Upload storage full, please delete some active files and try again.')));
        }
        
        // get params
        $fileName = trim($request->request->get('fileName'));
        $rowId = (int)$request->request->get('rowId');
        
        // process file import
        $pluginObj = PluginHelper::getInstance('ftpupload');
        $rsJson = $pluginObj->handleFileTransfer($fileName, $Auth->id, $rowId);
        
        return $this->renderContent($rsJson);
    }

}
