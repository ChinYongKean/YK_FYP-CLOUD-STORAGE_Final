<?php

namespace Plugins\Ftpupload\Controllers\Admin;

use App\Core\Database;
use App\Controllers\Admin\PluginController AS CorePluginController;
use App\Helpers\AdminHelper;
use App\Helpers\CoreHelper;
use App\Helpers\PluginHelper;
use App\Helpers\ValidationHelper;
use App\Models\Plugin;

class PluginController extends CorePluginController
{

    public function pluginSettings() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        // load plugin details
        $folderName = 'ftpupload';
        $plugin = Plugin::loadOneByClause('folder_name = :folder_name', array(
                    'folder_name' => $folderName,
        ));

        if (!$plugin) {
            return $this->redirect(ADMIN_WEB_ROOT . '/plugin_manage?error=' . urlencode('There was a problem loading the plugin details.'));
        }

        // connection types
        $connectionTypes = array();
        $connectionTypes['cpanel'] = 'cPanel (for WHM/cPanel servers only)';
        $connectionTypes['proftpd'] = 'ProFTPD (needs some config to ProFTP, detailed below)';

        $plugin_enabled = (int) $plugin->plugin_enabled;
        $connection_type = 'cpanel';
        $connection_cpanel_host = _CONFIG_SITE_HOST_URL;
        $connection_cpanel_user = '';
        $connection_cpanel_password = '';
        $connection_use_passive_mode = 1;
        $home_dir_path = 'public_html/';
        $ftp_account_quota = 2000;
        $paid_only = 0;
        $show_ftp_tab = 0;
        $append_username = '';
        $ftp_host_override = '';

        // load existing settings
        if (strlen($plugin->plugin_settings)) {
            $plugin_settings = json_decode($plugin->plugin_settings, true);
            if ($plugin_settings) {
                $connection_type = $plugin_settings['connection_type'];
                $connection_cpanel_host = $plugin_settings['connection_cpanel_host'];
                $connection_cpanel_user = $plugin_settings['connection_cpanel_user'];
                $connection_cpanel_password = $plugin_settings['connection_cpanel_password'];
                $connection_use_passive_mode = (int)$plugin_settings['connection_use_passive_mode'];
                $home_dir_path = $plugin_settings['home_dir_path'];
                $ftp_account_quota = $plugin_settings['ftp_account_quota'];
                $paid_only = $plugin_settings['paid_only'];
                $show_ftp_tab = $plugin_settings['show_ftp_tab'];
                $append_username = $plugin_settings['append_username'];
                $ftp_host_override = $plugin_settings['ftp_host_override'];
            }
        }

        // check for php ftp functions
        $pluginObj = PluginHelper::getInstance('ftpupload');
        if ($pluginObj->ftpFunctionsExist() === false) {
            AdminHelper::setError(AdminHelper::t("plugin_ftp_php_functions_not_exist", "PHP FTP functions have not been found on the current server. Please enable via php.ini and try again."));
        }

        // handle page submissions
        if ($request->request->has('submitted')) {
            // get variables
            $plugin_enabled = (int) $request->request->get('plugin_enabled');
            $plugin_enabled = $plugin_enabled != 1 ? 0 : 1;
            $connection_type = $_REQUEST['connection_type'];
            $connection_cpanel_host = strtolower(trim($_REQUEST['connection_cpanel_host']));
            $connection_cpanel_host = str_replace(array("http://", "https://", "www."), "", $connection_cpanel_host);
            $connection_cpanel_user = trim($_REQUEST['connection_cpanel_user']);
            $connection_cpanel_password = trim($_REQUEST['connection_cpanel_password']);
            $connection_use_passive_mode = (int) $request->request->get('connection_use_passive_mode');
            $home_dir_path = trim($_REQUEST['home_dir_path']);
            if (substr($home_dir_path, strlen($home_dir_path) - 1, 1) != '/') {
                $home_dir_path = $home_dir_path . '/';
            }
            if (substr($home_dir_path, 0, 1) == '/') {
                $home_dir_path = substr($home_dir_path, 1, strlen($home_dir_path) - 1);
            }
            $home_dir_path = '/' . $home_dir_path;
            $ftp_account_quota = (int) trim($_REQUEST['ftp_account_quota']);
            $paid_only = isset($_REQUEST['paid_only']) ? (int) $_REQUEST['paid_only'] : 0;
            $show_ftp_tab = isset($_REQUEST['show_ftp_tab']) ? (int) $_REQUEST['show_ftp_tab'] : 0;
            $append_username = trim($_REQUEST['append_username']);
            $ftp_host_override = trim($_REQUEST['ftp_host_override']);

            // validate submission
            if (_CONFIG_DEMO_MODE == true) {
                AdminHelper::setError(AdminHelper::t("no_changes_in_demo_mode"));
            }

            // test ftp path
            if (strlen($home_dir_path) == 0) {
                AdminHelper::setError(AdminHelper::t("set_the_ftp_path", "Please set the path to store ftp accounts."));
            }

            // update the settings
            if (AdminHelper::isErrors() == false) {
                // compile new settings
                $settingsArr = array();
                $settingsArr['connection_type'] = $connection_type;
                $settingsArr['connection_cpanel_host'] = $connection_cpanel_host;
                $settingsArr['connection_cpanel_user'] = $connection_cpanel_user;
                $settingsArr['connection_cpanel_password'] = $connection_cpanel_password;
                $settingsArr['connection_use_passive_mode'] = $connection_use_passive_mode;
                $settingsArr['home_dir_path'] = $home_dir_path;
                $settingsArr['paid_only'] = $paid_only;
                $settingsArr['ftp_account_quota'] = $ftp_account_quota;
                $settingsArr['show_ftp_tab'] = $show_ftp_tab;
                $settingsArr['append_username'] = $append_username;
                $settingsArr['ftp_host_override'] = $ftp_host_override;

                // update the plugin settings
                $plugin->plugin_enabled = $plugin_enabled;
                $plugin->plugin_settings = json_encode($settingsArr);
                $plugin->save();

                // reload plugin cache
                PluginHelper::loadPluginConfigurationFiles(true);

                // set onscreen alert
                AdminHelper::setSuccess('Plugin settings updated.');
            }
        }

        if (_CONFIG_DEMO_MODE == true) {
            $connection_cpanel_password = '****************';
        }

        // load template
        return $this->render('admin/plugin_settings.html', array(
                    'pluginName' => $plugin->plugin_name,
                    'yesNoOptions' => array(
                        0 => 'No',
                        1 => 'Yes'),
                    'connectionTypes' => $connectionTypes,
                    'plugin_enabled' => $plugin_enabled,
                    'connection_type' => $connection_type,
                    'connection_cpanel_host' => $connection_cpanel_host,
                    'connection_cpanel_user' => $connection_cpanel_user,
                    'connection_cpanel_password' => $connection_cpanel_password,
                    'connection_use_passive_mode' => $connection_use_passive_mode,
                    'home_dir_path' => $home_dir_path,
                    'paid_only' => $paid_only,
                    'ftp_account_quota' => $ftp_account_quota,
                    'show_ftp_tab' => $show_ftp_tab,
                    'append_username' => $append_username,
                    'ftp_host_override' => $ftp_host_override,
                        ), PLUGIN_DIRECTORY_ROOT . $folderName . '/views');
    }

    public function ftpAccounts() {
        // admin restrictions
        $this->restrictAdminAccess();

        // for later
        $db = Database::getDatabase();
        $request = $this->getRequest();
        $pluginObj = PluginHelper::getInstance('ftpupload');
        $ftpuploadSettings = $pluginObj->settings;

        // process submits
        if ($request->query->has('user_id')) {
            $pluginObj->deleteFTPAccount((int) $_REQUEST['user_id']);
            AdminHelper::setSuccess('FTP account deleted.');
        }

        // load all users
        $userDetails = $db->getRows("SELECT id, username AS selectValue "
                . "FROM users "
                . "ORDER BY username");

        $filterByUser = null;
        if ($request->request->has('filterByUser')) {
            $filterByUser = (int) $request->request->get('filterByUser');
        }

        // load template
        return $this->render('admin/ftp_accounts.html', array(
                    'pluginObj' => $pluginObj,
                    'userDetails' => $userDetails,
                    'filterByUser' => $filterByUser,
                        ), PLUGIN_DIRECTORY_ROOT . 'ftpupload/views');
    }

    public function ajaxFtpAccounts() {
        // admin restrictions
        $this->restrictAdminAccess();

        // pickup request
        $db = Database::getDatabase();
        $request = $this->getRequest();

        $iDisplayLength = (int) $request->query->get('iDisplayLength');
        $iDisplayStart = (int) $request->query->get('iDisplayStart');
        $sSortDir_0 = ($request->query->has('sSortDir_0') && $request->query->get('sSortDir_0') === 'asc') ? 'asc' : 'desc';
        $filterByUser = $request->query->has('filterByUser') ? $request->query->get('filterByUser') : false;

        // setup joins
        $joins = array();

        // get sorting columns
        $iSortCol_0 = (int) $request->query->get('iSortCol_0');
        $sColumns = trim($request->query->get('sColumns'));
        $arrCols = explode(",", $sColumns);
        $sortColumnName = $arrCols[$iSortCol_0];
        $sort = 'requested_date';
        switch ($sortColumnName) {
            case 'date_created':
                $sort = 'date_created';
                break;
            case 'owner':
                $sort = 'users.username';
                break;
            case 'ftp_username':
                $sort = 'ftp_user';
                break;
            case 'ftp_password':
                $sort = 'ftp_password';
                break;
            case 'ftp_path':
                $sort = 'ftp_path';
                break;
        }

        $sqlClause = "WHERE 1=1 ";
        if ($filterByUser) {
            $sqlClause .= " AND user_id = " . (int) $filterByUser;
        }

        $totalRS = $db->getValue("SELECT COUNT(plugin_ftp_account.id) AS total "
                . "FROM plugin_ftp_account "
                . "LEFT JOIN users ON plugin_ftp_account.user_id = users.id "
                . $sqlClause);
        $limitedRS = $db->getRows("SELECT plugin_ftp_account.*, users.username "
                . "FROM plugin_ftp_account "
                . "LEFT JOIN users ON plugin_ftp_account.user_id = users.id "
                . $sqlClause . " "
                . "ORDER BY " . $sort . " " . $db->escape($sSortDir_0) . " "
                . "LIMIT " . $iDisplayStart . ", " . $iDisplayLength);

        $data = array();
        if (count($limitedRS) > 0) {
            foreach ($limitedRS AS $ftpAccount) {
                $lRow = array();
                $lRow[] = '<img src="' . PLUGIN_WEB_ROOT . '/ftpupload/assets/img/icons/16px.png" width="16" height="16" title="request" alt="ftp account"/>';
                $lRow[] = CoreHelper::formatDate($ftpAccount['date_created'], SITE_CONFIG_DATE_TIME_FORMAT);
                $lRow[] = '<a href="' . ADMIN_WEB_ROOT . '/user_edit/' . $ftpAccount['user_id'] . '">' . ValidationHelper::safeOutputToScreen($ftpAccount['username']) . '</a>';

                $ftpUser = $ftpAccount['ftp_user'];
                if ((isset($pluginSettings['append_username'])) && (strlen($pluginSettings['append_username']))) {
                    $ftpUser .= '@' . $pluginSettings['append_username'];
                }
                $lRow[] = ValidationHelper::safeOutputToScreen($ftpUser);
                $lRow[] = ValidationHelper::safeOutputToScreen($ftpAccount['ftp_password']);
                $lRow[] = ValidationHelper::safeOutputToScreen($ftpAccount['ftp_path']);

                $links = array();
                $links[] = '<a href="' . ADMIN_WEB_ROOT . '/ftp_accounts?user_id=' . (int) $ftpAccount['user_id'] . '" onClick="return confirm(\'Are you sure you to remove this ftp account?\');">remove</a>';
                $lRow[] = implode(" | ", $links);

                $data[] = $lRow;
            }
        }

        $resultArr = array();
        $resultArr["sEcho"] = intval($request->query->get('sEcho'));
        $resultArr["iTotalRecords"] = (int) $totalRS;
        $resultArr["iTotalDisplayRecords"] = $resultArr["iTotalRecords"];
        $resultArr["aaData"] = $data;

        // output response
        return $this->renderJson($resultArr);
    }

}
